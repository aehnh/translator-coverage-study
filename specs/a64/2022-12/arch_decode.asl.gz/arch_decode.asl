__decode A64
    // A64
    case (31 +: 1, 29 +: 2, 25 +: 4, 0 +: 25) of
        when ('0', _, '0000', _) =>
            // reserved
            case (31 +: 1, 29 +: 2, 25 +: 4, 16 +: 9, 0 +: 16) of
                when (_, '00', _, '000000000', _) => // perm_undef
                    __field imm16 0 +: 16
                    case () of
                        when () => __encoding aarch64_udf // UDF_only_perm_undef
                when (_, _, _, !'000000000', _) => __UNPREDICTABLE
                when (_, !'00', _, _, _) => __UNPREDICTABLE
        when ('1', _, '0000', _) =>
            // sme
            case (31 +: 1, 29 +: 2, 25 +: 4, 10 +: 15, 5 +: 5, 2 +: 3, 0 +: 2) of
                when (_, '0x', _, 'x11xxxxxxxxxxxx', _, 'x0x', _) =>
                    // mortlach_64bit_prod
                    case (30 +: 2, 29 +: 1, 25 +: 4, 24 +: 1, 22 +: 2, 21 +: 1, 4 +: 17, 3 +: 1, 0 +: 3) of
                        when (_, '0', _, '0', _, '0', _, _, _) => // mortlach_f64f64_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMOPA_ZA_PP_ZZ_64 // fmopa_za_pp_zz_64
                                when ('1') => __encoding FMOPS_ZA_PP_ZZ_64 // fmops_za_pp_zz_64
                        when (_, '0', _, '0', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _) => // mortlach_i16i64_prod
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 3
                            case (u0, u1, S) of
                                when ('0', '0', '0') => __encoding SMOPA_ZA_PP_ZZ_64 // smopa_za_pp_zz_64
                                when ('0', '0', '1') => __encoding SMOPS_ZA_PP_ZZ_64 // smops_za_pp_zz_64
                                when ('0', '1', '0') => __encoding SUMOPA_ZA_PP_ZZ_64 // sumopa_za_pp_zz_64
                                when ('0', '1', '1') => __encoding SUMOPS_ZA_PP_ZZ_64 // sumops_za_pp_zz_64
                                when ('1', '0', '0') => __encoding USMOPA_ZA_PP_ZZ_64 // usmopa_za_pp_zz_64
                                when ('1', '0', '1') => __encoding USMOPS_ZA_PP_ZZ_64 // usmops_za_pp_zz_64
                                when ('1', '1', '0') => __encoding UMOPA_ZA_PP_ZZ_64 // umopa_za_pp_zz_64
                                when ('1', '1', '1') => __encoding UMOPS_ZA_PP_ZZ_64 // umops_za_pp_zz_64
                when (_, '0x', _, 'x11xxxxxxxxxxxx', _, 'x1x', _) => __UNPREDICTABLE
                when (_, '00', _, 'x0xxxxxxxxxxxxx', _, _, _) => __UNPREDICTABLE
                when (_, '00', _, 'x10xxxxxxxxxxxx', _, 'x00', _) =>
                    // mortlach_32bit_fp_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 4 +: 17, 2 +: 2, 0 +: 2) of
                        when (_, '0', _, '0', _, _, _) => // mortlach_f32f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding FMOPA_ZA_PP_ZZ_32 // fmopa_za_pp_zz_32
                                when ('1') => __encoding FMOPS_ZA_PP_ZZ_32 // fmops_za_pp_zz_32
                        when (_, '1', _, '0', _, _, _) => // mortlach_b16f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding BFMOPA_ZA32_PP_ZZ__ // bfmopa_za32_pp_zz_
                                when ('1') => __encoding BFMOPS_ZA32_PP_ZZ__ // bfmops_za32_pp_zz_
                        when (_, '1', _, '1', _, _, _) => // mortlach_f16f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding FMOPA_ZA32_PP_ZZ_16 // fmopa_za32_pp_zz_16
                                when ('1') => __encoding FMOPS_ZA32_PP_ZZ_16 // fmops_za32_pp_zz_16
                when (_, '00', _, '010xxxxxxxxxxxx', _, 'xx1', _) => __UNPREDICTABLE
                when (_, '00', _, '010xxxxxxxxxxxx', _, 'x10', _) =>
                    // mortlach_32bit_bin_prod
                    case (22 +: 10, 21 +: 1, 4 +: 17, 2 +: 2, 0 +: 2) of
                        when (_, '0', _, _, _) => // mortlach_bini32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding BMOPA_ZA_PP_ZZ_32 // bmopa_za_pp_zz_32
                                when ('1') => __encoding BMOPS_ZA_PP_ZZ_32 // bmops_za_pp_zz_32
                        when (_, '1', _, _, _) => __UNPREDICTABLE
                when (_, '00', _, '110xxxxxxxxxxxx', _, 'x01', _) => __UNPREDICTABLE
                when (_, '00', _, '110xxxxxxxxxxxx', _, 'x1x', _) =>
                    // mortlach_16bit_fp_prod
                    case (22 +: 10, 21 +: 1, 4 +: 17, 3 +: 1, 1 +: 2, 0 +: 1) of
                        when (_, '0', _, _, '00', _) => // mortlach_f16f16_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 1
                            case (S) of
                                when ('0') => __encoding FMOPA_ZA_PP_ZZ_16 // fmopa_za_pp_zz_16
                                when ('1') => __encoding FMOPS_ZA_PP_ZZ_16 // fmops_za_pp_zz_16
                        when (_, '1', _, _, '00', _) => // mortlach_b16b16_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 1
                            case (S) of
                                when ('0') => __encoding BFMOPA_ZA_PP_ZZ_16 // bfmopa_za_pp_zz_16
                                when ('1') => __encoding BFMOPS_ZA_PP_ZZ_16 // bfmops_za_pp_zz_16
                        when (_, _, _, _, 'x1', _) => __UNPREDICTABLE
                when (_, '01', _, 'x10xxxxxxxxxxxx', _, 'xx0', _) =>
                    // mortlach_32bit_int_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 4 +: 17, 3 +: 1, 2 +: 1, 0 +: 2) of
                        when (_, _, _, '0', _, '1', _, _) => // mortlach_i16i32_prod
                            __field u0 24 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (u0, S) of
                                when ('0', '0') => __encoding SMOPA_ZA32_PP_ZZ_16 // smopa_za32_pp_zz_16
                                when ('0', '1') => __encoding SMOPS_ZA32_PP_ZZ_16 // smops_za32_pp_zz_16
                                when ('1', '0') => __encoding UMOPA_ZA32_PP_ZZ_16 // umopa_za32_pp_zz_16
                                when ('1', '1') => __encoding UMOPS_ZA32_PP_ZZ_16 // umops_za32_pp_zz_16
                        when (_, _, _, '1', _, '1', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', _, _) => // mortlach_i8i32_prod
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (u0, u1, S) of
                                when ('0', '0', '0') => __encoding SMOPA_ZA_PP_ZZ_32 // smopa_za_pp_zz_32
                                when ('0', '0', '1') => __encoding SMOPS_ZA_PP_ZZ_32 // smops_za_pp_zz_32
                                when ('0', '1', '0') => __encoding SUMOPA_ZA_PP_ZZ_32 // sumopa_za_pp_zz_32
                                when ('0', '1', '1') => __encoding SUMOPS_ZA_PP_ZZ_32 // sumops_za_pp_zz_32
                                when ('1', '0', '0') => __encoding USMOPA_ZA_PP_ZZ_32 // usmopa_za_pp_zz_32
                                when ('1', '0', '1') => __encoding USMOPS_ZA_PP_ZZ_32 // usmops_za_pp_zz_32
                                when ('1', '1', '0') => __encoding UMOPA_ZA_PP_ZZ_32 // umopa_za_pp_zz_32
                                when ('1', '1', '1') => __encoding UMOPS_ZA_PP_ZZ_32 // umops_za_pp_zz_32
                when (_, '01', _, 'x10xxxxxxxxxxxx', _, 'xx1', _) => __UNPREDICTABLE
                when (_, '01', _, '00xxxxxxxxxxxxx', _, _, _) =>
                    // mortlach_multi_mem_ctg
                    case (23 +: 9, 20 +: 3, 16 +: 4, 15 +: 1, 2 +: 13, 1 +: 1, 0 +: 1) of
                        when (_, '00x', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZ_P_BR_2 // ld1b_mz_p_br_2
                                when ('00', '1') => __encoding LDNT1B_MZ_P_BR_2 // ldnt1b_mz_p_br_2
                                when ('01', '0') => __encoding LD1H_MZ_P_BR_2 // ld1h_mz_p_br_2
                                when ('01', '1') => __encoding LDNT1H_MZ_P_BR_2 // ldnt1h_mz_p_br_2
                                when ('10', '0') => __encoding LD1W_MZ_P_BR_2 // ld1w_mz_p_br_2
                                when ('10', '1') => __encoding LDNT1W_MZ_P_BR_2 // ldnt1w_mz_p_br_2
                                when ('11', '0') => __encoding LD1D_MZ_P_BR_2 // ld1d_mz_p_br_2
                                when ('11', '1') => __encoding LDNT1D_MZ_P_BR_2 // ldnt1d_mz_p_br_2
                        when (_, '00x', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZ_P_BR_4 // ld1b_mz_p_br_4
                                when ('00', '1') => __encoding LDNT1B_MZ_P_BR_4 // ldnt1b_mz_p_br_4
                                when ('01', '0') => __encoding LD1H_MZ_P_BR_4 // ld1h_mz_p_br_4
                                when ('01', '1') => __encoding LDNT1H_MZ_P_BR_4 // ldnt1h_mz_p_br_4
                                when ('10', '0') => __encoding LD1W_MZ_P_BR_4 // ld1w_mz_p_br_4
                                when ('10', '1') => __encoding LDNT1W_MZ_P_BR_4 // ldnt1w_mz_p_br_4
                                when ('11', '0') => __encoding LD1D_MZ_P_BR_4 // ld1d_mz_p_br_4
                                when ('11', '1') => __encoding LDNT1D_MZ_P_BR_4 // ldnt1d_mz_p_br_4
                        when (_, '01x', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZ_P_BR_2 // st1b_mz_p_br_2
                                when ('00', '1') => __encoding STNT1B_MZ_P_BR_2 // stnt1b_mz_p_br_2
                                when ('01', '0') => __encoding ST1H_MZ_P_BR_2 // st1h_mz_p_br_2
                                when ('01', '1') => __encoding STNT1H_MZ_P_BR_2 // stnt1h_mz_p_br_2
                                when ('10', '0') => __encoding ST1W_MZ_P_BR_2 // st1w_mz_p_br_2
                                when ('10', '1') => __encoding STNT1W_MZ_P_BR_2 // stnt1w_mz_p_br_2
                                when ('11', '0') => __encoding ST1D_MZ_P_BR_2 // st1d_mz_p_br_2
                                when ('11', '1') => __encoding STNT1D_MZ_P_BR_2 // stnt1d_mz_p_br_2
                        when (_, '01x', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZ_P_BR_4 // st1b_mz_p_br_4
                                when ('00', '1') => __encoding STNT1B_MZ_P_BR_4 // stnt1b_mz_p_br_4
                                when ('01', '0') => __encoding ST1H_MZ_P_BR_4 // st1h_mz_p_br_4
                                when ('01', '1') => __encoding STNT1H_MZ_P_BR_4 // stnt1h_mz_p_br_4
                                when ('10', '0') => __encoding ST1W_MZ_P_BR_4 // st1w_mz_p_br_4
                                when ('10', '1') => __encoding STNT1W_MZ_P_BR_4 // stnt1w_mz_p_br_4
                                when ('11', '0') => __encoding ST1D_MZ_P_BR_4 // st1d_mz_p_br_4
                                when ('11', '1') => __encoding STNT1D_MZ_P_BR_4 // stnt1d_mz_p_br_4
                        when (_, '0xx', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '100', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZ_P_BI_2 // ld1b_mz_p_bi_2
                                when ('00', '1') => __encoding LDNT1B_MZ_P_BI_2 // ldnt1b_mz_p_bi_2
                                when ('01', '0') => __encoding LD1H_MZ_P_BI_2 // ld1h_mz_p_bi_2
                                when ('01', '1') => __encoding LDNT1H_MZ_P_BI_2 // ldnt1h_mz_p_bi_2
                                when ('10', '0') => __encoding LD1W_MZ_P_BI_2 // ld1w_mz_p_bi_2
                                when ('10', '1') => __encoding LDNT1W_MZ_P_BI_2 // ldnt1w_mz_p_bi_2
                                when ('11', '0') => __encoding LD1D_MZ_P_BI_2 // ld1d_mz_p_bi_2
                                when ('11', '1') => __encoding LDNT1D_MZ_P_BI_2 // ldnt1d_mz_p_bi_2
                        when (_, '100', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZ_P_BI_4 // ld1b_mz_p_bi_4
                                when ('00', '1') => __encoding LDNT1B_MZ_P_BI_4 // ldnt1b_mz_p_bi_4
                                when ('01', '0') => __encoding LD1H_MZ_P_BI_4 // ld1h_mz_p_bi_4
                                when ('01', '1') => __encoding LDNT1H_MZ_P_BI_4 // ldnt1h_mz_p_bi_4
                                when ('10', '0') => __encoding LD1W_MZ_P_BI_4 // ld1w_mz_p_bi_4
                                when ('10', '1') => __encoding LDNT1W_MZ_P_BI_4 // ldnt1w_mz_p_bi_4
                                when ('11', '0') => __encoding LD1D_MZ_P_BI_4 // ld1d_mz_p_bi_4
                                when ('11', '1') => __encoding LDNT1D_MZ_P_BI_4 // ldnt1d_mz_p_bi_4
                        when (_, '110', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZ_P_BI_2 // st1b_mz_p_bi_2
                                when ('00', '1') => __encoding STNT1B_MZ_P_BI_2 // stnt1b_mz_p_bi_2
                                when ('01', '0') => __encoding ST1H_MZ_P_BI_2 // st1h_mz_p_bi_2
                                when ('01', '1') => __encoding STNT1H_MZ_P_BI_2 // stnt1h_mz_p_bi_2
                                when ('10', '0') => __encoding ST1W_MZ_P_BI_2 // st1w_mz_p_bi_2
                                when ('10', '1') => __encoding STNT1W_MZ_P_BI_2 // stnt1w_mz_p_bi_2
                                when ('11', '0') => __encoding ST1D_MZ_P_BI_2 // st1d_mz_p_bi_2
                                when ('11', '1') => __encoding STNT1D_MZ_P_BI_2 // stnt1d_mz_p_bi_2
                        when (_, '110', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZ_P_BI_4 // st1b_mz_p_bi_4
                                when ('00', '1') => __encoding STNT1B_MZ_P_BI_4 // stnt1b_mz_p_bi_4
                                when ('01', '0') => __encoding ST1H_MZ_P_BI_4 // st1h_mz_p_bi_4
                                when ('01', '1') => __encoding STNT1H_MZ_P_BI_4 // stnt1h_mz_p_bi_4
                                when ('10', '0') => __encoding ST1W_MZ_P_BI_4 // st1w_mz_p_bi_4
                                when ('10', '1') => __encoding STNT1W_MZ_P_BI_4 // stnt1w_mz_p_bi_4
                                when ('11', '0') => __encoding ST1D_MZ_P_BI_4 // st1d_mz_p_bi_4
                                when ('11', '1') => __encoding STNT1D_MZ_P_BI_4 // stnt1d_mz_p_bi_4
                        when (_, '1x0', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '1x1', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '01', _, '10xxxxxxxxxxxxx', _, _, _) =>
                    // mortlach_multi_mem_nctg
                    case (23 +: 9, 20 +: 3, 16 +: 4, 15 +: 1, 3 +: 12, 2 +: 1, 0 +: 2) of
                        when (_, '00x', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZx_P_BR_2x8 // ld1b_mzx_p_br_2x8
                                when ('00', '1') => __encoding LDNT1B_MZx_P_BR_2x8 // ldnt1b_mzx_p_br_2x8
                                when ('01', '0') => __encoding LD1H_MZx_P_BR_2x8 // ld1h_mzx_p_br_2x8
                                when ('01', '1') => __encoding LDNT1H_MZx_P_BR_2x8 // ldnt1h_mzx_p_br_2x8
                                when ('10', '0') => __encoding LD1W_MZx_P_BR_2x8 // ld1w_mzx_p_br_2x8
                                when ('10', '1') => __encoding LDNT1W_MZx_P_BR_2x8 // ldnt1w_mzx_p_br_2x8
                                when ('11', '0') => __encoding LD1D_MZx_P_BR_2x8 // ld1d_mzx_p_br_2x8
                                when ('11', '1') => __encoding LDNT1D_MZx_P_BR_2x8 // ldnt1d_mzx_p_br_2x8
                        when (_, '00x', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZx_P_BR_4x4 // ld1b_mzx_p_br_4x4
                                when ('00', '1') => __encoding LDNT1B_MZx_P_BR_4x4 // ldnt1b_mzx_p_br_4x4
                                when ('01', '0') => __encoding LD1H_MZx_P_BR_4x4 // ld1h_mzx_p_br_4x4
                                when ('01', '1') => __encoding LDNT1H_MZx_P_BR_4x4 // ldnt1h_mzx_p_br_4x4
                                when ('10', '0') => __encoding LD1W_MZx_P_BR_4x4 // ld1w_mzx_p_br_4x4
                                when ('10', '1') => __encoding LDNT1W_MZx_P_BR_4x4 // ldnt1w_mzx_p_br_4x4
                                when ('11', '0') => __encoding LD1D_MZx_P_BR_4x4 // ld1d_mzx_p_br_4x4
                                when ('11', '1') => __encoding LDNT1D_MZx_P_BR_4x4 // ldnt1d_mzx_p_br_4x4
                        when (_, '01x', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZx_P_BR_2x8 // st1b_mzx_p_br_2x8
                                when ('00', '1') => __encoding STNT1B_MZx_P_BR_2x8 // stnt1b_mzx_p_br_2x8
                                when ('01', '0') => __encoding ST1H_MZx_P_BR_2x8 // st1h_mzx_p_br_2x8
                                when ('01', '1') => __encoding STNT1H_MZx_P_BR_2x8 // stnt1h_mzx_p_br_2x8
                                when ('10', '0') => __encoding ST1W_MZx_P_BR_2x8 // st1w_mzx_p_br_2x8
                                when ('10', '1') => __encoding STNT1W_MZx_P_BR_2x8 // stnt1w_mzx_p_br_2x8
                                when ('11', '0') => __encoding ST1D_MZx_P_BR_2x8 // st1d_mzx_p_br_2x8
                                when ('11', '1') => __encoding STNT1D_MZx_P_BR_2x8 // stnt1d_mzx_p_br_2x8
                        when (_, '01x', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZx_P_BR_4x4 // st1b_mzx_p_br_4x4
                                when ('00', '1') => __encoding STNT1B_MZx_P_BR_4x4 // stnt1b_mzx_p_br_4x4
                                when ('01', '0') => __encoding ST1H_MZx_P_BR_4x4 // st1h_mzx_p_br_4x4
                                when ('01', '1') => __encoding STNT1H_MZx_P_BR_4x4 // stnt1h_mzx_p_br_4x4
                                when ('10', '0') => __encoding ST1W_MZx_P_BR_4x4 // st1w_mzx_p_br_4x4
                                when ('10', '1') => __encoding STNT1W_MZx_P_BR_4x4 // stnt1w_mzx_p_br_4x4
                                when ('11', '0') => __encoding ST1D_MZx_P_BR_4x4 // st1d_mzx_p_br_4x4
                                when ('11', '1') => __encoding STNT1D_MZx_P_BR_4x4 // stnt1d_mzx_p_br_4x4
                        when (_, '0xx', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '100', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZx_P_BI_2x8 // ld1b_mzx_p_bi_2x8
                                when ('00', '1') => __encoding LDNT1B_MZx_P_BI_2x8 // ldnt1b_mzx_p_bi_2x8
                                when ('01', '0') => __encoding LD1H_MZx_P_BI_2x8 // ld1h_mzx_p_bi_2x8
                                when ('01', '1') => __encoding LDNT1H_MZx_P_BI_2x8 // ldnt1h_mzx_p_bi_2x8
                                when ('10', '0') => __encoding LD1W_MZx_P_BI_2x8 // ld1w_mzx_p_bi_2x8
                                when ('10', '1') => __encoding LDNT1W_MZx_P_BI_2x8 // ldnt1w_mzx_p_bi_2x8
                                when ('11', '0') => __encoding LD1D_MZx_P_BI_2x8 // ld1d_mzx_p_bi_2x8
                                when ('11', '1') => __encoding LDNT1D_MZx_P_BI_2x8 // ldnt1d_mzx_p_bi_2x8
                        when (_, '100', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZx_P_BI_4x4 // ld1b_mzx_p_bi_4x4
                                when ('00', '1') => __encoding LDNT1B_MZx_P_BI_4x4 // ldnt1b_mzx_p_bi_4x4
                                when ('01', '0') => __encoding LD1H_MZx_P_BI_4x4 // ld1h_mzx_p_bi_4x4
                                when ('01', '1') => __encoding LDNT1H_MZx_P_BI_4x4 // ldnt1h_mzx_p_bi_4x4
                                when ('10', '0') => __encoding LD1W_MZx_P_BI_4x4 // ld1w_mzx_p_bi_4x4
                                when ('10', '1') => __encoding LDNT1W_MZx_P_BI_4x4 // ldnt1w_mzx_p_bi_4x4
                                when ('11', '0') => __encoding LD1D_MZx_P_BI_4x4 // ld1d_mzx_p_bi_4x4
                                when ('11', '1') => __encoding LDNT1D_MZx_P_BI_4x4 // ldnt1d_mzx_p_bi_4x4
                        when (_, '110', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZx_P_BI_2x8 // st1b_mzx_p_bi_2x8
                                when ('00', '1') => __encoding STNT1B_MZx_P_BI_2x8 // stnt1b_mzx_p_bi_2x8
                                when ('01', '0') => __encoding ST1H_MZx_P_BI_2x8 // st1h_mzx_p_bi_2x8
                                when ('01', '1') => __encoding STNT1H_MZx_P_BI_2x8 // stnt1h_mzx_p_bi_2x8
                                when ('10', '0') => __encoding ST1W_MZx_P_BI_2x8 // st1w_mzx_p_bi_2x8
                                when ('10', '1') => __encoding STNT1W_MZx_P_BI_2x8 // stnt1w_mzx_p_bi_2x8
                                when ('11', '0') => __encoding ST1D_MZx_P_BI_2x8 // st1d_mzx_p_bi_2x8
                                when ('11', '1') => __encoding STNT1D_MZx_P_BI_2x8 // stnt1d_mzx_p_bi_2x8
                        when (_, '110', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZx_P_BI_4x4 // st1b_mzx_p_bi_4x4
                                when ('00', '1') => __encoding STNT1B_MZx_P_BI_4x4 // stnt1b_mzx_p_bi_4x4
                                when ('01', '0') => __encoding ST1H_MZx_P_BI_4x4 // st1h_mzx_p_bi_4x4
                                when ('01', '1') => __encoding STNT1H_MZx_P_BI_4x4 // stnt1h_mzx_p_bi_4x4
                                when ('10', '0') => __encoding ST1W_MZx_P_BI_4x4 // st1w_mzx_p_bi_4x4
                                when ('10', '1') => __encoding STNT1W_MZx_P_BI_4x4 // stnt1w_mzx_p_bi_4x4
                                when ('11', '0') => __encoding ST1D_MZx_P_BI_4x4 // st1d_mzx_p_bi_4x4
                                when ('11', '1') => __encoding STNT1D_MZx_P_BI_4x4 // stnt1d_mzx_p_bi_4x4
                        when (_, '1x0', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '1x1', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx000x0xxxxxxx', _, '0xx', _) =>
                    // mortlach_ins
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 17 +: 1, 15 +: 2, 13 +: 2, 10 +: 3, 7 +: 3, 5 +: 2, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, '00', _, '1', _, '00', _, '010', _, 'x0', _, '0', _) => // mortlach_multi2_za_insert_ctg
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding MOVA_ZA_MZ2_1 // mova_za_mz2_1
                        when (_, '00', _, '1', _, '00', _, '011', _, '00', _, '0', _) => // mortlach_multi4_za_insert_ctg
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding MOVA_ZA_MZ4_1 // mova_za_mz4_1
                        when (_, '00', _, '1', _, '00', _, '0x0', _, 'x0', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0x0', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0x1', _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0x1', _, !'00', _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '000', _, 'x0', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '000', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '001', _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '001', _, !'00', _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '01x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '000', _, 'x0', _, '1', _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '000', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', _, '1x', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '01x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', _, _, _, _, _, _, _, _, _) => // mortlach_insert_pred
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field opc 0 +: 4
                            case (size, Q) of
                                when ('0x', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding MOVA_ZA_P_RZ_B // mova_za_p_rz_b
                                when ('01', '0') => __encoding MOVA_ZA_P_RZ_H // mova_za_p_rz_h
                                when ('10', '0') => __encoding MOVA_ZA_P_RZ_W // mova_za_p_rz_w
                                when ('10', '1') => __UNALLOCATED
                                when ('11', '0') => __encoding MOVA_ZA_P_RZ_D // mova_za_p_rz_d
                                when ('11', '1') => __encoding MOVA_ZA_P_RZ_Q // mova_za_p_rz_q
                        when (_, _, _, '1', _, '0x', _, '000', _, 'x0', _, '0', _) => // mortlach_multi2_insert_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Zn 6 +: 4
                            __field opc 0 +: 3
                            case (size) of
                                when ('00') => __encoding MOVA_ZA2_Z_B1 // mova_za2_z_b1
                                when ('01') => __encoding MOVA_ZA2_Z_H1 // mova_za2_z_h1
                                when ('10') => __encoding MOVA_ZA2_Z_W1 // mova_za2_z_w1
                                when ('11') => __encoding MOVA_ZA2_Z_D1 // mova_za2_z_d1
                        when (_, _, _, '1', _, '0x', _, '001', _, '00', _, '0', _) => // mortlach_multi4_insert_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Zn 7 +: 3
                            __field opc 0 +: 3
                            case (size, opc) of
                                when ('0x', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding MOVA_ZA4_Z_B1 // mova_za4_z_b1
                                when ('01', '0xx') => __encoding MOVA_ZA4_Z_H1 // mova_za4_z_h1
                                when ('10', '0xx') => __encoding MOVA_ZA4_Z_W1 // mova_za4_z_w1
                                when ('10', '1xx') => __UNALLOCATED
                                when ('11', _) => __encoding MOVA_ZA4_Z_D1 // mova_za4_z_d1
                        when (_, _, _, '1', _, '0x', _, '1xx', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '1x', _, _, _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx000x0xxxxxxx', _, '1xx', _) => __UNPREDICTABLE
                when (_, '10', _, '0xx000x1xxxxxxx', _, _, _) =>
                    // mortlach_ext
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 17 +: 1, 15 +: 2, 13 +: 2, 10 +: 3, 8 +: 2, 2 +: 6, 0 +: 2) of
                        when (_, '00', _, '1', _, '00', _, '010', '00', _, 'x0') => // mortlach_multi2_za_extract_ctg
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding MOVA_MZ_ZA2_1 // mova_mz_za2_1
                        when (_, '00', _, '1', _, '00', _, '010', '10', _, 'x0') => // mortlach_multi2_za_extract_zero
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding MOVAZ_MZ_ZA2_1 // movaz_mz_za2_1
                        when (_, '00', _, '1', _, '00', _, '011', '00', _, '00') => // mortlach_multi4_za_extract_ctg
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding MOVA_MZ_ZA4_1 // mova_mz_za4_1
                        when (_, '00', _, '1', _, '00', _, '011', '10', _, '00') => // mortlach_multi4_za_extract_zero
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding MOVAZ_MZ_ZA4_1 // movaz_mz_za4_1
                        when (_, '00', _, '1', _, '00', _, '0x0', 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0x1', 'x0', _, !'00') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0xx', 'x1', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '000', 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '001', 'x0', _, !'00') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '00x', 'x1', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '01x', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '000', 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', 'x0', _, '01') => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', 'x0', _, '1x') => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '00x', 'x1', _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '01x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', _, _, _, '000', '1x', _, _) => // mortlach_extract_zero
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 4
                            __field Zd 0 +: 5
                            case (size, Q) of
                                when ('0x', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding MOVAZ_Z_RZA_B // movaz_z_rza_b
                                when ('01', '0') => __encoding MOVAZ_Z_RZA_H // movaz_z_rza_h
                                when ('10', '0') => __encoding MOVAZ_Z_RZA_W // movaz_z_rza_w
                                when ('10', '1') => __UNALLOCATED
                                when ('11', '0') => __encoding MOVAZ_Z_RZA_D // movaz_z_rza_d
                                when ('11', '1') => __encoding MOVAZ_Z_RZA_Q // movaz_z_rza_q
                        when (_, _, _, '0', _, _, _, !'000', '1x', _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', _, _, _, _, '0x', _, _) => // mortlach_extract_pred
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field opc 5 +: 4
                            __field Zd 0 +: 5
                            case (size, Q) of
                                when ('0x', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding MOVA_Z_P_RZA_B // mova_z_p_rza_b
                                when ('01', '0') => __encoding MOVA_Z_P_RZA_H // mova_z_p_rza_h
                                when ('10', '0') => __encoding MOVA_Z_P_RZA_W // mova_z_p_rza_w
                                when ('10', '1') => __UNALLOCATED
                                when ('11', '0') => __encoding MOVA_Z_P_RZA_D // mova_z_p_rza_d
                                when ('11', '1') => __encoding MOVA_Z_P_RZA_Q // mova_z_p_rza_q
                        when (_, _, _, '1', _, '0x', _, '000', '00', _, 'x0') => // mortlach_multi2_extract_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 1 +: 4
                            case (size) of
                                when ('00') => __encoding MOVA_MZ2_ZA_B1 // mova_mz2_za_b1
                                when ('01') => __encoding MOVA_MZ2_ZA_H1 // mova_mz2_za_h1
                                when ('10') => __encoding MOVA_MZ2_ZA_W1 // mova_mz2_za_w1
                                when ('11') => __encoding MOVA_MZ2_ZA_D1 // mova_mz2_za_d1
                        when (_, _, _, '1', _, '0x', _, '000', '10', _, 'x0') => // mortlach_multi2_extract_zero
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 1 +: 4
                            case (size) of
                                when ('00') => __encoding MOVAZ_MZ2_ZA_B1 // movaz_mz2_za_b1
                                when ('01') => __encoding MOVAZ_MZ2_ZA_H1 // movaz_mz2_za_h1
                                when ('10') => __encoding MOVAZ_MZ2_ZA_W1 // movaz_mz2_za_w1
                                when ('11') => __encoding MOVAZ_MZ2_ZA_D1 // movaz_mz2_za_d1
                        when (_, _, _, '1', _, '0x', _, '001', '00', _, '00') => // mortlach_multi4_extract_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when ('0x', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding MOVA_MZ4_ZA_B1 // mova_mz4_za_b1
                                when ('01', '0xx') => __encoding MOVA_MZ4_ZA_H1 // mova_mz4_za_h1
                                when ('10', '0xx') => __encoding MOVA_MZ4_ZA_W1 // mova_mz4_za_w1
                                when ('10', '1xx') => __UNALLOCATED
                                when ('11', _) => __encoding MOVA_MZ4_ZA_D1 // mova_mz4_za_d1
                        when (_, _, _, '1', _, '0x', _, '001', '10', _, '00') => // mortlach_multi4_extract_zero
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when ('0x', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding MOVAZ_MZ4_ZA_B1 // movaz_mz4_za_b1
                                when ('01', '0xx') => __encoding MOVAZ_MZ4_ZA_H1 // movaz_mz4_za_h1
                                when ('10', '0xx') => __encoding MOVAZ_MZ4_ZA_W1 // movaz_mz4_za_w1
                                when ('10', '1xx') => __UNALLOCATED
                                when ('11', _) => __encoding MOVAZ_MZ4_ZA_D1 // movaz_mz4_za_d1
                        when (_, _, _, '1', _, '0x', _, '1xx', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '1x', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx010xxxxxxxxx', _, 'x0x', _) =>
                    // mortlach_hvadd
                    case (24 +: 8, 23 +: 1, 22 +: 1, 19 +: 3, 17 +: 2, 5 +: 12, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, '0', _, _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, '00', _, '0', _, _) => // mortlach_addhv
                            __field op 22 +: 1
                            __field V 16 +: 1
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field opc2 0 +: 3
                            case (op, V, opc2) of
                                when ('0', _, '1xx') => __UNALLOCATED
                                when ('0', '0', '0xx') => __encoding ADDHA_ZA_PP_Z_32 // addha_za_pp_z_32
                                when ('0', '1', '0xx') => __encoding ADDVA_ZA_PP_Z_32 // addva_za_pp_z_32
                                when ('1', '0', _) => __encoding ADDHA_ZA_PP_Z_64 // addha_za_pp_z_64
                                when ('1', '1', _) => __encoding ADDVA_ZA_PP_Z_64 // addva_za_pp_z_64
                        when (_, '1', _, _, '00', _, '1', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, !'00', _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx010xxxxxxxxx', _, 'x1x', _) => __UNPREDICTABLE
                when (_, '10', _, '0xx1xxxxxxxxxxx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '00x011xxxxxxxxx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0000010xxxxxxxx', _, _, _) =>
                    // mortlach_zero
                    case (18 +: 14, 8 +: 10, 0 +: 8) of
                        when (_, '0000000000', _) => // mortlach_zero
                            __field imm8 0 +: 8
                            case () of
                                when () => __encoding ZERO_ZA_I__ // zero_za_i_
                        when (_, !'0000000000', _) => __UNPREDICTABLE
                when (_, '10', _, '0000011xxxxxxxx', _, _, _) =>
                    // mortlach_multizero
                    case (18 +: 14, 13 +: 5, 3 +: 10, 0 +: 3) of
                        when (_, _, '0000000000', _) => // mortlach_multi_zero
                            __field opc 15 +: 3
                            __field Rv 13 +: 2
                            __field opc2 0 +: 3
                            case (opc, opc2) of
                                when ('x1x', '1xx') => __UNALLOCATED
                                when ('000', _) => __encoding ZERO_ZA1_RI_2 // zero_za1_ri_2
                                when ('001', _) => __encoding ZERO_ZA2_RI_1 // zero_za2_ri_1
                                when ('010', '0xx') => __encoding ZERO_ZA2_RI_2 // zero_za2_ri_2
                                when ('011', '0xx') => __encoding ZERO_ZA2_RI_4 // zero_za2_ri_4
                                when ('100', _) => __encoding ZERO_ZA1_RI_4 // zero_za1_ri_4
                                when ('101', '0xx') => __encoding ZERO_ZA4_RI_1 // zero_za4_ri_1
                                when ('101', '1xx') => __UNALLOCATED
                                when ('11x', '01x') => __UNALLOCATED
                                when ('110', '00x') => __encoding ZERO_ZA4_RI_2 // zero_za4_ri_2
                                when ('111', '00x') => __encoding ZERO_ZA4_RI_4 // zero_za4_ri_4
                        when (_, _, !'0000000000', _) => __UNPREDICTABLE
                when (_, '10', _, '0010010xxxxxxxx', _, _, _) =>
                    // mortlach_zero_zt
                    case (18 +: 14, 4 +: 14, 0 +: 4) of
                        when (_, '00000000000000', _) => // mortlach_zero_zt
                            __field opc 0 +: 4
                            case (opc) of
                                when ('0000') => __UNALLOCATED
                                when ('0001') => __encoding ZERO_ZT_I__ // zero_zt_i_
                                when ('001x') => __UNALLOCATED
                                when ('01xx') => __UNALLOCATED
                                when ('1xxx') => __UNALLOCATED
                        when (_, !'00000000000000', _) => __UNPREDICTABLE
                when (_, '10', _, '0010011xxxxxxxx', _, _, _) =>
                    // mortlach_mov_zt
                    case (18 +: 14, 17 +: 1, 15 +: 2, 0 +: 15) of
                        when (_, '0', '00', _) => // mortlach_extract_zt
                            __field imm3 12 +: 3
                            __field opc 5 +: 7
                            __field Rt 0 +: 5
                            case (opc) of
                                when ('000xxxx') => __UNALLOCATED
                                when ('0010xxx') => __UNALLOCATED
                                when ('00110xx') => __UNALLOCATED
                                when ('001110x') => __UNALLOCATED
                                when ('0011110') => __UNALLOCATED
                                when ('0011111') => __encoding MOVT_R_ZT__ // movt_r_zt_
                                when ('01xxxxx') => __UNALLOCATED
                                when ('1xxxxxx') => __UNALLOCATED
                        when (_, '1', '00', _) => // mortlach_insert_zt
                            __field imm3 12 +: 3
                            __field opc 5 +: 7
                            __field Rt 0 +: 5
                            case (opc) of
                                when ('000xxxx') => __UNALLOCATED
                                when ('0010xxx') => __UNALLOCATED
                                when ('00110xx') => __UNALLOCATED
                                when ('001110x') => __UNALLOCATED
                                when ('0011110') => __UNALLOCATED
                                when ('0011111') => __encoding MOVT_ZT_R__ // movt_zt_r_
                                when ('01xxxxx') => __UNALLOCATED
                                when ('1xxxxxx') => __UNALLOCATED
                        when (_, _, !'00', _) => __UNPREDICTABLE
                when (_, '10', _, '01x001xxxxxxxxx', _, _, _) =>
                    // mortlach_zt_expand_ctg
                    case (23 +: 9, 22 +: 1, 19 +: 3, 16 +: 3, 14 +: 2, 2 +: 12, 0 +: 2) of
                        when (_, '0', _, _, '00', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, '10', _, '00') => // mortlach_expand_4dst_ctg
                            __field opc 16 +: 3
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            case (opc, opc2) of
                                when ('00x', _) => __UNALLOCATED
                                when ('01x', '00') => __encoding LUTI4_MZ4_ZTZ_1 // luti4_mz4_ztz_1
                                when ('01x', '01') => __UNALLOCATED
                                when ('01x', '1x') => __UNALLOCATED
                                when ('1xx', '00') => __encoding LUTI2_MZ4_ZTZ_1 // luti2_mz4_ztz_1
                                when ('1xx', '01') => __UNALLOCATED
                                when ('1xx', '1x') => __UNALLOCATED
                        when (_, '0', _, _, '10', _, !'00') => __UNPREDICTABLE
                        when (_, '0', _, _, 'x1', _, 'x0') => // mortlach_expand_2dst_ctg
                            __field opc 15 +: 4
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            case (opc, opc2) of
                                when ('00xx', _) => __UNALLOCATED
                                when ('01xx', '00') => __encoding LUTI4_MZ2_ZTZ_1 // luti4_mz2_ztz_1
                                when ('01xx', '01') => __UNALLOCATED
                                when ('01xx', '1x') => __UNALLOCATED
                                when ('1xxx', '00') => __encoding LUTI2_MZ2_ZTZ_1 // luti2_mz2_ztz_1
                                when ('1xxx', '01') => __UNALLOCATED
                                when ('1xxx', '1x') => __UNALLOCATED
                        when (_, '0', _, _, 'x1', _, 'x1') => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _) => // mortlach_expand_1dst
                            __field opc 14 +: 5
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('00xxx', _) => __UNALLOCATED
                                when ('01xxx', '00') => __encoding LUTI4_Z_ZTZ__ // luti4_z_ztz_
                                when ('01xxx', '01') => __UNALLOCATED
                                when ('01xxx', '1x') => __UNALLOCATED
                                when ('1xxxx', '00') => __encoding LUTI2_Z_ZTZ__ // luti2_z_ztz_
                                when ('1xxxx', '01') => __UNALLOCATED
                                when ('1xxxx', '1x') => __UNALLOCATED
                when (_, '10', _, '010011xxxxxxxxx', _, _, _) =>
                    // mortlach_zt_expand_nctg
                    case (19 +: 13, 16 +: 3, 14 +: 2, 4 +: 10, 2 +: 2, 0 +: 2) of
                        when (_, _, '00', _, _, _) => __UNPREDICTABLE
                        when (_, _, '10', _, '00', _) => // mortlach_expand_4dst_nctg
                            __field opc 16 +: 3
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zdh 4 +: 1
                            __field Zdl 0 +: 2
                            case (opc, opc2) of
                                when ('00x', _) => __UNALLOCATED
                                when ('01x', '00') => __encoding LUTI4_MZ4_ZTZ_4 // luti4_mz4_ztz_4
                                when ('01x', '01') => __UNALLOCATED
                                when ('01x', '1x') => __UNALLOCATED
                                when ('1xx', '00') => __encoding LUTI2_MZ4_ZTZ_4 // luti2_mz4_ztz_4
                                when ('1xx', '01') => __UNALLOCATED
                                when ('1xx', '1x') => __UNALLOCATED
                        when (_, _, '10', _, '01', _) => __UNPREDICTABLE
                        when (_, _, !'00', _, '1x', _) => __UNPREDICTABLE
                        when (_, _, 'x1', _, '0x', _) => // mortlach_expand_2dst_nctg
                            __field opc 15 +: 4
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zdh 4 +: 1
                            __field Zdl 0 +: 3
                            case (opc, opc2) of
                                when ('00xx', _) => __UNALLOCATED
                                when ('01xx', '00') => __encoding LUTI4_MZ2_ZTZ_8 // luti4_mz2_ztz_8
                                when ('01xx', '01') => __UNALLOCATED
                                when ('01xx', '1x') => __UNALLOCATED
                                when ('1xxx', '00') => __encoding LUTI2_MZ2_ZTZ_8 // luti2_mz2_ztz_8
                                when ('1xxx', '01') => __UNALLOCATED
                                when ('1xxx', '1x') => __UNALLOCATED
                when (_, '10', _, '011011xxxxxxxxx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx00xxxxxxxxxx', _, _, _) =>
                    // mortlach_multi_indexed_1
                    case (24 +: 8, 22 +: 2, 20 +: 2, 13 +: 7, 12 +: 1, 3 +: 9, 2 +: 1, 0 +: 2) of
                        when (_, '00', _, _, _, _, _, _) => // mortlach_multi1_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field i4h 15 +: 1
                            __field Rv 13 +: 2
                            __field i4l 10 +: 3
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (U, S, op) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding SMLALL_ZA_ZZi_S // smlall_za_zzi_s
                                when ('0', '0', '1') => __encoding USMLALL_ZA_ZZi_S // usmlall_za_zzi_s
                                when ('0', '1', '0') => __encoding SMLSLL_ZA_ZZi_S // smlsll_za_zzi_s
                                when ('1', '0', '0') => __encoding UMLALL_ZA_ZZi_S // umlall_za_zzi_s
                                when ('1', '0', '1') => __encoding SUMLALL_ZA_ZZi_S // sumlall_za_zzi_s
                                when ('1', '1', '0') => __encoding UMLSLL_ZA_ZZi_S // umlsll_za_zzi_s
                        when (_, '01', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, '0', _, '0', _) => // mortlach_multi1_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLALL_ZA_ZZi_D // smlall_za_zzi_d
                                when ('0', '1') => __encoding SMLSLL_ZA_ZZi_D // smlsll_za_zzi_d
                                when ('1', '0') => __encoding UMLALL_ZA_ZZi_D // umlall_za_zzi_d
                                when ('1', '1') => __encoding UMLSLL_ZA_ZZi_D // umlsll_za_zzi_d
                        when (_, '10', _, _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '10', _, _, '1', _, _, _) => // mortlach_multi1_fma_long_idx
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZi_1 // fmlal_za_zzi_1
                                when ('0', '1') => __encoding FMLSL_ZA_ZZi_1 // fmlsl_za_zzi_1
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZi_1 // bfmlal_za_zzi_1
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZi_1 // bfmlsl_za_zzi_1
                        when (_, '11', _, _, '0', _, _, _) => __UNPREDICTABLE
                        when (_, '11', _, _, '1', _, _, _) => // mortlach_multi1_mla_long_idx
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZi_1 // smlal_za_zzi_1
                                when ('0', '1') => __encoding SMLSL_ZA_ZZi_1 // smlsl_za_zzi_1
                                when ('1', '0') => __encoding UMLAL_ZA_ZZi_1 // umlal_za_zzi_1
                                when ('1', '1') => __encoding UMLSL_ZA_ZZi_1 // umlsl_za_zzi_1
                when (_, '10', _, '1xx01xxxx0xxxxx', _, _, _) =>
                    // mortlach_multi_indexed_2
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 11 +: 2, 6 +: 5, 5 +: 1, 0 +: 5) of
                        when (_, '00', _, _, _, _, '0x', _, _, _) => // mortlach_multi2_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 5 +: 1
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case (op, U, S) of
                                when ('0', '0', '0') => __encoding SMLALL_ZA_ZZi_S2xi // smlall_za_zzi_s2xi
                                when ('0', '0', '1') => __encoding SMLSLL_ZA_ZZi_S2xi // smlsll_za_zzi_s2xi
                                when ('0', '1', '0') => __encoding UMLALL_ZA_ZZi_S2xi // umlall_za_zzi_s2xi
                                when ('0', '1', '1') => __encoding UMLSLL_ZA_ZZi_S2xi // umlsll_za_zzi_s2xi
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding USMLALL_ZA_ZZi_S2xi // usmlall_za_zzi_s2xi
                                when ('1', '1', '0') => __encoding SUMLALL_ZA_ZZi_S2xi // sumlall_za_zzi_s2xi
                        when (_, '00', _, _, _, _, '1x', _, _, _) => // mortlach_multi2_zza_idx_h
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 5 +: 1
                            __field S 4 +: 1
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZi_H2xi // fmla_za_zzi_h2xi
                                when ('0', '1') => __encoding FMLS_ZA_ZZi_H2xi // fmls_za_zzi_h2xi
                                when ('1', '0') => __encoding BFMLA_ZA_ZZi_H2xi // bfmla_za_zzi_h2xi
                                when ('1', '1') => __encoding BFMLS_ZA_ZZi_H2xi // bfmls_za_zzi_h2xi
                        when (_, '01', _, _, _, _, _, _, _, _) => // mortlach_multi2_zza_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 12 +: 1
                            __field i2 10 +: 2
                            __field Zn 6 +: 4
                            __field opc2 3 +: 3
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '000') => __encoding FMLA_ZA_ZZi_S2xi // fmla_za_zzi_s2xi
                                when ('0', '001') => __encoding FVDOT_ZA_ZZi_2xi // fvdot_za_zzi_2xi
                                when ('0', '010') => __encoding FMLS_ZA_ZZi_S2xi // fmls_za_zzi_s2xi
                                when ('0', '011') => __encoding BFVDOT_ZA_ZZi_2xi // bfvdot_za_zzi_2xi
                                when ('0', '100') => __encoding SVDOT_ZA32_ZZi_2xi // svdot_za32_zzi_2xi
                                when ('0', '101') => __UNALLOCATED
                                when ('0', '110') => __encoding UVDOT_ZA32_ZZi_2xi // uvdot_za32_zzi_2xi
                                when ('1', '000') => __encoding SDOT_ZA32_ZZi_2xi // sdot_za32_zzi_2xi
                                when ('1', '001') => __encoding FDOT_ZA_ZZi_2xi // fdot_za_zzi_2xi
                                when ('1', '010') => __encoding UDOT_ZA32_ZZi_2xi // udot_za32_zzi_2xi
                                when ('1', '011') => __encoding BFDOT_ZA_ZZi_2xi // bfdot_za_zzi_2xi
                                when ('1', '100') => __encoding SDOT_ZA_ZZi_S2xi // sdot_za_zzi_s2xi
                                when ('1', '101') => __encoding USDOT_ZA_ZZi_S2xi // usdot_za_zzi_s2xi
                                when ('1', '110') => __encoding UDOT_ZA_ZZi_S2xi // udot_za_zzi_s2xi
                                when ('1', '111') => __encoding SUDOT_ZA_ZZi_S2xi // sudot_za_zzi_s2xi
                        when (_, '10', _, _, _, _, '00', _, '0', _) => // mortlach_multi2_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 1
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 1 +: 2
                            __field o1 0 +: 1
                            case (U, S) of
                                when ('0', '0') => __encoding SMLALL_ZA_ZZi_D2xi // smlall_za_zzi_d2xi
                                when ('0', '1') => __encoding SMLSLL_ZA_ZZi_D2xi // smlsll_za_zzi_d2xi
                                when ('1', '0') => __encoding UMLALL_ZA_ZZi_D2xi // umlall_za_zzi_d2xi
                                when ('1', '1') => __encoding UMLSLL_ZA_ZZi_D2xi // umlsll_za_zzi_d2xi
                        when (_, '10', _, _, _, _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '0', _) => // mortlach_multi2_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZi_2xi // fmlal_za_zzi_2xi
                                when ('0', '1') => __encoding FMLSL_ZA_ZZi_2xi // fmlsl_za_zzi_2xi
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZi_2xi // bfmlal_za_zzi_2xi
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZi_2xi // bfmlsl_za_zzi_2xi
                        when (_, '10', _, _, _, _, '1x', _, '1', _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, _, '00', _, '0', _) => // mortlach_multi2_zza_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i1 10 +: 1
                            __field Zn 6 +: 4
                            __field opc 3 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding FMLA_ZA_ZZi_D2xi // fmla_za_zzi_d2xi
                                when ('01') => __encoding SDOT_ZA_ZZi_D2xi // sdot_za_zzi_d2xi
                                when ('10') => __encoding FMLS_ZA_ZZi_D2xi // fmls_za_zzi_d2xi
                                when ('11') => __encoding UDOT_ZA_ZZi_D2xi // udot_za_zzi_d2xi
                        when (_, '11', _, _, _, _, '01', _, '0', _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, _, '1x', _, '0', _) => // mortlach_multi2_mla_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZi_2xi // smlal_za_zzi_2xi
                                when ('0', '1') => __encoding SMLSL_ZA_ZZi_2xi // smlsl_za_zzi_2xi
                                when ('1', '0') => __encoding UMLAL_ZA_ZZi_2xi // umlal_za_zzi_2xi
                                when ('1', '1') => __encoding UMLSL_ZA_ZZi_2xi // umlsl_za_zzi_2xi
                when (_, '10', _, '1xx01xxxx1xxxxx', _, _, _) =>
                    // mortlach_multi_indexed_3
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 11 +: 2, 7 +: 4, 5 +: 2, 0 +: 5) of
                        when (_, '00', _, _, _, _, '0x', _, '0x', _) => // mortlach_multi4_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 5 +: 1
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case (op, U, S) of
                                when ('0', '0', '0') => __encoding SMLALL_ZA_ZZi_S4xi // smlall_za_zzi_s4xi
                                when ('0', '0', '1') => __encoding SMLSLL_ZA_ZZi_S4xi // smlsll_za_zzi_s4xi
                                when ('0', '1', '0') => __encoding UMLALL_ZA_ZZi_S4xi // umlall_za_zzi_s4xi
                                when ('0', '1', '1') => __encoding UMLSLL_ZA_ZZi_S4xi // umlsll_za_zzi_s4xi
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding USMLALL_ZA_ZZi_S4xi // usmlall_za_zzi_s4xi
                                when ('1', '1', '0') => __encoding SUMLALL_ZA_ZZi_S4xi // sumlall_za_zzi_s4xi
                        when (_, '00', _, _, _, _, '1x', _, '0x', _) => // mortlach_multi4_zza_idx_h
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 5 +: 1
                            __field S 4 +: 1
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZi_H4xi // fmla_za_zzi_h4xi
                                when ('0', '1') => __encoding FMLS_ZA_ZZi_H4xi // fmls_za_zzi_h4xi
                                when ('1', '0') => __encoding BFMLA_ZA_ZZi_H4xi // bfmla_za_zzi_h4xi
                                when ('1', '1') => __encoding BFMLS_ZA_ZZi_H4xi // bfmls_za_zzi_h4xi
                        when (_, '01', _, _, _, _, _, _, '0x', _) => // mortlach_multi4_zza_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 12 +: 1
                            __field i2 10 +: 2
                            __field Zn 7 +: 3
                            __field opc2 3 +: 3
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '000') => __encoding FMLA_ZA_ZZi_S4xi // fmla_za_zzi_s4xi
                                when ('0', '010') => __encoding FMLS_ZA_ZZi_S4xi // fmls_za_zzi_s4xi
                                when ('0', '100') => __encoding SVDOT_ZA_ZZi_S4xi // svdot_za_zzi_s4xi
                                when ('0', '101') => __encoding USVDOT_ZA_ZZi_S4xi // usvdot_za_zzi_s4xi
                                when ('0', '110') => __encoding UVDOT_ZA_ZZi_S4xi // uvdot_za_zzi_s4xi
                                when ('0', '111') => __encoding SUVDOT_ZA_ZZi_S4xi // suvdot_za_zzi_s4xi
                                when ('1', '000') => __encoding SDOT_ZA32_ZZi_4xi // sdot_za32_zzi_4xi
                                when ('1', '001') => __encoding FDOT_ZA_ZZi_4xi // fdot_za_zzi_4xi
                                when ('1', '010') => __encoding UDOT_ZA32_ZZi_4xi // udot_za32_zzi_4xi
                                when ('1', '011') => __encoding BFDOT_ZA_ZZi_4xi // bfdot_za_zzi_4xi
                                when ('1', '100') => __encoding SDOT_ZA_ZZi_S4xi // sdot_za_zzi_s4xi
                                when ('1', '101') => __encoding USDOT_ZA_ZZi_S4xi // usdot_za_zzi_s4xi
                                when ('1', '110') => __encoding UDOT_ZA_ZZi_S4xi // udot_za_zzi_s4xi
                                when ('1', '111') => __encoding SUDOT_ZA_ZZi_S4xi // sudot_za_zzi_s4xi
                        when (_, '0x', _, _, _, _, _, _, '1x', _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '00', _, '00', _) => // mortlach_multi4_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 1
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 1 +: 2
                            __field o1 0 +: 1
                            case (U, S) of
                                when ('0', '0') => __encoding SMLALL_ZA_ZZi_D4xi // smlall_za_zzi_d4xi
                                when ('0', '1') => __encoding SMLSLL_ZA_ZZi_D4xi // smlsll_za_zzi_d4xi
                                when ('1', '0') => __encoding UMLALL_ZA_ZZi_D4xi // umlall_za_zzi_d4xi
                                when ('1', '1') => __encoding UMLSLL_ZA_ZZi_D4xi // umlsll_za_zzi_d4xi
                        when (_, '10', _, _, _, _, '00', _, !'00', _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '00', _) => // mortlach_multi4_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZi_4xi // fmlal_za_zzi_4xi
                                when ('0', '1') => __encoding FMLSL_ZA_ZZi_4xi // fmlsl_za_zzi_4xi
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZi_4xi // bfmlal_za_zzi_4xi
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZi_4xi // bfmlsl_za_zzi_4xi
                        when (_, '10', _, _, _, _, '1x', _, !'00', _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, _, '0x', _, '00', _) => // mortlach_multi4_zza_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 11 +: 1
                            __field i1 10 +: 1
                            __field Zn 7 +: 3
                            __field opc2 3 +: 2
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '00') => __encoding FMLA_ZA_ZZi_D4xi // fmla_za_zzi_d4xi
                                when ('0', '01') => __encoding SDOT_ZA_ZZi_D4xi // sdot_za_zzi_d4xi
                                when ('0', '10') => __encoding FMLS_ZA_ZZi_D4xi // fmls_za_zzi_d4xi
                                when ('0', '11') => __encoding UDOT_ZA_ZZi_D4xi // udot_za_zzi_d4xi
                                when ('1', 'x0') => __UNALLOCATED
                                when ('1', '01') => __encoding SVDOT_ZA_ZZi_D4xi // svdot_za_zzi_d4xi
                                when ('1', '11') => __encoding UVDOT_ZA_ZZi_D4xi // uvdot_za_zzi_d4xi
                        when (_, '11', _, _, _, _, '0x', _, '01', _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, _, '1x', _, '00', _) => // mortlach_multi4_mla_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZi_4xi // smlal_za_zzi_4xi
                                when ('0', '1') => __encoding SMLSL_ZA_ZZi_4xi // smlsl_za_zzi_4xi
                                when ('1', '0') => __encoding UMLAL_ZA_ZZi_4xi // umlal_za_zzi_4xi
                                when ('1', '1') => __encoding UMLSL_ZA_ZZi_4xi // umlsl_za_zzi_4xi
                        when (_, '11', _, _, _, _, _, _, '1x', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx100xxx', _, _, _) =>
                    // mortlach_multi_sve_1
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 7 +: 6, 5 +: 2, 2 +: 3, 0 +: 2) of
                        when (_, _, _, _, '01', _, _, '00', _, '00') => // mortlach_multi4_select_int
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field PNg 10 +: 3
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding SEL_MZ_P_ZZ_4 // sel_mz_p_zz_4
                        when (_, _, _, _, '01', _, _, '00', _, !'00') => __UNPREDICTABLE
                        when (_, _, _, _, '01', _, _, !'00', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '11', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, 'x0', _, 'x0') => // mortlach_multi2_select_int
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field PNg 10 +: 3
                            __field Zn 6 +: 4
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding SEL_MZ_P_ZZ_2 // sel_mz_p_zz_2
                        when (_, _, _, _, 'x0', _, _, 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, 'x1', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx110xxx', _, _, _) =>
                    // mortlach_multi_sve_3
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 2 +: 8, 0 +: 2) of
                        when (_, '00', _, _, _, '101', _, _) => // mortlach_multi2_z_z_long_zip
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding ZIP_MZ_ZZ_2Q // zip_mz_zz_2q
                                when ('1') => __encoding UZP_MZ_ZZ_2Q // uzp_mz_zz_2q
                        when (_, '01', _, _, _, '101', _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, '101', _, _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, '101', _, _) => // mortlach_multi2_qrshr
                            __field op 20 +: 1
                            __field imm4 16 +: 4
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SQRSHR_Z_MZ2__ // sqrshr_z_mz2_
                                when ('0', '1') => __encoding UQRSHR_Z_MZ2__ // uqrshr_z_mz2_
                                when ('1', '0') => __encoding SQRSHRU_Z_MZ2__ // sqrshru_z_mz2_
                                when ('1', '1') => __UNALLOCATED
                        when (_, _, _, _, _, '000', _, 'x0') => // mortlach_multi2_fclamp
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            case (size) of
                                when (!'00') => __encoding FCLAMP_MZ_ZZ_2 // fclamp_mz_zz_2
                                when ('00') => __encoding BFCLAMP_MZ_ZZ_2 // bfclamp_mz_zz_2
                        when (_, _, _, _, _, '000', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, _, _, '001', _, _) => // mortlach_multi2_clamp_int
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding SCLAMP_MZ_ZZ_2 // sclamp_mz_zz_2
                                when ('1') => __encoding UCLAMP_MZ_ZZ_2 // uclamp_mz_zz_2
                        when (_, _, _, _, _, '010', _, '00') => // mortlach_multi4_fclamp
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            case (size) of
                                when (!'00') => __encoding FCLAMP_MZ_ZZ_4 // fclamp_mz_zz_4
                                when ('00') => __encoding BFCLAMP_MZ_ZZ_4 // bfclamp_mz_zz_4
                        when (_, _, _, _, _, '010', _, '01') => __UNPREDICTABLE
                        when (_, _, _, _, _, '011', _, '0x') => // mortlach_multi4_clamp_int
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding SCLAMP_MZ_ZZ_4 // sclamp_mz_zz_4
                                when ('1') => __encoding UCLAMP_MZ_ZZ_4 // uclamp_mz_zz_4
                        when (_, _, _, _, _, '01x', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, _, _, '100', _, _) => // mortlach_multi2_z_z_zip
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding ZIP_MZ_ZZ_2 // zip_mz_zz_2
                                when ('1') => __encoding UZP_MZ_ZZ_2 // uzp_mz_zz_2
                        when (_, _, _, _, _, '11x', _, _) => // mortlach_multi4_qrshr
                            __field tsize 22 +: 2
                            __field imm5 16 +: 5
                            __field N 10 +: 1
                            __field Zn 7 +: 3
                            __field op 6 +: 1
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (N, op, U) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding SQRSHR_Z_MZ4__ // sqrshr_z_mz4_
                                when ('0', '0', '1') => __encoding UQRSHR_Z_MZ4__ // uqrshr_z_mz4_
                                when ('0', '1', '0') => __encoding SQRSHRU_Z_MZ4__ // sqrshru_z_mz4_
                                when ('1', '0', '0') => __encoding SQRSHRN_Z_MZ4__ // sqrshrn_z_mz4_
                                when ('1', '0', '1') => __encoding UQRSHRN_Z_MZ4__ // uqrshrn_z_mz4_
                                when ('1', '1', '0') => __encoding SQRSHRUN_Z_MZ4__ // sqrshrun_z_mz4_
                when (_, '10', _, '1xx1xxxxx111000', _, _, _) =>
                    // mortlach_multi_sve_4
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 10 +: 6, 7 +: 3, 5 +: 2, 2 +: 3, 0 +: 2) of
                        when (_, '00', _, '000', '01', _, _, _, _, 'x0') => // mortlach_multi2_fpint_cvrt
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 1 +: 4
                            case (U) of
                                when ('0') => __encoding FCVTZS_MZ_Z_2 // fcvtzs_mz_z_2
                                when ('1') => __encoding FCVTZU_MZ_Z_2 // fcvtzu_mz_z_2
                        when (_, '00', _, '000', '01', _, _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '000', '10', _, _, _, _, 'x0') => // mortlach_multi2_intfp_cvrt
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 1 +: 4
                            case (U) of
                                when ('0') => __encoding SCVTF_MZ_Z_2 // scvtf_mz_z_2
                                when ('1') => __encoding UCVTF_MZ_Z_2 // ucvtf_mz_z_2
                        when (_, '00', _, '000', '10', _, _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '001', '11', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '100', '01', _, _, '0x', _, '00') => // mortlach_multi4_fpint_cvrt
                            __field Zn 7 +: 3
                            __field U 5 +: 1
                            __field Zd 2 +: 3
                            case (U) of
                                when ('0') => __encoding FCVTZS_MZ_Z_4 // fcvtzs_mz_z_4
                                when ('1') => __encoding FCVTZU_MZ_Z_4 // fcvtzu_mz_z_4
                        when (_, '00', _, '100', '01', _, _, '0x', _, !'00') => __UNPREDICTABLE
                        when (_, '00', _, '100', '0x', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '100', '10', _, _, '0x', _, '00') => // mortlach_multi4_intfp_cvrt
                            __field Zn 7 +: 3
                            __field U 5 +: 1
                            __field Zd 2 +: 3
                            case (U) of
                                when ('0') => __encoding SCVTF_MZ_Z_4 // scvtf_mz_z_4
                                when ('1') => __encoding UCVTF_MZ_Z_4 // ucvtf_mz_z_4
                        when (_, '00', _, '100', '10', _, _, '0x', _, !'00') => __UNPREDICTABLE
                        when (_, '00', _, '100', '10', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '101', '11', _, _, '00', _, 'x0') => // mortlach_multi4_z_z_long_zip
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            __field op 1 +: 1
                            case (op) of
                                when ('0') => __encoding ZIP_MZ_Z_4Q // zip_mz_z_4q
                                when ('1') => __encoding UZP_MZ_Z_4Q // uzp_mz_z_4q
                        when (_, '00', _, '101', '1x', _, _, '00', _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '101', '1x', _, _, !'00', _, _) => __UNPREDICTABLE
                        when (_, '01', _, '000', '01', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '01', _, 'x00', '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0x', _, '000', '00', _, _, _, _, _) => // mortlach_multi2_narrow_fp_cvrt
                            __field op 22 +: 1
                            __field Zn 6 +: 4
                            __field N 5 +: 1
                            __field Zd 0 +: 5
                            case (op, N) of
                                when ('0', '0') => __encoding FCVT_Z_MZ2__ // fcvt_z_mz2_
                                when ('0', '1') => __encoding FCVTN_Z_MZ2__ // fcvtn_z_mz2_
                                when ('1', '0') => __encoding BFCVT_Z_MZ2__ // bfcvt_z_mz2_
                                when ('1', '1') => __encoding BFCVTN_Z_MZ2__ // bfcvtn_z_mz2_
                        when (_, '0x', _, '000', '11', _, _, _, _, _) => // mortlach_multi2_narrow_int_cvrt
                            __field op 22 +: 1
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SQCVT_Z_MZ2__ // sqcvt_z_mz2_
                                when ('0', '1') => __encoding UQCVT_Z_MZ2__ // uqcvt_z_mz2_
                                when ('1', '0') => __encoding SQCVTU_Z_MZ2__ // sqcvtu_z_mz2_
                                when ('1', '1') => __UNALLOCATED
                        when (_, '0x', _, '001', '00', _, _, 'x1', _, _) => __UNPREDICTABLE
                        when (_, '0x', _, '101', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '10', _, '000', '00', _, _, _, _, _) => // mortlach_multi2_wide_fp_cvrt
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field L 0 +: 1
                            case (L) of
                                when ('0') => __encoding FCVT_MZ2_Z__ // fcvt_mz2_z_
                                when ('1') => __encoding FCVTL_MZ2_Z__ // fcvtl_mz2_z_
                        when (_, '10', _, '000', !'00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '11', _, '000', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1x', _, '100', '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1x', _, 'x01', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '100', '0x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '101', '10', _, _, '00', _, 'x1') => __UNPREDICTABLE
                        when (_, !'00', _, '101', '10', _, _, '01', _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '101', '10', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, !'00', _, 'x01', '11', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '001', '01', _, _, _, _, _) => // mortlach_multi2_wide_int
                            __field size 22 +: 2
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding SUNPK_MZ_Z_2 // sunpk_mz_z_2
                                when ('1') => __encoding UUNPK_MZ_Z_2 // uunpk_mz_z_2
                        when (_, _, _, '01x', _, _, _, 'x0', _, 'x0') => // mortlach_multi2_frint
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Zn 6 +: 4
                            __field Zd 1 +: 4
                            case (size, opc) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '000') => __encoding FRINTN_MZ_Z_2 // frintn_mz_z_2
                                when ('10', '001') => __encoding FRINTP_MZ_Z_2 // frintp_mz_z_2
                                when ('10', '010') => __encoding FRINTM_MZ_Z_2 // frintm_mz_z_2
                                when ('10', '011') => __UNALLOCATED
                                when ('10', '100') => __encoding FRINTA_MZ_Z_2 // frinta_mz_z_2
                                when ('10', '101') => __UNALLOCATED
                                when ('10', '11x') => __UNALLOCATED
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '01x', _, _, _, 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, '01x', _, _, _, 'x1', _, _) => __UNPREDICTABLE
                        when (_, _, _, '100', '11', _, _, _, _, _) => // mortlach_multi4_narrow_int_cvrt
                            __field sz 23 +: 1
                            __field op 22 +: 1
                            __field Zn 7 +: 3
                            __field N 6 +: 1
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, N, U) of
                                when ('0', '0', '0') => __encoding SQCVT_Z_MZ4__ // sqcvt_z_mz4_
                                when ('0', '0', '1') => __encoding UQCVT_Z_MZ4__ // uqcvt_z_mz4_
                                when ('0', '1', '0') => __encoding SQCVTN_Z_MZ4__ // sqcvtn_z_mz4_
                                when ('0', '1', '1') => __encoding UQCVTN_Z_MZ4__ // uqcvtn_z_mz4_
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding SQCVTU_Z_MZ4__ // sqcvtu_z_mz4_
                                when ('1', '1', '0') => __encoding SQCVTUN_Z_MZ4__ // sqcvtun_z_mz4_
                        when (_, _, _, '101', '01', _, _, 'x0', _, '0x') => // mortlach_multi4_wide_int
                            __field size 22 +: 2
                            __field Zn 6 +: 4
                            __field Zd 2 +: 3
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding SUNPK_MZ_Z_4 // sunpk_mz_z_4
                                when ('1') => __encoding UUNPK_MZ_Z_4 // uunpk_mz_z_4
                        when (_, _, _, '101', '01', _, _, 'x0', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, '101', '01', _, _, 'x1', _, _) => __UNPREDICTABLE
                        when (_, _, _, '101', '10', _, _, '00', _, 'x0') => // mortlach_multi4_z_z_zip
                            __field size 22 +: 2
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            __field op 1 +: 1
                            case (op) of
                                when ('0') => __encoding ZIP_MZ_Z_4 // zip_mz_z_4
                                when ('1') => __encoding UZP_MZ_Z_4 // uzp_mz_z_4
                        when (_, _, _, '11x', _, _, _, '00', _, '00') => // mortlach_multi4_frint
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '000') => __encoding FRINTN_MZ_Z_4 // frintn_mz_z_4
                                when ('10', '001') => __encoding FRINTP_MZ_Z_4 // frintp_mz_z_4
                                when ('10', '010') => __encoding FRINTM_MZ_Z_4 // frintm_mz_z_4
                                when ('10', '011') => __UNALLOCATED
                                when ('10', '100') => __encoding FRINTA_MZ_Z_4 // frinta_mz_z_4
                                when ('10', '101') => __UNALLOCATED
                                when ('10', '11x') => __UNALLOCATED
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '11x', _, _, _, '00', _, !'00') => __UNPREDICTABLE
                        when (_, _, _, '11x', _, _, _, !'00', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx111001', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx11101x', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxx010110x', _, _, _) =>
                    // mortlach_multi_sve_2c
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 11 +: 6, 10 +: 1, 5 +: 5, 1 +: 4, 0 +: 1) of
                        when (_, _, _, _, _, '0', '0000x', _, _) => // mortlach_multi2_z_z_minmax_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field op 5 +: 1
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (op, U) of
                                when ('0', '0') => __encoding SMAX_MZ_ZZW_2x2 // smax_mz_zzw_2x2
                                when ('0', '1') => __encoding UMAX_MZ_ZZW_2x2 // umax_mz_zzw_2x2
                                when ('1', '0') => __encoding SMIN_MZ_ZZW_2x2 // smin_mz_zzw_2x2
                                when ('1', '1') => __encoding UMIN_MZ_ZZW_2x2 // umin_mz_zzw_2x2
                        when (_, _, _, _, _, '0', '0100x', _, _) => // mortlach_multi2_z_z_fminmax_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field op 5 +: 1
                            __field Zdn 1 +: 4
                            __field o2 0 +: 1
                            case (size, op, o2) of
                                when (!'00', '0', '0') => __encoding FMAX_MZ_ZZW_2x2 // fmax_mz_zzw_2x2
                                when (!'00', '0', '1') => __encoding FMIN_MZ_ZZW_2x2 // fmin_mz_zzw_2x2
                                when (!'00', '1', '0') => __encoding FMAXNM_MZ_ZZW_2x2 // fmaxnm_mz_zzw_2x2
                                when (!'00', '1', '1') => __encoding FMINNM_MZ_ZZW_2x2 // fminnm_mz_zzw_2x2
                                when ('00', '0', '0') => __encoding BFMAX_MZ_ZZW_2x2 // bfmax_mz_zzw_2x2
                                when ('00', '0', '1') => __encoding BFMIN_MZ_ZZW_2x2 // bfmin_mz_zzw_2x2
                                when ('00', '1', '0') => __encoding BFMAXNM_MZ_ZZW_2x2 // bfmaxnm_mz_zzw_2x2
                                when ('00', '1', '1') => __encoding BFMINNM_MZ_ZZW_2x2 // bfminnm_mz_zzw_2x2
                        when (_, _, _, _, _, '0', '0x!= 00x', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '10xxx', _, _) => // mortlach_multi2_z_z_shift_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 3
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('000', _) => __UNALLOCATED
                                when ('001', '0') => __encoding SRSHL_MZ_ZZW_2x2 // srshl_mz_zzw_2x2
                                when ('001', '1') => __encoding URSHL_MZ_ZZW_2x2 // urshl_mz_zzw_2x2
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, _, _, '0', '11xxx', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00000', _, '0') => // mortlach_multi2_z_z_sqdmulh_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field Zdn 1 +: 4
                            case () of
                                when () => __encoding SQDMULH_MZ_ZZW_2x2 // sqdmulh_mz_zzw_2x2
                        when (_, _, _, _, _, '1', '00000', _, '1') => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', !'00000', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxx010111x', _, _, _) =>
                    // mortlach_multi_sve_2d
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 17 +: 1, 11 +: 6, 10 +: 1, 5 +: 5, 2 +: 3, 0 +: 2) of
                        when (_, _, _, _, '0', _, '0', '0000x', _, '0x') => // mortlach_multi4_z_z_minmax_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field op 5 +: 1
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (op, U) of
                                when ('0', '0') => __encoding SMAX_MZ_ZZW_4x4 // smax_mz_zzw_4x4
                                when ('0', '1') => __encoding UMAX_MZ_ZZW_4x4 // umax_mz_zzw_4x4
                                when ('1', '0') => __encoding SMIN_MZ_ZZW_4x4 // smin_mz_zzw_4x4
                                when ('1', '1') => __encoding UMIN_MZ_ZZW_4x4 // umin_mz_zzw_4x4
                        when (_, _, _, _, '0', _, '0', '0100x', _, '0x') => // mortlach_multi4_z_z_fminmax_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field op 5 +: 1
                            __field Zdn 2 +: 3
                            __field o2 0 +: 1
                            case (size, op, o2) of
                                when (!'00', '0', '0') => __encoding FMAX_MZ_ZZW_4x4 // fmax_mz_zzw_4x4
                                when (!'00', '0', '1') => __encoding FMIN_MZ_ZZW_4x4 // fmin_mz_zzw_4x4
                                when (!'00', '1', '0') => __encoding FMAXNM_MZ_ZZW_4x4 // fmaxnm_mz_zzw_4x4
                                when (!'00', '1', '1') => __encoding FMINNM_MZ_ZZW_4x4 // fminnm_mz_zzw_4x4
                                when ('00', '0', '0') => __encoding BFMAX_MZ_ZZW_4x4 // bfmax_mz_zzw_4x4
                                when ('00', '0', '1') => __encoding BFMIN_MZ_ZZW_4x4 // bfmin_mz_zzw_4x4
                                when ('00', '1', '0') => __encoding BFMAXNM_MZ_ZZW_4x4 // bfmaxnm_mz_zzw_4x4
                                when ('00', '1', '1') => __encoding BFMINNM_MZ_ZZW_4x4 // bfminnm_mz_zzw_4x4
                        when (_, _, _, _, '0', _, '0', '0x00x', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, _, '0', _, '0', '0x!= 00x', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '0', _, '0', '10xxx', _, '0x') => // mortlach_multi4_z_z_shift_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 3
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('000', _) => __UNALLOCATED
                                when ('001', '0') => __encoding SRSHL_MZ_ZZW_4x4 // srshl_mz_zzw_4x4
                                when ('001', '1') => __encoding URSHL_MZ_ZZW_4x4 // urshl_mz_zzw_4x4
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, _, '0', _, '0', '10xxx', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, _, '0', _, '0', '11xxx', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '0', _, '1', '00000', _, '00') => // mortlach_multi4_z_z_sqdmulh_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field Zdn 2 +: 3
                            case () of
                                when () => __encoding SQDMULH_MZ_ZZW_4x4 // sqdmulh_mz_zzw_4x4
                        when (_, _, _, _, '0', _, '1', '00000', _, !'00') => __UNPREDICTABLE
                        when (_, _, _, _, '0', _, '1', !'00000', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '1', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxxx10100x', _, _, _) =>
                    // mortlach_multi_sve_2a
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 11 +: 5, 10 +: 1, 5 +: 5, 1 +: 4, 0 +: 1) of
                        when (_, _, _, _, _, '0', '0000x', _, _) => // mortlach_multi2_z_z_minmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (op, U) of
                                when ('0', '0') => __encoding SMAX_MZ_ZZV_2x1 // smax_mz_zzv_2x1
                                when ('0', '1') => __encoding UMAX_MZ_ZZV_2x1 // umax_mz_zzv_2x1
                                when ('1', '0') => __encoding SMIN_MZ_ZZV_2x1 // smin_mz_zzv_2x1
                                when ('1', '1') => __encoding UMIN_MZ_ZZV_2x1 // umin_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '0100x', _, _) => // mortlach_multi2_z_z_fminmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 1 +: 4
                            __field o2 0 +: 1
                            case (size, op, o2) of
                                when (!'00', '0', '0') => __encoding FMAX_MZ_ZZV_2x1 // fmax_mz_zzv_2x1
                                when (!'00', '0', '1') => __encoding FMIN_MZ_ZZV_2x1 // fmin_mz_zzv_2x1
                                when (!'00', '1', '0') => __encoding FMAXNM_MZ_ZZV_2x1 // fmaxnm_mz_zzv_2x1
                                when (!'00', '1', '1') => __encoding FMINNM_MZ_ZZV_2x1 // fminnm_mz_zzv_2x1
                                when ('00', '0', '0') => __encoding BFMAX_MZ_ZZV_2x1 // bfmax_mz_zzv_2x1
                                when ('00', '0', '1') => __encoding BFMIN_MZ_ZZV_2x1 // bfmin_mz_zzv_2x1
                                when ('00', '1', '0') => __encoding BFMAXNM_MZ_ZZV_2x1 // bfmaxnm_mz_zzv_2x1
                                when ('00', '1', '1') => __encoding BFMINNM_MZ_ZZV_2x1 // bfminnm_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '0x!= 00x', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '10xxx', _, _) => // mortlach_multi2_z_z_shift_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field opc 5 +: 3
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('000', _) => __UNALLOCATED
                                when ('001', '0') => __encoding SRSHL_MZ_ZZV_2x1 // srshl_mz_zzv_2x1
                                when ('001', '1') => __encoding URSHL_MZ_ZZV_2x1 // urshl_mz_zzv_2x1
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, _, _, '0', '11000', _, '0') => // mortlach_multi2_z_z_add_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 1 +: 4
                            case () of
                                when () => __encoding ADD_MZ_ZZV_2x1 // add_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '11000', _, '1') => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '11!= 000', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00000', _, '0') => // mortlach_multi2_z_z_sqdmulh_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 1 +: 4
                            case () of
                                when () => __encoding SQDMULH_MZ_ZZV_2x1 // sqdmulh_mz_zzv_2x1
                        when (_, _, _, _, _, '1', '00000', _, '1') => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', !'00000', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxxx10101x', _, _, _) =>
                    // mortlach_multi_sve_2b
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 11 +: 5, 10 +: 1, 5 +: 5, 2 +: 3, 0 +: 2) of
                        when (_, _, _, _, _, '0', '0000x', _, '0x') => // mortlach_multi4_z_z_minmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (op, U) of
                                when ('0', '0') => __encoding SMAX_MZ_ZZV_4x1 // smax_mz_zzv_4x1
                                when ('0', '1') => __encoding UMAX_MZ_ZZV_4x1 // umax_mz_zzv_4x1
                                when ('1', '0') => __encoding SMIN_MZ_ZZV_4x1 // smin_mz_zzv_4x1
                                when ('1', '1') => __encoding UMIN_MZ_ZZV_4x1 // umin_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '0100x', _, '0x') => // mortlach_multi4_z_z_fminmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 2 +: 3
                            __field o2 0 +: 1
                            case (size, op, o2) of
                                when (!'00', '0', '0') => __encoding FMAX_MZ_ZZV_4x1 // fmax_mz_zzv_4x1
                                when (!'00', '0', '1') => __encoding FMIN_MZ_ZZV_4x1 // fmin_mz_zzv_4x1
                                when (!'00', '1', '0') => __encoding FMAXNM_MZ_ZZV_4x1 // fmaxnm_mz_zzv_4x1
                                when (!'00', '1', '1') => __encoding FMINNM_MZ_ZZV_4x1 // fminnm_mz_zzv_4x1
                                when ('00', '0', '0') => __encoding BFMAX_MZ_ZZV_4x1 // bfmax_mz_zzv_4x1
                                when ('00', '0', '1') => __encoding BFMIN_MZ_ZZV_4x1 // bfmin_mz_zzv_4x1
                                when ('00', '1', '0') => __encoding BFMAXNM_MZ_ZZV_4x1 // bfmaxnm_mz_zzv_4x1
                                when ('00', '1', '1') => __encoding BFMINNM_MZ_ZZV_4x1 // bfminnm_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '0x00x', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '0x!= 00x', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '10xxx', _, '0x') => // mortlach_multi4_z_z_shift_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field opc 5 +: 3
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('000', _) => __UNALLOCATED
                                when ('001', '0') => __encoding SRSHL_MZ_ZZV_4x1 // srshl_mz_zzv_4x1
                                when ('001', '1') => __encoding URSHL_MZ_ZZV_4x1 // urshl_mz_zzv_4x1
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, _, _, '0', '10xxx', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '11000', _, '00') => // mortlach_multi4_z_z_add_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 2 +: 3
                            case () of
                                when () => __encoding ADD_MZ_ZZV_4x1 // add_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '11000', _, !'00') => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '11!= 000', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00000', _, '00') => // mortlach_multi4_z_z_sqdmulh_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 2 +: 3
                            case () of
                                when () => __encoding SQDMULH_MZ_ZZV_4x1 // sqdmulh_mz_zzv_4x1
                        when (_, _, _, _, _, '1', '00000', _, !'00') => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', !'00000', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxx01111xx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxx11x11xx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx11xxxx1111xx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx11xxx01010xx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx11xxx1101xxx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '10x1xxxxx0xxxxx', _, _, _) =>
                    // mortlach_multi_array_1
                    case (23 +: 9, 22 +: 1, 21 +: 1, 20 +: 1, 16 +: 4, 15 +: 1, 13 +: 2, 10 +: 3, 5 +: 5, 1 +: 4, 0 +: 1) of
                        when (_, '0', _, '0', _, _, _, '010', _, 'xx0x', _) => // mortlach_multi2_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZV_2x1 // fmlal_za_zzv_2x1
                                when ('0', '1') => __encoding FMLSL_ZA_ZZV_2x1 // fmlsl_za_zzv_2x1
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZV_2x1 // bfmlal_za_zzv_2x1
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZV_2x1 // bfmlsl_za_zzv_2x1
                        when (_, '0', _, '0', _, _, _, '011', _, _, _) => // mortlach_multi1_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZV_1 // fmlal_za_zzv_1
                                when ('0', '1') => __encoding FMLSL_ZA_ZZV_1 // fmlsl_za_zzv_1
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZV_1 // bfmlal_za_zzv_1
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZV_1 // bfmlsl_za_zzv_1
                        when (_, '0', _, '0', _, _, _, '101', _, 'x1xx', _) => // mortlach_multi2_z_za_mixed_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding USDOT_ZA_ZZV_S2x1 // usdot_za_zzv_s2x1
                                when ('1') => __encoding SUDOT_ZA_ZZV_S2x1 // sudot_za_zzv_s2x1
                        when (_, '0', _, '1', _, _, _, '010', _, 'xx0x', _) => // mortlach_multi4_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZV_4x1 // fmlal_za_zzv_4x1
                                when ('0', '1') => __encoding FMLSL_ZA_ZZV_4x1 // fmlsl_za_zzv_4x1
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZV_4x1 // bfmlal_za_zzv_4x1
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZV_4x1 // bfmlsl_za_zzv_4x1
                        when (_, '0', _, '1', _, _, _, '101', _, 'x1xx', _) => // mortlach_multi4_z_za_mixed_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding USDOT_ZA_ZZV_S4x1 // usdot_za_zzv_s4x1
                                when ('1') => __encoding SUDOT_ZA_ZZV_S4x1 // sudot_za_zzv_s4x1
                        when (_, '1', _, '0', _, _, _, '010', _, 'xx0x', _) => // mortlach_multi2_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZV_2x1 // smlal_za_zzv_2x1
                                when ('0', '1') => __encoding SMLSL_ZA_ZZV_2x1 // smlsl_za_zzv_2x1
                                when ('1', '0') => __encoding UMLAL_ZA_ZZV_2x1 // umlal_za_zzv_2x1
                                when ('1', '1') => __encoding UMLSL_ZA_ZZV_2x1 // umlsl_za_zzv_2x1
                        when (_, '1', _, '0', _, _, _, '011', _, _, _) => // mortlach_multi1_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZV_1 // smlal_za_zzv_1
                                when ('0', '1') => __encoding SMLSL_ZA_ZZV_1 // smlsl_za_zzv_1
                                when ('1', '0') => __encoding UMLAL_ZA_ZZV_1 // umlal_za_zzv_1
                                when ('1', '1') => __encoding UMLSL_ZA_ZZV_1 // umlsl_za_zzv_1
                        when (_, '1', _, '0', _, _, _, '101', _, 'x1xx', _) => // mortlach_multi2_z_za_2way_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA32_ZZV_2x1 // sdot_za32_zzv_2x1
                                when ('1') => __encoding UDOT_ZA32_ZZV_2x1 // udot_za32_zzv_2x1
                        when (_, '1', _, '1', _, _, _, '010', _, 'xx0x', _) => // mortlach_multi4_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZV_4x1 // smlal_za_zzv_4x1
                                when ('0', '1') => __encoding SMLSL_ZA_ZZV_4x1 // smlsl_za_zzv_4x1
                                when ('1', '0') => __encoding UMLAL_ZA_ZZV_4x1 // umlal_za_zzv_4x1
                                when ('1', '1') => __encoding UMLSL_ZA_ZZV_4x1 // umlsl_za_zzv_4x1
                        when (_, '1', _, '1', _, _, _, '101', _, 'x1xx', _) => // mortlach_multi4_z_za_2way_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA32_ZZV_4x1 // sdot_za32_zzv_4x1
                                when ('1') => __encoding UDOT_ZA32_ZZV_4x1 // udot_za32_zzv_4x1
                        when (_, _, _, '0', _, _, _, '000', _, 'xxx0', _) => // mortlach_multi2_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZV_2x1 // smlall_za_zzv_2x1
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZV_2x1 // smlsll_za_zzv_2x1
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZV_2x1 // umlall_za_zzv_2x1
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZV_2x1 // umlsll_za_zzv_2x1
                                when ('0', _, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZV_S2x1 // usmlall_za_zzv_s2x1
                                when ('0', '1', '0', '1') => __encoding SUMLALL_ZA_ZZV_S2x1 // sumlall_za_zzv_s2x1
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, '0', _, _, _, '001', _, _, _) => // mortlach_multi1_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZV_1 // smlall_za_zzv_1
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZV_1 // smlsll_za_zzv_1
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZV_1 // umlall_za_zzv_1
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZV_1 // umlsll_za_zzv_1
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZV_S // usmlall_za_zzv_s
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, '0', _, _, _, '100', _, _, _) => // mortlach_multi2_z_za_fpdot_sm
                            __field op 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field opc2 3 +: 2
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '00') => __encoding FDOT_ZA_ZZV_2x1 // fdot_za_zzv_2x1
                                when ('0', '10') => __encoding BFDOT_ZA_ZZV_2x1 // bfdot_za_zzv_2x1
                                when ('1', '01') => __UNALLOCATED
                                when ('1', '1x') => __UNALLOCATED
                        when (_, _, _, '0', _, _, _, '101', _, 'x0xx', _) => // mortlach_multi2_z_za_4way_dot_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA_ZZV_2x1 // sdot_za_zzv_2x1
                                when ('1') => __encoding UDOT_ZA_ZZV_2x1 // udot_za_zzv_2x1
                        when (_, _, _, '0', _, _, _, '110', _, '0xxx', _) => // mortlach_multi2_zz_za_float_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMLA_ZA_ZZV_2x1 // fmla_za_zzv_2x1
                                when ('1') => __encoding FMLS_ZA_ZZV_2x1 // fmls_za_zzv_2x1
                        when (_, _, _, '0', _, _, _, '110', _, '1xxx', _) => // mortlach_multi2_zz_za_int_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZZV_2x1 // add_za_zzv_2x1
                                when ('1') => __encoding SUB_ZA_ZZV_2x1 // sub_za_zzv_2x1
                        when (_, _, _, '0', _, _, _, '111', _, '0xxx', _) => // mortlach_multi2_zz_za_f16_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZV_2x1_16 // fmla_za_zzv_2x1_16
                                when ('0', '1') => __encoding FMLS_ZA_ZZV_2x1_16 // fmls_za_zzv_2x1_16
                                when ('1', '0') => __encoding BFMLA_ZA_ZZV_2x1_16 // bfmla_za_zzv_2x1_16
                                when ('1', '1') => __encoding BFMLS_ZA_ZZV_2x1_16 // bfmls_za_zzv_2x1_16
                        when (_, _, _, '1', _, _, _, '000', _, 'xxx0', _) => // mortlach_multi4_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZV_4x1 // smlall_za_zzv_4x1
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZV_4x1 // smlsll_za_zzv_4x1
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZV_4x1 // umlall_za_zzv_4x1
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZV_4x1 // umlsll_za_zzv_4x1
                                when ('0', _, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZV_S4x1 // usmlall_za_zzv_s4x1
                                when ('0', '1', '0', '1') => __encoding SUMLALL_ZA_ZZV_S4x1 // sumlall_za_zzv_s4x1
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, '1', _, _, _, '0x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, _, _, '100', _, _, _) => // mortlach_multi4_z_za_fpdot_sm
                            __field op 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field opc2 3 +: 2
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '00') => __encoding FDOT_ZA_ZZV_4x1 // fdot_za_zzv_4x1
                                when ('0', '10') => __encoding BFDOT_ZA_ZZV_4x1 // bfdot_za_zzv_4x1
                                when ('1', '01') => __UNALLOCATED
                                when ('1', '1x') => __UNALLOCATED
                        when (_, _, _, '1', _, _, _, '101', _, 'x0xx', _) => // mortlach_multi4_z_za_4way_dot_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA_ZZV_4x1 // sdot_za_zzv_4x1
                                when ('1') => __encoding UDOT_ZA_ZZV_4x1 // udot_za_zzv_4x1
                        when (_, _, _, '1', _, _, _, '110', _, '0xxx', _) => // mortlach_multi4_zz_za_float_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMLA_ZA_ZZV_4x1 // fmla_za_zzv_4x1
                                when ('1') => __encoding FMLS_ZA_ZZV_4x1 // fmls_za_zzv_4x1
                        when (_, _, _, '1', _, _, _, '110', _, '1xxx', _) => // mortlach_multi4_zz_za_int_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZZV_4x1 // add_za_zzv_4x1
                                when ('1') => __encoding SUB_ZA_ZZV_4x1 // sub_za_zzv_4x1
                        when (_, _, _, '1', _, _, _, '111', _, '0xxx', _) => // mortlach_multi4_zz_za_f16_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZV_4x1_16 // fmla_za_zzv_4x1_16
                                when ('0', '1') => __encoding FMLS_ZA_ZZV_4x1_16 // fmls_za_zzv_4x1_16
                                when ('1', '0') => __encoding BFMLA_ZA_ZZV_4x1_16 // bfmla_za_zzv_4x1_16
                                when ('1', '1') => __encoding BFMLS_ZA_ZZV_4x1_16 // bfmls_za_zzv_4x1_16
                        when (_, _, _, _, _, _, _, '000', _, 'xxx1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '010', _, 'xx1x', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '111', _, '1xxx', _) => __UNPREDICTABLE
                when (_, '10', _, '11x1xxxx00xxxxx', _, _, _) =>
                    // mortlach_multi_array_2a
                    case (23 +: 9, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 15 +: 2, 13 +: 2, 10 +: 3, 6 +: 4, 1 +: 5, 0 +: 1) of
                        when (_, '0', _, _, _, _, _, '010', _, '0xx0x', _) => // mortlach_multi2_zz_za_fma_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZW_2x2 // fmlal_za_zzw_2x2
                                when ('0', '1') => __encoding FMLSL_ZA_ZZW_2x2 // fmlsl_za_zzw_2x2
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZW_2x2 // bfmlal_za_zzw_2x2
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZW_2x2 // bfmlsl_za_zzw_2x2
                        when (_, '0', _, _, _, _, _, '101', _, '001xx', _) => // mortlach_multi2_z_za_mixed_dot_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding USDOT_ZA_ZZW_S2x2 // usdot_za_zzw_s2x2
                        when (_, '0', _, _, _, _, _, '101', _, '011xx', _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, '010', _, '0xx0x', _) => // mortlach_multi2_zz_za_mla_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZW_2x2 // smlal_za_zzw_2x2
                                when ('0', '1') => __encoding SMLSL_ZA_ZZW_2x2 // smlsl_za_zzw_2x2
                                when ('1', '0') => __encoding UMLAL_ZA_ZZW_2x2 // umlal_za_zzw_2x2
                                when ('1', '1') => __encoding UMLSL_ZA_ZZW_2x2 // umlsl_za_zzw_2x2
                        when (_, '1', _, _, _, _, _, '101', _, '0x1xx', _) => // mortlach_multi2_z_za_2way_dot_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA32_ZZW_2x2 // sdot_za32_zzw_2x2
                                when ('1') => __encoding UDOT_ZA32_ZZW_2x2 // udot_za32_zzw_2x2
                        when (_, _, _, '00', '00', _, _, '111', _, '00xxx', _) => // mortlach_multi2_z_za_float_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FADD_ZA_ZW_2x2 // fadd_za_zw_2x2
                                when ('1') => __encoding FSUB_ZA_ZW_2x2 // fsub_za_zw_2x2
                        when (_, _, _, '00', '00', _, _, '111', _, '01xxx', _) => // mortlach_multi2_z_za_int_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZW_2x2 // add_za_zw_2x2
                                when ('1') => __encoding SUB_ZA_ZW_2x2 // sub_za_zw_2x2
                        when (_, _, _, '00', '10', _, _, '111', _, '00xxx', _) => // mortlach_multi2_z_za_f16_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FADD_ZA_ZW_2x2_16 // fadd_za_zw_2x2_16
                                when ('0', '1') => __encoding FSUB_ZA_ZW_2x2_16 // fsub_za_zw_2x2_16
                                when ('1', '0') => __encoding BFADD_ZA_ZW_2x2_16 // bfadd_za_zw_2x2_16
                                when ('1', '1') => __encoding BFSUB_ZA_ZW_2x2_16 // bfsub_za_zw_2x2_16
                        when (_, _, _, '00', '10', _, _, '111', _, '01xxx', _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x0', _, _, '11x', _, '1xxxx', _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x1', _, _, '110', _, '1xxxx', _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x1', _, _, '111', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', _, _, _, '110', _, '1xxxx', _) => __UNPREDICTABLE
                        when (_, _, _, !'00', _, _, _, '111', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '000', _, '0xxx0', _) => // mortlach_multi2_zz_za_mla_long_long_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZW_2x2 // smlall_za_zzw_2x2
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZW_2x2 // smlsll_za_zzw_2x2
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZW_2x2 // umlall_za_zzw_2x2
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZW_2x2 // umlsll_za_zzw_2x2
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZW_S2x2 // usmlall_za_zzw_s2x2
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, _, '000', _, '0xxx1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '010', _, '0xx1x', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '0x0', _, '1xxxx', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '0x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '100', _, '0x1xx', _) => // mortlach_multi2_zz_za_f16_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 4 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZW_2x2_16 // fmla_za_zzw_2x2_16
                                when ('0', '1') => __encoding FMLS_ZA_ZZW_2x2_16 // fmls_za_zzw_2x2_16
                                when ('1', '0') => __encoding BFMLA_ZA_ZZW_2x2_16 // bfmla_za_zzw_2x2_16
                                when ('1', '1') => __encoding BFMLS_ZA_ZZW_2x2_16 // bfmls_za_zzw_2x2_16
                        when (_, _, _, _, _, _, _, '100', _, '1x1xx', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '100', _, 'xx0xx', _) => // mortlach_multi2_z_za_fpdot_mm
                            __field op 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field opc2 4 +: 2
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '00') => __encoding FDOT_ZA_ZZW_2x2 // fdot_za_zzw_2x2
                                when ('0', '01') => __encoding BFDOT_ZA_ZZW_2x2 // bfdot_za_zzw_2x2
                                when ('1', '01') => __UNALLOCATED
                                when ('1', '1x') => __UNALLOCATED
                        when (_, _, _, _, _, _, _, '101', _, '0x0xx', _) => // mortlach_multi2_z_za_4way_dot_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA_ZZW_2x2 // sdot_za_zzw_2x2
                                when ('1') => __encoding UDOT_ZA_ZZW_2x2 // udot_za_zzw_2x2
                        when (_, _, _, _, _, _, _, '101', _, '1xxxx', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '110', _, '00xxx', _) => // mortlach_multi2_zz_za_float_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMLA_ZA_ZZW_2x2 // fmla_za_zzw_2x2
                                when ('1') => __encoding FMLS_ZA_ZZW_2x2 // fmls_za_zzw_2x2
                        when (_, _, _, _, _, _, _, '110', _, '01xxx', _) => // mortlach_multi2_zz_za_int_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZZW_2x2 // add_za_zzw_2x2
                                when ('1') => __encoding SUB_ZA_ZZW_2x2 // sub_za_zzw_2x2
                when (_, '10', _, '11x1xxxx10xxxxx', _, _, _) =>
                    // mortlach_multi_array_2b
                    case (23 +: 9, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 15 +: 2, 13 +: 2, 10 +: 3, 7 +: 3, 5 +: 2, 1 +: 4, 0 +: 1) of
                        when (_, '0', _, _, 'x0', _, _, '010', _, '00', 'xx0x', _) => // mortlach_multi4_zz_za_fma_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZW_4x4 // fmlal_za_zzw_4x4
                                when ('0', '1') => __encoding FMLSL_ZA_ZZW_4x4 // fmlsl_za_zzw_4x4
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZW_4x4 // bfmlal_za_zzw_4x4
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZW_4x4 // bfmlsl_za_zzw_4x4
                        when (_, '0', _, _, 'x0', _, _, '101', _, '00', '01xx', _) => // mortlach_multi4_z_za_mixed_dot_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding USDOT_ZA_ZZW_S4x4 // usdot_za_zzw_s4x4
                        when (_, '0', _, _, 'x0', _, _, '101', _, '00', '11xx', _) => __UNPREDICTABLE
                        when (_, '1', _, _, 'x0', _, _, '010', _, '00', 'xx0x', _) => // mortlach_multi4_zz_za_mla_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZW_4x4 // smlal_za_zzw_4x4
                                when ('0', '1') => __encoding SMLSL_ZA_ZZW_4x4 // smlsl_za_zzw_4x4
                                when ('1', '0') => __encoding UMLAL_ZA_ZZW_4x4 // umlal_za_zzw_4x4
                                when ('1', '1') => __encoding UMLSL_ZA_ZZW_4x4 // umlsl_za_zzw_4x4
                        when (_, '1', _, _, 'x0', _, _, '101', _, '00', 'x1xx', _) => // mortlach_multi4_z_za_2way_dot_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA32_ZZW_4x4 // sdot_za32_zzw_4x4
                                when ('1') => __encoding UDOT_ZA32_ZZW_4x4 // udot_za32_zzw_4x4
                        when (_, _, _, '00', '00', _, _, '111', _, '00', '0xxx', _) => // mortlach_multi4_z_za_float_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FADD_ZA_ZW_4x4 // fadd_za_zw_4x4
                                when ('1') => __encoding FSUB_ZA_ZW_4x4 // fsub_za_zw_4x4
                        when (_, _, _, '00', '00', _, _, '111', _, '00', '1xxx', _) => // mortlach_multi4_z_za_int_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZW_4x4 // add_za_zw_4x4
                                when ('1') => __encoding SUB_ZA_ZW_4x4 // sub_za_zw_4x4
                        when (_, _, _, '00', '10', _, _, '111', _, '00', '0xxx', _) => // mortlach_multi4_z_za_f16_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FADD_ZA_ZW_4x4_16 // fadd_za_zw_4x4_16
                                when ('0', '1') => __encoding FSUB_ZA_ZW_4x4_16 // fsub_za_zw_4x4_16
                                when ('1', '0') => __encoding BFADD_ZA_ZW_4x4_16 // bfadd_za_zw_4x4_16
                                when ('1', '1') => __encoding BFSUB_ZA_ZW_4x4_16 // bfsub_za_zw_4x4_16
                        when (_, _, _, '00', '10', _, _, '111', _, '00', '1xxx', _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x0', _, _, '11x', _, '01', _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x0', _, _, '1xx', _, '1x', _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', 'x0', _, _, '10x', _, '1x', _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', 'x0', _, _, '110', _, '01', _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', 'x0', _, _, '110', _, '1x', _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', 'x0', _, _, '111', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '000', _, '00', 'xxx0', _) => // mortlach_multi4_zz_za_mla_long_long_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZW_4x4 // smlall_za_zzw_4x4
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZW_4x4 // smlsll_za_zzw_4x4
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZW_4x4 // umlall_za_zzw_4x4
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZW_4x4 // umlsll_za_zzw_4x4
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZW_S4x4 // usmlall_za_zzw_s4x4
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, 'x0', _, _, '000', _, '00', 'xxx1', _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '010', _, '00', 'xx1x', _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '0x0', _, !'00', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '0x1', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '100', _, '00', 'x1xx', _) => // mortlach_multi4_zz_za_f16_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 4 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZW_4x4_16 // fmla_za_zzw_4x4_16
                                when ('0', '1') => __encoding FMLS_ZA_ZZW_4x4_16 // fmls_za_zzw_4x4_16
                                when ('1', '0') => __encoding BFMLA_ZA_ZZW_4x4_16 // bfmla_za_zzw_4x4_16
                                when ('1', '1') => __encoding BFMLS_ZA_ZZW_4x4_16 // bfmls_za_zzw_4x4_16
                        when (_, _, _, _, 'x0', _, _, '100', _, '01', 'x1xx', _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '100', _, '0x', 'x0xx', _) => // mortlach_multi4_z_za_fpdot_mm
                            __field op 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field opc2 4 +: 2
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '00') => __encoding FDOT_ZA_ZZW_4x4 // fdot_za_zzw_4x4
                                when ('0', '01') => __encoding BFDOT_ZA_ZZW_4x4 // bfdot_za_zzw_4x4
                                when ('1', '01') => __UNALLOCATED
                                when ('1', '1x') => __UNALLOCATED
                        when (_, _, _, _, 'x0', _, _, '101', _, '00', 'x0xx', _) => // mortlach_multi4_z_za_4way_dot_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA_ZZW_4x4 // sdot_za_zzw_4x4
                                when ('1') => __encoding UDOT_ZA_ZZW_4x4 // udot_za_zzw_4x4
                        when (_, _, _, _, 'x0', _, _, '101', _, '01', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '110', _, '00', '0xxx', _) => // mortlach_multi4_zz_za_float_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMLA_ZA_ZZW_4x4 // fmla_za_zzw_4x4
                                when ('1') => __encoding FMLS_ZA_ZZW_4x4 // fmls_za_zzw_4x4
                        when (_, _, _, _, 'x0', _, _, '110', _, '00', '1xxx', _) => // mortlach_multi4_zz_za_int_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZZW_4x4 // add_za_zzw_4x4
                                when ('1') => __encoding SUB_ZA_ZZW_4x4 // sub_za_zzw_4x4
                        when (_, _, _, _, 'x1', _, _, _, _, _, _, _) => __UNPREDICTABLE
                when (_, '11', _, _, _, _, _) =>
                    // mortlach_mem
                    case (25 +: 7, 21 +: 4, 16 +: 5, 15 +: 1, 10 +: 5, 5 +: 5, 2 +: 3, 0 +: 2) of
                        when (_, '0xx0', _, _, _, _, '0xx', _) => // mortlach_contig_load
                            __field msz 22 +: 2
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field opc 0 +: 4
                            case (msz) of
                                when ('00') => __encoding LD1B_ZA_P_RRR__ // ld1b_za_p_rrr_
                                when ('01') => __encoding LD1H_ZA_P_RRR__ // ld1h_za_p_rrr_
                                when ('10') => __encoding LD1W_ZA_P_RRR__ // ld1w_za_p_rrr_
                                when ('11') => __encoding LD1D_ZA_P_RRR__ // ld1d_za_p_rrr_
                        when (_, '0xx1', _, _, _, _, '0xx', _) => // mortlach_contig_store
                            __field msz 22 +: 2
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field opc 0 +: 4
                            case (msz) of
                                when ('00') => __encoding ST1B_ZA_P_RRR__ // st1b_za_p_rrr_
                                when ('01') => __encoding ST1H_ZA_P_RRR__ // st1h_za_p_rrr_
                                when ('10') => __encoding ST1W_ZA_P_RRR__ // st1w_za_p_rrr_
                                when ('11') => __encoding ST1D_ZA_P_RRR__ // st1d_za_p_rrr_
                        when (_, '0xxx', _, _, _, _, '1xx', _) => __UNPREDICTABLE
                        when (_, '100x', '00000', '0', 'xx000', _, '0xx', _) => // mortlach_ctxt_ldst
                            __field op 21 +: 1
                            __field Rv 13 +: 2
                            __field Rn 5 +: 5
                            __field imm4 0 +: 4
                            case (op) of
                                when ('0') => __encoding LDR_ZA_RI__ // ldr_za_ri_
                                when ('1') => __encoding STR_ZA_RI__ // str_za_ri_
                        when (_, '100x', '00000', '0', 'xx000', _, '1xx', _) => __UNPREDICTABLE
                        when (_, '100x', '00000', '0', 'xx!= 000', _, _, _) => __UNPREDICTABLE
                        when (_, '100x', !'00000', '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, '100x', _, '1', '00000', _, '000', _) => // mortlach_zt_ldst
                            __field opc 16 +: 6
                            __field Rn 5 +: 5
                            __field opc2 0 +: 2
                            case (opc, opc2) of
                                when ('x0xxxx', _) => __UNALLOCATED
                                when ('x10xxx', _) => __UNALLOCATED
                                when ('x110xx', _) => __UNALLOCATED
                                when ('x1110x', _) => __UNALLOCATED
                                when ('x11110', _) => __UNALLOCATED
                                when ('x11111', '01') => __UNALLOCATED
                                when ('x11111', '1x') => __UNALLOCATED
                                when ('011111', '00') => __encoding LDR_ZT_BR__ // ldr_zt_br_
                                when ('111111', '00') => __encoding STR_ZT_BR__ // str_zt_br_
                        when (_, '100x', _, '1', '00000', _, !'000', _) => __UNPREDICTABLE
                        when (_, '100x', _, '1', !'00000', _, _, _) => __UNPREDICTABLE
                        when (_, '101x', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '110x', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1110', _, _, _, _, '0xx', _) => // mortlach_contig_qload
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field ZAt 0 +: 4
                            case () of
                                when () => __encoding LD1Q_ZA_P_RRR__ // ld1q_za_p_rrr_
                        when (_, '1111', _, _, _, _, '0xx', _) => // mortlach_contig_qstore
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field ZAt 0 +: 4
                            case () of
                                when () => __encoding ST1Q_ZA_P_RRR__ // st1q_za_p_rrr_
                        when (_, '111x', _, _, _, _, '1xx', _) => __UNPREDICTABLE
        when (_, _, '0001', _) => __UNPREDICTABLE
        when (_, _, '0010', _) =>
            // sve
            case (29 +: 3, 25 +: 4, 10 +: 15, 5 +: 5, 4 +: 1, 0 +: 4) of
                when ('000', _, '0xx0xxxxxx1xxxx', _, _, _) =>
                    // sve_int_muladd_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 14 +: 1, 0 +: 14) of
                        when (_, _, _, _, '0', _, _) => // sve_int_mlas_vvv_pred
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op) of
                                when ('0') => __encoding MLA_Z_P_ZZZ__ // mla_z_p_zzz_
                                when ('1') => __encoding MLS_Z_P_ZZZ__ // mls_z_p_zzz_
                        when (_, _, _, _, '1', _, _) => // sve_int_mladdsub_vvv_pred
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field Pg 10 +: 3
                            __field Za 5 +: 5
                            __field Zdn 0 +: 5
                            case (op) of
                                when ('0') => __encoding MAD_Z_P_ZZZ__ // mad_z_p_zzz_
                                when ('1') => __encoding MSB_Z_P_ZZZ__ // msb_z_p_zzz_
                when ('000', _, '0xx0xxxxx000xxx', _, _, _) =>
                    // sve_int_pred_bin
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '00x', _, _, _) => // sve_int_bin_pred_arit_0
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding ADD_Z_P_ZZ__ // add_z_p_zz_
                                when ('001') => __encoding SUB_Z_P_ZZ__ // sub_z_p_zz_
                                when ('010') => __UNALLOCATED
                                when ('011') => __encoding SUBR_Z_P_ZZ__ // subr_z_p_zz_
                                when ('1xx') => __UNALLOCATED
                        when (_, _, _, '01x', _, _, _) => // sve_int_bin_pred_arit_1
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, U) of
                                when ('00', '0') => __encoding SMAX_Z_P_ZZ__ // smax_z_p_zz_
                                when ('00', '1') => __encoding UMAX_Z_P_ZZ__ // umax_z_p_zz_
                                when ('01', '0') => __encoding SMIN_Z_P_ZZ__ // smin_z_p_zz_
                                when ('01', '1') => __encoding UMIN_Z_P_ZZ__ // umin_z_p_zz_
                                when ('10', '0') => __encoding SABD_Z_P_ZZ__ // sabd_z_p_zz_
                                when ('10', '1') => __encoding UABD_Z_P_ZZ__ // uabd_z_p_zz_
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '100', _, _, _) => // sve_int_bin_pred_arit_2
                            __field size 22 +: 2
                            __field H 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (H, U) of
                                when ('0', '0') => __encoding MUL_Z_P_ZZ__ // mul_z_p_zz_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', '0') => __encoding SMULH_Z_P_ZZ__ // smulh_z_p_zz_
                                when ('1', '1') => __encoding UMULH_Z_P_ZZ__ // umulh_z_p_zz_
                        when (_, _, _, '101', _, _, _) => // sve_int_bin_pred_div
                            __field size 22 +: 2
                            __field R 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, U) of
                                when ('0', '0') => __encoding SDIV_Z_P_ZZ__ // sdiv_z_p_zz_
                                when ('0', '1') => __encoding UDIV_Z_P_ZZ__ // udiv_z_p_zz_
                                when ('1', '0') => __encoding SDIVR_Z_P_ZZ__ // sdivr_z_p_zz_
                                when ('1', '1') => __encoding UDIVR_Z_P_ZZ__ // udivr_z_p_zz_
                        when (_, _, _, '11x', _, _, _) => // sve_int_bin_pred_log
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding ORR_Z_P_ZZ__ // orr_z_p_zz_
                                when ('001') => __encoding EOR_Z_P_ZZ__ // eor_z_p_zz_
                                when ('010') => __encoding AND_Z_P_ZZ__ // and_z_p_zz_
                                when ('011') => __encoding BIC_Z_P_ZZ__ // bic_z_p_zz_
                                when ('1xx') => __UNALLOCATED
                when ('000', _, '0xx0xxxxx001xxx', _, _, _) =>
                    // sve_int_pred_red
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '000', _, _, _) => // sve_int_reduce_0
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SADDV_R_P_Z__ // saddv_r_p_z_
                                when ('0', '1') => __encoding UADDV_R_P_Z__ // uaddv_r_p_z_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '001', _, _, _) => // sve_int_reduce_0q
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __UNALLOCATED
                                when ('0', '1') => __encoding ADDQV_Z_P_Z__ // addqv_z_p_z_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '010', _, _, _) => // sve_int_reduce_1
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SMAXV_R_P_Z__ // smaxv_r_p_z_
                                when ('0', '1') => __encoding UMAXV_R_P_Z__ // umaxv_r_p_z_
                                when ('1', '0') => __encoding SMINV_R_P_Z__ // sminv_r_p_z_
                                when ('1', '1') => __encoding UMINV_R_P_Z__ // uminv_r_p_z_
                        when (_, _, _, '011', _, _, _) => // sve_int_reduce_1q
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SMAXQV_Z_P_Z__ // smaxqv_z_p_z_
                                when ('0', '1') => __encoding UMAXQV_Z_P_Z__ // umaxqv_z_p_z_
                                when ('1', '0') => __encoding SMINQV_Z_P_Z__ // sminqv_z_p_z_
                                when ('1', '1') => __encoding UMINQV_Z_P_Z__ // uminqv_z_p_z_
                        when (_, _, _, '10x', _, _, _) => // sve_int_movprfx_pred
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field M 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding MOVPRFX_Z_P_Z__ // movprfx_z_p_z_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '110', _, _, _) => // sve_int_reduce_2
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ORV_R_P_Z__ // orv_r_p_z_
                                when ('01') => __encoding EORV_R_P_Z__ // eorv_r_p_z_
                                when ('10') => __encoding ANDV_R_P_Z__ // andv_r_p_z_
                                when ('11') => __UNALLOCATED
                        when (_, _, _, '111', _, _, _) => // sve_int_reduce_2q
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ORQV_Z_P_Z__ // orqv_z_p_z_
                                when ('01') => __encoding EORQV_Z_P_Z__ // eorqv_z_p_z_
                                when ('10') => __encoding ANDQV_Z_P_Z__ // andqv_z_p_z_
                                when ('11') => __UNALLOCATED
                when ('000', _, '0xx0xxxxx100xxx', _, _, _) =>
                    // sve_int_pred_shift
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '0x', _, _, _) => // sve_int_bin_pred_shift_0
                            __field tszh 22 +: 2
                            __field opc 18 +: 2
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field tszl 8 +: 2
                            __field imm3 5 +: 3
                            __field Zdn 0 +: 5
                            case (opc, L, U) of
                                when ('00', '0', '0') => __encoding ASR_Z_P_ZI__ // asr_z_p_zi_
                                when ('00', '0', '1') => __encoding LSR_Z_P_ZI__ // lsr_z_p_zi_
                                when ('00', '1', '0') => __UNALLOCATED
                                when ('00', '1', '1') => __encoding LSL_Z_P_ZI__ // lsl_z_p_zi_
                                when ('01', '0', '0') => __encoding ASRD_Z_P_ZI__ // asrd_z_p_zi_
                                when ('01', '0', '1') => __UNALLOCATED
                                when ('01', '1', '0') => __encoding SQSHL_Z_P_ZI__ // sqshl_z_p_zi_
                                when ('01', '1', '1') => __encoding UQSHL_Z_P_ZI__ // uqshl_z_p_zi_
                                when ('10', _, _) => __UNALLOCATED
                                when ('11', '0', '0') => __encoding SRSHR_Z_P_ZI__ // srshr_z_p_zi_
                                when ('11', '0', '1') => __encoding URSHR_Z_P_ZI__ // urshr_z_p_zi_
                                when ('11', '1', '0') => __UNALLOCATED
                                when ('11', '1', '1') => __encoding SQSHLU_Z_P_ZI__ // sqshlu_z_p_zi_
                        when (_, _, _, '10', _, _, _) => // sve_int_bin_pred_shift_1
                            __field size 22 +: 2
                            __field R 18 +: 1
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, L, U) of
                                when (_, '1', '0') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding ASR_Z_P_ZZ__ // asr_z_p_zz_
                                when ('0', '0', '1') => __encoding LSR_Z_P_ZZ__ // lsr_z_p_zz_
                                when ('0', '1', '1') => __encoding LSL_Z_P_ZZ__ // lsl_z_p_zz_
                                when ('1', '0', '0') => __encoding ASRR_Z_P_ZZ__ // asrr_z_p_zz_
                                when ('1', '0', '1') => __encoding LSRR_Z_P_ZZ__ // lsrr_z_p_zz_
                                when ('1', '1', '1') => __encoding LSLR_Z_P_ZZ__ // lslr_z_p_zz_
                        when (_, _, _, '11', _, _, _) => // sve_int_bin_pred_shift_2
                            __field size 22 +: 2
                            __field R 18 +: 1
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, L, U) of
                                when ('0', '0', '0') => __encoding ASR_Z_P_ZW__ // asr_z_p_zw_
                                when ('0', '0', '1') => __encoding LSR_Z_P_ZW__ // lsr_z_p_zw_
                                when ('0', '1', '0') => __UNALLOCATED
                                when ('0', '1', '1') => __encoding LSL_Z_P_ZW__ // lsl_z_p_zw_
                                when ('1', _, _) => __UNALLOCATED
                when ('000', _, '0xx0xxxxx101xxx', _, _, _) =>
                    // sve_int_pred_un
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '0x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10', _, _, _) => // sve_int_un_pred_arit_0
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding SXTB_Z_P_Z__ // sxtb_z_p_z_
                                when ('001') => __encoding UXTB_Z_P_Z__ // uxtb_z_p_z_
                                when ('010') => __encoding SXTH_Z_P_Z__ // sxth_z_p_z_
                                when ('011') => __encoding UXTH_Z_P_Z__ // uxth_z_p_z_
                                when ('100') => __encoding SXTW_Z_P_Z__ // sxtw_z_p_z_
                                when ('101') => __encoding UXTW_Z_P_Z__ // uxtw_z_p_z_
                                when ('110') => __encoding ABS_Z_P_Z__ // abs_z_p_z_
                                when ('111') => __encoding NEG_Z_P_Z__ // neg_z_p_z_
                        when (_, _, _, '11', _, _, _) => // sve_int_un_pred_arit_1
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding CLS_Z_P_Z__ // cls_z_p_z_
                                when ('001') => __encoding CLZ_Z_P_Z__ // clz_z_p_z_
                                when ('010') => __encoding CNT_Z_P_Z__ // cnt_z_p_z_
                                when ('011') => __encoding CNOT_Z_P_Z__ // cnot_z_p_z_
                                when ('100') => __encoding FABS_Z_P_Z__ // fabs_z_p_z_
                                when ('101') => __encoding FNEG_Z_P_Z__ // fneg_z_p_z_
                                when ('110') => __encoding NOT_Z_P_Z__ // not_z_p_z_
                                when ('111') => __UNALLOCATED
                when ('000', _, '0xx1xxxxx000xxx', _, _, _) => // sve_int_bin_cons_arit_0
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding ADD_Z_ZZ__ // add_z_zz_
                        when ('001') => __encoding SUB_Z_ZZ__ // sub_z_zz_
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding SQADD_Z_ZZ__ // sqadd_z_zz_
                        when ('101') => __encoding UQADD_Z_ZZ__ // uqadd_z_zz_
                        when ('110') => __encoding SQSUB_Z_ZZ__ // sqsub_z_zz_
                        when ('111') => __encoding UQSUB_Z_ZZ__ // uqsub_z_zz_
                when ('000', _, '0xx1xxxxx001xxx', _, _, _) =>
                    // sve_int_unpred_logical
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 0 +: 10) of
                        when (_, _, _, _, _, '0xx', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '100', _) => // sve_int_bin_cons_log
                            __field opc 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding AND_Z_ZZ__ // and_z_zz_
                                when ('01') => __encoding ORR_Z_ZZ__ // orr_z_zz_
                                when ('10') => __encoding EOR_Z_ZZ__ // eor_z_zz_
                                when ('11') => __encoding BIC_Z_ZZ__ // bic_z_zz_
                        when (_, _, _, _, _, '101', _) => // sve_int_rotate_imm
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding XAR_Z_ZZI__ // xar_z_zzi_
                        when (_, _, _, _, _, '11x', _) => // sve_int_tern_log
                            __field opc 22 +: 2
                            __field Zm 16 +: 5
                            __field o2 10 +: 1
                            __field Zk 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when ('00', '0') => __encoding EOR3_Z_ZZZ__ // eor3_z_zzz_
                                when ('00', '1') => __encoding BSL_Z_ZZZ__ // bsl_z_zzz_
                                when ('01', '0') => __encoding BCAX_Z_ZZZ__ // bcax_z_zzz_
                                when ('01', '1') => __encoding BSL1N_Z_ZZZ__ // bsl1n_z_zzz_
                                when ('1x', '0') => __UNALLOCATED
                                when ('10', '1') => __encoding BSL2N_Z_ZZZ__ // bsl2n_z_zzz_
                                when ('11', '1') => __encoding NBSL_Z_ZZZ__ // nbsl_z_zzz_
                when ('000', _, '0xx1xxxxx0100xx', _, _, _) =>
                    // sve_index
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 12 +: 4, 10 +: 2, 0 +: 10) of
                        when (_, _, _, _, _, '00', _) => // sve_int_index_ii
                            __field size 22 +: 2
                            __field imm5b 16 +: 5
                            __field imm5 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding INDEX_Z_II__ // index_z_ii_
                        when (_, _, _, _, _, '01', _) => // sve_int_index_ri
                            __field size 22 +: 2
                            __field imm5 16 +: 5
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding INDEX_Z_RI__ // index_z_ri_
                        when (_, _, _, _, _, '10', _) => // sve_int_index_ir
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field imm5 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding INDEX_Z_IR__ // index_z_ir_
                        when (_, _, _, _, _, '11', _) => // sve_int_index_rr
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding INDEX_Z_RR__ // index_z_rr_
                when ('000', _, '0xx1xxxxx0101xx', _, _, _) =>
                    // sve_alloca
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 12 +: 4, 11 +: 1, 0 +: 11) of
                        when (_, '0', _, _, _, _, '0', _) => // sve_int_arith_vl
                            __field op 22 +: 1
                            __field Rn 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op) of
                                when ('0') => __encoding ADDVL_R_RI__ // addvl_r_ri_
                                when ('1') => __encoding ADDPL_R_RI__ // addpl_r_ri_
                        when (_, '0', _, _, _, _, '1', _) => // sve_int_arith_svl
                            __field op 22 +: 1
                            __field Rn 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op) of
                                when ('0') => __encoding ADDSVL_R_RI__ // addsvl_r_ri_
                                when ('1') => __encoding ADDSPL_R_RI__ // addspl_r_ri_
                        when (_, '1', _, _, _, _, '0', _) => // sve_int_read_vl_a
                            __field op 22 +: 1
                            __field opc2 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op, opc2) of
                                when ('0', '0xxxx') => __UNALLOCATED
                                when ('0', '10xxx') => __UNALLOCATED
                                when ('0', '110xx') => __UNALLOCATED
                                when ('0', '1110x') => __UNALLOCATED
                                when ('0', '11110') => __UNALLOCATED
                                when ('0', '11111') => __encoding RDVL_R_I__ // rdvl_r_i_
                                when ('1', _) => __UNALLOCATED
                        when (_, '1', _, _, _, _, '1', _) => // sve_int_read_svl_a
                            __field op 22 +: 1
                            __field opc2 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op, opc2) of
                                when ('0', '0xxxx') => __UNALLOCATED
                                when ('0', '10xxx') => __UNALLOCATED
                                when ('0', '110xx') => __UNALLOCATED
                                when ('0', '1110x') => __UNALLOCATED
                                when ('0', '11110') => __UNALLOCATED
                                when ('0', '11111') => __encoding RDSVL_R_I__ // rdsvl_r_i_
                                when ('1', _) => __UNALLOCATED
                when ('000', _, '0xx1xxxxx011xxx', _, _, _) =>
                    // sve_int_unpred_arit_b
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 11 +: 2, 0 +: 11) of
                        when (_, _, _, _, _, '0x', _) => // sve_int_mul_b
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, opc) of
                                when (_, '00') => __encoding MUL_Z_ZZ__ // mul_z_zz_
                                when (_, '10') => __encoding SMULH_Z_ZZ__ // smulh_z_zz_
                                when (_, '11') => __encoding UMULH_Z_ZZ__ // umulh_z_zz_
                                when ('00', '01') => __encoding PMUL_Z_ZZ__ // pmul_z_zz_
                                when ('01', '01') => __UNALLOCATED
                                when ('1x', '01') => __UNALLOCATED
                        when (_, _, _, _, _, '10', _) => // sve_int_sqdmulh
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field R 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (R) of
                                when ('0') => __encoding SQDMULH_Z_ZZ__ // sqdmulh_z_zz_
                                when ('1') => __encoding SQRDMULH_Z_ZZ__ // sqrdmulh_z_zz_
                        when (_, _, _, _, _, '11', _) => __UNPREDICTABLE
                when ('000', _, '0xx1xxxxx100xxx', _, _, _) =>
                    // sve_int_unpred_shift
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 12 +: 1, 0 +: 12) of
                        when (_, _, _, _, _, '0', _) => // sve_int_bin_cons_shift_a
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ASR_Z_ZW__ // asr_z_zw_
                                when ('01') => __encoding LSR_Z_ZW__ // lsr_z_zw_
                                when ('10') => __UNALLOCATED
                                when ('11') => __encoding LSL_Z_ZW__ // lsl_z_zw_
                        when (_, _, _, _, _, '1', _) => // sve_int_bin_cons_shift_b
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ASR_Z_ZI__ // asr_z_zi_
                                when ('01') => __encoding LSR_Z_ZI__ // lsr_z_zi_
                                when ('10') => __UNALLOCATED
                                when ('11') => __encoding LSL_Z_ZI__ // lsl_z_zi_
                when ('000', _, '0xx1xxxxx1010xx', _, _, _) => // sve_int_bin_cons_misc_0_a
                    __field opc 22 +: 2
                    __field Zm 16 +: 5
                    __field msz 10 +: 2
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('00') => __encoding ADR_Z_AZ_D_s32_scaled // adr_z_az_d_s32_scaled
                        when ('01') => __encoding ADR_Z_AZ_D_u32_scaled // adr_z_az_d_u32_scaled
                        when ('1x') => __encoding ADR_Z_AZ_SD_same_scaled // adr_z_az_sd_same_scaled
                when ('000', _, '0xx1xxxxx1011xx', _, _, _) =>
                    // sve_int_unpred_misc
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 12 +: 4, 10 +: 2, 0 +: 10) of
                        when (_, _, _, _, _, '0x', _) => // sve_int_bin_cons_misc_0_b
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding FTSSEL_Z_ZZ__ // ftssel_z_zz_
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '10', _) => // sve_int_bin_cons_misc_0_c
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00000') => __encoding FEXPA_Z_Z__ // fexpa_z_z_
                                when ('00001') => __UNALLOCATED
                                when ('0001x') => __UNALLOCATED
                                when ('001xx') => __UNALLOCATED
                                when ('01xxx') => __UNALLOCATED
                                when ('1xxxx') => __UNALLOCATED
                        when (_, _, _, _, _, '11', _) => // sve_int_bin_cons_misc_0_d
                            __field opc 22 +: 2
                            __field opc2 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('00', '00000') => __encoding MOVPRFX_Z_Z__ // movprfx_z_z_
                                when ('00', '00001') => __UNALLOCATED
                                when ('00', '0001x') => __UNALLOCATED
                                when ('00', '001xx') => __UNALLOCATED
                                when ('00', '01xxx') => __UNALLOCATED
                                when ('00', '1xxxx') => __UNALLOCATED
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                when ('000', _, '0xx1xxxxx11xxxx', _, _, _) =>
                    // sve_countelt
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 16 +: 4, 14 +: 2, 11 +: 3, 0 +: 11) of
                        when (_, _, _, '0', _, _, '00x', _) => // sve_int_countvlv0
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 11 +: 1
                            __field U 10 +: 1
                            __field pattern 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, D, U) of
                                when ('00', _, _) => __UNALLOCATED
                                when ('01', '0', '0') => __encoding SQINCH_Z_ZS__ // sqinch_z_zs_
                                when ('01', '0', '1') => __encoding UQINCH_Z_ZS__ // uqinch_z_zs_
                                when ('01', '1', '0') => __encoding SQDECH_Z_ZS__ // sqdech_z_zs_
                                when ('01', '1', '1') => __encoding UQDECH_Z_ZS__ // uqdech_z_zs_
                                when ('10', '0', '0') => __encoding SQINCW_Z_ZS__ // sqincw_z_zs_
                                when ('10', '0', '1') => __encoding UQINCW_Z_ZS__ // uqincw_z_zs_
                                when ('10', '1', '0') => __encoding SQDECW_Z_ZS__ // sqdecw_z_zs_
                                when ('10', '1', '1') => __encoding UQDECW_Z_ZS__ // uqdecw_z_zs_
                                when ('11', '0', '0') => __encoding SQINCD_Z_ZS__ // sqincd_z_zs_
                                when ('11', '0', '1') => __encoding UQINCD_Z_ZS__ // uqincd_z_zs_
                                when ('11', '1', '0') => __encoding SQDECD_Z_ZS__ // sqdecd_z_zs_
                                when ('11', '1', '1') => __encoding UQDECD_Z_ZS__ // uqdecd_z_zs_
                        when (_, _, _, '0', _, _, '100', _) => // sve_int_count
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field op 10 +: 1
                            __field pattern 5 +: 5
                            __field Rd 0 +: 5
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when ('00', '0') => __encoding CNTB_R_S__ // cntb_r_s_
                                when ('01', '0') => __encoding CNTH_R_S__ // cnth_r_s_
                                when ('10', '0') => __encoding CNTW_R_S__ // cntw_r_s_
                                when ('11', '0') => __encoding CNTD_R_S__ // cntd_r_s_
                        when (_, _, _, '0', _, _, '101', _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, _, '000', _) => // sve_int_countvlv1
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 10 +: 1
                            __field pattern 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, D) of
                                when ('00', _) => __UNALLOCATED
                                when ('01', '0') => __encoding INCH_Z_ZS__ // inch_z_zs_
                                when ('01', '1') => __encoding DECH_Z_ZS__ // dech_z_zs_
                                when ('10', '0') => __encoding INCW_Z_ZS__ // incw_z_zs_
                                when ('10', '1') => __encoding DECW_Z_ZS__ // decw_z_zs_
                                when ('11', '0') => __encoding INCD_Z_ZS__ // incd_z_zs_
                                when ('11', '1') => __encoding DECD_Z_ZS__ // decd_z_zs_
                        when (_, _, _, '1', _, _, '100', _) => // sve_int_pred_pattern_a
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 10 +: 1
                            __field pattern 5 +: 5
                            __field Rdn 0 +: 5
                            case (size, D) of
                                when ('00', '0') => __encoding INCB_R_RS__ // incb_r_rs_
                                when ('00', '1') => __encoding DECB_R_RS__ // decb_r_rs_
                                when ('01', '0') => __encoding INCH_R_RS__ // inch_r_rs_
                                when ('01', '1') => __encoding DECH_R_RS__ // dech_r_rs_
                                when ('10', '0') => __encoding INCW_R_RS__ // incw_r_rs_
                                when ('10', '1') => __encoding DECW_R_RS__ // decw_r_rs_
                                when ('11', '0') => __encoding INCD_R_RS__ // incd_r_rs_
                                when ('11', '1') => __encoding DECD_R_RS__ // decd_r_rs_
                        when (_, _, _, '1', _, _, 'x01', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '01x', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '11x', _) => // sve_int_pred_pattern_b
                            __field size 22 +: 2
                            __field sf 20 +: 1
                            __field imm4 16 +: 4
                            __field D 11 +: 1
                            __field U 10 +: 1
                            __field pattern 5 +: 5
                            __field Rdn 0 +: 5
                            case (size, sf, D, U) of
                                when ('00', '0', '0', '0') => __encoding SQINCB_R_RS_SX // sqincb_r_rs_sx
                                when ('00', '0', '0', '1') => __encoding UQINCB_R_RS_UW // uqincb_r_rs_uw
                                when ('00', '0', '1', '0') => __encoding SQDECB_R_RS_SX // sqdecb_r_rs_sx
                                when ('00', '0', '1', '1') => __encoding UQDECB_R_RS_UW // uqdecb_r_rs_uw
                                when ('00', '1', '0', '0') => __encoding SQINCB_R_RS_X // sqincb_r_rs_x
                                when ('00', '1', '0', '1') => __encoding UQINCB_R_RS_X // uqincb_r_rs_x
                                when ('00', '1', '1', '0') => __encoding SQDECB_R_RS_X // sqdecb_r_rs_x
                                when ('00', '1', '1', '1') => __encoding UQDECB_R_RS_X // uqdecb_r_rs_x
                                when ('01', '0', '0', '0') => __encoding SQINCH_R_RS_SX // sqinch_r_rs_sx
                                when ('01', '0', '0', '1') => __encoding UQINCH_R_RS_UW // uqinch_r_rs_uw
                                when ('01', '0', '1', '0') => __encoding SQDECH_R_RS_SX // sqdech_r_rs_sx
                                when ('01', '0', '1', '1') => __encoding UQDECH_R_RS_UW // uqdech_r_rs_uw
                                when ('01', '1', '0', '0') => __encoding SQINCH_R_RS_X // sqinch_r_rs_x
                                when ('01', '1', '0', '1') => __encoding UQINCH_R_RS_X // uqinch_r_rs_x
                                when ('01', '1', '1', '0') => __encoding SQDECH_R_RS_X // sqdech_r_rs_x
                                when ('01', '1', '1', '1') => __encoding UQDECH_R_RS_X // uqdech_r_rs_x
                                when ('10', '0', '0', '0') => __encoding SQINCW_R_RS_SX // sqincw_r_rs_sx
                                when ('10', '0', '0', '1') => __encoding UQINCW_R_RS_UW // uqincw_r_rs_uw
                                when ('10', '0', '1', '0') => __encoding SQDECW_R_RS_SX // sqdecw_r_rs_sx
                                when ('10', '0', '1', '1') => __encoding UQDECW_R_RS_UW // uqdecw_r_rs_uw
                                when ('10', '1', '0', '0') => __encoding SQINCW_R_RS_X // sqincw_r_rs_x
                                when ('10', '1', '0', '1') => __encoding UQINCW_R_RS_X // uqincw_r_rs_x
                                when ('10', '1', '1', '0') => __encoding SQDECW_R_RS_X // sqdecw_r_rs_x
                                when ('10', '1', '1', '1') => __encoding UQDECW_R_RS_X // uqdecw_r_rs_x
                                when ('11', '0', '0', '0') => __encoding SQINCD_R_RS_SX // sqincd_r_rs_sx
                                when ('11', '0', '0', '1') => __encoding UQINCD_R_RS_UW // uqincd_r_rs_uw
                                when ('11', '0', '1', '0') => __encoding SQDECD_R_RS_SX // sqdecd_r_rs_sx
                                when ('11', '0', '1', '1') => __encoding UQDECD_R_RS_UW // uqdecd_r_rs_uw
                                when ('11', '1', '0', '0') => __encoding SQINCD_R_RS_X // sqincd_r_rs_x
                                when ('11', '1', '0', '1') => __encoding UQINCD_R_RS_X // uqincd_r_rs_x
                                when ('11', '1', '1', '0') => __encoding SQDECD_R_RS_X // sqdecd_r_rs_x
                                when ('11', '1', '1', '1') => __encoding UQDECD_R_RS_X // uqdecd_r_rs_x
                when ('000', _, '1xx00xxxxxxxxxx', _, _, _) =>
                    // sve_maskimm
                    case (24 +: 8, 22 +: 2, 20 +: 2, 18 +: 2, 0 +: 18) of
                        when (_, '11', _, '00', _) => // sve_int_dup_mask_imm
                            __field imm13 5 +: 13
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding DUPM_Z_I__ // dupm_z_i_
                        when (_, !'11', _, '00', _) => // sve_int_log_imm
                            __field opc 22 +: 2
                            __field imm13 5 +: 13
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ORR_Z_ZI__ // orr_z_zi_
                                when ('01') => __encoding EOR_Z_ZI__ // eor_z_zi_
                                when ('10') => __encoding AND_Z_ZI__ // and_z_zi_
                        when (_, _, _, !'00', _) => __UNPREDICTABLE
                when ('000', _, '1xx01xxxxxxxxxx', _, _, _) =>
                    // sve_wideimm_pred
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 13 +: 3, 0 +: 13) of
                        when (_, _, _, _, '0xx', _) => // sve_int_dup_imm_pred
                            __field size 22 +: 2
                            __field Pg 16 +: 4
                            __field M 14 +: 1
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (M) of
                                when ('0') => __encoding CPY_Z_O_I__ // cpy_z_o_i_
                                when ('1') => __encoding CPY_Z_P_I__ // cpy_z_p_i_
                        when (_, _, _, _, '10x', _) => __UNPREDICTABLE
                        when (_, _, _, _, '110', _) => // sve_int_dup_fpimm_pred
                            __field size 22 +: 2
                            __field Pg 16 +: 4
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding FCPY_Z_P_I__ // fcpy_z_p_i_
                        when (_, _, _, _, '111', _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxxx001000', _, _, _) => // sve_int_perm_dup_i
                    __field imm2 22 +: 2
                    __field tsz 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding DUP_Z_Zi__ // dup_z_zi_
                when ('000', _, '1xx1xxxxx001001', _, _, _) =>
                    // sve_perm_quads_a
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 16 +: 4, 10 +: 6, 0 +: 10) of
                        when (_, '00', _, _, _, _, _) => // sve_int_perm_dupq_i
                            __field i1 20 +: 1
                            __field tsz 16 +: 4
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding DUPQ_Z_Zi__ // dupq_z_zi_
                        when (_, '01', _, '0', _, _, _) => // sve_int_perm_extq
                            __field imm4 16 +: 4
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding EXTQ_Z_ZI_Des // extq_z_zi_des
                        when (_, '01', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1x', _, _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxxx00101x', _, _, _) => // sve_int_perm_tbl_3src
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field op 10 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (op) of
                        when ('0') => __encoding TBL_Z_ZZ_2 // tbl_z_zz_2
                        when ('1') => __encoding TBX_Z_ZZ__ // tbx_z_zz_
                when ('000', _, '1xx1xxxxx001100', _, _, _) => // sve_int_perm_tbl
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding TBL_Z_ZZ_1 // tbl_z_zz_1
                when ('000', _, '1xx1xxxxx001101', _, _, _) => // sve_int_perm_tbxquads
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding TBXQ_Z_ZZ__ // tbxq_z_zz_
                when ('000', _, '1xx1xxxxx001110', _, _, _) =>
                    // sve_perm_unpred_d
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 10 +: 6, 9 +: 1, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '00', '000', _, _, _, _, _) => // sve_int_perm_dup_r
                            __field size 22 +: 2
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding DUP_Z_R__ // dup_z_r_
                        when (_, _, _, '00', '100', _, _, _, _, _) => // sve_int_perm_insrs
                            __field size 22 +: 2
                            __field Rm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding INSR_Z_R__ // insr_z_r_
                        when (_, _, _, '00', 'x10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'xx1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '01', 'xx0', _, _, _, '0', _) => // sve_int_mov_v2p
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field Zn 5 +: 5
                            __field Pd 0 +: 4
                            case (opc, opc2) of
                                when ('00', '00') => __UNALLOCATED
                                when ('00', '01') => __encoding PMOV_P_ZI_B // pmov_p_zi_b
                                when ('00', '1x') => __encoding PMOV_P_ZI_H // pmov_p_zi_h
                                when ('01', _) => __encoding PMOV_P_ZI_S // pmov_p_zi_s
                                when ('1x', _) => __encoding PMOV_P_ZI_D // pmov_p_zi_d
                        when (_, _, _, '01', 'xx0', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '01', 'xx1', _, '0', _, _, _) => // sve_int_mov_p2v
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field Pn 5 +: 4
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('00', '00') => __UNALLOCATED
                                when ('00', '01') => __encoding PMOV_Z_PI_B // pmov_z_pi_b
                                when ('00', '1x') => __encoding PMOV_Z_PI_H // pmov_z_pi_h
                                when ('01', _) => __encoding PMOV_Z_PI_S // pmov_z_pi_s
                                when ('1x', _) => __encoding PMOV_Z_PI_D // pmov_z_pi_d
                        when (_, _, _, '01', 'xx1', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10', '0xx', _, _, _, _, _) => // sve_int_perm_unpk
                            __field size 22 +: 2
                            __field U 17 +: 1
                            __field H 16 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (U, H) of
                                when ('0', '0') => __encoding SUNPKLO_Z_Z__ // sunpklo_z_z_
                                when ('0', '1') => __encoding SUNPKHI_Z_Z__ // sunpkhi_z_z_
                                when ('1', '0') => __encoding UUNPKLO_Z_Z__ // uunpklo_z_z_
                                when ('1', '1') => __encoding UUNPKHI_Z_Z__ // uunpkhi_z_z_
                        when (_, _, _, '10', '100', _, _, _, _, _) => // sve_int_perm_insrv
                            __field size 22 +: 2
                            __field Vm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding INSR_Z_V__ // insr_z_v_
                        when (_, _, _, '10', '110', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10', '1x1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '11', '000', _, _, _, _, _) => // sve_int_perm_reverse_z
                            __field size 22 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding REV_Z_Z__ // rev_z_z_
                        when (_, _, _, '11', !'000', _, _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxxx001111', _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxxx010xxx', _, _, _) =>
                    // sve_perm_predicates
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 9 +: 4, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, '00', _, '1000x', _, '0000', _, '0', _) => // sve_int_perm_punpk
                            __field H 16 +: 1
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case (H) of
                                when ('0') => __encoding PUNPKLO_P_P__ // punpklo_p_p_
                                when ('1') => __encoding PUNPKHI_P_P__ // punpkhi_p_p_
                        when (_, '01', _, '1000x', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, '10', _, '1000x', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, '11', _, '1000x', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0xxxx', _, 'xxx0', _, '0', _) => // sve_int_perm_bin_perm_pp
                            __field size 22 +: 2
                            __field Pm 16 +: 4
                            __field opc 11 +: 2
                            __field H 10 +: 1
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case (opc, H) of
                                when ('00', '0') => __encoding ZIP1_P_PP__ // zip1_p_pp_
                                when ('00', '1') => __encoding ZIP2_P_PP__ // zip2_p_pp_
                                when ('01', '0') => __encoding UZP1_P_PP__ // uzp1_p_pp_
                                when ('01', '1') => __encoding UZP2_P_PP__ // uzp2_p_pp_
                                when ('10', '0') => __encoding TRN1_P_PP__ // trn1_p_pp_
                                when ('10', '1') => __encoding TRN2_P_PP__ // trn2_p_pp_
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '0xxxx', _, 'xxx1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10100', _, '0000', _, '0', _) => // sve_int_perm_reverse_p
                            __field size 22 +: 2
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case () of
                                when () => __encoding REV_P_P__ // rev_p_p_
                        when (_, _, _, '10101', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, '1000', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, 'x100', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, 'xx10', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, 'xxx1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x1x', _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '11xxx', _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '1', _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxxx011xxx', _, _, _) => // sve_int_perm_bin_perm_zz
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding ZIP1_Z_ZZ__ // zip1_z_zz_
                        when ('001') => __encoding ZIP2_Z_ZZ__ // zip2_z_zz_
                        when ('010') => __encoding UZP1_Z_ZZ__ // uzp1_z_zz_
                        when ('011') => __encoding UZP2_Z_ZZ__ // uzp2_z_zz_
                        when ('100') => __encoding TRN1_Z_ZZ__ // trn1_z_zz_
                        when ('101') => __encoding TRN2_Z_ZZ__ // trn2_z_zz_
                        when ('11x') => __UNALLOCATED
                when ('000', _, '1xx1xxxxx10xxxx', _, _, _) =>
                    // sve_perm_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 17 +: 3, 16 +: 1, 14 +: 2, 13 +: 1, 0 +: 13) of
                        when (_, _, _, '0', '000', '0', _, '0', _) => // sve_int_perm_cpy_v
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Vn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding CPY_Z_P_V__ // cpy_z_p_v_
                        when (_, _, _, '0', '000', '1', _, '0', _) => // sve_int_perm_compact
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding COMPACT_Z_P_Z__ // compact_z_p_z_
                        when (_, _, _, '0', '000', _, _, '1', _) => // sve_int_perm_last_r
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Rd 0 +: 5
                            case (B) of
                                when ('0') => __encoding LASTA_R_P_Z__ // lasta_r_p_z_
                                when ('1') => __encoding LASTB_R_P_Z__ // lastb_r_p_z_
                        when (_, _, _, '0', '001', _, _, '0', _) => // sve_int_perm_last_v
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (B) of
                                when ('0') => __encoding LASTA_V_P_Z__ // lasta_v_p_z_
                                when ('1') => __encoding LASTB_V_P_Z__ // lastb_v_p_z_
                        when (_, _, _, '0', '01x', _, _, '0', _) => // sve_int_perm_rev
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding REVB_Z_Z__ // revb_z_z_
                                when ('01') => __encoding REVH_Z_Z__ // revh_z_z_
                                when ('10') => __encoding REVW_Z_Z__ // revw_z_z_
                                when ('11') => __encoding RBIT_Z_P_Z__ // rbit_z_p_z_
                        when (_, _, _, '0', '01x', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '100', '0', _, '1', _) => // sve_int_perm_cpy_r
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding CPY_Z_P_R__ // cpy_z_p_r_
                        when (_, _, _, '0', '100', '1', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '100', _, _, '0', _) => // sve_int_perm_clast_zz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding CLASTA_Z_P_ZZ__ // clasta_z_p_zz_
                                when ('1') => __encoding CLASTB_Z_P_ZZ__ // clastb_z_p_zz_
                        when (_, _, _, '0', '101', _, _, '0', _) => // sve_int_perm_clast_vz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Vdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding CLASTA_V_P_Z__ // clasta_v_p_z_
                                when ('1') => __encoding CLASTB_V_P_Z__ // clastb_v_p_z_
                        when (_, _, _, '0', '110', '0', _, '0', _) => // sve_int_perm_splice
                            __field size 22 +: 2
                            __field Pv 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding SPLICE_Z_P_ZZ_Des // splice_z_p_zz_des
                        when (_, _, _, '0', '110', '1', _, '0', _) => // sve_intx_perm_splice
                            __field size 22 +: 2
                            __field Pv 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding SPLICE_Z_P_ZZ_Con // splice_z_p_zz_con
                        when (_, _, _, '0', '110', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '111', '0', _, '0', _) => // sve_int_perm_revd
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size) of
                                when ('00') => __encoding REVD_Z_P_Z__ // revd_z_p_z_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '0', '111', '0', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '111', '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', 'x01', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '1', '000', _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1', '000', _, _, '1', _) => // sve_int_perm_clast_rz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Rdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding CLASTA_R_P_Z__ // clasta_r_p_z_
                                when ('1') => __encoding CLASTB_R_P_Z__ // clastb_r_p_z_
                        when (_, _, _, '1', !'000', _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxxx11xxxx', _, _, _) => // sve_int_sel_vvv
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pv 10 +: 4
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding SEL_Z_P_ZZ__ // sel_z_p_zz_
                when ('000', _, '10x1xxxxx000xxx', _, _, _) =>
                    // sve_perm_extract
                    case (23 +: 9, 22 +: 1, 21 +: 1, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, '0', _, _, _, _) => // sve_int_perm_extract_i
                            __field imm8h 16 +: 5
                            __field imm8l 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding EXT_Z_ZI_Des // ext_z_zi_des
                        when (_, '1', _, _, _, _) => // sve_intx_perm_extract_i
                            __field imm8h 16 +: 5
                            __field imm8l 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding EXT_Z_ZI_Con // ext_z_zi_con
                when ('000', _, '11x1xxxxx000xxx', _, _, _) =>
                    // sve_perm_inter_long
                    case (23 +: 9, 22 +: 1, 21 +: 1, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, '0', _, _, _, _) => // sve_int_perm_bin_long_perm_zz
                            __field Zm 16 +: 5
                            __field opc 11 +: 2
                            __field H 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, H) of
                                when ('00', '0') => __encoding ZIP1_Z_ZZ_Q // zip1_z_zz_q
                                when ('00', '1') => __encoding ZIP2_Z_ZZ_Q // zip2_z_zz_q
                                when ('01', '0') => __encoding UZP1_Z_ZZ_Q // uzp1_z_zz_q
                                when ('01', '1') => __encoding UZP2_Z_ZZ_Q // uzp2_z_zz_q
                                when ('10', _) => __UNALLOCATED
                                when ('11', '0') => __encoding TRN1_Z_ZZ_Q // trn1_z_zz_q
                                when ('11', '1') => __encoding TRN2_Z_ZZ_Q // trn2_z_zz_q
                        when (_, '1', _, _, _, _) => __UNPREDICTABLE
                when ('001', _, '0xx0xxxxxxxxxxx', _, _, _) =>
                    // sve_cmpvec
                    case (24 +: 8, 22 +: 2, 21 +: 1, 15 +: 6, 14 +: 1, 0 +: 14) of
                        when (_, _, _, _, '0', _) => // sve_int_cmp_0
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 15 +: 1
                            __field o2 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (op, o2, ne) of
                                when ('0', '0', '0') => __encoding CMPHS_P_P_ZZ__ // cmphs_p_p_zz_
                                when ('0', '0', '1') => __encoding CMPHI_P_P_ZZ__ // cmphi_p_p_zz_
                                when ('0', '1', '0') => __encoding CMPEQ_P_P_ZW__ // cmpeq_p_p_zw_
                                when ('0', '1', '1') => __encoding CMPNE_P_P_ZW__ // cmpne_p_p_zw_
                                when ('1', '0', '0') => __encoding CMPGE_P_P_ZZ__ // cmpge_p_p_zz_
                                when ('1', '0', '1') => __encoding CMPGT_P_P_ZZ__ // cmpgt_p_p_zz_
                                when ('1', '1', '0') => __encoding CMPEQ_P_P_ZZ__ // cmpeq_p_p_zz_
                                when ('1', '1', '1') => __encoding CMPNE_P_P_ZZ__ // cmpne_p_p_zz_
                        when (_, _, _, _, '1', _) => // sve_int_cmp_1
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 15 +: 1
                            __field lt 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (U, lt, ne) of
                                when ('0', '0', '0') => __encoding CMPGE_P_P_ZW__ // cmpge_p_p_zw_
                                when ('0', '0', '1') => __encoding CMPGT_P_P_ZW__ // cmpgt_p_p_zw_
                                when ('0', '1', '0') => __encoding CMPLT_P_P_ZW__ // cmplt_p_p_zw_
                                when ('0', '1', '1') => __encoding CMPLE_P_P_ZW__ // cmple_p_p_zw_
                                when ('1', '0', '0') => __encoding CMPHS_P_P_ZW__ // cmphs_p_p_zw_
                                when ('1', '0', '1') => __encoding CMPHI_P_P_ZW__ // cmphi_p_p_zw_
                                when ('1', '1', '0') => __encoding CMPLO_P_P_ZW__ // cmplo_p_p_zw_
                                when ('1', '1', '1') => __encoding CMPLS_P_P_ZW__ // cmpls_p_p_zw_
                when ('001', _, '0xx1xxxxxxxxxxx', _, _, _) => // sve_int_ucmp_vi
                    __field size 22 +: 2
                    __field imm7 14 +: 7
                    __field lt 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field ne 4 +: 1
                    __field Pd 0 +: 4
                    case (lt, ne) of
                        when ('0', '0') => __encoding CMPHS_P_P_ZI__ // cmphs_p_p_zi_
                        when ('0', '1') => __encoding CMPHI_P_P_ZI__ // cmphi_p_p_zi_
                        when ('1', '0') => __encoding CMPLO_P_P_ZI__ // cmplo_p_p_zi_
                        when ('1', '1') => __encoding CMPLS_P_P_ZI__ // cmpls_p_p_zi_
                when ('001', _, '1xx0xxxxxx0xxxx', _, _, _) => // sve_int_scmp_vi
                    __field size 22 +: 2
                    __field imm5 16 +: 5
                    __field op 15 +: 1
                    __field o2 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field ne 4 +: 1
                    __field Pd 0 +: 4
                    case (op, o2, ne) of
                        when ('0', '0', '0') => __encoding CMPGE_P_P_ZI__ // cmpge_p_p_zi_
                        when ('0', '0', '1') => __encoding CMPGT_P_P_ZI__ // cmpgt_p_p_zi_
                        when ('0', '1', '0') => __encoding CMPLT_P_P_ZI__ // cmplt_p_p_zi_
                        when ('0', '1', '1') => __encoding CMPLE_P_P_ZI__ // cmple_p_p_zi_
                        when ('1', '0', '0') => __encoding CMPEQ_P_P_ZI__ // cmpeq_p_p_zi_
                        when ('1', '0', '1') => __encoding CMPNE_P_P_ZI__ // cmpne_p_p_zi_
                        when ('1', '1', _) => __UNALLOCATED
                when ('001', _, '1xx00xxxx01xxxx', _, _, _) => // sve_int_pred_log
                    __field op 23 +: 1
                    __field S 22 +: 1
                    __field Pm 16 +: 4
                    __field Pg 10 +: 4
                    __field o2 9 +: 1
                    __field Pn 5 +: 4
                    __field o3 4 +: 1
                    __field Pd 0 +: 4
                    case (op, S, o2, o3) of
                        when ('0', '0', '0', '0') => __encoding AND_P_P_PP_Z // and_p_p_pp_z
                        when ('0', '0', '0', '1') => __encoding BIC_P_P_PP_Z // bic_p_p_pp_z
                        when ('0', '0', '1', '0') => __encoding EOR_P_P_PP_Z // eor_p_p_pp_z
                        when ('0', '0', '1', '1') => __encoding SEL_P_P_PP__ // sel_p_p_pp_
                        when ('0', '1', '0', '0') => __encoding ANDS_P_P_PP_Z // ands_p_p_pp_z
                        when ('0', '1', '0', '1') => __encoding BICS_P_P_PP_Z // bics_p_p_pp_z
                        when ('0', '1', '1', '0') => __encoding EORS_P_P_PP_Z // eors_p_p_pp_z
                        when ('0', '1', '1', '1') => __UNALLOCATED
                        when ('1', '0', '0', '0') => __encoding ORR_P_P_PP_Z // orr_p_p_pp_z
                        when ('1', '0', '0', '1') => __encoding ORN_P_P_PP_Z // orn_p_p_pp_z
                        when ('1', '0', '1', '0') => __encoding NOR_P_P_PP_Z // nor_p_p_pp_z
                        when ('1', '0', '1', '1') => __encoding NAND_P_P_PP_Z // nand_p_p_pp_z
                        when ('1', '1', '0', '0') => __encoding ORRS_P_P_PP_Z // orrs_p_p_pp_z
                        when ('1', '1', '0', '1') => __encoding ORNS_P_P_PP_Z // orns_p_p_pp_z
                        when ('1', '1', '1', '0') => __encoding NORS_P_P_PP_Z // nors_p_p_pp_z
                        when ('1', '1', '1', '1') => __encoding NANDS_P_P_PP_Z // nands_p_p_pp_z
                when ('001', _, '1xx00xxxx11xxxx', _, _, _) =>
                    // sve_pred_gen_b
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 14 +: 2, 10 +: 4, 9 +: 1, 0 +: 9) of
                        when (_, _, _, _, _, _, '0', _) => // sve_int_brkp
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pm 16 +: 4
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field B 4 +: 1
                            __field Pd 0 +: 4
                            case (op, S, B) of
                                when ('0', '0', '0') => __encoding BRKPA_P_P_PP__ // brkpa_p_p_pp_
                                when ('0', '0', '1') => __encoding BRKPB_P_P_PP__ // brkpb_p_p_pp_
                                when ('0', '1', '0') => __encoding BRKPAS_P_P_PP__ // brkpas_p_p_pp_
                                when ('0', '1', '1') => __encoding BRKPBS_P_P_PP__ // brkpbs_p_p_pp_
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, _, _, _, '1', _) => __UNPREDICTABLE
                when ('001', _, '1xx01xxxx01xxxx', _, _, _) =>
                    // sve_pred_gen_c
                    case (24 +: 8, 23 +: 1, 22 +: 1, 20 +: 2, 16 +: 4, 14 +: 2, 10 +: 4, 9 +: 1, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, '1000', _, _, '0', _, '0', _) => // sve_int_brkn
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field Pdm 0 +: 4
                            case (S) of
                                when ('0') => __encoding BRKN_P_P_PP__ // brkn_p_p_pp_
                                when ('1') => __encoding BRKNS_P_P_PP__ // brkns_p_p_pp_
                        when (_, '0', _, _, '1000', _, _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x000', _, _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x1xx', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'xx1x', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'xxx1', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, '0000', _, _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, !'0000', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '0000', _, _, '0', _, _, _) => // sve_int_break
                            __field B 23 +: 1
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field M 4 +: 1
                            __field Pd 0 +: 4
                            case (B, S, M) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', _) => __encoding BRKA_P_P_P__ // brka_p_p_p_
                                when ('0', '1', '0') => __encoding BRKAS_P_P_P_Z // brkas_p_p_p_z
                                when ('1', '0', _) => __encoding BRKB_P_P_P__ // brkb_p_p_p_
                                when ('1', '1', '0') => __encoding BRKBS_P_P_P_Z // brkbs_p_p_p_z
                when ('001', _, '1xx01xxxx11xxxx', _, _, _) =>
                    // sve_pred_gen_d
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 14 +: 2, 11 +: 3, 9 +: 2, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0000', _, _, 'x0', _, '0', _) => // sve_int_ptest
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field opc2 0 +: 4
                            case (op, S, opc2) of
                                when ('0', '0', _) => __UNALLOCATED
                                when ('0', '1', '0000') => __encoding PTEST__P_P__ // ptest_p_p_
                                when ('0', '1', '0001') => __UNALLOCATED
                                when ('0', '1', '001x') => __UNALLOCATED
                                when ('0', '1', '01xx') => __UNALLOCATED
                                when ('0', '1', '1xxx') => __UNALLOCATED
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, '0100', _, _, 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0x10', _, _, 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0xx1', _, _, 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0xxx', _, _, 'x1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '000', '00', _, '0', _) => // sve_int_pfirst
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 5 +: 4
                            __field Pdn 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __UNALLOCATED
                                when ('0', '1') => __encoding PFIRST_P_P_P__ // pfirst_p_p_p_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1000', _, '000', !'00', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '100', '10', '0000', '0', _) => // sve_int_pfalse
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding PFALSE_P__ // pfalse_p_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1000', _, '100', '10', !'0000', '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '110', '00', _, '0', _) => // sve_int_rdffr
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 5 +: 4
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding RDFFR_P_P_F__ // rdffr_p_p_f_
                                when ('0', '1') => __encoding RDFFRS_P_P_F__ // rdffrs_p_p_f_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1001', _, '000', '0x', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1001', _, '000', '10', _, '0', _) => // sve_int_pnext
                            __field size 22 +: 2
                            __field Pv 5 +: 4
                            __field Pdn 0 +: 4
                            case () of
                                when () => __encoding PNEXT_P_P_P__ // pnext_p_p_p_
                        when (_, _, _, '1001', _, '000', '11', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1001', _, '100', '10', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1001', _, '110', '00', '0000', '0', _) => // sve_int_rdffr_2
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding RDFFR_P_F__ // rdffr_p_f_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1001', _, '110', '00', !'0000', '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '010', _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '100', '0x', _, '0', _) => // sve_int_ptrue
                            __field size 22 +: 2
                            __field S 16 +: 1
                            __field pattern 5 +: 5
                            __field Pd 0 +: 4
                            case (S) of
                                when ('0') => __encoding PTRUE_P_S__ // ptrue_p_s_
                                when ('1') => __encoding PTRUES_P_S__ // ptrues_p_s_
                        when (_, _, _, '100x', _, '100', '11', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '110', !'00', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, 'xx1', _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '110x', _, _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1x1x', _, _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, _, '1', _) => __UNPREDICTABLE
                when ('001', _, '1xx1xxxxx00xxxx', _, _, _) =>
                    // sve_cmpgpr
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 14 +: 2, 12 +: 2, 10 +: 2, 4 +: 6, 0 +: 4) of
                        when (_, _, _, _, _, '0x', _, _, _) => // sve_int_while_rr
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field sf 12 +: 1
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field eq 4 +: 1
                            __field Pd 0 +: 4
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding WHILEGE_P_P_RR__ // whilege_p_p_rr_
                                when ('0', '0', '1') => __encoding WHILEGT_P_P_RR__ // whilegt_p_p_rr_
                                when ('0', '1', '0') => __encoding WHILELT_P_P_RR__ // whilelt_p_p_rr_
                                when ('0', '1', '1') => __encoding WHILELE_P_P_RR__ // whilele_p_p_rr_
                                when ('1', '0', '0') => __encoding WHILEHS_P_P_RR__ // whilehs_p_p_rr_
                                when ('1', '0', '1') => __encoding WHILEHI_P_P_RR__ // whilehi_p_p_rr_
                                when ('1', '1', '0') => __encoding WHILELO_P_P_RR__ // whilelo_p_p_rr_
                                when ('1', '1', '1') => __encoding WHILELS_P_P_RR__ // whilels_p_p_rr_
                        when (_, _, _, _, _, '10', '00', _, '0000') => // sve_int_cterm
                            __field op 23 +: 1
                            __field sz 22 +: 1
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field ne 4 +: 1
                            case (op, ne) of
                                when ('0', _) => __UNALLOCATED
                                when ('1', '0') => __encoding CTERMEQ_RR__ // ctermeq_rr_
                                when ('1', '1') => __encoding CTERMNE_RR__ // ctermne_rr_
                        when (_, _, _, _, _, '10', '00', _, !'0000') => __UNPREDICTABLE
                        when (_, _, _, _, _, '11', '00', _, _) => // sve_int_whilenc
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field rw 4 +: 1
                            __field Pd 0 +: 4
                            case (rw) of
                                when ('0') => __encoding WHILEWR_P_RR__ // whilewr_p_rr_
                                when ('1') => __encoding WHILERW_P_RR__ // whilerw_p_rr_
                        when (_, _, _, _, _, '1x', !'00', _, _) => __UNPREDICTABLE
                when ('001', _, '1xx1xxxxx01xxxx', _, '0', _) => // sve_int_pred_dup
                    __field i1 23 +: 1
                    __field tszh 22 +: 1
                    __field tszl 18 +: 3
                    __field Rv 16 +: 2
                    __field Pn 10 +: 4
                    __field S 9 +: 1
                    __field Pm 5 +: 4
                    __field Pd 0 +: 4
                    case (S) of
                        when ('0') => __encoding PSEL_P_PPi__ // psel_p_ppi_
                        when ('1') => __UNALLOCATED
                when ('001', _, '1xx1xxxxx01xxxx', _, '1', _) =>
                    // sve_while_pn
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 14 +: 2, 11 +: 3, 5 +: 6, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, _, _, '00000', _, '110', _, _, _, _) => // sve_int_ctr_to_mask
                            __field size 22 +: 2
                            __field opc 8 +: 3
                            __field PNn 5 +: 3
                            __field Pd 0 +: 4
                            case (opc) of
                                when ('0xx') => __encoding PEXT_PN_RR__ // pext_pn_rr_
                                when ('10x') => __encoding PEXT_PP_RR__ // pext_pp_rr_
                                when ('11x') => __UNALLOCATED
                        when (_, _, _, '00000', _, '111', '000000', _, '0', _) => // sve_int_pn_ptrue
                            __field size 22 +: 2
                            __field PNd 0 +: 3
                            case () of
                                when () => __encoding PTRUE_PN_I__ // ptrue_pn_i_
                        when (_, _, _, '00000', _, '111', '000000', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '00000', _, '111', !'000000', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00000', _, '11x', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '01x', _, _, _, _) => // sve_int_while_rr_pair
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field Pd 1 +: 3
                            __field eq 0 +: 1
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding WHILEGE_PP_RR__ // whilege_pp_rr_
                                when ('0', '0', '1') => __encoding WHILEGT_PP_RR__ // whilegt_pp_rr_
                                when ('0', '1', '0') => __encoding WHILELT_PP_RR__ // whilelt_pp_rr_
                                when ('0', '1', '1') => __encoding WHILELE_PP_RR__ // whilele_pp_rr_
                                when ('1', '0', '0') => __encoding WHILEHS_PP_RR__ // whilehs_pp_rr_
                                when ('1', '0', '1') => __encoding WHILEHI_PP_RR__ // whilehi_pp_rr_
                                when ('1', '1', '0') => __encoding WHILELO_PP_RR__ // whilelo_pp_rr_
                                when ('1', '1', '1') => __encoding WHILELS_PP_RR__ // whilels_pp_rr_
                        when (_, _, _, _, _, 'x0x', _, _, _, _) => // sve_int_while_rr_pn
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field vl 13 +: 1
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field eq 3 +: 1
                            __field PNd 0 +: 3
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding WHILEGE_PN_RR__ // whilege_pn_rr_
                                when ('0', '0', '1') => __encoding WHILEGT_PN_RR__ // whilegt_pn_rr_
                                when ('0', '1', '0') => __encoding WHILELT_PN_RR__ // whilelt_pn_rr_
                                when ('0', '1', '1') => __encoding WHILELE_PN_RR__ // whilele_pn_rr_
                                when ('1', '0', '0') => __encoding WHILEHS_PN_RR__ // whilehs_pn_rr_
                                when ('1', '0', '1') => __encoding WHILEHI_PN_RR__ // whilehi_pn_rr_
                                when ('1', '1', '0') => __encoding WHILELO_PN_RR__ // whilelo_pn_rr_
                                when ('1', '1', '1') => __encoding WHILELS_PN_RR__ // whilels_pn_rr_
                when ('001', _, '1xx1xxxxx11xxxx', _, _, _) =>
                    // sve_wideimm_unpred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 17 +: 2, 16 +: 1, 14 +: 2, 0 +: 14) of
                        when (_, _, _, '00', _, _, _, _) => // sve_int_arith_imm0
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding ADD_Z_ZI__ // add_z_zi_
                                when ('001') => __encoding SUB_Z_ZI__ // sub_z_zi_
                                when ('010') => __UNALLOCATED
                                when ('011') => __encoding SUBR_Z_ZI__ // subr_z_zi_
                                when ('100') => __encoding SQADD_Z_ZI__ // sqadd_z_zi_
                                when ('101') => __encoding UQADD_Z_ZI__ // uqadd_z_zi_
                                when ('110') => __encoding SQSUB_Z_ZI__ // sqsub_z_zi_
                                when ('111') => __encoding UQSUB_Z_ZI__ // uqsub_z_zi_
                        when (_, _, _, '01', _, _, _, _) => // sve_int_arith_imm1
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when ('0xx', '1') => __UNALLOCATED
                                when ('000', '0') => __encoding SMAX_Z_ZI__ // smax_z_zi_
                                when ('001', '0') => __encoding UMAX_Z_ZI__ // umax_z_zi_
                                when ('010', '0') => __encoding SMIN_Z_ZI__ // smin_z_zi_
                                when ('011', '0') => __encoding UMIN_Z_ZI__ // umin_z_zi_
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, '10', _, _, _, _) => // sve_int_arith_imm2
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when ('000', '0') => __encoding MUL_Z_ZI__ // mul_z_zi_
                                when ('000', '1') => __UNALLOCATED
                                when ('001', _) => __UNALLOCATED
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, '11', _, '0', _, _) => // sve_int_dup_imm
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding DUP_Z_I__ // dup_z_i_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '11', _, '1', _, _) => // sve_int_dup_fpimm
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (opc, o2) of
                                when ('00', '0') => __encoding FDUP_Z_I__ // fdup_z_i_
                                when ('00', '1') => __UNALLOCATED
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                when ('001', _, '1xx100xxx10xxxx', _, _, _) =>
                    // sve_pred_count_a
                    case (24 +: 8, 22 +: 2, 19 +: 3, 16 +: 3, 14 +: 2, 11 +: 3, 10 +: 1, 9 +: 1, 0 +: 9) of
                        when (_, _, _, _, _, '000', _, '1', _) => // sve_int_pcount_pn
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field vl 10 +: 1
                            __field PNn 5 +: 4
                            __field Rd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding CNTP_R_PN__ // cntp_r_pn_
                                when ('001') => __UNALLOCATED
                                when ('01x') => __UNALLOCATED
                                when ('1xx') => __UNALLOCATED
                        when (_, _, _, _, _, !'000', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '0', _) => // sve_int_pcount_pred
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field Rd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding CNTP_R_P_P__ // cntp_r_p_p_
                                when ('001') => __UNALLOCATED
                                when ('01x') => __UNALLOCATED
                                when ('1xx') => __UNALLOCATED
                when ('001', _, '1xx101xxx1000xx', _, _, _) =>
                    // sve_pred_count_b
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 12 +: 4, 11 +: 1, 0 +: 11) of
                        when (_, _, _, '0', _, _, '0', _) => // sve_int_count_v_sat
                            __field size 22 +: 2
                            __field D 17 +: 1
                            __field U 16 +: 1
                            __field opc 9 +: 2
                            __field Pm 5 +: 4
                            __field Zdn 0 +: 5
                            case (D, U, opc) of
                                when (_, _, '01') => __UNALLOCATED
                                when (_, _, '1x') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding SQINCP_Z_P_Z__ // sqincp_z_p_z_
                                when ('0', '1', '00') => __encoding UQINCP_Z_P_Z__ // uqincp_z_p_z_
                                when ('1', '0', '00') => __encoding SQDECP_Z_P_Z__ // sqdecp_z_p_z_
                                when ('1', '1', '00') => __encoding UQDECP_Z_P_Z__ // uqdecp_z_p_z_
                        when (_, _, _, '0', _, _, '1', _) => // sve_int_count_r_sat
                            __field size 22 +: 2
                            __field D 17 +: 1
                            __field U 16 +: 1
                            __field sf 10 +: 1
                            __field op 9 +: 1
                            __field Pm 5 +: 4
                            __field Rdn 0 +: 5
                            case (D, U, sf, op) of
                                when (_, _, _, '1') => __UNALLOCATED
                                when ('0', '0', '0', '0') => __encoding SQINCP_R_P_R_SX // sqincp_r_p_r_sx
                                when ('0', '0', '1', '0') => __encoding SQINCP_R_P_R_X // sqincp_r_p_r_x
                                when ('0', '1', '0', '0') => __encoding UQINCP_R_P_R_UW // uqincp_r_p_r_uw
                                when ('0', '1', '1', '0') => __encoding UQINCP_R_P_R_X // uqincp_r_p_r_x
                                when ('1', '0', '0', '0') => __encoding SQDECP_R_P_R_SX // sqdecp_r_p_r_sx
                                when ('1', '0', '1', '0') => __encoding SQDECP_R_P_R_X // sqdecp_r_p_r_x
                                when ('1', '1', '0', '0') => __encoding UQDECP_R_P_R_UW // uqdecp_r_p_r_uw
                                when ('1', '1', '1', '0') => __encoding UQDECP_R_P_R_X // uqdecp_r_p_r_x
                        when (_, _, _, '1', _, _, '0', _) => // sve_int_count_v
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field D 16 +: 1
                            __field opc2 9 +: 2
                            __field Pm 5 +: 4
                            __field Zdn 0 +: 5
                            case (op, D, opc2) of
                                when ('0', _, '01') => __UNALLOCATED
                                when ('0', _, '1x') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding INCP_Z_P_Z__ // incp_z_p_z_
                                when ('0', '1', '00') => __encoding DECP_Z_P_Z__ // decp_z_p_z_
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, '1', _, _, '1', _) => // sve_int_count_r
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field D 16 +: 1
                            __field opc2 9 +: 2
                            __field Pm 5 +: 4
                            __field Rdn 0 +: 5
                            case (op, D, opc2) of
                                when ('0', _, '01') => __UNALLOCATED
                                when ('0', _, '1x') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding INCP_R_P_R__ // incp_r_p_r_
                                when ('0', '1', '00') => __encoding DECP_R_P_R__ // decp_r_p_r_
                                when ('1', _, _) => __UNALLOCATED
                when ('001', _, '1xx101xxx1001xx', _, _, _) =>
                    // sve_pred_wrffr
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 12 +: 4, 9 +: 3, 5 +: 4, 0 +: 5) of
                        when (_, _, _, '0', '00', _, '000', _, '00000') => // sve_int_wrffr
                            __field opc 22 +: 2
                            __field Pn 5 +: 4
                            case (opc) of
                                when ('00') => __encoding WRFFR_F_P__ // wrffr_f_p_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '1', '00', _, '000', '0000', '00000') => // sve_int_setffr
                            __field opc 22 +: 2
                            case (opc) of
                                when ('00') => __encoding SETFFR_F__ // setffr_f_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '1', '00', _, '000', '1xxx', '00000') => __UNPREDICTABLE
                        when (_, _, _, '1', '00', _, '000', 'x1xx', '00000') => __UNPREDICTABLE
                        when (_, _, _, '1', '00', _, '000', 'xx1x', '00000') => __UNPREDICTABLE
                        when (_, _, _, '1', '00', _, '000', 'xxx1', '00000') => __UNPREDICTABLE
                        when (_, _, _, _, '00', _, '000', _, !'00000') => __UNPREDICTABLE
                        when (_, _, _, _, '00', _, !'000', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, !'00', _, _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx101xxx101xxx', _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx11xxxx10xxxx', _, _, _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxxx0xxxxx', _, _, _) =>
                    // sve_intx_muladd_unpred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 10 +: 5, 0 +: 10) of
                        when (_, _, _, _, _, '0000x', _) => // sve_intx_dot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding SDOT_Z_ZZZ__ // sdot_z_zzz_
                                when ('1') => __encoding UDOT_Z_ZZZ__ // udot_z_zzz_
                        when (_, _, _, _, _, '0001x', _) => // sve_intx_qdmlalbt
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S) of
                                when ('0') => __encoding SQDMLALBT_Z_ZZZ__ // sqdmlalbt_z_zzz_
                                when ('1') => __encoding SQDMLSLBT_Z_ZZZ__ // sqdmlslbt_z_zzz_
                        when (_, _, _, _, _, '001xx', _) => // sve_intx_cdot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case () of
                                when () => __encoding CDOT_Z_ZZZ__ // cdot_z_zzz_
                        when (_, _, _, _, _, '01xxx', _) => // sve_intx_cmla
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 12 +: 1
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op) of
                                when ('0') => __encoding CMLA_Z_ZZZ__ // cmla_z_zzz_
                                when ('1') => __encoding SQRDCMLAH_Z_ZZZ__ // sqrdcmlah_z_zzz_
                        when (_, _, _, _, _, '10xxx', _) => // sve_intx_mlal_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S, U, T) of
                                when ('0', '0', '0') => __encoding SMLALB_Z_ZZZ__ // smlalb_z_zzz_
                                when ('0', '0', '1') => __encoding SMLALT_Z_ZZZ__ // smlalt_z_zzz_
                                when ('0', '1', '0') => __encoding UMLALB_Z_ZZZ__ // umlalb_z_zzz_
                                when ('0', '1', '1') => __encoding UMLALT_Z_ZZZ__ // umlalt_z_zzz_
                                when ('1', '0', '0') => __encoding SMLSLB_Z_ZZZ__ // smlslb_z_zzz_
                                when ('1', '0', '1') => __encoding SMLSLT_Z_ZZZ__ // smlslt_z_zzz_
                                when ('1', '1', '0') => __encoding UMLSLB_Z_ZZZ__ // umlslb_z_zzz_
                                when ('1', '1', '1') => __encoding UMLSLT_Z_ZZZ__ // umlslt_z_zzz_
                        when (_, _, _, _, _, '110xx', _) => // sve_intx_qdmlal_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S, T) of
                                when ('0', '0') => __encoding SQDMLALB_Z_ZZZ__ // sqdmlalb_z_zzz_
                                when ('0', '1') => __encoding SQDMLALT_Z_ZZZ__ // sqdmlalt_z_zzz_
                                when ('1', '0') => __encoding SQDMLSLB_Z_ZZZ__ // sqdmlslb_z_zzz_
                                when ('1', '1') => __encoding SQDMLSLT_Z_ZZZ__ // sqdmlslt_z_zzz_
                        when (_, _, _, _, _, '1110x', _) => // sve_intx_qrdmlah
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S) of
                                when ('0') => __encoding SQRDMLAH_Z_ZZZ__ // sqrdmlah_z_zzz_
                                when ('1') => __encoding SQRDMLSH_Z_ZZZ__ // sqrdmlsh_z_zzz_
                        when (_, _, _, _, _, '11110', _) => // sve_intx_mixed_dot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding USDOT_Z_ZZZ_S // usdot_z_zzz_s
                                when ('11') => __UNALLOCATED
                        when (_, _, _, _, _, '11111', _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxxx10xxxx', _, _, _) =>
                    // sve_intx_predicated
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 16 +: 1, 14 +: 2, 13 +: 1, 0 +: 13) of
                        when (_, _, _, '0010', _, _, '1', _) => // sve_intx_accumulate_long_pairs
                            __field size 22 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding SADALP_Z_P_Z__ // sadalp_z_p_z_
                                when ('1') => __encoding UADALP_Z_P_Z__ // uadalp_z_p_z_
                        when (_, _, _, '0011', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '011x', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0x0x', _, _, '1', _) => // sve_intx_pred_arith_unary
                            __field size 22 +: 2
                            __field Q 19 +: 1
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (Q, opc) of
                                when (_, '1x') => __UNALLOCATED
                                when ('0', '00') => __encoding URECPE_Z_P_Z__ // urecpe_z_p_z_
                                when ('0', '01') => __encoding URSQRTE_Z_P_Z__ // ursqrte_z_p_z_
                                when ('1', '00') => __encoding SQABS_Z_P_Z__ // sqabs_z_p_z_
                                when ('1', '01') => __encoding SQNEG_Z_P_Z__ // sqneg_z_p_z_
                        when (_, _, _, '0xxx', _, _, '0', _) => // sve_intx_bin_pred_shift_sat_round
                            __field size 22 +: 2
                            __field Q 19 +: 1
                            __field R 18 +: 1
                            __field N 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (Q, R, N, U) of
                                when ('0', _, '0', _) => __UNALLOCATED
                                when ('0', '0', '1', '0') => __encoding SRSHL_Z_P_ZZ__ // srshl_z_p_zz_
                                when ('0', '0', '1', '1') => __encoding URSHL_Z_P_ZZ__ // urshl_z_p_zz_
                                when ('0', '1', '1', '0') => __encoding SRSHLR_Z_P_ZZ__ // srshlr_z_p_zz_
                                when ('0', '1', '1', '1') => __encoding URSHLR_Z_P_ZZ__ // urshlr_z_p_zz_
                                when ('1', '0', '0', '0') => __encoding SQSHL_Z_P_ZZ__ // sqshl_z_p_zz_
                                when ('1', '0', '0', '1') => __encoding UQSHL_Z_P_ZZ__ // uqshl_z_p_zz_
                                when ('1', '0', '1', '0') => __encoding SQRSHL_Z_P_ZZ__ // sqrshl_z_p_zz_
                                when ('1', '0', '1', '1') => __encoding UQRSHL_Z_P_ZZ__ // uqrshl_z_p_zz_
                                when ('1', '1', '0', '0') => __encoding SQSHLR_Z_P_ZZ__ // sqshlr_z_p_zz_
                                when ('1', '1', '0', '1') => __encoding UQSHLR_Z_P_ZZ__ // uqshlr_z_p_zz_
                                when ('1', '1', '1', '0') => __encoding SQRSHLR_Z_P_ZZ__ // sqrshlr_z_p_zz_
                                when ('1', '1', '1', '1') => __encoding UQRSHLR_Z_P_ZZ__ // uqrshlr_z_p_zz_
                        when (_, _, _, '10xx', _, _, '0', _) => // sve_intx_pred_arith_binary
                            __field size 22 +: 2
                            __field R 18 +: 1
                            __field S 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, S, U) of
                                when ('0', '0', '0') => __encoding SHADD_Z_P_ZZ__ // shadd_z_p_zz_
                                when ('0', '0', '1') => __encoding UHADD_Z_P_ZZ__ // uhadd_z_p_zz_
                                when ('0', '1', '0') => __encoding SHSUB_Z_P_ZZ__ // shsub_z_p_zz_
                                when ('0', '1', '1') => __encoding UHSUB_Z_P_ZZ__ // uhsub_z_p_zz_
                                when ('1', '0', '0') => __encoding SRHADD_Z_P_ZZ__ // srhadd_z_p_zz_
                                when ('1', '0', '1') => __encoding URHADD_Z_P_ZZ__ // urhadd_z_p_zz_
                                when ('1', '1', '0') => __encoding SHSUBR_Z_P_ZZ__ // shsubr_z_p_zz_
                                when ('1', '1', '1') => __encoding UHSUBR_Z_P_ZZ__ // uhsubr_z_p_zz_
                        when (_, _, _, '10xx', _, _, '1', _) => // sve_intx_arith_binary_pairs
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, U) of
                                when ('00', '0') => __UNALLOCATED
                                when ('00', '1') => __encoding ADDP_Z_P_ZZ__ // addp_z_p_zz_
                                when ('01', _) => __UNALLOCATED
                                when ('10', '0') => __encoding SMAXP_Z_P_ZZ__ // smaxp_z_p_zz_
                                when ('10', '1') => __encoding UMAXP_Z_P_ZZ__ // umaxp_z_p_zz_
                                when ('11', '0') => __encoding SMINP_Z_P_ZZ__ // sminp_z_p_zz_
                                when ('11', '1') => __encoding UMINP_Z_P_ZZ__ // uminp_z_p_zz_
                        when (_, _, _, '11xx', _, _, '0', _) => // sve_intx_pred_arith_binary_sat
                            __field size 22 +: 2
                            __field op 18 +: 1
                            __field S 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (op, S, U) of
                                when ('0', '0', '0') => __encoding SQADD_Z_P_ZZ__ // sqadd_z_p_zz_
                                when ('0', '0', '1') => __encoding UQADD_Z_P_ZZ__ // uqadd_z_p_zz_
                                when ('0', '1', '0') => __encoding SQSUB_Z_P_ZZ__ // sqsub_z_p_zz_
                                when ('0', '1', '1') => __encoding UQSUB_Z_P_ZZ__ // uqsub_z_p_zz_
                                when ('1', '0', '0') => __encoding SUQADD_Z_P_ZZ__ // suqadd_z_p_zz_
                                when ('1', '0', '1') => __encoding USQADD_Z_P_ZZ__ // usqadd_z_p_zz_
                                when ('1', '1', '0') => __encoding SQSUBR_Z_P_ZZ__ // sqsubr_z_p_zz_
                                when ('1', '1', '1') => __encoding UQSUBR_Z_P_ZZ__ // uqsubr_z_p_zz_
                        when (_, _, _, '11xx', _, _, '1', _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxxx11000x', _, _, _) => // sve_intx_clamp
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (U) of
                        when ('0') => __encoding SCLAMP_Z_ZZ__ // sclamp_z_zz_
                        when ('1') => __encoding UCLAMP_Z_ZZ__ // uclamp_z_zz_
                when ('010', _, '0xx0xxxxx1101xx', _, _, _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxxx111xxx', _, _, _) => // sve_int_perm_binquads
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding ZIPQ1_Z_ZZ__ // zipq1_z_zz_
                        when ('001') => __encoding ZIPQ2_Z_ZZ__ // zipq2_z_zz_
                        when ('010') => __encoding UZPQ1_Z_ZZ__ // uzpq1_z_zz_
                        when ('011') => __encoding UZPQ2_Z_ZZ__ // uzpq2_z_zz_
                        when ('10x') => __UNALLOCATED
                        when ('110') => __encoding TBLQ_Z_ZZ__ // tblq_z_zz_
                        when ('111') => __UNALLOCATED
                when ('010', _, '0xx1xxxxxxxxxxx', _, _, _) =>
                    // sve_intx_by_indexed_elem
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 10 +: 6, 0 +: 10) of
                        when (_, _, _, _, '00000x', _) => // sve_intx_dot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, U) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '0') => __encoding SDOT_Z_ZZZi_S // sdot_z_zzzi_s
                                when ('10', '1') => __encoding UDOT_Z_ZZZi_S // udot_z_zzzi_s
                                when ('11', '0') => __encoding SDOT_Z_ZZZi_D // sdot_z_zzzi_d
                                when ('11', '1') => __encoding UDOT_Z_ZZZi_D // udot_z_zzzi_d
                        when (_, _, _, _, '00001x', _) => // sve_intx_mla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S) of
                                when ('0x', '0') => __encoding MLA_Z_ZZZi_H // mla_z_zzzi_h
                                when ('0x', '1') => __encoding MLS_Z_ZZZi_H // mls_z_zzzi_h
                                when ('10', '0') => __encoding MLA_Z_ZZZi_S // mla_z_zzzi_s
                                when ('10', '1') => __encoding MLS_Z_ZZZi_S // mls_z_zzzi_s
                                when ('11', '0') => __encoding MLA_Z_ZZZi_D // mla_z_zzzi_d
                                when ('11', '1') => __encoding MLS_Z_ZZZi_D // mls_z_zzzi_d
                        when (_, _, _, _, '00010x', _) => // sve_intx_qrdmlah_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S) of
                                when ('0x', '0') => __encoding SQRDMLAH_Z_ZZZi_H // sqrdmlah_z_zzzi_h
                                when ('0x', '1') => __encoding SQRDMLSH_Z_ZZZi_H // sqrdmlsh_z_zzzi_h
                                when ('10', '0') => __encoding SQRDMLAH_Z_ZZZi_S // sqrdmlah_z_zzzi_s
                                when ('10', '1') => __encoding SQRDMLSH_Z_ZZZi_S // sqrdmlsh_z_zzzi_s
                                when ('11', '0') => __encoding SQRDMLAH_Z_ZZZi_D // sqrdmlah_z_zzzi_d
                                when ('11', '1') => __encoding SQRDMLSH_Z_ZZZi_D // sqrdmlsh_z_zzzi_d
                        when (_, _, _, _, '00011x', _) => // sve_intx_mixed_dot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, U) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '0') => __encoding USDOT_Z_ZZZi_S // usdot_z_zzzi_s
                                when ('10', '1') => __encoding SUDOT_Z_ZZZi_S // sudot_z_zzzi_s
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, _, '001xxx', _) => // sve_intx_qdmla_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S, T) of
                                when ('0x', _, _) => __UNALLOCATED
                                when ('10', '0', '0') => __encoding SQDMLALB_Z_ZZZi_S // sqdmlalb_z_zzzi_s
                                when ('10', '0', '1') => __encoding SQDMLALT_Z_ZZZi_S // sqdmlalt_z_zzzi_s
                                when ('10', '1', '0') => __encoding SQDMLSLB_Z_ZZZi_S // sqdmlslb_z_zzzi_s
                                when ('10', '1', '1') => __encoding SQDMLSLT_Z_ZZZi_S // sqdmlslt_z_zzzi_s
                                when ('11', '0', '0') => __encoding SQDMLALB_Z_ZZZi_D // sqdmlalb_z_zzzi_d
                                when ('11', '0', '1') => __encoding SQDMLALT_Z_ZZZi_D // sqdmlalt_z_zzzi_d
                                when ('11', '1', '0') => __encoding SQDMLSLB_Z_ZZZi_D // sqdmlslb_z_zzzi_d
                                when ('11', '1', '1') => __encoding SQDMLSLT_Z_ZZZi_D // sqdmlslt_z_zzzi_d
                        when (_, _, _, _, '0100xx', _) => // sve_intx_cdot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding CDOT_Z_ZZZi_S // cdot_z_zzzi_s
                                when ('11') => __encoding CDOT_Z_ZZZi_D // cdot_z_zzzi_d
                        when (_, _, _, _, '0101xx', _) => __UNPREDICTABLE
                        when (_, _, _, _, '0110xx', _) => // sve_intx_cmla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding CMLA_Z_ZZZi_H // cmla_z_zzzi_h
                                when ('11') => __encoding CMLA_Z_ZZZi_S // cmla_z_zzzi_s
                        when (_, _, _, _, '0111xx', _) => // sve_intx_qrdcmla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding SQRDCMLAH_Z_ZZZi_H // sqrdcmlah_z_zzzi_h
                                when ('11') => __encoding SQRDCMLAH_Z_ZZZi_S // sqrdcmlah_z_zzzi_s
                        when (_, _, _, _, '10xxxx', _) => // sve_intx_mla_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 13 +: 1
                            __field U 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S, U, T) of
                                when ('0x', _, _, _) => __UNALLOCATED
                                when ('10', '0', '0', '0') => __encoding SMLALB_Z_ZZZi_S // smlalb_z_zzzi_s
                                when ('10', '0', '0', '1') => __encoding SMLALT_Z_ZZZi_S // smlalt_z_zzzi_s
                                when ('10', '0', '1', '0') => __encoding UMLALB_Z_ZZZi_S // umlalb_z_zzzi_s
                                when ('10', '0', '1', '1') => __encoding UMLALT_Z_ZZZi_S // umlalt_z_zzzi_s
                                when ('10', '1', '0', '0') => __encoding SMLSLB_Z_ZZZi_S // smlslb_z_zzzi_s
                                when ('10', '1', '0', '1') => __encoding SMLSLT_Z_ZZZi_S // smlslt_z_zzzi_s
                                when ('10', '1', '1', '0') => __encoding UMLSLB_Z_ZZZi_S // umlslb_z_zzzi_s
                                when ('10', '1', '1', '1') => __encoding UMLSLT_Z_ZZZi_S // umlslt_z_zzzi_s
                                when ('11', '0', '0', '0') => __encoding SMLALB_Z_ZZZi_D // smlalb_z_zzzi_d
                                when ('11', '0', '0', '1') => __encoding SMLALT_Z_ZZZi_D // smlalt_z_zzzi_d
                                when ('11', '0', '1', '0') => __encoding UMLALB_Z_ZZZi_D // umlalb_z_zzzi_d
                                when ('11', '0', '1', '1') => __encoding UMLALT_Z_ZZZi_D // umlalt_z_zzzi_d
                                when ('11', '1', '0', '0') => __encoding SMLSLB_Z_ZZZi_D // smlslb_z_zzzi_d
                                when ('11', '1', '0', '1') => __encoding SMLSLT_Z_ZZZi_D // smlslt_z_zzzi_d
                                when ('11', '1', '1', '0') => __encoding UMLSLB_Z_ZZZi_D // umlslb_z_zzzi_d
                                when ('11', '1', '1', '1') => __encoding UMLSLT_Z_ZZZi_D // umlslt_z_zzzi_d
                        when (_, _, _, _, '110xxx', _) => // sve_intx_mul_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, U, T) of
                                when ('0x', _, _) => __UNALLOCATED
                                when ('10', '0', '0') => __encoding SMULLB_Z_ZZi_S // smullb_z_zzi_s
                                when ('10', '0', '1') => __encoding SMULLT_Z_ZZi_S // smullt_z_zzi_s
                                when ('10', '1', '0') => __encoding UMULLB_Z_ZZi_S // umullb_z_zzi_s
                                when ('10', '1', '1') => __encoding UMULLT_Z_ZZi_S // umullt_z_zzi_s
                                when ('11', '0', '0') => __encoding SMULLB_Z_ZZi_D // smullb_z_zzi_d
                                when ('11', '0', '1') => __encoding SMULLT_Z_ZZi_D // smullt_z_zzi_d
                                when ('11', '1', '0') => __encoding UMULLB_Z_ZZi_D // umullb_z_zzi_d
                                when ('11', '1', '1') => __encoding UMULLT_Z_ZZi_D // umullt_z_zzi_d
                        when (_, _, _, _, '1110xx', _) => // sve_intx_qdmul_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, T) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '0') => __encoding SQDMULLB_Z_ZZi_S // sqdmullb_z_zzi_s
                                when ('10', '1') => __encoding SQDMULLT_Z_ZZi_S // sqdmullt_z_zzi_s
                                when ('11', '0') => __encoding SQDMULLB_Z_ZZi_D // sqdmullb_z_zzi_d
                                when ('11', '1') => __encoding SQDMULLT_Z_ZZi_D // sqdmullt_z_zzi_d
                        when (_, _, _, _, '11110x', _) => // sve_intx_qdmulh_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field R 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, R) of
                                when ('0x', '0') => __encoding SQDMULH_Z_ZZi_H // sqdmulh_z_zzi_h
                                when ('0x', '1') => __encoding SQRDMULH_Z_ZZi_H // sqrdmulh_z_zzi_h
                                when ('10', '0') => __encoding SQDMULH_Z_ZZi_S // sqdmulh_z_zzi_s
                                when ('10', '1') => __encoding SQRDMULH_Z_ZZi_S // sqrdmulh_z_zzi_s
                                when ('11', '0') => __encoding SQDMULH_Z_ZZi_D // sqdmulh_z_zzi_d
                                when ('11', '1') => __encoding SQRDMULH_Z_ZZi_D // sqrdmulh_z_zzi_d
                        when (_, _, _, _, '111110', _) => // sve_intx_mul_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size) of
                                when ('0x') => __encoding MUL_Z_ZZi_H // mul_z_zzi_h
                                when ('10') => __encoding MUL_Z_ZZi_S // mul_z_zzi_s
                                when ('11') => __encoding MUL_Z_ZZi_D // mul_z_zzi_d
                        when (_, _, _, _, '111111', _) => __UNPREDICTABLE
                when ('010', _, '0x10xxxxx11001x', _, _, _) => __UNPREDICTABLE
                when ('010', _, '0000xxxxx11001x', _, _, _) => // sve_intx_dot2
                    __field Zm 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (U) of
                        when ('0') => __encoding SDOT_Z32_ZZZ__ // sdot_z32_zzz_
                        when ('1') => __encoding UDOT_Z32_ZZZ__ // udot_z32_zzz_
                when ('010', _, '0100xxxxx11001x', _, _, _) => // sve_intx_dot2_by_indexed_elem
                    __field opc 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (U) of
                        when ('0') => __encoding SDOT_Z32_ZZZi__ // sdot_z32_zzzi_
                        when ('1') => __encoding UDOT_Z32_ZZZi__ // udot_z32_zzzi_
                when ('010', _, '1xx0xxxxx0xxxxx', _, _, _) =>
                    // sve_intx_cons_widening
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 13 +: 2, 0 +: 13) of
                        when (_, _, _, _, _, '0x', _) => // sve_intx_cons_arith_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op, S, U, T) of
                                when ('0', '0', '0', '0') => __encoding SADDLB_Z_ZZ__ // saddlb_z_zz_
                                when ('0', '0', '0', '1') => __encoding SADDLT_Z_ZZ__ // saddlt_z_zz_
                                when ('0', '0', '1', '0') => __encoding UADDLB_Z_ZZ__ // uaddlb_z_zz_
                                when ('0', '0', '1', '1') => __encoding UADDLT_Z_ZZ__ // uaddlt_z_zz_
                                when ('0', '1', '0', '0') => __encoding SSUBLB_Z_ZZ__ // ssublb_z_zz_
                                when ('0', '1', '0', '1') => __encoding SSUBLT_Z_ZZ__ // ssublt_z_zz_
                                when ('0', '1', '1', '0') => __encoding USUBLB_Z_ZZ__ // usublb_z_zz_
                                when ('0', '1', '1', '1') => __encoding USUBLT_Z_ZZ__ // usublt_z_zz_
                                when ('1', '0', _, _) => __UNALLOCATED
                                when ('1', '1', '0', '0') => __encoding SABDLB_Z_ZZ__ // sabdlb_z_zz_
                                when ('1', '1', '0', '1') => __encoding SABDLT_Z_ZZ__ // sabdlt_z_zz_
                                when ('1', '1', '1', '0') => __encoding UABDLB_Z_ZZ__ // uabdlb_z_zz_
                                when ('1', '1', '1', '1') => __encoding UABDLT_Z_ZZ__ // uabdlt_z_zz_
                        when (_, _, _, _, _, '10', _) => // sve_intx_cons_arith_wide
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, U, T) of
                                when ('0', '0', '0') => __encoding SADDWB_Z_ZZ__ // saddwb_z_zz_
                                when ('0', '0', '1') => __encoding SADDWT_Z_ZZ__ // saddwt_z_zz_
                                when ('0', '1', '0') => __encoding UADDWB_Z_ZZ__ // uaddwb_z_zz_
                                when ('0', '1', '1') => __encoding UADDWT_Z_ZZ__ // uaddwt_z_zz_
                                when ('1', '0', '0') => __encoding SSUBWB_Z_ZZ__ // ssubwb_z_zz_
                                when ('1', '0', '1') => __encoding SSUBWT_Z_ZZ__ // ssubwt_z_zz_
                                when ('1', '1', '0') => __encoding USUBWB_Z_ZZ__ // usubwb_z_zz_
                                when ('1', '1', '1') => __encoding USUBWT_Z_ZZ__ // usubwt_z_zz_
                        when (_, _, _, _, _, '11', _) => // sve_intx_cons_mul_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, op, U, T) of
                                when (_, '0', '0', '0') => __encoding SQDMULLB_Z_ZZ__ // sqdmullb_z_zz_
                                when (_, '0', '0', '1') => __encoding SQDMULLT_Z_ZZ__ // sqdmullt_z_zz_
                                when (_, '1', '0', '0') => __encoding SMULLB_Z_ZZ__ // smullb_z_zz_
                                when (_, '1', '0', '1') => __encoding SMULLT_Z_ZZ__ // smullt_z_zz_
                                when (_, '1', '1', '0') => __encoding UMULLB_Z_ZZ__ // umullb_z_zz_
                                when (_, '1', '1', '1') => __encoding UMULLT_Z_ZZ__ // umullt_z_zz_
                                when (!'00', '0', '1', '0') => __encoding PMULLB_Z_ZZ__ // pmullb_z_zz_
                                when (!'00', '0', '1', '1') => __encoding PMULLT_Z_ZZ__ // pmullt_z_zz_
                                when ('00', '0', '1', '0') => __encoding PMULLB_Z_ZZ_Q // pmullb_z_zz_q
                                when ('00', '0', '1', '1') => __encoding PMULLT_Z_ZZ_Q // pmullt_z_zz_q
                when ('010', _, '1xx0xxxxx10xxxx', _, _, _) =>
                    // sve_intx_constructive
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 10 +: 4, 0 +: 10) of
                        when (_, '0', _, _, _, _, '10xx', _) => // sve_intx_shift_long
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (U, T) of
                                when ('0', '0') => __encoding SSHLLB_Z_ZI__ // sshllb_z_zi_
                                when ('0', '1') => __encoding SSHLLT_Z_ZI__ // sshllt_z_zi_
                                when ('1', '0') => __encoding USHLLB_Z_ZI__ // ushllb_z_zi_
                                when ('1', '1') => __encoding USHLLT_Z_ZI__ // ushllt_z_zi_
                        when (_, '1', _, _, _, _, '10xx', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00xx', _) => // sve_intx_clong
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 11 +: 1
                            __field tb 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, tb) of
                                when ('0', '0') => __encoding SADDLBT_Z_ZZ__ // saddlbt_z_zz_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', '0') => __encoding SSUBLBT_Z_ZZ__ // ssublbt_z_zz_
                                when ('1', '1') => __encoding SSUBLTB_Z_ZZ__ // ssubltb_z_zz_
                        when (_, _, _, _, _, _, '010x', _) => // sve_intx_eorx
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field tb 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (tb) of
                                when ('0') => __encoding EORBT_Z_ZZ__ // eorbt_z_zz_
                                when ('1') => __encoding EORTB_Z_ZZ__ // eortb_z_zz_
                        when (_, _, _, _, _, _, '0110', _) => // sve_intx_mmla
                            __field uns 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (uns) of
                                when ('00') => __encoding SMMLA_Z_ZZZ__ // smmla_z_zzz_
                                when ('01') => __UNALLOCATED
                                when ('10') => __encoding USMMLA_Z_ZZZ__ // usmmla_z_zzz_
                                when ('11') => __encoding UMMLA_Z_ZZZ__ // ummla_z_zzz_
                        when (_, _, _, _, _, _, '0111', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '11xx', _) => // sve_intx_perm_bit
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding BEXT_Z_ZZ__ // bext_z_zz_
                                when ('01') => __encoding BDEP_Z_ZZ__ // bdep_z_zz_
                                when ('10') => __encoding BGRP_Z_ZZ__ // bgrp_z_zz_
                                when ('11') => __UNALLOCATED
                when ('010', _, '1xx0xxxxx11xxxx', _, _, _) =>
                    // sve_intx_acc
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 16 +: 1, 14 +: 2, 11 +: 3, 0 +: 11) of
                        when (_, _, _, '0000', _, _, '011', _) => // sve_intx_cadd
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field rot 10 +: 1
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (op) of
                                when ('0') => __encoding CADD_Z_ZZ__ // cadd_z_zz_
                                when ('1') => __encoding SQCADD_Z_ZZ__ // sqcadd_z_zz_
                        when (_, _, _, !'0000', _, _, '011', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00x', _) => // sve_intx_aba_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U, T) of
                                when ('0', '0') => __encoding SABALB_Z_ZZZ__ // sabalb_z_zzz_
                                when ('0', '1') => __encoding SABALT_Z_ZZZ__ // sabalt_z_zzz_
                                when ('1', '0') => __encoding UABALB_Z_ZZZ__ // uabalb_z_zzz_
                                when ('1', '1') => __encoding UABALT_Z_ZZZ__ // uabalt_z_zzz_
                        when (_, _, _, _, _, _, '010', _) => // sve_intx_adc_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, T) of
                                when ('0x', '0') => __encoding ADCLB_Z_ZZZ__ // adclb_z_zzz_
                                when ('0x', '1') => __encoding ADCLT_Z_ZZZ__ // adclt_z_zzz_
                                when ('1x', '0') => __encoding SBCLB_Z_ZZZ__ // sbclb_z_zzz_
                                when ('1x', '1') => __encoding SBCLT_Z_ZZZ__ // sbclt_z_zzz_
                        when (_, _, _, _, _, _, '10x', _) => // sve_intx_sra
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field R 11 +: 1
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (R, U) of
                                when ('0', '0') => __encoding SSRA_Z_ZI__ // ssra_z_zi_
                                when ('0', '1') => __encoding USRA_Z_ZI__ // usra_z_zi_
                                when ('1', '0') => __encoding SRSRA_Z_ZI__ // srsra_z_zi_
                                when ('1', '1') => __encoding URSRA_Z_ZI__ // ursra_z_zi_
                        when (_, _, _, _, _, _, '110', _) => // sve_intx_shift_insert
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding SRI_Z_ZZI__ // sri_z_zzi_
                                when ('1') => __encoding SLI_Z_ZZI__ // sli_z_zzi_
                        when (_, _, _, _, _, _, '111', _) => // sve_intx_aba
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding SABA_Z_ZZZ__ // saba_z_zzz_
                                when ('1') => __encoding UABA_Z_ZZZ__ // uaba_z_zzz_
                when ('010', _, '1xx1xxxxx0xxxxx', _, _, _) =>
                    // sve_intx_narrowing
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 16 +: 1, 15 +: 1, 13 +: 2, 11 +: 2, 10 +: 1, 6 +: 4, 5 +: 1, 0 +: 5) of
                        when (_, '0', _, _, _, '00', '0', _, '10', _, _, _, _, _) => // sve_intx_extract_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field opc 11 +: 2
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, T) of
                                when ('00', '0') => __encoding SQXTNB_Z_ZZ__ // sqxtnb_z_zz_
                                when ('00', '1') => __encoding SQXTNT_Z_ZZ__ // sqxtnt_z_zz_
                                when ('01', '0') => __encoding UQXTNB_Z_ZZ__ // uqxtnb_z_zz_
                                when ('01', '1') => __encoding UQXTNT_Z_ZZ__ // uqxtnt_z_zz_
                                when ('10', '0') => __encoding SQXTUNB_Z_ZZ__ // sqxtunb_z_zz_
                                when ('10', '1') => __encoding SQXTUNT_Z_ZZ__ // sqxtunt_z_zz_
                                when ('11', _) => __UNALLOCATED
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '0', _, '0', _) => // sve_intx_multi_extract_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field opc 11 +: 2
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (tszh, tszl, opc) of
                                when ('0', '0x', _) => __UNALLOCATED
                                when ('0', '10', '00') => __encoding SQCVTN_Z_MZ2__ // sqcvtn_z_mz2_
                                when ('0', '10', '01') => __encoding UQCVTN_Z_MZ2__ // uqcvtn_z_mz2_
                                when ('0', '10', '10') => __encoding SQCVTUN_Z_MZ2__ // sqcvtun_z_mz2_
                                when ('0', '10', '11') => __UNALLOCATED
                                when ('0', '11', _) => __UNALLOCATED
                                when ('1', _, _) => __UNALLOCATED
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, !'00', _, _, '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, _, '0x', _, _, _, _, _) => // sve_intx_shift_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field op 13 +: 1
                            __field U 12 +: 1
                            __field R 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op, U, R, T) of
                                when ('0', '0', '0', '0') => __encoding SQSHRUNB_Z_ZI__ // sqshrunb_z_zi_
                                when ('0', '0', '0', '1') => __encoding SQSHRUNT_Z_ZI__ // sqshrunt_z_zi_
                                when ('0', '0', '1', '0') => __encoding SQRSHRUNB_Z_ZI__ // sqrshrunb_z_zi_
                                when ('0', '0', '1', '1') => __encoding SQRSHRUNT_Z_ZI__ // sqrshrunt_z_zi_
                                when ('0', '1', '0', '0') => __encoding SHRNB_Z_ZI__ // shrnb_z_zi_
                                when ('0', '1', '0', '1') => __encoding SHRNT_Z_ZI__ // shrnt_z_zi_
                                when ('0', '1', '1', '0') => __encoding RSHRNB_Z_ZI__ // rshrnb_z_zi_
                                when ('0', '1', '1', '1') => __encoding RSHRNT_Z_ZI__ // rshrnt_z_zi_
                                when ('1', '0', '0', '0') => __encoding SQSHRNB_Z_ZI__ // sqshrnb_z_zi_
                                when ('1', '0', '0', '1') => __encoding SQSHRNT_Z_ZI__ // sqshrnt_z_zi_
                                when ('1', '0', '1', '0') => __encoding SQRSHRNB_Z_ZI__ // sqrshrnb_z_zi_
                                when ('1', '0', '1', '1') => __encoding SQRSHRNT_Z_ZI__ // sqrshrnt_z_zi_
                                when ('1', '1', '0', '0') => __encoding UQSHRNB_Z_ZI__ // uqshrnb_z_zi_
                                when ('1', '1', '0', '1') => __encoding UQSHRNT_Z_ZI__ // uqshrnt_z_zi_
                                when ('1', '1', '1', '0') => __encoding UQRSHRNB_Z_ZI__ // uqrshrnb_z_zi_
                                when ('1', '1', '1', '1') => __encoding UQRSHRNT_Z_ZI__ // uqrshrnt_z_zi_
                        when (_, '1', _, _, _, _, _, _, '0x', _, '0', _, '0', _) => // sve_intx_multi_shift_narrow
                            __field tszh 22 +: 1
                            __field tszl 20 +: 1
                            __field imm4 16 +: 4
                            __field op 13 +: 1
                            __field U 12 +: 1
                            __field R 11 +: 1
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (tszh, tszl, op, U, R) of
                                when ('0', '0', _, _, _) => __UNALLOCATED
                                when ('0', '1', '0', '0', '0') => __UNALLOCATED
                                when ('0', '1', '0', '0', '1') => __encoding SQRSHRUN_Z_MZ2__ // sqrshrun_z_mz2_
                                when ('0', '1', '0', '1', _) => __UNALLOCATED
                                when ('0', '1', '1', _, '0') => __UNALLOCATED
                                when ('0', '1', '1', '0', '1') => __encoding SQRSHRN_Z_MZ2__ // sqrshrn_z_mz2_
                                when ('0', '1', '1', '1', '1') => __encoding UQRSHRN_Z_MZ2__ // uqrshrn_z_mz2_
                                when ('1', _, _, _, _) => __UNALLOCATED
                        when (_, '1', _, _, _, _, _, _, '0x', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, '0x', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, _, '11', _, _, _, _, _) => // sve_intx_arith_narrow
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field R 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, R, T) of
                                when ('0', '0', '0') => __encoding ADDHNB_Z_ZZ__ // addhnb_z_zz_
                                when ('0', '0', '1') => __encoding ADDHNT_Z_ZZ__ // addhnt_z_zz_
                                when ('0', '1', '0') => __encoding RADDHNB_Z_ZZ__ // raddhnb_z_zz_
                                when ('0', '1', '1') => __encoding RADDHNT_Z_ZZ__ // raddhnt_z_zz_
                                when ('1', '0', '0') => __encoding SUBHNB_Z_ZZ__ // subhnb_z_zz_
                                when ('1', '0', '1') => __encoding SUBHNT_Z_ZZ__ // subhnt_z_zz_
                                when ('1', '1', '0') => __encoding RSUBHNB_Z_ZZ__ // rsubhnb_z_zz_
                                when ('1', '1', '1') => __encoding RSUBHNT_Z_ZZ__ // rsubhnt_z_zz_
                when ('010', _, '1xx1xxxxx100xxx', _, _, _) => // sve_intx_match
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field op 4 +: 1
                    __field Pd 0 +: 4
                    case (op) of
                        when ('0') => __encoding MATCH_P_P_ZZ__ // match_p_p_zz_
                        when ('1') => __encoding NMATCH_P_P_ZZ__ // nmatch_p_p_zz_
                when ('010', _, '1xx1xxxxx101xxx', _, _, _) =>
                    // sve_intx_histseg
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 0 +: 10) of
                        when (_, _, _, _, _, '000', _) => // sve_intx_histseg
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding HISTSEG_Z_ZZ__ // histseg_z_zz_
                        when (_, _, _, _, _, !'000', _) => __UNPREDICTABLE
                when ('010', _, '1xx1xxxxx110xxx', _, _, _) => // sve_intx_histcnt
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding HISTCNT_Z_P_ZZ__ // histcnt_z_p_zz_
                when ('010', _, '1xx1xxxxx111xxx', _, _, _) =>
                    // sve_intx_crypto
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 11 +: 2, 10 +: 1, 5 +: 5, 0 +: 5) of
                        when (_, _, _, '000', '00', _, '00', _, '00000', _) => // sve_crypto_unary
                            __field size 22 +: 2
                            __field op 10 +: 1
                            __field Zdn 0 +: 5
                            case (size, op) of
                                when ('00', '0') => __encoding AESMC_Z_Z__ // aesmc_z_z_
                                when ('00', '1') => __encoding AESIMC_Z_Z__ // aesimc_z_z_
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                        when (_, _, _, '000', '00', _, '00', _, !'00000', _) => __UNPREDICTABLE
                        when (_, _, _, '000', '00', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '000', '01', _, '0x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '000', '01', _, '11', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '000', '1x', _, '00', _, _, _) => // sve_crypto_binary_dest
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field o2 10 +: 1
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, op, o2) of
                                when ('00', '0', '0') => __encoding AESE_Z_ZZ__ // aese_z_zz_
                                when ('00', '0', '1') => __encoding AESD_Z_ZZ__ // aesd_z_zz_
                                when ('00', '1', '0') => __encoding SM4E_Z_ZZ__ // sm4e_z_zz_
                                when ('00', '1', '1') => __UNALLOCATED
                                when ('01', _, _) => __UNALLOCATED
                                when ('1x', _, _) => __UNALLOCATED
                        when (_, _, _, '000', '1x', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'000', _, _, '0x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'000', _, _, '11', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '10', _, _, _) => // sve_crypto_binary_const
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, op) of
                                when ('00', '0') => __encoding SM4EKEY_Z_ZZ__ // sm4ekey_z_zz_
                                when ('00', '1') => __encoding RAX1_Z_ZZ__ // rax1_z_zz_
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                when ('011', _, '0xx0xxxxx0xxxxx', _, _, _) => // sve_fp_fcmla
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field rot 13 +: 2
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case () of
                        when () => __encoding FCMLA_Z_P_ZZZ__ // fcmla_z_p_zzz_
                when ('011', _, '0xx00000x100xxx', _, _, _) => // sve_fp_fcadd
                    __field size 22 +: 2
                    __field rot 16 +: 1
                    __field Pg 10 +: 3
                    __field Zm 5 +: 5
                    __field Zdn 0 +: 5
                    case () of
                        when () => __encoding FCADD_Z_P_ZZ__ // fcadd_z_p_zz_
                when ('011', _, '0xx00000x101xxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00000x11xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00001x1xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx0001xx1xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx0010xx100xxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx0010xx101xxx', _, _, _) => // sve_fp_fcvt2
                    __field opc 22 +: 2
                    __field opc2 16 +: 2
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc, opc2) of
                        when ('x0', '11') => __UNALLOCATED
                        when ('00', '0x') => __UNALLOCATED
                        when ('00', '10') => __encoding FCVTXNT_Z_P_Z_D2S // fcvtxnt_z_p_z_d2s
                        when ('01', _) => __UNALLOCATED
                        when ('10', '00') => __encoding FCVTNT_Z_P_Z_S2H // fcvtnt_z_p_z_s2h
                        when ('10', '01') => __encoding FCVTLT_Z_P_Z_H2S // fcvtlt_z_p_z_h2s
                        when ('10', '10') => __encoding BFCVTNT_Z_P_Z_S2BF // bfcvtnt_z_p_z_s2bf
                        when ('11', '0x') => __UNALLOCATED
                        when ('11', '10') => __encoding FCVTNT_Z_P_Z_D2S // fcvtnt_z_p_z_d2s
                        when ('11', '11') => __encoding FCVTLT_Z_P_Z_S2D // fcvtlt_z_p_z_s2d
                when ('011', _, '0xx0010xx11xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx001100100xxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00110011xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx0011011xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00111x1xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx010xxx100xxx', _, _, _) => // sve_fp_pairwise
                    __field size 22 +: 2
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zm 5 +: 5
                    __field Zdn 0 +: 5
                    case (opc) of
                        when ('000') => __encoding FADDP_Z_P_ZZ__ // faddp_z_p_zz_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding FMAXNMP_Z_P_ZZ__ // fmaxnmp_z_p_zz_
                        when ('101') => __encoding FMINNMP_Z_P_ZZ__ // fminnmp_z_p_zz_
                        when ('110') => __encoding FMAXP_Z_P_ZZ__ // fmaxp_z_p_zz_
                        when ('111') => __encoding FMINP_Z_P_ZZ__ // fminp_z_p_zz_
                when ('011', _, '0xx010xxx101xxx', _, _, _) => // sve_fp_fast_redq
                    __field size 22 +: 2
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Vd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding FADDQV_Z_P_Z__ // faddqv_z_p_z_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding FMAXNMQV_Z_P_Z__ // fmaxnmqv_z_p_z_
                        when ('101') => __encoding FMINNMQV_Z_P_Z__ // fminnmqv_z_p_z_
                        when ('110') => __encoding FMAXQV_Z_P_Z__ // fmaxqv_z_p_z_
                        when ('111') => __encoding FMINQV_Z_P_Z__ // fminqv_z_p_z_
                when ('011', _, '0xx010xxx11xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx011xxx1xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx0000xx', _, _, _) => // sve_fp_fma_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field o2 11 +: 1
                    __field op 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (size, o2, op) of
                        when ('0x', '0', '0') => __encoding FMLA_Z_ZZZi_H // fmla_z_zzzi_h
                        when ('0x', '0', '1') => __encoding FMLS_Z_ZZZi_H // fmls_z_zzzi_h
                        when ('0x', '1', '0') => __encoding BFMLA_Z_ZZZi_H // bfmla_z_zzzi_h
                        when ('0x', '1', '1') => __encoding BFMLS_Z_ZZZi_H // bfmls_z_zzzi_h
                        when ('1x', '1', _) => __UNALLOCATED
                        when ('10', '0', '0') => __encoding FMLA_Z_ZZZi_S // fmla_z_zzzi_s
                        when ('10', '0', '1') => __encoding FMLS_Z_ZZZi_S // fmls_z_zzzi_s
                        when ('11', '0', '0') => __encoding FMLA_Z_ZZZi_D // fmla_z_zzzi_d
                        when ('11', '0', '1') => __encoding FMLS_Z_ZZZi_D // fmls_z_zzzi_d
                when ('011', _, '0xx1xxxxx0001xx', _, _, _) => // sve_fp_fcmla_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field rot 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (size) of
                        when ('0x') => __UNALLOCATED
                        when ('10') => __encoding FCMLA_Z_ZZZi_H // fcmla_z_zzzi_h
                        when ('11') => __encoding FCMLA_Z_ZZZi_S // fcmla_z_zzzi_s
                when ('011', _, '0xx1xxxxx0010x0', _, _, _) => // sve_fp_fmul_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field o2 11 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size, o2) of
                        when ('0x', '0') => __encoding FMUL_Z_ZZi_H // fmul_z_zzi_h
                        when ('0x', '1') => __encoding BFMUL_Z_ZZi_H // bfmul_z_zzi_h
                        when ('1x', '1') => __UNALLOCATED
                        when ('10', '0') => __encoding FMUL_Z_ZZi_S // fmul_z_zzi_s
                        when ('11', '0') => __encoding FMUL_Z_ZZi_D // fmul_z_zzi_d
                when ('011', _, '0xx1xxxxx001001', _, _, _) => // sve_fp_clamp
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size) of
                        when (!'00') => __encoding FCLAMP_Z_ZZ__ // fclamp_z_zz_
                        when ('00') => __encoding BFCLAMP_Z_ZZ__ // bfclamp_z_zz_
                when ('011', _, '0xx1xxxxx001011', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx0011xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx01x0xx', _, _, _) =>
                    // sve_fp_fma_w_by_indexed_elem
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 13 +: 1, 12 +: 1, 0 +: 12) of
                        when (_, '0', _, _, _, _, '0', _, _) => // sve_fp_fdot_by_indexed_elem
                            __field op 22 +: 1
                            __field i2 19 +: 2
                            __field Zm 16 +: 3
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op, opc2) of
                                when ('0', '00') => __encoding FDOT_Z_ZZZi__ // fdot_z_zzzi_
                                when ('1', '00') => __encoding BFDOT_Z_ZZZi__ // bfdot_z_zzzi_
                                when ('1', '10') => __UNALLOCATED
                        when (_, '0', _, _, _, _, '1', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _) => // sve_fp_fma_long_by_indexed_elem
                            __field o2 22 +: 1
                            __field i3h 19 +: 2
                            __field Zm 16 +: 3
                            __field op 13 +: 1
                            __field i3l 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (o2, op, T) of
                                when ('0', '0', '0') => __encoding FMLALB_Z_ZZZi_S // fmlalb_z_zzzi_s
                                when ('0', '0', '1') => __encoding FMLALT_Z_ZZZi_S // fmlalt_z_zzzi_s
                                when ('0', '1', '0') => __encoding FMLSLB_Z_ZZZi_S // fmlslb_z_zzzi_s
                                when ('0', '1', '1') => __encoding FMLSLT_Z_ZZZi_S // fmlslt_z_zzzi_s
                                when ('1', '0', '0') => __encoding BFMLALB_Z_ZZZi__ // bfmlalb_z_zzzi_
                                when ('1', '0', '1') => __encoding BFMLALT_Z_ZZZi__ // bfmlalt_z_zzzi_
                                when ('1', '1', '0') => __encoding BFMLSLB_Z_ZZZi__ // bfmlslb_z_zzzi_
                                when ('1', '1', '1') => __encoding BFMLSLT_Z_ZZZi__ // bfmlslt_z_zzzi_
                when ('011', _, '0xx1xxxxx01x1xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx10x00x', _, _, _) =>
                    // sve_fp_fma_w
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 13 +: 1, 11 +: 2, 0 +: 11) of
                        when (_, '0', _, _, _, _, _, _, _) => // sve_fp_fdot
                            __field op 22 +: 1
                            __field Zm 16 +: 5
                            __field o2 13 +: 1
                            __field o3 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op, o2, o3) of
                                when ('0', '0', '0') => __encoding FDOT_Z_ZZZ__ // fdot_z_zzz_
                                when ('0', '1', '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding BFDOT_Z_ZZZ__ // bfdot_z_zzz_
                                when ('1', '1', _) => __UNALLOCATED
                        when (_, '1', _, _, _, _, _, _, _) => // sve_fp_fma_long
                            __field o2 22 +: 1
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (o2, op, T) of
                                when ('0', '0', '0') => __encoding FMLALB_Z_ZZZ__ // fmlalb_z_zzz_
                                when ('0', '0', '1') => __encoding FMLALT_Z_ZZZ__ // fmlalt_z_zzz_
                                when ('0', '1', '0') => __encoding FMLSLB_Z_ZZZ__ // fmlslb_z_zzz_
                                when ('0', '1', '1') => __encoding FMLSLT_Z_ZZZ__ // fmlslt_z_zzz_
                                when ('1', '0', '0') => __encoding BFMLALB_Z_ZZZ__ // bfmlalb_z_zzz_
                                when ('1', '0', '1') => __encoding BFMLALT_Z_ZZZ__ // bfmlalt_z_zzz_
                                when ('1', '1', '0') => __encoding BFMLSLB_Z_ZZZ__ // bfmlslb_z_zzz_
                                when ('1', '1', '1') => __encoding BFMLSLT_Z_ZZZ__ // bfmlslt_z_zzz_
                when ('011', _, '0xx1xxxxx10x01x', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx10x1xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx110xxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx111000', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx111001', _, _, _) => // sve_fp_fmmla
                    __field opc 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (opc) of
                        when ('00') => __UNALLOCATED
                        when ('01') => __encoding BFMMLA_Z_ZZZ__ // bfmmla_z_zzz_
                        when ('10') => __encoding FMMLA_Z_ZZZ_S // fmmla_z_zzz_s
                        when ('11') => __encoding FMMLA_Z_ZZZ_D // fmmla_z_zzz_d
                when ('011', _, '0xx1xxxxx11101x', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxxx1111xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx0xxxxxx1xxxx', _, _, _) => // sve_fp_3op_p_pd
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field op 15 +: 1
                    __field o2 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field o3 4 +: 1
                    __field Pd 0 +: 4
                    case (op, o2, o3) of
                        when ('0', '0', '0') => __encoding FCMGE_P_P_ZZ__ // fcmge_p_p_zz_
                        when ('0', '0', '1') => __encoding FCMGT_P_P_ZZ__ // fcmgt_p_p_zz_
                        when ('0', '1', '0') => __encoding FCMEQ_P_P_ZZ__ // fcmeq_p_p_zz_
                        when ('0', '1', '1') => __encoding FCMNE_P_P_ZZ__ // fcmne_p_p_zz_
                        when ('1', '0', '0') => __encoding FCMUO_P_P_ZZ__ // fcmuo_p_p_zz_
                        when ('1', '0', '1') => __encoding FACGE_P_P_ZZ__ // facge_p_p_zz_
                        when ('1', '1', '0') => __UNALLOCATED
                        when ('1', '1', '1') => __encoding FACGT_P_P_ZZ__ // facgt_p_p_zz_
                when ('011', _, '1xx0xxxxx000xxx', _, _, _) => // sve_fp_3op_u_zd
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size, opc) of
                        when (_, '011') => __encoding FTSMUL_Z_ZZ__ // ftsmul_z_zz_
                        when (_, '10x') => __UNALLOCATED
                        when (_, '110') => __encoding FRECPS_Z_ZZ__ // frecps_z_zz_
                        when (_, '111') => __encoding FRSQRTS_Z_ZZ__ // frsqrts_z_zz_
                        when (!'00', '000') => __encoding FADD_Z_ZZ__ // fadd_z_zz_
                        when (!'00', '001') => __encoding FSUB_Z_ZZ__ // fsub_z_zz_
                        when (!'00', '010') => __encoding FMUL_Z_ZZ__ // fmul_z_zz_
                        when ('00', '000') => __encoding BFADD_Z_ZZ__ // bfadd_z_zz_
                        when ('00', '001') => __encoding BFSUB_Z_ZZ__ // bfsub_z_zz_
                        when ('00', '010') => __encoding BFMUL_Z_ZZ__ // bfmul_z_zz_
                when ('011', _, '1xx0xxxxx100xxx', _, _, _) =>
                    // sve_fp_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 10 +: 3, 6 +: 4, 0 +: 6) of
                        when (_, _, _, '0x', _, _, _, _, _) => // sve_fp_2op_p_zds
                            __field size 22 +: 2
                            __field opc 16 +: 4
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, opc) of
                                when (_, '0011') => __encoding FSUBR_Z_P_ZZ__ // fsubr_z_p_zz_
                                when (_, '1000') => __encoding FABD_Z_P_ZZ__ // fabd_z_p_zz_
                                when (_, '1001') => __encoding FSCALE_Z_P_ZZ__ // fscale_z_p_zz_
                                when (_, '1010') => __encoding FMULX_Z_P_ZZ__ // fmulx_z_p_zz_
                                when (_, '1011') => __UNALLOCATED
                                when (_, '1100') => __encoding FDIVR_Z_P_ZZ__ // fdivr_z_p_zz_
                                when (_, '1101') => __encoding FDIV_Z_P_ZZ__ // fdiv_z_p_zz_
                                when (!'00', '0000') => __encoding FADD_Z_P_ZZ__ // fadd_z_p_zz_
                                when (!'00', '0001') => __encoding FSUB_Z_P_ZZ__ // fsub_z_p_zz_
                                when (!'00', '0010') => __encoding FMUL_Z_P_ZZ__ // fmul_z_p_zz_
                                when (!'00', '0100') => __encoding FMAXNM_Z_P_ZZ__ // fmaxnm_z_p_zz_
                                when (!'00', '0101') => __encoding FMINNM_Z_P_ZZ__ // fminnm_z_p_zz_
                                when (!'00', '0110') => __encoding FMAX_Z_P_ZZ__ // fmax_z_p_zz_
                                when (!'00', '0111') => __encoding FMIN_Z_P_ZZ__ // fmin_z_p_zz_
                                when ('00', '0000') => __encoding BFADD_Z_P_ZZ__ // bfadd_z_p_zz_
                                when ('00', '0001') => __encoding BFSUB_Z_P_ZZ__ // bfsub_z_p_zz_
                                when ('00', '0010') => __encoding BFMUL_Z_P_ZZ__ // bfmul_z_p_zz_
                                when ('00', '0100') => __encoding BFMAXNM_Z_P_ZZ__ // bfmaxnm_z_p_zz_
                                when ('00', '0101') => __encoding BFMINNM_Z_P_ZZ__ // bfminnm_z_p_zz_
                                when ('00', '0110') => __encoding BFMAX_Z_P_ZZ__ // bfmax_z_p_zz_
                                when ('00', '0111') => __encoding BFMIN_Z_P_ZZ__ // bfmin_z_p_zz_
                        when (_, _, _, '10', _, _, '000', _, _) => // sve_fp_ftmad
                            __field size 22 +: 2
                            __field imm3 16 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding FTMAD_Z_ZZI__ // ftmad_z_zzi_
                        when (_, _, _, '10', _, _, !'000', _, _) => __UNPREDICTABLE
                        when (_, _, _, '11', _, _, _, '0000', _) => // sve_fp_2op_i_p_zds
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field i1 5 +: 1
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding FADD_Z_P_ZS__ // fadd_z_p_zs_
                                when ('001') => __encoding FSUB_Z_P_ZS__ // fsub_z_p_zs_
                                when ('010') => __encoding FMUL_Z_P_ZS__ // fmul_z_p_zs_
                                when ('011') => __encoding FSUBR_Z_P_ZS__ // fsubr_z_p_zs_
                                when ('100') => __encoding FMAXNM_Z_P_ZS__ // fmaxnm_z_p_zs_
                                when ('101') => __encoding FMINNM_Z_P_ZS__ // fminnm_z_p_zs_
                                when ('110') => __encoding FMAX_Z_P_ZS__ // fmax_z_p_zs_
                                when ('111') => __encoding FMIN_Z_P_ZS__ // fmin_z_p_zs_
                        when (_, _, _, '11', _, _, _, !'0000', _) => __UNPREDICTABLE
                when ('011', _, '1xx0xxxxx101xxx', _, _, _) =>
                    // sve_fp_unary
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '00x', _, _, _) => // sve_fp_2op_p_zd_a
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding FRINTN_Z_P_Z__ // frintn_z_p_z_
                                when ('001') => __encoding FRINTP_Z_P_Z__ // frintp_z_p_z_
                                when ('010') => __encoding FRINTM_Z_P_Z__ // frintm_z_p_z_
                                when ('011') => __encoding FRINTZ_Z_P_Z__ // frintz_z_p_z_
                                when ('100') => __encoding FRINTA_Z_P_Z__ // frinta_z_p_z_
                                when ('101') => __UNALLOCATED
                                when ('110') => __encoding FRINTX_Z_P_Z__ // frintx_z_p_z_
                                when ('111') => __encoding FRINTI_Z_P_Z__ // frinti_z_p_z_
                        when (_, _, _, '010', _, _, _) => // sve_fp_2op_p_zd_b_0
                            __field opc 22 +: 2
                            __field opc2 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('x0', '11') => __UNALLOCATED
                                when ('00', '0x') => __UNALLOCATED
                                when ('00', '10') => __encoding FCVTX_Z_P_Z_D2S // fcvtx_z_p_z_d2s
                                when ('01', _) => __UNALLOCATED
                                when ('10', '00') => __encoding FCVT_Z_P_Z_S2H // fcvt_z_p_z_s2h
                                when ('10', '01') => __encoding FCVT_Z_P_Z_H2S // fcvt_z_p_z_h2s
                                when ('10', '10') => __encoding BFCVT_Z_P_Z_S2BF // bfcvt_z_p_z_s2bf
                                when ('11', '00') => __encoding FCVT_Z_P_Z_D2H // fcvt_z_p_z_d2h
                                when ('11', '01') => __encoding FCVT_Z_P_Z_H2D // fcvt_z_p_z_h2d
                                when ('11', '10') => __encoding FCVT_Z_P_Z_D2S // fcvt_z_p_z_d2s
                                when ('11', '11') => __encoding FCVT_Z_P_Z_S2D // fcvt_z_p_z_s2d
                        when (_, _, _, '011', _, _, _) => // sve_fp_2op_p_zd_b_1
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding FRECPX_Z_P_Z__ // frecpx_z_p_z_
                                when ('01') => __encoding FSQRT_Z_P_Z__ // fsqrt_z_p_z_
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '10x', _, _, _) => // sve_fp_2op_p_zd_c
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2, U) of
                                when ('00', _, _) => __UNALLOCATED
                                when ('01', '00', _) => __UNALLOCATED
                                when ('01', '01', '0') => __encoding SCVTF_Z_P_Z_H2FP16 // scvtf_z_p_z_h2fp16
                                when ('01', '01', '1') => __encoding UCVTF_Z_P_Z_H2FP16 // ucvtf_z_p_z_h2fp16
                                when ('01', '10', '0') => __encoding SCVTF_Z_P_Z_W2FP16 // scvtf_z_p_z_w2fp16
                                when ('01', '10', '1') => __encoding UCVTF_Z_P_Z_W2FP16 // ucvtf_z_p_z_w2fp16
                                when ('01', '11', '0') => __encoding SCVTF_Z_P_Z_X2FP16 // scvtf_z_p_z_x2fp16
                                when ('01', '11', '1') => __encoding UCVTF_Z_P_Z_X2FP16 // ucvtf_z_p_z_x2fp16
                                when ('10', '0x', _) => __UNALLOCATED
                                when ('10', '10', '0') => __encoding SCVTF_Z_P_Z_W2S // scvtf_z_p_z_w2s
                                when ('10', '10', '1') => __encoding UCVTF_Z_P_Z_W2S // ucvtf_z_p_z_w2s
                                when ('10', '11', _) => __UNALLOCATED
                                when ('11', '00', '0') => __encoding SCVTF_Z_P_Z_W2D // scvtf_z_p_z_w2d
                                when ('11', '00', '1') => __encoding UCVTF_Z_P_Z_W2D // ucvtf_z_p_z_w2d
                                when ('11', '01', _) => __UNALLOCATED
                                when ('11', '10', '0') => __encoding SCVTF_Z_P_Z_X2S // scvtf_z_p_z_x2s
                                when ('11', '10', '1') => __encoding UCVTF_Z_P_Z_X2S // ucvtf_z_p_z_x2s
                                when ('11', '11', '0') => __encoding SCVTF_Z_P_Z_X2D // scvtf_z_p_z_x2d
                                when ('11', '11', '1') => __encoding UCVTF_Z_P_Z_X2D // ucvtf_z_p_z_x2d
                        when (_, _, _, '11x', _, _, _) => // sve_fp_2op_p_zd_d
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2, U) of
                                when ('00', _, '0') => __encoding FLOGB_Z_P_Z__ // flogb_z_p_z_
                                when ('00', _, '1') => __UNALLOCATED
                                when ('01', '00', _) => __UNALLOCATED
                                when ('01', '01', '0') => __encoding FCVTZS_Z_P_Z_FP162H // fcvtzs_z_p_z_fp162h
                                when ('01', '01', '1') => __encoding FCVTZU_Z_P_Z_FP162H // fcvtzu_z_p_z_fp162h
                                when ('01', '10', '0') => __encoding FCVTZS_Z_P_Z_FP162W // fcvtzs_z_p_z_fp162w
                                when ('01', '10', '1') => __encoding FCVTZU_Z_P_Z_FP162W // fcvtzu_z_p_z_fp162w
                                when ('01', '11', '0') => __encoding FCVTZS_Z_P_Z_FP162X // fcvtzs_z_p_z_fp162x
                                when ('01', '11', '1') => __encoding FCVTZU_Z_P_Z_FP162X // fcvtzu_z_p_z_fp162x
                                when ('10', '0x', _) => __UNALLOCATED
                                when ('10', '10', '0') => __encoding FCVTZS_Z_P_Z_S2W // fcvtzs_z_p_z_s2w
                                when ('10', '10', '1') => __encoding FCVTZU_Z_P_Z_S2W // fcvtzu_z_p_z_s2w
                                when ('10', '11', _) => __UNALLOCATED
                                when ('11', '00', '0') => __encoding FCVTZS_Z_P_Z_D2W // fcvtzs_z_p_z_d2w
                                when ('11', '00', '1') => __encoding FCVTZU_Z_P_Z_D2W // fcvtzu_z_p_z_d2w
                                when ('11', '01', _) => __UNALLOCATED
                                when ('11', '10', '0') => __encoding FCVTZS_Z_P_Z_S2X // fcvtzs_z_p_z_s2x
                                when ('11', '10', '1') => __encoding FCVTZU_Z_P_Z_S2X // fcvtzu_z_p_z_s2x
                                when ('11', '11', '0') => __encoding FCVTZS_Z_P_Z_D2X // fcvtzs_z_p_z_d2x
                                when ('11', '11', '1') => __encoding FCVTZU_Z_P_Z_D2X // fcvtzu_z_p_z_d2x
                when ('011', _, '1xx000xxx001xxx', _, _, _) => // sve_fp_fast_red
                    __field size 22 +: 2
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Vd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding FADDV_V_P_Z__ // faddv_v_p_z_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding FMAXNMV_V_P_Z__ // fmaxnmv_v_p_z_
                        when ('101') => __encoding FMINNMV_V_P_Z__ // fminnmv_v_p_z_
                        when ('110') => __encoding FMAXV_V_P_Z__ // fmaxv_v_p_z_
                        when ('111') => __encoding FMINV_V_P_Z__ // fminv_v_p_z_
                when ('011', _, '1xx001xxx0010xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx001xxx0011xx', _, _, _) =>
                    // sve_fp_unary_unpred
                    case (24 +: 8, 22 +: 2, 19 +: 3, 16 +: 3, 12 +: 4, 10 +: 2, 0 +: 10) of
                        when (_, _, _, _, _, '00', _) => // sve_fp_2op_u_zd
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('0xx') => __UNALLOCATED
                                when ('10x') => __UNALLOCATED
                                when ('110') => __encoding FRECPE_Z_Z__ // frecpe_z_z_
                                when ('111') => __encoding FRSQRTE_Z_Z__ // frsqrte_z_z_
                        when (_, _, _, _, _, !'00', _) => __UNPREDICTABLE
                when ('011', _, '1xx010xxx001xxx', _, _, _) =>
                    // sve_fp_cmpzero
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '0', _, _, _) => // sve_fp_2op_p_pd
                            __field size 22 +: 2
                            __field eq 17 +: 1
                            __field lt 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (eq, lt, ne) of
                                when ('0', '0', '0') => __encoding FCMGE_P_P_Z0__ // fcmge_p_p_z0_
                                when ('0', '0', '1') => __encoding FCMGT_P_P_Z0__ // fcmgt_p_p_z0_
                                when ('0', '1', '0') => __encoding FCMLT_P_P_Z0__ // fcmlt_p_p_z0_
                                when ('0', '1', '1') => __encoding FCMLE_P_P_Z0__ // fcmle_p_p_z0_
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding FCMEQ_P_P_Z0__ // fcmeq_p_p_z0_
                                when ('1', '1', '0') => __encoding FCMNE_P_P_Z0__ // fcmne_p_p_z0_
                        when (_, _, _, '1', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx011xxx001xxx', _, _, _) =>
                    // sve_fp_slowreduce
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '0', _, _, _) => // sve_fp_2op_p_vd
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Vdn 0 +: 5
                            case (opc) of
                                when ('00') => __encoding FADDA_V_P_Z__ // fadda_v_p_z_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '1', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx1xxxxxxxxxxx', _, _, _) =>
                    // sve_fp_fma
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 0 +: 15) of
                        when (_, _, _, _, '0', _) => // sve_fp_3op_p_zds_a
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, opc) of
                                when (_, '10') => __encoding FNMLA_Z_P_ZZZ__ // fnmla_z_p_zzz_
                                when (_, '11') => __encoding FNMLS_Z_P_ZZZ__ // fnmls_z_p_zzz_
                                when (!'00', '00') => __encoding FMLA_Z_P_ZZZ__ // fmla_z_p_zzz_
                                when (!'00', '01') => __encoding FMLS_Z_P_ZZZ__ // fmls_z_p_zzz_
                                when ('00', '00') => __encoding BFMLA_Z_P_ZZZ__ // bfmla_z_p_zzz_
                                when ('00', '01') => __encoding BFMLS_Z_P_ZZZ__ // bfmls_z_p_zzz_
                        when (_, _, _, _, '1', _) => // sve_fp_3op_p_zds_b
                            __field size 22 +: 2
                            __field Za 16 +: 5
                            __field opc 13 +: 2
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('00') => __encoding FMAD_Z_P_ZZZ__ // fmad_z_p_zzz_
                                when ('01') => __encoding FMSB_Z_P_ZZZ__ // fmsb_z_p_zzz_
                                when ('10') => __encoding FNMAD_Z_P_ZZZ__ // fnmad_z_p_zzz_
                                when ('11') => __encoding FNMSB_Z_P_ZZZ__ // fnmsb_z_p_zzz_
                when ('100', _, _, _, _, _) =>
                    // sve_mem32
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '00', 'x1', _, '0xx', _, '0', _) => // sve_mem_32b_prfm_sv
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BZ_S_x32_scaled // prfb_i_p_bz_s_x32_scaled
                                when ('01') => __encoding PRFH_I_P_BZ_S_x32_scaled // prfh_i_p_bz_s_x32_scaled
                                when ('10') => __encoding PRFW_I_P_BZ_S_x32_scaled // prfw_i_p_bz_s_x32_scaled
                                when ('11') => __encoding PRFD_I_P_BZ_S_x32_scaled // prfd_i_p_bz_s_x32_scaled
                        when (_, '00', 'x1', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, '01', 'x1', _, '0xx', _, _, _) => // sve_mem_32b_gld_sv_a
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (U, ff) of
                                when ('0', '0') => __encoding LD1SH_Z_P_BZ_S_x32_scaled // ld1sh_z_p_bz_s_x32_scaled
                                when ('0', '1') => __encoding LDFF1SH_Z_P_BZ_S_x32_scaled // ldff1sh_z_p_bz_s_x32_scaled
                                when ('1', '0') => __encoding LD1H_Z_P_BZ_S_x32_scaled // ld1h_z_p_bz_s_x32_scaled
                                when ('1', '1') => __encoding LDFF1H_Z_P_BZ_S_x32_scaled // ldff1h_z_p_bz_s_x32_scaled
                        when (_, '10', 'x1', _, '0xx', _, _, _) => // sve_mem_32b_gld_sv_b
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (U, ff) of
                                when ('0', _) => __UNALLOCATED
                                when ('1', '0') => __encoding LD1W_Z_P_BZ_S_x32_scaled // ld1w_z_p_bz_s_x32_scaled
                                when ('1', '1') => __encoding LDFF1W_Z_P_BZ_S_x32_scaled // ldff1w_z_p_bz_s_x32_scaled
                        when (_, '11', '0x', _, '000', _, '0', _) => // sve_mem_32b_pfill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Pt 0 +: 4
                            case () of
                                when () => __encoding LDR_P_BI__ // ldr_p_bi_
                        when (_, '11', '0x', _, '000', _, '1', _) => __UNPREDICTABLE
                        when (_, '11', '0x', _, '010', _, _, _) => // sve_mem_32b_fill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding LDR_Z_BI__ // ldr_z_bi_
                        when (_, '11', '0x', _, '0x1', _, _, _) => __UNPREDICTABLE
                        when (_, '11', '1x', _, '0xx', _, '0', _) => // sve_mem_prfm_si
                            __field imm6 16 +: 6
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BI_S // prfb_i_p_bi_s
                                when ('01') => __encoding PRFH_I_P_BI_S // prfh_i_p_bi_s
                                when ('10') => __encoding PRFW_I_P_BI_S // prfw_i_p_bi_s
                                when ('11') => __encoding PRFD_I_P_BI_S // prfd_i_p_bi_s
                        when (_, '11', '1x', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, !'11', 'x0', _, '0xx', _, _, _) => // sve_mem_32b_gld_vs
                            __field opc 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_BZ_S_x32_unscaled // ld1sb_z_p_bz_s_x32_unscaled
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_BZ_S_x32_unscaled // ldff1sb_z_p_bz_s_x32_unscaled
                                when ('00', '1', '0') => __encoding LD1B_Z_P_BZ_S_x32_unscaled // ld1b_z_p_bz_s_x32_unscaled
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_BZ_S_x32_unscaled // ldff1b_z_p_bz_s_x32_unscaled
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_S_x32_unscaled // ld1sh_z_p_bz_s_x32_unscaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_S_x32_unscaled // ldff1sh_z_p_bz_s_x32_unscaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_S_x32_unscaled // ld1h_z_p_bz_s_x32_unscaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_S_x32_unscaled // ldff1h_z_p_bz_s_x32_unscaled
                                when ('10', '0', _) => __UNALLOCATED
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_S_x32_unscaled // ld1w_z_p_bz_s_x32_unscaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_S_x32_unscaled // ldff1w_z_p_bz_s_x32_unscaled
                        when (_, _, '00', _, '10x', _, _, _) => // sve_mem_32b_gldnt_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field U 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U) of
                                when ('00', '0') => __encoding LDNT1SB_Z_P_AR_S_x32_unscaled // ldnt1sb_z_p_ar_s_x32_unscaled
                                when ('00', '1') => __encoding LDNT1B_Z_P_AR_S_x32_unscaled // ldnt1b_z_p_ar_s_x32_unscaled
                                when ('01', '0') => __encoding LDNT1SH_Z_P_AR_S_x32_unscaled // ldnt1sh_z_p_ar_s_x32_unscaled
                                when ('01', '1') => __encoding LDNT1H_Z_P_AR_S_x32_unscaled // ldnt1h_z_p_ar_s_x32_unscaled
                                when ('10', '0') => __UNALLOCATED
                                when ('10', '1') => __encoding LDNT1W_Z_P_AR_S_x32_unscaled // ldnt1w_z_p_ar_s_x32_unscaled
                                when ('11', _) => __UNALLOCATED
                        when (_, _, '00', _, '110', _, '0', _) => // sve_mem_prfm_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BR_S // prfb_i_p_br_s
                                when ('01') => __encoding PRFH_I_P_BR_S // prfh_i_p_br_s
                                when ('10') => __encoding PRFW_I_P_BR_S // prfw_i_p_br_s
                                when ('11') => __encoding PRFD_I_P_BR_S // prfd_i_p_br_s
                        when (_, _, '00', _, '111', _, '0', _) => // sve_mem_32b_prfm_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_AI_S // prfb_i_p_ai_s
                                when ('01') => __encoding PRFH_I_P_AI_S // prfh_i_p_ai_s
                                when ('10') => __encoding PRFW_I_P_AI_S // prfw_i_p_ai_s
                                when ('11') => __encoding PRFD_I_P_AI_S // prfd_i_p_ai_s
                        when (_, _, '00', _, '11x', _, '1', _) => __UNPREDICTABLE
                        when (_, _, '01', _, '1xx', _, _, _) => // sve_mem_32b_gld_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_AI_S // ld1sb_z_p_ai_s
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_AI_S // ldff1sb_z_p_ai_s
                                when ('00', '1', '0') => __encoding LD1B_Z_P_AI_S // ld1b_z_p_ai_s
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_AI_S // ldff1b_z_p_ai_s
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_AI_S // ld1sh_z_p_ai_s
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_AI_S // ldff1sh_z_p_ai_s
                                when ('01', '1', '0') => __encoding LD1H_Z_P_AI_S // ld1h_z_p_ai_s
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_AI_S // ldff1h_z_p_ai_s
                                when ('10', '0', _) => __UNALLOCATED
                                when ('10', '1', '0') => __encoding LD1W_Z_P_AI_S // ld1w_z_p_ai_s
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_AI_S // ldff1w_z_p_ai_s
                                when ('11', _, _) => __UNALLOCATED
                        when (_, _, '1x', _, '1xx', _, _, _) => // sve_mem_ld_dup
                            __field dtypeh 23 +: 2
                            __field imm6 16 +: 6
                            __field dtypel 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtypeh, dtypel) of
                                when ('00', '00') => __encoding LD1RB_Z_P_BI_U8 // ld1rb_z_p_bi_u8
                                when ('00', '01') => __encoding LD1RB_Z_P_BI_U16 // ld1rb_z_p_bi_u16
                                when ('00', '10') => __encoding LD1RB_Z_P_BI_U32 // ld1rb_z_p_bi_u32
                                when ('00', '11') => __encoding LD1RB_Z_P_BI_U64 // ld1rb_z_p_bi_u64
                                when ('01', '00') => __encoding LD1RSW_Z_P_BI_S64 // ld1rsw_z_p_bi_s64
                                when ('01', '01') => __encoding LD1RH_Z_P_BI_U16 // ld1rh_z_p_bi_u16
                                when ('01', '10') => __encoding LD1RH_Z_P_BI_U32 // ld1rh_z_p_bi_u32
                                when ('01', '11') => __encoding LD1RH_Z_P_BI_U64 // ld1rh_z_p_bi_u64
                                when ('10', '00') => __encoding LD1RSH_Z_P_BI_S64 // ld1rsh_z_p_bi_s64
                                when ('10', '01') => __encoding LD1RSH_Z_P_BI_S32 // ld1rsh_z_p_bi_s32
                                when ('10', '10') => __encoding LD1RW_Z_P_BI_U32 // ld1rw_z_p_bi_u32
                                when ('10', '11') => __encoding LD1RW_Z_P_BI_U64 // ld1rw_z_p_bi_u64
                                when ('11', '00') => __encoding LD1RSB_Z_P_BI_S64 // ld1rsb_z_p_bi_s64
                                when ('11', '01') => __encoding LD1RSB_Z_P_BI_S32 // ld1rsb_z_p_bi_s32
                                when ('11', '10') => __encoding LD1RSB_Z_P_BI_S16 // ld1rsb_z_p_bi_s16
                                when ('11', '11') => __encoding LD1RD_Z_P_BI_U64 // ld1rd_z_p_bi_u64
                when ('101', _, _, _, _, _) =>
                    // sve_memcld
                    case (25 +: 7, 23 +: 2, 21 +: 2, 20 +: 1, 16 +: 4, 13 +: 3, 0 +: 13) of
                        when (_, _, '00', '0', _, '111', _) => // sve_mem_cldnt_si
                            __field msz 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding LDNT1B_Z_P_BI_Contiguous // ldnt1b_z_p_bi_contiguous
                                when ('01') => __encoding LDNT1H_Z_P_BI_Contiguous // ldnt1h_z_p_bi_contiguous
                                when ('10') => __encoding LDNT1W_Z_P_BI_Contiguous // ldnt1w_z_p_bi_contiguous
                                when ('11') => __encoding LDNT1D_Z_P_BI_Contiguous // ldnt1d_z_p_bi_contiguous
                        when (_, _, '00', '1', _, '001', _) => // sve_mem_cld_si_q
                            __field dtype 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding LD1W_Z_P_BI_U128 // ld1w_z_p_bi_u128
                                when ('11') => __encoding LD1D_Z_P_BI_U128 // ld1d_z_p_bi_u128
                        when (_, _, '00', '1', _, '111', _) => // sve_mem_eldq_si
                            __field num 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding LD2Q_Z_P_BI_Contiguous // ld2q_z_p_bi_contiguous
                                when ('10') => __encoding LD3Q_Z_P_BI_Contiguous // ld3q_z_p_bi_contiguous
                                when ('11') => __encoding LD4Q_Z_P_BI_Contiguous // ld4q_z_p_bi_contiguous
                        when (_, _, '00', _, _, '100', _) => // sve_mem_cld_ss_q
                            __field dtype 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding LD1W_Z_P_BR_U128 // ld1w_z_p_br_u128
                                when ('11') => __encoding LD1D_Z_P_BR_U128 // ld1d_z_p_br_u128
                        when (_, _, '00', _, _, '110', _) => // sve_mem_cldnt_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding LDNT1B_Z_P_BR_Contiguous // ldnt1b_z_p_br_contiguous
                                when ('01') => __encoding LDNT1H_Z_P_BR_Contiguous // ldnt1h_z_p_br_contiguous
                                when ('10') => __encoding LDNT1W_Z_P_BR_Contiguous // ldnt1w_z_p_br_contiguous
                                when ('11') => __encoding LDNT1D_Z_P_BR_Contiguous // ldnt1d_z_p_br_contiguous
                        when (_, _, '01', _, _, '100', _) => // sve_mem_eldq_ss
                            __field num 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding LD2Q_Z_P_BR_Contiguous // ld2q_z_p_br_contiguous
                                when ('10') => __encoding LD3Q_Z_P_BR_Contiguous // ld3q_z_p_br_contiguous
                                when ('11') => __encoding LD4Q_Z_P_BR_Contiguous // ld4q_z_p_br_contiguous
                        when (_, _, '1x', _, _, '100', _) => __UNPREDICTABLE
                        when (_, _, !'00', '0', _, '111', _) => // sve_mem_eld_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding LD2B_Z_P_BI_Contiguous // ld2b_z_p_bi_contiguous
                                when ('00', '10') => __encoding LD3B_Z_P_BI_Contiguous // ld3b_z_p_bi_contiguous
                                when ('00', '11') => __encoding LD4B_Z_P_BI_Contiguous // ld4b_z_p_bi_contiguous
                                when ('01', '01') => __encoding LD2H_Z_P_BI_Contiguous // ld2h_z_p_bi_contiguous
                                when ('01', '10') => __encoding LD3H_Z_P_BI_Contiguous // ld3h_z_p_bi_contiguous
                                when ('01', '11') => __encoding LD4H_Z_P_BI_Contiguous // ld4h_z_p_bi_contiguous
                                when ('10', '01') => __encoding LD2W_Z_P_BI_Contiguous // ld2w_z_p_bi_contiguous
                                when ('10', '10') => __encoding LD3W_Z_P_BI_Contiguous // ld3w_z_p_bi_contiguous
                                when ('10', '11') => __encoding LD4W_Z_P_BI_Contiguous // ld4w_z_p_bi_contiguous
                                when ('11', '01') => __encoding LD2D_Z_P_BI_Contiguous // ld2d_z_p_bi_contiguous
                                when ('11', '10') => __encoding LD3D_Z_P_BI_Contiguous // ld3d_z_p_bi_contiguous
                                when ('11', '11') => __encoding LD4D_Z_P_BI_Contiguous // ld4d_z_p_bi_contiguous
                        when (_, _, !'00', '1', _, '001', _) => __UNPREDICTABLE
                        when (_, _, !'00', '1', _, '111', _) => __UNPREDICTABLE
                        when (_, _, !'00', _, _, '110', _) => // sve_mem_eld_ss
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding LD2B_Z_P_BR_Contiguous // ld2b_z_p_br_contiguous
                                when ('00', '10') => __encoding LD3B_Z_P_BR_Contiguous // ld3b_z_p_br_contiguous
                                when ('00', '11') => __encoding LD4B_Z_P_BR_Contiguous // ld4b_z_p_br_contiguous
                                when ('01', '01') => __encoding LD2H_Z_P_BR_Contiguous // ld2h_z_p_br_contiguous
                                when ('01', '10') => __encoding LD3H_Z_P_BR_Contiguous // ld3h_z_p_br_contiguous
                                when ('01', '11') => __encoding LD4H_Z_P_BR_Contiguous // ld4h_z_p_br_contiguous
                                when ('10', '01') => __encoding LD2W_Z_P_BR_Contiguous // ld2w_z_p_br_contiguous
                                when ('10', '10') => __encoding LD3W_Z_P_BR_Contiguous // ld3w_z_p_br_contiguous
                                when ('10', '11') => __encoding LD4W_Z_P_BR_Contiguous // ld4w_z_p_br_contiguous
                                when ('11', '01') => __encoding LD2D_Z_P_BR_Contiguous // ld2d_z_p_br_contiguous
                                when ('11', '10') => __encoding LD3D_Z_P_BR_Contiguous // ld3d_z_p_br_contiguous
                                when ('11', '11') => __encoding LD4D_Z_P_BR_Contiguous // ld4d_z_p_br_contiguous
                        when (_, _, _, '0', _, '001', _) => // sve_mem_ldqr_si
                            __field msz 23 +: 2
                            __field ssz 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, ssz) of
                                when (_, '1x') => __UNALLOCATED
                                when ('00', '00') => __encoding LD1RQB_Z_P_BI_U8 // ld1rqb_z_p_bi_u8
                                when ('00', '01') => __encoding LD1ROB_Z_P_BI_U8 // ld1rob_z_p_bi_u8
                                when ('01', '00') => __encoding LD1RQH_Z_P_BI_U16 // ld1rqh_z_p_bi_u16
                                when ('01', '01') => __encoding LD1ROH_Z_P_BI_U16 // ld1roh_z_p_bi_u16
                                when ('10', '00') => __encoding LD1RQW_Z_P_BI_U32 // ld1rqw_z_p_bi_u32
                                when ('10', '01') => __encoding LD1ROW_Z_P_BI_U32 // ld1row_z_p_bi_u32
                                when ('11', '00') => __encoding LD1RQD_Z_P_BI_U64 // ld1rqd_z_p_bi_u64
                                when ('11', '01') => __encoding LD1ROD_Z_P_BI_U64 // ld1rod_z_p_bi_u64
                        when (_, _, _, '0', _, '101', _) => // sve_mem_cld_si
                            __field dtype 21 +: 4
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding LD1B_Z_P_BI_U8 // ld1b_z_p_bi_u8
                                when ('0001') => __encoding LD1B_Z_P_BI_U16 // ld1b_z_p_bi_u16
                                when ('0010') => __encoding LD1B_Z_P_BI_U32 // ld1b_z_p_bi_u32
                                when ('0011') => __encoding LD1B_Z_P_BI_U64 // ld1b_z_p_bi_u64
                                when ('0100') => __encoding LD1SW_Z_P_BI_S64 // ld1sw_z_p_bi_s64
                                when ('0101') => __encoding LD1H_Z_P_BI_U16 // ld1h_z_p_bi_u16
                                when ('0110') => __encoding LD1H_Z_P_BI_U32 // ld1h_z_p_bi_u32
                                when ('0111') => __encoding LD1H_Z_P_BI_U64 // ld1h_z_p_bi_u64
                                when ('1000') => __encoding LD1SH_Z_P_BI_S64 // ld1sh_z_p_bi_s64
                                when ('1001') => __encoding LD1SH_Z_P_BI_S32 // ld1sh_z_p_bi_s32
                                when ('1010') => __encoding LD1W_Z_P_BI_U32 // ld1w_z_p_bi_u32
                                when ('1011') => __encoding LD1W_Z_P_BI_U64 // ld1w_z_p_bi_u64
                                when ('1100') => __encoding LD1SB_Z_P_BI_S64 // ld1sb_z_p_bi_s64
                                when ('1101') => __encoding LD1SB_Z_P_BI_S32 // ld1sb_z_p_bi_s32
                                when ('1110') => __encoding LD1SB_Z_P_BI_S16 // ld1sb_z_p_bi_s16
                                when ('1111') => __encoding LD1D_Z_P_BI_U64 // ld1d_z_p_bi_u64
                        when (_, _, _, '1', _, '101', _) => // sve_mem_cldnf_si
                            __field dtype 21 +: 4
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding LDNF1B_Z_P_BI_U8 // ldnf1b_z_p_bi_u8
                                when ('0001') => __encoding LDNF1B_Z_P_BI_U16 // ldnf1b_z_p_bi_u16
                                when ('0010') => __encoding LDNF1B_Z_P_BI_U32 // ldnf1b_z_p_bi_u32
                                when ('0011') => __encoding LDNF1B_Z_P_BI_U64 // ldnf1b_z_p_bi_u64
                                when ('0100') => __encoding LDNF1SW_Z_P_BI_S64 // ldnf1sw_z_p_bi_s64
                                when ('0101') => __encoding LDNF1H_Z_P_BI_U16 // ldnf1h_z_p_bi_u16
                                when ('0110') => __encoding LDNF1H_Z_P_BI_U32 // ldnf1h_z_p_bi_u32
                                when ('0111') => __encoding LDNF1H_Z_P_BI_U64 // ldnf1h_z_p_bi_u64
                                when ('1000') => __encoding LDNF1SH_Z_P_BI_S64 // ldnf1sh_z_p_bi_s64
                                when ('1001') => __encoding LDNF1SH_Z_P_BI_S32 // ldnf1sh_z_p_bi_s32
                                when ('1010') => __encoding LDNF1W_Z_P_BI_U32 // ldnf1w_z_p_bi_u32
                                when ('1011') => __encoding LDNF1W_Z_P_BI_U64 // ldnf1w_z_p_bi_u64
                                when ('1100') => __encoding LDNF1SB_Z_P_BI_S64 // ldnf1sb_z_p_bi_s64
                                when ('1101') => __encoding LDNF1SB_Z_P_BI_S32 // ldnf1sb_z_p_bi_s32
                                when ('1110') => __encoding LDNF1SB_Z_P_BI_S16 // ldnf1sb_z_p_bi_s16
                                when ('1111') => __encoding LDNF1D_Z_P_BI_U64 // ldnf1d_z_p_bi_u64
                        when (_, _, _, _, _, '000', _) => // sve_mem_ldqr_ss
                            __field msz 23 +: 2
                            __field ssz 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, ssz) of
                                when (_, '1x') => __UNALLOCATED
                                when ('00', '00') => __encoding LD1RQB_Z_P_BR_Contiguous // ld1rqb_z_p_br_contiguous
                                when ('00', '01') => __encoding LD1ROB_Z_P_BR_Contiguous // ld1rob_z_p_br_contiguous
                                when ('01', '00') => __encoding LD1RQH_Z_P_BR_Contiguous // ld1rqh_z_p_br_contiguous
                                when ('01', '01') => __encoding LD1ROH_Z_P_BR_Contiguous // ld1roh_z_p_br_contiguous
                                when ('10', '00') => __encoding LD1RQW_Z_P_BR_Contiguous // ld1rqw_z_p_br_contiguous
                                when ('10', '01') => __encoding LD1ROW_Z_P_BR_Contiguous // ld1row_z_p_br_contiguous
                                when ('11', '00') => __encoding LD1RQD_Z_P_BR_Contiguous // ld1rqd_z_p_br_contiguous
                                when ('11', '01') => __encoding LD1ROD_Z_P_BR_Contiguous // ld1rod_z_p_br_contiguous
                        when (_, _, _, _, _, '010', _) => // sve_mem_cld_ss
                            __field dtype 21 +: 4
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding LD1B_Z_P_BR_U8 // ld1b_z_p_br_u8
                                when ('0001') => __encoding LD1B_Z_P_BR_U16 // ld1b_z_p_br_u16
                                when ('0010') => __encoding LD1B_Z_P_BR_U32 // ld1b_z_p_br_u32
                                when ('0011') => __encoding LD1B_Z_P_BR_U64 // ld1b_z_p_br_u64
                                when ('0100') => __encoding LD1SW_Z_P_BR_S64 // ld1sw_z_p_br_s64
                                when ('0101') => __encoding LD1H_Z_P_BR_U16 // ld1h_z_p_br_u16
                                when ('0110') => __encoding LD1H_Z_P_BR_U32 // ld1h_z_p_br_u32
                                when ('0111') => __encoding LD1H_Z_P_BR_U64 // ld1h_z_p_br_u64
                                when ('1000') => __encoding LD1SH_Z_P_BR_S64 // ld1sh_z_p_br_s64
                                when ('1001') => __encoding LD1SH_Z_P_BR_S32 // ld1sh_z_p_br_s32
                                when ('1010') => __encoding LD1W_Z_P_BR_U32 // ld1w_z_p_br_u32
                                when ('1011') => __encoding LD1W_Z_P_BR_U64 // ld1w_z_p_br_u64
                                when ('1100') => __encoding LD1SB_Z_P_BR_S64 // ld1sb_z_p_br_s64
                                when ('1101') => __encoding LD1SB_Z_P_BR_S32 // ld1sb_z_p_br_s32
                                when ('1110') => __encoding LD1SB_Z_P_BR_S16 // ld1sb_z_p_br_s16
                                when ('1111') => __encoding LD1D_Z_P_BR_U64 // ld1d_z_p_br_u64
                        when (_, _, _, _, _, '011', _) => // sve_mem_cldff_ss
                            __field dtype 21 +: 4
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding LDFF1B_Z_P_BR_U8 // ldff1b_z_p_br_u8
                                when ('0001') => __encoding LDFF1B_Z_P_BR_U16 // ldff1b_z_p_br_u16
                                when ('0010') => __encoding LDFF1B_Z_P_BR_U32 // ldff1b_z_p_br_u32
                                when ('0011') => __encoding LDFF1B_Z_P_BR_U64 // ldff1b_z_p_br_u64
                                when ('0100') => __encoding LDFF1SW_Z_P_BR_S64 // ldff1sw_z_p_br_s64
                                when ('0101') => __encoding LDFF1H_Z_P_BR_U16 // ldff1h_z_p_br_u16
                                when ('0110') => __encoding LDFF1H_Z_P_BR_U32 // ldff1h_z_p_br_u32
                                when ('0111') => __encoding LDFF1H_Z_P_BR_U64 // ldff1h_z_p_br_u64
                                when ('1000') => __encoding LDFF1SH_Z_P_BR_S64 // ldff1sh_z_p_br_s64
                                when ('1001') => __encoding LDFF1SH_Z_P_BR_S32 // ldff1sh_z_p_br_s32
                                when ('1010') => __encoding LDFF1W_Z_P_BR_U32 // ldff1w_z_p_br_u32
                                when ('1011') => __encoding LDFF1W_Z_P_BR_U64 // ldff1w_z_p_br_u64
                                when ('1100') => __encoding LDFF1SB_Z_P_BR_S64 // ldff1sb_z_p_br_s64
                                when ('1101') => __encoding LDFF1SB_Z_P_BR_S32 // ldff1sb_z_p_br_s32
                                when ('1110') => __encoding LDFF1SB_Z_P_BR_S16 // ldff1sb_z_p_br_s16
                                when ('1111') => __encoding LDFF1D_Z_P_BR_U64 // ldff1d_z_p_br_u64
                when ('110', _, _, _, _, _) =>
                    // sve_mem64
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '00', '00', _, '101', _, _, _) => // sve_mem_64b_gldq_vs
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding LD1Q_Z_P_AR_D_64_unscaled // ld1q_z_p_ar_d_64_unscaled
                        when (_, '00', '01', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', '11', _, '1xx', _, '0', _) => // sve_mem_64b_prfm_sv2
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BZ_D_64_scaled // prfb_i_p_bz_d_64_scaled
                                when ('01') => __encoding PRFH_I_P_BZ_D_64_scaled // prfh_i_p_bz_d_64_scaled
                                when ('10') => __encoding PRFW_I_P_BZ_D_64_scaled // prfw_i_p_bz_d_64_scaled
                                when ('11') => __encoding PRFD_I_P_BZ_D_64_scaled // prfd_i_p_bz_d_64_scaled
                        when (_, '00', '11', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, '00', 'x1', _, '0xx', _, '0', _) => // sve_mem_64b_prfm_sv
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BZ_D_x32_scaled // prfb_i_p_bz_d_x32_scaled
                                when ('01') => __encoding PRFH_I_P_BZ_D_x32_scaled // prfh_i_p_bz_d_x32_scaled
                                when ('10') => __encoding PRFW_I_P_BZ_D_x32_scaled // prfw_i_p_bz_d_x32_scaled
                                when ('11') => __encoding PRFD_I_P_BZ_D_x32_scaled // prfd_i_p_bz_d_x32_scaled
                        when (_, !'00', '00', _, '101', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', '11', _, '1xx', _, _, _) => // sve_mem_64b_gld_sv2
                            __field opc 23 +: 2
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_D_64_scaled // ld1sh_z_p_bz_d_64_scaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_D_64_scaled // ldff1sh_z_p_bz_d_64_scaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_D_64_scaled // ld1h_z_p_bz_d_64_scaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_D_64_scaled // ldff1h_z_p_bz_d_64_scaled
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_BZ_D_64_scaled // ld1sw_z_p_bz_d_64_scaled
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_BZ_D_64_scaled // ldff1sw_z_p_bz_d_64_scaled
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_D_64_scaled // ld1w_z_p_bz_d_64_scaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_D_64_scaled // ldff1w_z_p_bz_d_64_scaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_BZ_D_64_scaled // ld1d_z_p_bz_d_64_scaled
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_BZ_D_64_scaled // ldff1d_z_p_bz_d_64_scaled
                        when (_, !'00', 'x1', _, '0xx', _, _, _) => // sve_mem_64b_gld_sv
                            __field opc 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_D_x32_scaled // ld1sh_z_p_bz_d_x32_scaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_D_x32_scaled // ldff1sh_z_p_bz_d_x32_scaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_D_x32_scaled // ld1h_z_p_bz_d_x32_scaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_D_x32_scaled // ldff1h_z_p_bz_d_x32_scaled
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_BZ_D_x32_scaled // ld1sw_z_p_bz_d_x32_scaled
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_BZ_D_x32_scaled // ldff1sw_z_p_bz_d_x32_scaled
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_D_x32_scaled // ld1w_z_p_bz_d_x32_scaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_D_x32_scaled // ldff1w_z_p_bz_d_x32_scaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_BZ_D_x32_scaled // ld1d_z_p_bz_d_x32_scaled
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_BZ_D_x32_scaled // ldff1d_z_p_bz_d_x32_scaled
                        when (_, _, '00', _, '111', _, '0', _) => // sve_mem_64b_prfm_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_AI_D // prfb_i_p_ai_d
                                when ('01') => __encoding PRFH_I_P_AI_D // prfh_i_p_ai_d
                                when ('10') => __encoding PRFW_I_P_AI_D // prfw_i_p_ai_d
                                when ('11') => __encoding PRFD_I_P_AI_D // prfd_i_p_ai_d
                        when (_, _, '00', _, '111', _, '1', _) => __UNPREDICTABLE
                        when (_, _, '00', _, '1x0', _, _, _) => // sve_mem_64b_gldnt_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field U 14 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U) of
                                when ('00', '0') => __encoding LDNT1SB_Z_P_AR_D_64_unscaled // ldnt1sb_z_p_ar_d_64_unscaled
                                when ('00', '1') => __encoding LDNT1B_Z_P_AR_D_64_unscaled // ldnt1b_z_p_ar_d_64_unscaled
                                when ('01', '0') => __encoding LDNT1SH_Z_P_AR_D_64_unscaled // ldnt1sh_z_p_ar_d_64_unscaled
                                when ('01', '1') => __encoding LDNT1H_Z_P_AR_D_64_unscaled // ldnt1h_z_p_ar_d_64_unscaled
                                when ('10', '0') => __encoding LDNT1SW_Z_P_AR_D_64_unscaled // ldnt1sw_z_p_ar_d_64_unscaled
                                when ('10', '1') => __encoding LDNT1W_Z_P_AR_D_64_unscaled // ldnt1w_z_p_ar_d_64_unscaled
                                when ('11', '0') => __UNALLOCATED
                                when ('11', '1') => __encoding LDNT1D_Z_P_AR_D_64_unscaled // ldnt1d_z_p_ar_d_64_unscaled
                        when (_, _, '01', _, '1xx', _, _, _) => // sve_mem_64b_gld_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_AI_D // ld1sb_z_p_ai_d
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_AI_D // ldff1sb_z_p_ai_d
                                when ('00', '1', '0') => __encoding LD1B_Z_P_AI_D // ld1b_z_p_ai_d
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_AI_D // ldff1b_z_p_ai_d
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_AI_D // ld1sh_z_p_ai_d
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_AI_D // ldff1sh_z_p_ai_d
                                when ('01', '1', '0') => __encoding LD1H_Z_P_AI_D // ld1h_z_p_ai_d
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_AI_D // ldff1h_z_p_ai_d
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_AI_D // ld1sw_z_p_ai_d
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_AI_D // ldff1sw_z_p_ai_d
                                when ('10', '1', '0') => __encoding LD1W_Z_P_AI_D // ld1w_z_p_ai_d
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_AI_D // ldff1w_z_p_ai_d
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_AI_D // ld1d_z_p_ai_d
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_AI_D // ldff1d_z_p_ai_d
                        when (_, _, '10', _, '1xx', _, _, _) => // sve_mem_64b_gld_vs2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_BZ_D_64_unscaled // ld1sb_z_p_bz_d_64_unscaled
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_BZ_D_64_unscaled // ldff1sb_z_p_bz_d_64_unscaled
                                when ('00', '1', '0') => __encoding LD1B_Z_P_BZ_D_64_unscaled // ld1b_z_p_bz_d_64_unscaled
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_BZ_D_64_unscaled // ldff1b_z_p_bz_d_64_unscaled
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_D_64_unscaled // ld1sh_z_p_bz_d_64_unscaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_D_64_unscaled // ldff1sh_z_p_bz_d_64_unscaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_D_64_unscaled // ld1h_z_p_bz_d_64_unscaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_D_64_unscaled // ldff1h_z_p_bz_d_64_unscaled
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_BZ_D_64_unscaled // ld1sw_z_p_bz_d_64_unscaled
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_BZ_D_64_unscaled // ldff1sw_z_p_bz_d_64_unscaled
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_D_64_unscaled // ld1w_z_p_bz_d_64_unscaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_D_64_unscaled // ldff1w_z_p_bz_d_64_unscaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_BZ_D_64_unscaled // ld1d_z_p_bz_d_64_unscaled
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_BZ_D_64_unscaled // ldff1d_z_p_bz_d_64_unscaled
                        when (_, _, 'x0', _, '0xx', _, _, _) => // sve_mem_64b_gld_vs
                            __field msz 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_BZ_D_x32_unscaled // ld1sb_z_p_bz_d_x32_unscaled
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_BZ_D_x32_unscaled // ldff1sb_z_p_bz_d_x32_unscaled
                                when ('00', '1', '0') => __encoding LD1B_Z_P_BZ_D_x32_unscaled // ld1b_z_p_bz_d_x32_unscaled
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_BZ_D_x32_unscaled // ldff1b_z_p_bz_d_x32_unscaled
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_D_x32_unscaled // ld1sh_z_p_bz_d_x32_unscaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_D_x32_unscaled // ldff1sh_z_p_bz_d_x32_unscaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_D_x32_unscaled // ld1h_z_p_bz_d_x32_unscaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_D_x32_unscaled // ldff1h_z_p_bz_d_x32_unscaled
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_BZ_D_x32_unscaled // ld1sw_z_p_bz_d_x32_unscaled
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_BZ_D_x32_unscaled // ldff1sw_z_p_bz_d_x32_unscaled
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_D_x32_unscaled // ld1w_z_p_bz_d_x32_unscaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_D_x32_unscaled // ldff1w_z_p_bz_d_x32_unscaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_BZ_D_x32_unscaled // ld1d_z_p_bz_d_x32_unscaled
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_BZ_D_x32_unscaled // ldff1d_z_p_bz_d_x32_unscaled
                when ('111', _, 'xxxxxxxxx0x0xxx', _, _, _) =>
                    // sve_memst_cs
                    case (25 +: 7, 22 +: 3, 20 +: 2, 16 +: 4, 15 +: 1, 14 +: 1, 13 +: 1, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '0xx', '00', _, _, '0', _, _, _, _) => // sve_mem_estq_si
                            __field num 22 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST2Q_Z_P_BI_Contiguous // st2q_z_p_bi_contiguous
                                when ('10') => __encoding ST3Q_Z_P_BI_Contiguous // st3q_z_p_bi_contiguous
                                when ('11') => __encoding ST4Q_Z_P_BI_Contiguous // st4q_z_p_bi_contiguous
                        when (_, '0xx', '01', _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, '0xx', '1x', _, _, '0', _, _, _, _) => // sve_mem_estq_ss
                            __field num 22 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST2Q_Z_P_BR_Contiguous // st2q_z_p_br_contiguous
                                when ('10') => __encoding ST3Q_Z_P_BR_Contiguous // st3q_z_p_br_contiguous
                                when ('11') => __encoding ST4Q_Z_P_BR_Contiguous // st4q_z_p_br_contiguous
                        when (_, '10x', _, _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, '110', _, _, _, '0', _, _, '0', _) => // sve_mem_pspill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Pt 0 +: 4
                            case () of
                                when () => __encoding STR_P_BI__ // str_p_bi_
                        when (_, '110', _, _, _, '0', _, _, '1', _) => __UNPREDICTABLE
                        when (_, '110', _, _, _, '1', _, _, _, _) => // sve_mem_spill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding STR_Z_BI__ // str_z_bi_
                        when (_, '111', _, _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, !'110', _, _, _, '1', _, _, _, _) => // sve_mem_cst_ss
                            __field opc 22 +: 3
                            __field o2 21 +: 1
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, o2) of
                                when ('00x', _) => __encoding ST1B_Z_P_BR__ // st1b_z_p_br_
                                when ('01x', _) => __encoding ST1H_Z_P_BR__ // st1h_z_p_br_
                                when ('100', '0') => __encoding ST1W_Z_P_BR_U128 // st1w_z_p_br_u128
                                when ('101', _) => __encoding ST1W_Z_P_BR__ // st1w_z_p_br_
                                when ('111', '0') => __encoding ST1D_Z_P_BR_U128 // st1d_z_p_br_u128
                                when ('111', '1') => __encoding ST1D_Z_P_BR__ // st1d_z_p_br_
                when ('111', _, 'xxxxxxxxx001xxx', _, _, _) =>
                    // sve_memsst_nt
                    case (25 +: 7, 22 +: 3, 21 +: 1, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, '000', '1', _, _, _) => // sve_mem_sstq_64b_vs
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding ST1Q_Z_P_AR_D_64_unscaled // st1q_z_p_ar_d_64_unscaled
                        when (_, !'000', '1', _, _, _) => __UNPREDICTABLE
                        when (_, 'xx0', '0', _, _, _) => // sve_mem_sstnt_64b_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding STNT1B_Z_P_AR_D_64_unscaled // stnt1b_z_p_ar_d_64_unscaled
                                when ('01') => __encoding STNT1H_Z_P_AR_D_64_unscaled // stnt1h_z_p_ar_d_64_unscaled
                                when ('10') => __encoding STNT1W_Z_P_AR_D_64_unscaled // stnt1w_z_p_ar_d_64_unscaled
                                when ('11') => __encoding STNT1D_Z_P_AR_D_64_unscaled // stnt1d_z_p_ar_d_64_unscaled
                        when (_, 'xx1', '0', _, _, _) => // sve_mem_sstnt_32b_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding STNT1B_Z_P_AR_S_x32_unscaled // stnt1b_z_p_ar_s_x32_unscaled
                                when ('01') => __encoding STNT1H_Z_P_AR_S_x32_unscaled // stnt1h_z_p_ar_s_x32_unscaled
                                when ('10') => __encoding STNT1W_Z_P_AR_S_x32_unscaled // stnt1w_z_p_ar_s_x32_unscaled
                                when ('11') => __UNALLOCATED
                when ('111', _, 'xxxxxxxxx011xxx', _, _, _) =>
                    // sve_memcst_nt
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, _, '00', _, _, _) => // sve_mem_cstnt_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding STNT1B_Z_P_BR_Contiguous // stnt1b_z_p_br_contiguous
                                when ('01') => __encoding STNT1H_Z_P_BR_Contiguous // stnt1h_z_p_br_contiguous
                                when ('10') => __encoding STNT1W_Z_P_BR_Contiguous // stnt1w_z_p_br_contiguous
                                when ('11') => __encoding STNT1D_Z_P_BR_Contiguous // stnt1d_z_p_br_contiguous
                        when (_, _, !'00', _, _, _) => // sve_mem_est_ss
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding ST2B_Z_P_BR_Contiguous // st2b_z_p_br_contiguous
                                when ('00', '10') => __encoding ST3B_Z_P_BR_Contiguous // st3b_z_p_br_contiguous
                                when ('00', '11') => __encoding ST4B_Z_P_BR_Contiguous // st4b_z_p_br_contiguous
                                when ('01', '01') => __encoding ST2H_Z_P_BR_Contiguous // st2h_z_p_br_contiguous
                                when ('01', '10') => __encoding ST3H_Z_P_BR_Contiguous // st3h_z_p_br_contiguous
                                when ('01', '11') => __encoding ST4H_Z_P_BR_Contiguous // st4h_z_p_br_contiguous
                                when ('10', '01') => __encoding ST2W_Z_P_BR_Contiguous // st2w_z_p_br_contiguous
                                when ('10', '10') => __encoding ST3W_Z_P_BR_Contiguous // st3w_z_p_br_contiguous
                                when ('10', '11') => __encoding ST4W_Z_P_BR_Contiguous // st4w_z_p_br_contiguous
                                when ('11', '01') => __encoding ST2D_Z_P_BR_Contiguous // st2d_z_p_br_contiguous
                                when ('11', '10') => __encoding ST3D_Z_P_BR_Contiguous // st3d_z_p_br_contiguous
                                when ('11', '11') => __encoding ST4D_Z_P_BR_Contiguous // st4d_z_p_br_contiguous
                when ('111', _, 'xxxxxxxxx1x0xxx', _, _, _) =>
                    // sve_memst_ss
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 15 +: 1, 14 +: 1, 13 +: 1, 0 +: 13) of
                        when (_, _, '00', _, _, _, _, _) => // sve_mem_sst_vs_a
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_BZ_D_x32_unscaled // st1b_z_p_bz_d_x32_unscaled
                                when ('01') => __encoding ST1H_Z_P_BZ_D_x32_unscaled // st1h_z_p_bz_d_x32_unscaled
                                when ('10') => __encoding ST1W_Z_P_BZ_D_x32_unscaled // st1w_z_p_bz_d_x32_unscaled
                                when ('11') => __encoding ST1D_Z_P_BZ_D_x32_unscaled // st1d_z_p_bz_d_x32_unscaled
                        when (_, _, '01', _, _, _, _, _) => // sve_mem_sst_sv_a
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST1H_Z_P_BZ_D_x32_scaled // st1h_z_p_bz_d_x32_scaled
                                when ('10') => __encoding ST1W_Z_P_BZ_D_x32_scaled // st1w_z_p_bz_d_x32_scaled
                                when ('11') => __encoding ST1D_Z_P_BZ_D_x32_scaled // st1d_z_p_bz_d_x32_scaled
                        when (_, _, '10', _, _, _, _, _) => // sve_mem_sst_vs_b
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_BZ_S_x32_unscaled // st1b_z_p_bz_s_x32_unscaled
                                when ('01') => __encoding ST1H_Z_P_BZ_S_x32_unscaled // st1h_z_p_bz_s_x32_unscaled
                                when ('10') => __encoding ST1W_Z_P_BZ_S_x32_unscaled // st1w_z_p_bz_s_x32_unscaled
                                when ('11') => __UNALLOCATED
                        when (_, _, '11', _, _, _, _, _) => // sve_mem_sst_sv_b
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST1H_Z_P_BZ_S_x32_scaled // st1h_z_p_bz_s_x32_scaled
                                when ('10') => __encoding ST1W_Z_P_BZ_S_x32_scaled // st1w_z_p_bz_s_x32_scaled
                                when ('11') => __UNALLOCATED
                when ('111', _, 'xxxxxxxxx101xxx', _, _, _) =>
                    // sve_memst_ss2
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, _, '00', _, _, _) => // sve_mem_sst_vs2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_BZ_D_64_unscaled // st1b_z_p_bz_d_64_unscaled
                                when ('01') => __encoding ST1H_Z_P_BZ_D_64_unscaled // st1h_z_p_bz_d_64_unscaled
                                when ('10') => __encoding ST1W_Z_P_BZ_D_64_unscaled // st1w_z_p_bz_d_64_unscaled
                                when ('11') => __encoding ST1D_Z_P_BZ_D_64_unscaled // st1d_z_p_bz_d_64_unscaled
                        when (_, _, '01', _, _, _) => // sve_mem_sst_sv2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST1H_Z_P_BZ_D_64_scaled // st1h_z_p_bz_d_64_scaled
                                when ('10') => __encoding ST1W_Z_P_BZ_D_64_scaled // st1w_z_p_bz_d_64_scaled
                                when ('11') => __encoding ST1D_Z_P_BZ_D_64_scaled // st1d_z_p_bz_d_64_scaled
                        when (_, _, '10', _, _, _) => // sve_mem_sst_vi_a
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_AI_D // st1b_z_p_ai_d
                                when ('01') => __encoding ST1H_Z_P_AI_D // st1h_z_p_ai_d
                                when ('10') => __encoding ST1W_Z_P_AI_D // st1w_z_p_ai_d
                                when ('11') => __encoding ST1D_Z_P_AI_D // st1d_z_p_ai_d
                        when (_, _, '11', _, _, _) => // sve_mem_sst_vi_b
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_AI_S // st1b_z_p_ai_s
                                when ('01') => __encoding ST1H_Z_P_AI_S // st1h_z_p_ai_s
                                when ('10') => __encoding ST1W_Z_P_AI_S // st1w_z_p_ai_s
                                when ('11') => __UNALLOCATED
                when ('111', _, 'xxxxxxxxx111xxx', _, _, _) =>
                    // sve_memst_si
                    case (25 +: 7, 23 +: 2, 21 +: 2, 20 +: 1, 16 +: 4, 13 +: 3, 0 +: 13) of
                        when (_, _, '00', '1', _, _, _) => // sve_mem_cstnt_si
                            __field msz 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding STNT1B_Z_P_BI_Contiguous // stnt1b_z_p_bi_contiguous
                                when ('01') => __encoding STNT1H_Z_P_BI_Contiguous // stnt1h_z_p_bi_contiguous
                                when ('10') => __encoding STNT1W_Z_P_BI_Contiguous // stnt1w_z_p_bi_contiguous
                                when ('11') => __encoding STNT1D_Z_P_BI_Contiguous // stnt1d_z_p_bi_contiguous
                        when (_, _, !'00', '1', _, _, _) => // sve_mem_est_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding ST2B_Z_P_BI_Contiguous // st2b_z_p_bi_contiguous
                                when ('00', '10') => __encoding ST3B_Z_P_BI_Contiguous // st3b_z_p_bi_contiguous
                                when ('00', '11') => __encoding ST4B_Z_P_BI_Contiguous // st4b_z_p_bi_contiguous
                                when ('01', '01') => __encoding ST2H_Z_P_BI_Contiguous // st2h_z_p_bi_contiguous
                                when ('01', '10') => __encoding ST3H_Z_P_BI_Contiguous // st3h_z_p_bi_contiguous
                                when ('01', '11') => __encoding ST4H_Z_P_BI_Contiguous // st4h_z_p_bi_contiguous
                                when ('10', '01') => __encoding ST2W_Z_P_BI_Contiguous // st2w_z_p_bi_contiguous
                                when ('10', '10') => __encoding ST3W_Z_P_BI_Contiguous // st3w_z_p_bi_contiguous
                                when ('10', '11') => __encoding ST4W_Z_P_BI_Contiguous // st4w_z_p_bi_contiguous
                                when ('11', '01') => __encoding ST2D_Z_P_BI_Contiguous // st2d_z_p_bi_contiguous
                                when ('11', '10') => __encoding ST3D_Z_P_BI_Contiguous // st3d_z_p_bi_contiguous
                                when ('11', '11') => __encoding ST4D_Z_P_BI_Contiguous // st4d_z_p_bi_contiguous
                        when (_, _, _, '0', _, _, _) => // sve_mem_cst_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', _) => __encoding ST1B_Z_P_BI__ // st1b_z_p_bi_
                                when ('01', _) => __encoding ST1H_Z_P_BI__ // st1h_z_p_bi_
                                when ('10', '00') => __encoding ST1W_Z_P_BI_U128 // st1w_z_p_bi_u128
                                when ('10', '01') => __UNALLOCATED
                                when ('10', '1x') => __encoding ST1W_Z_P_BI__ // st1w_z_p_bi_
                                when ('11', '0x') => __UNALLOCATED
                                when ('11', '10') => __encoding ST1D_Z_P_BI_U128 // st1d_z_p_bi_u128
                                when ('11', '11') => __encoding ST1D_Z_P_BI__ // st1d_z_p_bi_
        when (_, _, '0011', _) => __UNPREDICTABLE
        when (_, _, '100x', _) =>
            // dpimm
            case (29 +: 3, 26 +: 3, 22 +: 4, 0 +: 22) of
                when (_, _, '00xx', _) => // pcreladdr
                    __field op 31 +: 1
                    __field immlo 29 +: 2
                    __field immhi 5 +: 19
                    __field Rd 0 +: 5
                    case (op) of
                        when ('0') => __encoding aarch64_integer_arithmetic_address_pc_rel // ADR_only_pcreladdr
                        when ('1') => __encoding aarch64_integer_arithmetic_address_pc_rel // ADRP_only_pcreladdr
                when (_, _, '010x', _) => // addsub_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field sh 22 +: 1
                    __field imm12 10 +: 12
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', '0', '0') => __encoding aarch64_integer_arithmetic_add_sub_immediate // ADD_32_addsub_imm
                        when ('0', '0', '1') => __encoding aarch64_integer_arithmetic_add_sub_immediate // ADDS_32S_addsub_imm
                        when ('0', '1', '0') => __encoding aarch64_integer_arithmetic_add_sub_immediate // SUB_32_addsub_imm
                        when ('0', '1', '1') => __encoding aarch64_integer_arithmetic_add_sub_immediate // SUBS_32S_addsub_imm
                        when ('1', '0', '0') => __encoding aarch64_integer_arithmetic_add_sub_immediate // ADD_64_addsub_imm
                        when ('1', '0', '1') => __encoding aarch64_integer_arithmetic_add_sub_immediate // ADDS_64S_addsub_imm
                        when ('1', '1', '0') => __encoding aarch64_integer_arithmetic_add_sub_immediate // SUB_64_addsub_imm
                        when ('1', '1', '1') => __encoding aarch64_integer_arithmetic_add_sub_immediate // SUBS_64S_addsub_imm
                when (_, _, '0110', _) => // addsub_immtags
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field uimm6 16 +: 6
                    __field op3 14 +: 2
                    __field uimm4 10 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', _, _) => __UNALLOCATED
                        when ('1', _, '1') => __UNALLOCATED
                        when ('1', '0', '0') => __encoding aarch64_integer_tags_mcaddtag // ADDG_64_addsub_immtags
                        when ('1', '1', '0') => __encoding aarch64_integer_tags_mcsubtag // SUBG_64_addsub_immtags
                when (_, _, '0111', _) => // minmax_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opc 18 +: 4
                    __field imm8 10 +: 8
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, opc) of
                        when (_, '0', _, '01xx') => __UNALLOCATED
                        when (_, '0', _, '1xxx') => __UNALLOCATED
                        when (_, '0', '1', '00xx') => __UNALLOCATED
                        when (_, '1', _, _) => __UNALLOCATED
                        when ('0', '0', '0', '0000') => __encoding aarch64_integer_arithmetic_max_min_smax_imm // SMAX_32_minmax_imm
                        when ('0', '0', '0', '0001') => __encoding aarch64_integer_arithmetic_max_min_umax_imm // UMAX_32U_minmax_imm
                        when ('0', '0', '0', '0010') => __encoding aarch64_integer_arithmetic_max_min_smin_imm // SMIN_32_minmax_imm
                        when ('0', '0', '0', '0011') => __encoding aarch64_integer_arithmetic_max_min_umin_imm // UMIN_32U_minmax_imm
                        when ('1', '0', '0', '0000') => __encoding aarch64_integer_arithmetic_max_min_smax_imm // SMAX_64_minmax_imm
                        when ('1', '0', '0', '0001') => __encoding aarch64_integer_arithmetic_max_min_umax_imm // UMAX_64U_minmax_imm
                        when ('1', '0', '0', '0010') => __encoding aarch64_integer_arithmetic_max_min_smin_imm // SMIN_64_minmax_imm
                        when ('1', '0', '0', '0011') => __encoding aarch64_integer_arithmetic_max_min_umin_imm // UMIN_64U_minmax_imm
                when (_, _, '100x', _) => // log_imm
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field N 22 +: 1
                    __field immr 16 +: 6
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N) of
                        when ('0', _, '1') => __UNALLOCATED
                        when ('0', '00', '0') => __encoding aarch64_integer_logical_immediate // AND_32_log_imm
                        when ('0', '01', '0') => __encoding aarch64_integer_logical_immediate // ORR_32_log_imm
                        when ('0', '10', '0') => __encoding aarch64_integer_logical_immediate // EOR_32_log_imm
                        when ('0', '11', '0') => __encoding aarch64_integer_logical_immediate // ANDS_32S_log_imm
                        when ('1', '00', _) => __encoding aarch64_integer_logical_immediate // AND_64_log_imm
                        when ('1', '01', _) => __encoding aarch64_integer_logical_immediate // ORR_64_log_imm
                        when ('1', '10', _) => __encoding aarch64_integer_logical_immediate // EOR_64_log_imm
                        when ('1', '11', _) => __encoding aarch64_integer_logical_immediate // ANDS_64S_log_imm
                when (_, _, '101x', _) => // movewide
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field hw 21 +: 2
                    __field imm16 5 +: 16
                    __field Rd 0 +: 5
                    case (sf, opc, hw) of
                        when (_, '01', _) => __UNALLOCATED
                        when ('0', _, '1x') => __UNALLOCATED
                        when ('0', '00', '0x') => __encoding aarch64_integer_ins_ext_insert_movewide // MOVN_32_movewide
                        when ('0', '10', '0x') => __encoding aarch64_integer_ins_ext_insert_movewide // MOVZ_32_movewide
                        when ('0', '11', '0x') => __encoding aarch64_integer_ins_ext_insert_movewide // MOVK_32_movewide
                        when ('1', '00', _) => __encoding aarch64_integer_ins_ext_insert_movewide // MOVN_64_movewide
                        when ('1', '10', _) => __encoding aarch64_integer_ins_ext_insert_movewide // MOVZ_64_movewide
                        when ('1', '11', _) => __encoding aarch64_integer_ins_ext_insert_movewide // MOVK_64_movewide
                when (_, _, '110x', _) => // bitfield
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field N 22 +: 1
                    __field immr 16 +: 6
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N) of
                        when (_, '11', _) => __UNALLOCATED
                        when ('0', _, '1') => __UNALLOCATED
                        when ('0', '00', '0') => __encoding aarch64_integer_bitfield // SBFM_32M_bitfield
                        when ('0', '01', '0') => __encoding aarch64_integer_bitfield // BFM_32M_bitfield
                        when ('0', '10', '0') => __encoding aarch64_integer_bitfield // UBFM_32M_bitfield
                        when ('1', _, '0') => __UNALLOCATED
                        when ('1', '00', '1') => __encoding aarch64_integer_bitfield // SBFM_64M_bitfield
                        when ('1', '01', '1') => __encoding aarch64_integer_bitfield // BFM_64M_bitfield
                        when ('1', '10', '1') => __encoding aarch64_integer_bitfield // UBFM_64M_bitfield
                when (_, _, '111x', _) => // extract
                    __field sf 31 +: 1
                    __field op21 29 +: 2
                    __field N 22 +: 1
                    __field o0 21 +: 1
                    __field Rm 16 +: 5
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op21, N, o0, imms) of
                        when (_, 'x1', _, _, _) => __UNALLOCATED
                        when (_, '00', _, '1', _) => __UNALLOCATED
                        when (_, '1x', _, _, _) => __UNALLOCATED
                        when ('0', _, _, _, '1xxxxx') => __UNALLOCATED
                        when ('0', _, '1', _, _) => __UNALLOCATED
                        when ('0', '00', '0', '0', '0xxxxx') => __encoding aarch64_integer_ins_ext_extract_immediate // EXTR_32_extract
                        when ('1', _, '0', _, _) => __UNALLOCATED
                        when ('1', '00', '1', '0', _) => __encoding aarch64_integer_ins_ext_extract_immediate // EXTR_64_extract
        when (_, _, '101x', _) =>
            // control
            case (29 +: 3, 26 +: 3, 12 +: 14, 5 +: 7, 0 +: 5) of
                when ('010', _, '0xxxxxxxxxxxxx', _, _) => // condbranch
                    __field o1 24 +: 1
                    __field imm19 5 +: 19
                    __field o0 4 +: 1
                    __field cond 0 +: 4
                    case (o1, o0) of
                        when ('0', '0') => __encoding aarch64_branch_conditional_cond // B_only_condbranch
                        when ('0', '1') => __encoding aarch64_branch_conditional_hinted // BC_only_condbranch
                        when ('1', _) => __UNALLOCATED
                when ('110', _, '00xxxxxxxxxxxx', _, _) => // exception
                    __field opc 21 +: 3
                    __field imm16 5 +: 16
                    __field op2 2 +: 3
                    __field LL 0 +: 2
                    case (opc, op2, LL) of
                        when (_, '001', _) => __UNALLOCATED
                        when (_, '01x', _) => __UNALLOCATED
                        when (_, '1xx', _) => __UNALLOCATED
                        when ('000', '000', '00') => __UNALLOCATED
                        when ('000', '000', '01') => __encoding aarch64_system_exceptions_runtime_svc // SVC_EX_exception
                        when ('000', '000', '10') => __encoding aarch64_system_exceptions_runtime_hvc // HVC_EX_exception
                        when ('000', '000', '11') => __encoding aarch64_system_exceptions_runtime_smc // SMC_EX_exception
                        when ('001', '000', 'x1') => __UNALLOCATED
                        when ('001', '000', '00') => __encoding aarch64_system_exceptions_debug_breakpoint // BRK_EX_exception
                        when ('001', '000', '1x') => __UNALLOCATED
                        when ('010', '000', 'x1') => __UNALLOCATED
                        when ('010', '000', '00') => __encoding aarch64_system_exceptions_debug_halt // HLT_EX_exception
                        when ('010', '000', '1x') => __UNALLOCATED
                        when ('011', '000', '00') => __encoding aarch64_system_tme_tcancel // TCANCEL_EX_exception
                        when ('011', '000', '01') => __UNALLOCATED
                        when ('011', '000', '1x') => __UNALLOCATED
                        when ('100', '000', _) => __UNALLOCATED
                        when ('101', '000', '00') => __UNALLOCATED
                        when ('101', '000', '01') => __encoding aarch64_system_exceptions_debug_exception // DCPS1_DC_exception
                        when ('101', '000', '10') => __encoding aarch64_system_exceptions_debug_exception // DCPS2_DC_exception
                        when ('101', '000', '11') => __encoding aarch64_system_exceptions_debug_exception // DCPS3_DC_exception
                        when ('110', '000', _) => __UNALLOCATED
                        when ('111', '000', _) => __UNALLOCATED
                when ('110', _, '01000000110001', _, _) => // systeminstrswithreg
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (CRm, op2) of
                        when (!'0000', _) => __UNALLOCATED
                        when ('0000', '000') => __encoding aarch64_system_sysinstwithreg_wfet // WFET_only_systeminstrswithreg
                        when ('0000', '001') => __encoding aarch64_system_sysinstwithreg_wfit // WFIT_only_systeminstrswithreg
                        when ('0000', '01x') => __UNALLOCATED
                        when ('0000', '1xx') => __UNALLOCATED
                when ('110', _, '01000000110010', _, '11111') => // hints
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    case (CRm, op2) of
                        when (_, _) => __encoding aarch64_system_hints // HINT_HM_hints
                        when ('0000', '000') => __encoding aarch64_system_hints // NOP_HI_hints
                        when ('0000', '001') => __encoding aarch64_system_hints // YIELD_HI_hints
                        when ('0000', '010') => __encoding aarch64_system_hints // WFE_HI_hints
                        when ('0000', '011') => __encoding aarch64_system_hints // WFI_HI_hints
                        when ('0000', '100') => __encoding aarch64_system_hints // SEV_HI_hints
                        when ('0000', '101') => __encoding aarch64_system_hints // SEVL_HI_hints
                        when ('0000', '110') => __encoding aarch64_system_hints // DGH_HI_hints
                        when ('0000', '111') => __encoding aarch64_integer_pac_strip_hint // XPACLRI_HI_hints
                        when ('0001', '000') => __encoding aarch64_integer_pac_pacia_hint // PACIA1716_HI_hints
                        when ('0001', '010') => __encoding aarch64_integer_pac_pacib_hint // PACIB1716_HI_hints
                        when ('0001', '100') => __encoding aarch64_integer_pac_autia_hint // AUTIA1716_HI_hints
                        when ('0001', '110') => __encoding aarch64_integer_pac_autib_hint // AUTIB1716_HI_hints
                        when ('0010', '000') => __encoding aarch64_system_hints // ESB_HI_hints
                        when ('0010', '001') => __encoding aarch64_system_hints // PSB_HC_hints
                        when ('0010', '010') => __encoding aarch64_system_hints // TSB_HC_hints
                        when ('0010', '011') => __encoding aarch64_system_hints // GCSB_HD_hints
                        when ('0010', '100') => __encoding aarch64_system_hints // CSDB_HI_hints
                        when ('0010', '110') => __encoding aarch64_system_hints // CLRBHB_HI_hints
                        when ('0011', '000') => __encoding aarch64_integer_pac_pacia_hint // PACIAZ_HI_hints
                        when ('0011', '001') => __encoding aarch64_integer_pac_pacia_hint // PACIASP_HI_hints
                        when ('0011', '010') => __encoding aarch64_integer_pac_pacib_hint // PACIBZ_HI_hints
                        when ('0011', '011') => __encoding aarch64_integer_pac_pacib_hint // PACIBSP_HI_hints
                        when ('0011', '100') => __encoding aarch64_integer_pac_autia_hint // AUTIAZ_HI_hints
                        when ('0011', '101') => __encoding aarch64_integer_pac_autia_hint // AUTIASP_HI_hints
                        when ('0011', '110') => __encoding aarch64_integer_pac_autib_hint // AUTIBZ_HI_hints
                        when ('0011', '111') => __encoding aarch64_integer_pac_autib_hint // AUTIBSP_HI_hints
                        when ('0100', 'xx0') => __encoding aarch64_system_hints // BTI_HB_hints
                        when ('0101', '000') => __encoding aarch64_system_hints // CHKFEAT_HI_hints
                when ('110', _, '01000000110011', _, _) => // barriers
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (CRm, op2, Rt) of
                        when (_, '000', _) => __UNALLOCATED
                        when (_, '001', !'11111') => __UNALLOCATED
                        when (_, '010', '11111') => __encoding aarch64_system_monitors // CLREX_BN_barriers
                        when (_, '100', '11111') => __encoding aarch64_system_barriers_dsb // DSB_BO_barriers
                        when (_, '101', '11111') => __encoding aarch64_system_barriers_dmb // DMB_BO_barriers
                        when (_, '110', '11111') => __encoding aarch64_system_barriers_isb // ISB_BI_barriers
                        when (_, '111', !'11111') => __UNALLOCATED
                        when (_, '111', '11111') => __encoding aarch64_system_barriers_sb // SB_only_barriers
                        when ('xx0x', '001', '11111') => __UNALLOCATED
                        when ('xx10', '001', '11111') => __encoding aarch64_system_barriers_dsb_nxs // DSB_BOn_barriers
                        when ('xx11', '001', '11111') => __UNALLOCATED
                        when ('0000', '011', '11111') => __encoding aarch64_system_tme_tcommit // TCOMMIT_only_barriers
                        when ('0001', '011', _) => __UNALLOCATED
                        when ('001x', '011', _) => __UNALLOCATED
                        when ('01xx', '011', _) => __UNALLOCATED
                        when ('1xxx', '011', _) => __UNALLOCATED
                when ('110', _, '0100000xxx0100', _, _) => // pstate
                    __field op1 16 +: 3
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (op1, op2, Rt) of
                        when (_, _, !'11111') => __UNALLOCATED
                        when (_, _, '11111') => __encoding aarch64_system_register_cpsr // MSR_SI_pstate
                        when ('000', '000', '11111') => __encoding aarch64_integer_flags_cfinv // CFINV_M_pstate
                        when ('000', '001', '11111') => __encoding aarch64_integer_flags_xaflag // XAFLAG_M_pstate
                        when ('000', '010', '11111') => __encoding aarch64_integer_flags_axflag // AXFLAG_M_pstate
                when ('110', _, '0100100xxxxxxx', _, _) => // systemresult
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (op1, CRn, CRm, op2) of
                        when (!'011', _, _, _) => __UNALLOCATED
                        when ('011', !'0011', _, _) => __UNALLOCATED
                        when ('011', '0011', _, !'011') => __UNALLOCATED
                        when ('011', '0011', !'000x', '011') => __UNALLOCATED
                        when ('011', '0011', '0000', '011') => __encoding aarch64_system_tme_tstart // TSTART_BR_systemresult
                        when ('011', '0011', '0001', '011') => __encoding aarch64_system_tme_ttest // TTEST_BR_systemresult
                when ('110', _, '0100x01xxxxxxx', _, _) => // systeminstrs
                    __field L 21 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding aarch64_system_sysops // SYS_CR_systeminstrs
                        when ('1') => __encoding aarch64_system_sysops // SYSL_RC_systeminstrs
                when ('110', _, '0100x1xxxxxxxx', _, _) => // systemmove
                    __field L 21 +: 1
                    __field o0 19 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding aarch64_system_register_system // MSR_SR_systemmove
                        when ('1') => __encoding aarch64_system_register_system // MRS_RS_systemmove
                when ('110', _, '0101x01xxxxxxx', _, _) => // syspairinstrs
                    __field L 21 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding aarch64_system_sysops_128 // SYSP_CR_syspairinstrs
                        when ('1') => __UNALLOCATED
                when ('110', _, '0101x1xxxxxxxx', _, _) => // systemmovepr
                    __field L 21 +: 1
                    __field o0 19 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding aarch64_system_register_system_128 // MSRR_SR_systemmovepr
                        when ('1') => __encoding aarch64_system_register_system_128 // MRRS_RS_systemmovepr
                when ('110', _, '1xxxxxxxxxxxxx', _, _) => // branch_reg
                    __field opc 21 +: 4
                    __field op2 16 +: 5
                    __field op3 10 +: 6
                    __field Rn 5 +: 5
                    __field op4 0 +: 5
                    case (opc, op2, op3, Rn, op4) of
                        when (_, !'11111', _, _, _) => __UNALLOCATED
                        when ('0000', '11111', '000000', _, !'00000') => __UNALLOCATED
                        when ('0000', '11111', '000000', _, '00000') => __encoding aarch64_branch_unconditional_register // BR_64_branch_reg
                        when ('0000', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0000', '11111', '000010', _, !'11111') => __UNALLOCATED
                        when ('0000', '11111', '000010', _, '11111') => __encoding aarch64_branch_unconditional_register // BRAAZ_64_branch_reg
                        when ('0000', '11111', '000011', _, !'11111') => __UNALLOCATED
                        when ('0000', '11111', '000011', _, '11111') => __encoding aarch64_branch_unconditional_register // BRABZ_64_branch_reg
                        when ('0000', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('0000', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('0000', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('0000', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('0001', '11111', '000000', _, !'00000') => __UNALLOCATED
                        when ('0001', '11111', '000000', _, '00000') => __encoding aarch64_branch_unconditional_register // BLR_64_branch_reg
                        when ('0001', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0001', '11111', '000010', _, !'11111') => __UNALLOCATED
                        when ('0001', '11111', '000010', _, '11111') => __encoding aarch64_branch_unconditional_register // BLRAAZ_64_branch_reg
                        when ('0001', '11111', '000011', _, !'11111') => __UNALLOCATED
                        when ('0001', '11111', '000011', _, '11111') => __encoding aarch64_branch_unconditional_register // BLRABZ_64_branch_reg
                        when ('0001', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('0001', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('0001', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('0001', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('0010', '11111', '000000', _, !'00000') => __UNALLOCATED
                        when ('0010', '11111', '000000', _, '00000') => __encoding aarch64_branch_unconditional_register // RET_64R_branch_reg
                        when ('0010', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0010', '11111', '000010', !'11111', !'11111') => __UNALLOCATED
                        when ('0010', '11111', '000010', !'11111', '11111') => __UNALLOCATED
                        when ('0010', '11111', '000010', '11111', !'11111') => __UNALLOCATED
                        when ('0010', '11111', '000010', '11111', '11111') => __encoding aarch64_branch_unconditional_register // RETAA_64E_branch_reg
                        when ('0010', '11111', '000011', !'11111', !'11111') => __UNALLOCATED
                        when ('0010', '11111', '000011', !'11111', '11111') => __UNALLOCATED
                        when ('0010', '11111', '000011', '11111', !'11111') => __UNALLOCATED
                        when ('0010', '11111', '000011', '11111', '11111') => __encoding aarch64_branch_unconditional_register // RETAB_64E_branch_reg
                        when ('0010', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('0010', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('0010', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('0010', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('0011', '11111', _, _, _) => __UNALLOCATED
                        when ('0100', '11111', '000000', !'11111', !'00000') => __UNALLOCATED
                        when ('0100', '11111', '000000', !'11111', '00000') => __UNALLOCATED
                        when ('0100', '11111', '000000', '11111', !'00000') => __UNALLOCATED
                        when ('0100', '11111', '000000', '11111', '00000') => __encoding aarch64_branch_unconditional_eret // ERET_64E_branch_reg
                        when ('0100', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0100', '11111', '000010', !'11111', !'11111') => __UNALLOCATED
                        when ('0100', '11111', '000010', !'11111', '11111') => __UNALLOCATED
                        when ('0100', '11111', '000010', '11111', !'11111') => __UNALLOCATED
                        when ('0100', '11111', '000010', '11111', '11111') => __encoding aarch64_branch_unconditional_eret // ERETAA_64E_branch_reg
                        when ('0100', '11111', '000011', !'11111', !'11111') => __UNALLOCATED
                        when ('0100', '11111', '000011', !'11111', '11111') => __UNALLOCATED
                        when ('0100', '11111', '000011', '11111', !'11111') => __UNALLOCATED
                        when ('0100', '11111', '000011', '11111', '11111') => __encoding aarch64_branch_unconditional_eret // ERETAB_64E_branch_reg
                        when ('0100', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('0100', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('0100', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('0100', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('0101', '11111', !'000000', _, _) => __UNALLOCATED
                        when ('0101', '11111', '000000', !'11111', !'00000') => __UNALLOCATED
                        when ('0101', '11111', '000000', !'11111', '00000') => __UNALLOCATED
                        when ('0101', '11111', '000000', '11111', !'00000') => __UNALLOCATED
                        when ('0101', '11111', '000000', '11111', '00000') => __encoding aarch64_branch_unconditional_dret // DRPS_64E_branch_reg
                        when ('011x', '11111', _, _, _) => __UNALLOCATED
                        when ('1000', '11111', '00000x', _, _) => __UNALLOCATED
                        when ('1000', '11111', '000010', _, _) => __encoding aarch64_branch_unconditional_register // BRAA_64P_branch_reg
                        when ('1000', '11111', '000011', _, _) => __encoding aarch64_branch_unconditional_register // BRAB_64P_branch_reg
                        when ('1000', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('1000', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('1000', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('1000', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('1001', '11111', '00000x', _, _) => __UNALLOCATED
                        when ('1001', '11111', '000010', _, _) => __encoding aarch64_branch_unconditional_register // BLRAA_64P_branch_reg
                        when ('1001', '11111', '000011', _, _) => __encoding aarch64_branch_unconditional_register // BLRAB_64P_branch_reg
                        when ('1001', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('1001', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('1001', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('1001', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('101x', '11111', _, _, _) => __UNALLOCATED
                        when ('11xx', '11111', _, _, _) => __UNALLOCATED
                when ('x00', _, _, _, _) => // branch_imm
                    __field op 31 +: 1
                    __field imm26 0 +: 26
                    case (op) of
                        when ('0') => __encoding aarch64_branch_unconditional_immediate // B_only_branch_imm
                        when ('1') => __encoding aarch64_branch_unconditional_immediate // BL_only_branch_imm
                when ('x01', _, '0xxxxxxxxxxxxx', _, _) => // compbranch
                    __field sf 31 +: 1
                    __field op 24 +: 1
                    __field imm19 5 +: 19
                    __field Rt 0 +: 5
                    case (sf, op) of
                        when ('0', '0') => __encoding aarch64_branch_conditional_compare // CBZ_32_compbranch
                        when ('0', '1') => __encoding aarch64_branch_conditional_compare // CBNZ_32_compbranch
                        when ('1', '0') => __encoding aarch64_branch_conditional_compare // CBZ_64_compbranch
                        when ('1', '1') => __encoding aarch64_branch_conditional_compare // CBNZ_64_compbranch
                when ('x01', _, '1xxxxxxxxxxxxx', _, _) => // testbranch
                    __field b5 31 +: 1
                    __field op 24 +: 1
                    __field b40 19 +: 5
                    __field imm14 5 +: 14
                    __field Rt 0 +: 5
                    case (op) of
                        when ('0') => __encoding aarch64_branch_conditional_test // TBZ_only_testbranch
                        when ('1') => __encoding aarch64_branch_conditional_test // TBNZ_only_testbranch
        when (_, _, 'x1x0', _) =>
            // ldst
            case (28 +: 4, 27 +: 1, 26 +: 1, 25 +: 1, 10 +: 15, 0 +: 10) of
                when ('0x00', _, '0', _, '00x1xxxxxxxxxxx', _) => // comswappr
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0, Rt2) of
                        when (_, _, _, !'11111') => __UNALLOCATED
                        when ('0', '0', '0', '11111') => __encoding aarch64_memory_atomicops_cas_pair // CASP_CP32_comswappr
                        when ('0', '0', '1', '11111') => __encoding aarch64_memory_atomicops_cas_pair // CASPL_CP32_comswappr
                        when ('0', '1', '0', '11111') => __encoding aarch64_memory_atomicops_cas_pair // CASPA_CP32_comswappr
                        when ('0', '1', '1', '11111') => __encoding aarch64_memory_atomicops_cas_pair // CASPAL_CP32_comswappr
                        when ('1', '0', '0', '11111') => __encoding aarch64_memory_atomicops_cas_pair // CASP_CP64_comswappr
                        when ('1', '0', '1', '11111') => __encoding aarch64_memory_atomicops_cas_pair // CASPL_CP64_comswappr
                        when ('1', '1', '0', '11111') => __encoding aarch64_memory_atomicops_cas_pair // CASPA_CP64_comswappr
                        when ('1', '1', '1', '11111') => __encoding aarch64_memory_atomicops_cas_pair // CASPAL_CP64_comswappr
                when ('0x00', _, '1', _, '00x000000xxxxxx', _) => // asisdlse
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field opcode 12 +: 4
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, opcode) of
                        when ('0', '0000') => __encoding aarch64_memory_vector_multiple_no_wb // ST4_asisdlse_R4
                        when ('0', '0001') => __UNALLOCATED
                        when ('0', '0010') => __encoding aarch64_memory_vector_multiple_no_wb // ST1_asisdlse_R4_4v
                        when ('0', '0011') => __UNALLOCATED
                        when ('0', '0100') => __encoding aarch64_memory_vector_multiple_no_wb // ST3_asisdlse_R3
                        when ('0', '0101') => __UNALLOCATED
                        when ('0', '0110') => __encoding aarch64_memory_vector_multiple_no_wb // ST1_asisdlse_R3_3v
                        when ('0', '0111') => __encoding aarch64_memory_vector_multiple_no_wb // ST1_asisdlse_R1_1v
                        when ('0', '1000') => __encoding aarch64_memory_vector_multiple_no_wb // ST2_asisdlse_R2
                        when ('0', '1001') => __UNALLOCATED
                        when ('0', '1010') => __encoding aarch64_memory_vector_multiple_no_wb // ST1_asisdlse_R2_2v
                        when ('0', '1011') => __UNALLOCATED
                        when ('0', '11xx') => __UNALLOCATED
                        when ('1', '0000') => __encoding aarch64_memory_vector_multiple_no_wb // LD4_asisdlse_R4
                        when ('1', '0001') => __UNALLOCATED
                        when ('1', '0010') => __encoding aarch64_memory_vector_multiple_no_wb // LD1_asisdlse_R4_4v
                        when ('1', '0011') => __UNALLOCATED
                        when ('1', '0100') => __encoding aarch64_memory_vector_multiple_no_wb // LD3_asisdlse_R3
                        when ('1', '0101') => __UNALLOCATED
                        when ('1', '0110') => __encoding aarch64_memory_vector_multiple_no_wb // LD1_asisdlse_R3_3v
                        when ('1', '0111') => __encoding aarch64_memory_vector_multiple_no_wb // LD1_asisdlse_R1_1v
                        when ('1', '1000') => __encoding aarch64_memory_vector_multiple_no_wb // LD2_asisdlse_R2
                        when ('1', '1001') => __UNALLOCATED
                        when ('1', '1010') => __encoding aarch64_memory_vector_multiple_no_wb // LD1_asisdlse_R2_2v
                        when ('1', '1011') => __UNALLOCATED
                        when ('1', '11xx') => __UNALLOCATED
                when ('0x00', _, '1', _, '00xxxxxx1xxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '01x0xxxxxxxxxxx', _) => // asisdlsep
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, Rm, opcode) of
                        when ('0', _, '0001') => __UNALLOCATED
                        when ('0', _, '0011') => __UNALLOCATED
                        when ('0', _, '0101') => __UNALLOCATED
                        when ('0', _, '1001') => __UNALLOCATED
                        when ('0', _, '1011') => __UNALLOCATED
                        when ('0', _, '11xx') => __UNALLOCATED
                        when ('0', !'11111', '0000') => __encoding aarch64_memory_vector_multiple_post_inc // ST4_asisdlsep_R4_r
                        when ('0', !'11111', '0010') => __encoding aarch64_memory_vector_multiple_post_inc // ST1_asisdlsep_R4_r4
                        when ('0', !'11111', '0100') => __encoding aarch64_memory_vector_multiple_post_inc // ST3_asisdlsep_R3_r
                        when ('0', !'11111', '0110') => __encoding aarch64_memory_vector_multiple_post_inc // ST1_asisdlsep_R3_r3
                        when ('0', !'11111', '0111') => __encoding aarch64_memory_vector_multiple_post_inc // ST1_asisdlsep_R1_r1
                        when ('0', !'11111', '1000') => __encoding aarch64_memory_vector_multiple_post_inc // ST2_asisdlsep_R2_r
                        when ('0', !'11111', '1010') => __encoding aarch64_memory_vector_multiple_post_inc // ST1_asisdlsep_R2_r2
                        when ('0', '11111', '0000') => __encoding aarch64_memory_vector_multiple_post_inc // ST4_asisdlsep_I4_i
                        when ('0', '11111', '0010') => __encoding aarch64_memory_vector_multiple_post_inc // ST1_asisdlsep_I4_i4
                        when ('0', '11111', '0100') => __encoding aarch64_memory_vector_multiple_post_inc // ST3_asisdlsep_I3_i
                        when ('0', '11111', '0110') => __encoding aarch64_memory_vector_multiple_post_inc // ST1_asisdlsep_I3_i3
                        when ('0', '11111', '0111') => __encoding aarch64_memory_vector_multiple_post_inc // ST1_asisdlsep_I1_i1
                        when ('0', '11111', '1000') => __encoding aarch64_memory_vector_multiple_post_inc // ST2_asisdlsep_I2_i
                        when ('0', '11111', '1010') => __encoding aarch64_memory_vector_multiple_post_inc // ST1_asisdlsep_I2_i2
                        when ('1', _, '0001') => __UNALLOCATED
                        when ('1', _, '0011') => __UNALLOCATED
                        when ('1', _, '0101') => __UNALLOCATED
                        when ('1', _, '1001') => __UNALLOCATED
                        when ('1', _, '1011') => __UNALLOCATED
                        when ('1', _, '11xx') => __UNALLOCATED
                        when ('1', !'11111', '0000') => __encoding aarch64_memory_vector_multiple_post_inc // LD4_asisdlsep_R4_r
                        when ('1', !'11111', '0010') => __encoding aarch64_memory_vector_multiple_post_inc // LD1_asisdlsep_R4_r4
                        when ('1', !'11111', '0100') => __encoding aarch64_memory_vector_multiple_post_inc // LD3_asisdlsep_R3_r
                        when ('1', !'11111', '0110') => __encoding aarch64_memory_vector_multiple_post_inc // LD1_asisdlsep_R3_r3
                        when ('1', !'11111', '0111') => __encoding aarch64_memory_vector_multiple_post_inc // LD1_asisdlsep_R1_r1
                        when ('1', !'11111', '1000') => __encoding aarch64_memory_vector_multiple_post_inc // LD2_asisdlsep_R2_r
                        when ('1', !'11111', '1010') => __encoding aarch64_memory_vector_multiple_post_inc // LD1_asisdlsep_R2_r2
                        when ('1', '11111', '0000') => __encoding aarch64_memory_vector_multiple_post_inc // LD4_asisdlsep_I4_i
                        when ('1', '11111', '0010') => __encoding aarch64_memory_vector_multiple_post_inc // LD1_asisdlsep_I4_i4
                        when ('1', '11111', '0100') => __encoding aarch64_memory_vector_multiple_post_inc // LD3_asisdlsep_I3_i
                        when ('1', '11111', '0110') => __encoding aarch64_memory_vector_multiple_post_inc // LD1_asisdlsep_I3_i3
                        when ('1', '11111', '0111') => __encoding aarch64_memory_vector_multiple_post_inc // LD1_asisdlsep_I1_i1
                        when ('1', '11111', '1000') => __encoding aarch64_memory_vector_multiple_post_inc // LD2_asisdlsep_I2_i
                        when ('1', '11111', '1010') => __encoding aarch64_memory_vector_multiple_post_inc // LD1_asisdlsep_I2_i2
                when ('0x00', _, '1', _, '0xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10xx0000xxxxxxx', _) => // asisdlso
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field R 21 +: 1
                    __field o2 16 +: 1
                    __field opcode 13 +: 3
                    __field S 12 +: 1
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, R, o2, opcode, S, size) of
                        when (_, '0', '1', 'x00', '0', '00') => __UNALLOCATED
                        when (_, '0', '1', 'x00', '0', '1x') => __UNALLOCATED
                        when (_, '0', '1', 'x00', '1', _) => __UNALLOCATED
                        when (_, '0', '1', 'x01', _, _) => __UNALLOCATED
                        when (_, '0', '1', 'x1x', _, _) => __UNALLOCATED
                        when (_, '1', '1', _, _, _) => __UNALLOCATED
                        when ('0', _, '0', '11x', _, _) => __UNALLOCATED
                        when ('0', '0', '0', '000', _, _) => __encoding aarch64_memory_vector_single_no_wb // ST1_asisdlso_B1_1b
                        when ('0', '0', '0', '001', _, _) => __encoding aarch64_memory_vector_single_no_wb // ST3_asisdlso_B3_3b
                        when ('0', '0', '0', '010', _, 'x0') => __encoding aarch64_memory_vector_single_no_wb // ST1_asisdlso_H1_1h
                        when ('0', '0', '0', '010', _, 'x1') => __UNALLOCATED
                        when ('0', '0', '0', '011', _, 'x0') => __encoding aarch64_memory_vector_single_no_wb // ST3_asisdlso_H3_3h
                        when ('0', '0', '0', '011', _, 'x1') => __UNALLOCATED
                        when ('0', '0', '0', '100', _, '00') => __encoding aarch64_memory_vector_single_no_wb // ST1_asisdlso_S1_1s
                        when ('0', '0', '0', '100', _, '1x') => __UNALLOCATED
                        when ('0', '0', '0', '100', '0', '01') => __encoding aarch64_memory_vector_single_no_wb // ST1_asisdlso_D1_1d
                        when ('0', '0', '0', '100', '1', '01') => __UNALLOCATED
                        when ('0', '0', '0', '101', _, '00') => __encoding aarch64_memory_vector_single_no_wb // ST3_asisdlso_S3_3s
                        when ('0', '0', '0', '101', _, '10') => __UNALLOCATED
                        when ('0', '0', '0', '101', '0', '01') => __encoding aarch64_memory_vector_single_no_wb // ST3_asisdlso_D3_3d
                        when ('0', '0', '0', '101', '0', '11') => __UNALLOCATED
                        when ('0', '0', '0', '101', '1', 'x1') => __UNALLOCATED
                        when ('0', '0', '1', '100', '0', '01') => __encoding aarch64_memory_vector_single_no_wb_ordered // STL1_asisdlso_D1
                        when ('0', '1', '0', '000', _, _) => __encoding aarch64_memory_vector_single_no_wb // ST2_asisdlso_B2_2b
                        when ('0', '1', '0', '001', _, _) => __encoding aarch64_memory_vector_single_no_wb // ST4_asisdlso_B4_4b
                        when ('0', '1', '0', '010', _, 'x0') => __encoding aarch64_memory_vector_single_no_wb // ST2_asisdlso_H2_2h
                        when ('0', '1', '0', '010', _, 'x1') => __UNALLOCATED
                        when ('0', '1', '0', '011', _, 'x0') => __encoding aarch64_memory_vector_single_no_wb // ST4_asisdlso_H4_4h
                        when ('0', '1', '0', '011', _, 'x1') => __UNALLOCATED
                        when ('0', '1', '0', '100', _, '00') => __encoding aarch64_memory_vector_single_no_wb // ST2_asisdlso_S2_2s
                        when ('0', '1', '0', '100', _, '10') => __UNALLOCATED
                        when ('0', '1', '0', '100', '0', '01') => __encoding aarch64_memory_vector_single_no_wb // ST2_asisdlso_D2_2d
                        when ('0', '1', '0', '100', '0', '11') => __UNALLOCATED
                        when ('0', '1', '0', '100', '1', 'x1') => __UNALLOCATED
                        when ('0', '1', '0', '101', _, '00') => __encoding aarch64_memory_vector_single_no_wb // ST4_asisdlso_S4_4s
                        when ('0', '1', '0', '101', _, '10') => __UNALLOCATED
                        when ('0', '1', '0', '101', '0', '01') => __encoding aarch64_memory_vector_single_no_wb // ST4_asisdlso_D4_4d
                        when ('0', '1', '0', '101', '0', '11') => __UNALLOCATED
                        when ('0', '1', '0', '101', '1', 'x1') => __UNALLOCATED
                        when ('1', '0', '0', '000', _, _) => __encoding aarch64_memory_vector_single_no_wb // LD1_asisdlso_B1_1b
                        when ('1', '0', '0', '001', _, _) => __encoding aarch64_memory_vector_single_no_wb // LD3_asisdlso_B3_3b
                        when ('1', '0', '0', '010', _, 'x0') => __encoding aarch64_memory_vector_single_no_wb // LD1_asisdlso_H1_1h
                        when ('1', '0', '0', '010', _, 'x1') => __UNALLOCATED
                        when ('1', '0', '0', '011', _, 'x0') => __encoding aarch64_memory_vector_single_no_wb // LD3_asisdlso_H3_3h
                        when ('1', '0', '0', '011', _, 'x1') => __UNALLOCATED
                        when ('1', '0', '0', '100', _, '00') => __encoding aarch64_memory_vector_single_no_wb // LD1_asisdlso_S1_1s
                        when ('1', '0', '0', '100', _, '1x') => __UNALLOCATED
                        when ('1', '0', '0', '100', '0', '01') => __encoding aarch64_memory_vector_single_no_wb // LD1_asisdlso_D1_1d
                        when ('1', '0', '0', '100', '1', '01') => __UNALLOCATED
                        when ('1', '0', '0', '101', _, '00') => __encoding aarch64_memory_vector_single_no_wb // LD3_asisdlso_S3_3s
                        when ('1', '0', '0', '101', _, '10') => __UNALLOCATED
                        when ('1', '0', '0', '101', '0', '01') => __encoding aarch64_memory_vector_single_no_wb // LD3_asisdlso_D3_3d
                        when ('1', '0', '0', '101', '0', '11') => __UNALLOCATED
                        when ('1', '0', '0', '101', '1', 'x1') => __UNALLOCATED
                        when ('1', '0', '0', '110', '0', _) => __encoding aarch64_memory_vector_single_no_wb // LD1R_asisdlso_R1
                        when ('1', '0', '0', '110', '1', _) => __UNALLOCATED
                        when ('1', '0', '0', '111', '0', _) => __encoding aarch64_memory_vector_single_no_wb // LD3R_asisdlso_R3
                        when ('1', '0', '0', '111', '1', _) => __UNALLOCATED
                        when ('1', '0', '1', '100', '0', '01') => __encoding aarch64_memory_vector_single_no_wb_ordered // LDAP1_asisdlso_D1
                        when ('1', '1', '0', '000', _, _) => __encoding aarch64_memory_vector_single_no_wb // LD2_asisdlso_B2_2b
                        when ('1', '1', '0', '001', _, _) => __encoding aarch64_memory_vector_single_no_wb // LD4_asisdlso_B4_4b
                        when ('1', '1', '0', '010', _, 'x0') => __encoding aarch64_memory_vector_single_no_wb // LD2_asisdlso_H2_2h
                        when ('1', '1', '0', '010', _, 'x1') => __UNALLOCATED
                        when ('1', '1', '0', '011', _, 'x0') => __encoding aarch64_memory_vector_single_no_wb // LD4_asisdlso_H4_4h
                        when ('1', '1', '0', '011', _, 'x1') => __UNALLOCATED
                        when ('1', '1', '0', '100', _, '00') => __encoding aarch64_memory_vector_single_no_wb // LD2_asisdlso_S2_2s
                        when ('1', '1', '0', '100', _, '10') => __UNALLOCATED
                        when ('1', '1', '0', '100', '0', '01') => __encoding aarch64_memory_vector_single_no_wb // LD2_asisdlso_D2_2d
                        when ('1', '1', '0', '100', '0', '11') => __UNALLOCATED
                        when ('1', '1', '0', '100', '1', 'x1') => __UNALLOCATED
                        when ('1', '1', '0', '101', _, '00') => __encoding aarch64_memory_vector_single_no_wb // LD4_asisdlso_S4_4s
                        when ('1', '1', '0', '101', _, '10') => __UNALLOCATED
                        when ('1', '1', '0', '101', '0', '01') => __encoding aarch64_memory_vector_single_no_wb // LD4_asisdlso_D4_4d
                        when ('1', '1', '0', '101', '0', '11') => __UNALLOCATED
                        when ('1', '1', '0', '101', '1', 'x1') => __UNALLOCATED
                        when ('1', '1', '0', '110', '0', _) => __encoding aarch64_memory_vector_single_no_wb // LD2R_asisdlso_R2
                        when ('1', '1', '0', '110', '1', _) => __UNALLOCATED
                        when ('1', '1', '0', '111', '0', _) => __encoding aarch64_memory_vector_single_no_wb // LD4R_asisdlso_R4
                        when ('1', '1', '0', '111', '1', _) => __UNALLOCATED
                when ('0x00', _, '1', _, '11xxxxxxxxxxxxx', _) => // asisdlsop
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field R 21 +: 1
                    __field Rm 16 +: 5
                    __field opcode 13 +: 3
                    __field S 12 +: 1
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, R, Rm, opcode, S, size) of
                        when ('0', _, _, '11x', _, _) => __UNALLOCATED
                        when ('0', '0', _, '010', _, 'x1') => __UNALLOCATED
                        when ('0', '0', _, '011', _, 'x1') => __UNALLOCATED
                        when ('0', '0', _, '100', _, '1x') => __UNALLOCATED
                        when ('0', '0', _, '100', '1', '01') => __UNALLOCATED
                        when ('0', '0', _, '101', _, '10') => __UNALLOCATED
                        when ('0', '0', _, '101', '0', '11') => __UNALLOCATED
                        when ('0', '0', _, '101', '1', 'x1') => __UNALLOCATED
                        when ('0', '0', !'11111', '000', _, _) => __encoding aarch64_memory_vector_single_post_inc // ST1_asisdlsop_BX1_r1b
                        when ('0', '0', !'11111', '001', _, _) => __encoding aarch64_memory_vector_single_post_inc // ST3_asisdlsop_BX3_r3b
                        when ('0', '0', !'11111', '010', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // ST1_asisdlsop_HX1_r1h
                        when ('0', '0', !'11111', '011', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // ST3_asisdlsop_HX3_r3h
                        when ('0', '0', !'11111', '100', _, '00') => __encoding aarch64_memory_vector_single_post_inc // ST1_asisdlsop_SX1_r1s
                        when ('0', '0', !'11111', '100', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // ST1_asisdlsop_DX1_r1d
                        when ('0', '0', !'11111', '101', _, '00') => __encoding aarch64_memory_vector_single_post_inc // ST3_asisdlsop_SX3_r3s
                        when ('0', '0', !'11111', '101', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // ST3_asisdlsop_DX3_r3d
                        when ('0', '0', '11111', '000', _, _) => __encoding aarch64_memory_vector_single_post_inc // ST1_asisdlsop_B1_i1b
                        when ('0', '0', '11111', '001', _, _) => __encoding aarch64_memory_vector_single_post_inc // ST3_asisdlsop_B3_i3b
                        when ('0', '0', '11111', '010', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // ST1_asisdlsop_H1_i1h
                        when ('0', '0', '11111', '011', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // ST3_asisdlsop_H3_i3h
                        when ('0', '0', '11111', '100', _, '00') => __encoding aarch64_memory_vector_single_post_inc // ST1_asisdlsop_S1_i1s
                        when ('0', '0', '11111', '100', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // ST1_asisdlsop_D1_i1d
                        when ('0', '0', '11111', '101', _, '00') => __encoding aarch64_memory_vector_single_post_inc // ST3_asisdlsop_S3_i3s
                        when ('0', '0', '11111', '101', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // ST3_asisdlsop_D3_i3d
                        when ('0', '1', _, '010', _, 'x1') => __UNALLOCATED
                        when ('0', '1', _, '011', _, 'x1') => __UNALLOCATED
                        when ('0', '1', _, '100', _, '10') => __UNALLOCATED
                        when ('0', '1', _, '100', '0', '11') => __UNALLOCATED
                        when ('0', '1', _, '100', '1', 'x1') => __UNALLOCATED
                        when ('0', '1', _, '101', _, '10') => __UNALLOCATED
                        when ('0', '1', _, '101', '0', '11') => __UNALLOCATED
                        when ('0', '1', _, '101', '1', 'x1') => __UNALLOCATED
                        when ('0', '1', !'11111', '000', _, _) => __encoding aarch64_memory_vector_single_post_inc // ST2_asisdlsop_BX2_r2b
                        when ('0', '1', !'11111', '001', _, _) => __encoding aarch64_memory_vector_single_post_inc // ST4_asisdlsop_BX4_r4b
                        when ('0', '1', !'11111', '010', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // ST2_asisdlsop_HX2_r2h
                        when ('0', '1', !'11111', '011', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // ST4_asisdlsop_HX4_r4h
                        when ('0', '1', !'11111', '100', _, '00') => __encoding aarch64_memory_vector_single_post_inc // ST2_asisdlsop_SX2_r2s
                        when ('0', '1', !'11111', '100', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // ST2_asisdlsop_DX2_r2d
                        when ('0', '1', !'11111', '101', _, '00') => __encoding aarch64_memory_vector_single_post_inc // ST4_asisdlsop_SX4_r4s
                        when ('0', '1', !'11111', '101', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // ST4_asisdlsop_DX4_r4d
                        when ('0', '1', '11111', '000', _, _) => __encoding aarch64_memory_vector_single_post_inc // ST2_asisdlsop_B2_i2b
                        when ('0', '1', '11111', '001', _, _) => __encoding aarch64_memory_vector_single_post_inc // ST4_asisdlsop_B4_i4b
                        when ('0', '1', '11111', '010', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // ST2_asisdlsop_H2_i2h
                        when ('0', '1', '11111', '011', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // ST4_asisdlsop_H4_i4h
                        when ('0', '1', '11111', '100', _, '00') => __encoding aarch64_memory_vector_single_post_inc // ST2_asisdlsop_S2_i2s
                        when ('0', '1', '11111', '100', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // ST2_asisdlsop_D2_i2d
                        when ('0', '1', '11111', '101', _, '00') => __encoding aarch64_memory_vector_single_post_inc // ST4_asisdlsop_S4_i4s
                        when ('0', '1', '11111', '101', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // ST4_asisdlsop_D4_i4d
                        when ('1', '0', _, '010', _, 'x1') => __UNALLOCATED
                        when ('1', '0', _, '011', _, 'x1') => __UNALLOCATED
                        when ('1', '0', _, '100', _, '1x') => __UNALLOCATED
                        when ('1', '0', _, '100', '1', '01') => __UNALLOCATED
                        when ('1', '0', _, '101', _, '10') => __UNALLOCATED
                        when ('1', '0', _, '101', '0', '11') => __UNALLOCATED
                        when ('1', '0', _, '101', '1', 'x1') => __UNALLOCATED
                        when ('1', '0', _, '110', '1', _) => __UNALLOCATED
                        when ('1', '0', _, '111', '1', _) => __UNALLOCATED
                        when ('1', '0', !'11111', '000', _, _) => __encoding aarch64_memory_vector_single_post_inc // LD1_asisdlsop_BX1_r1b
                        when ('1', '0', !'11111', '001', _, _) => __encoding aarch64_memory_vector_single_post_inc // LD3_asisdlsop_BX3_r3b
                        when ('1', '0', !'11111', '010', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // LD1_asisdlsop_HX1_r1h
                        when ('1', '0', !'11111', '011', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // LD3_asisdlsop_HX3_r3h
                        when ('1', '0', !'11111', '100', _, '00') => __encoding aarch64_memory_vector_single_post_inc // LD1_asisdlsop_SX1_r1s
                        when ('1', '0', !'11111', '100', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // LD1_asisdlsop_DX1_r1d
                        when ('1', '0', !'11111', '101', _, '00') => __encoding aarch64_memory_vector_single_post_inc // LD3_asisdlsop_SX3_r3s
                        when ('1', '0', !'11111', '101', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // LD3_asisdlsop_DX3_r3d
                        when ('1', '0', !'11111', '110', '0', _) => __encoding aarch64_memory_vector_single_post_inc // LD1R_asisdlsop_RX1_r
                        when ('1', '0', !'11111', '111', '0', _) => __encoding aarch64_memory_vector_single_post_inc // LD3R_asisdlsop_RX3_r
                        when ('1', '0', '11111', '000', _, _) => __encoding aarch64_memory_vector_single_post_inc // LD1_asisdlsop_B1_i1b
                        when ('1', '0', '11111', '001', _, _) => __encoding aarch64_memory_vector_single_post_inc // LD3_asisdlsop_B3_i3b
                        when ('1', '0', '11111', '010', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // LD1_asisdlsop_H1_i1h
                        when ('1', '0', '11111', '011', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // LD3_asisdlsop_H3_i3h
                        when ('1', '0', '11111', '100', _, '00') => __encoding aarch64_memory_vector_single_post_inc // LD1_asisdlsop_S1_i1s
                        when ('1', '0', '11111', '100', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // LD1_asisdlsop_D1_i1d
                        when ('1', '0', '11111', '101', _, '00') => __encoding aarch64_memory_vector_single_post_inc // LD3_asisdlsop_S3_i3s
                        when ('1', '0', '11111', '101', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // LD3_asisdlsop_D3_i3d
                        when ('1', '0', '11111', '110', '0', _) => __encoding aarch64_memory_vector_single_post_inc // LD1R_asisdlsop_R1_i
                        when ('1', '0', '11111', '111', '0', _) => __encoding aarch64_memory_vector_single_post_inc // LD3R_asisdlsop_R3_i
                        when ('1', '1', _, '010', _, 'x1') => __UNALLOCATED
                        when ('1', '1', _, '011', _, 'x1') => __UNALLOCATED
                        when ('1', '1', _, '100', _, '10') => __UNALLOCATED
                        when ('1', '1', _, '100', '0', '11') => __UNALLOCATED
                        when ('1', '1', _, '100', '1', 'x1') => __UNALLOCATED
                        when ('1', '1', _, '101', _, '10') => __UNALLOCATED
                        when ('1', '1', _, '101', '0', '11') => __UNALLOCATED
                        when ('1', '1', _, '101', '1', 'x1') => __UNALLOCATED
                        when ('1', '1', _, '110', '1', _) => __UNALLOCATED
                        when ('1', '1', _, '111', '1', _) => __UNALLOCATED
                        when ('1', '1', !'11111', '000', _, _) => __encoding aarch64_memory_vector_single_post_inc // LD2_asisdlsop_BX2_r2b
                        when ('1', '1', !'11111', '001', _, _) => __encoding aarch64_memory_vector_single_post_inc // LD4_asisdlsop_BX4_r4b
                        when ('1', '1', !'11111', '010', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // LD2_asisdlsop_HX2_r2h
                        when ('1', '1', !'11111', '011', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // LD4_asisdlsop_HX4_r4h
                        when ('1', '1', !'11111', '100', _, '00') => __encoding aarch64_memory_vector_single_post_inc // LD2_asisdlsop_SX2_r2s
                        when ('1', '1', !'11111', '100', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // LD2_asisdlsop_DX2_r2d
                        when ('1', '1', !'11111', '101', _, '00') => __encoding aarch64_memory_vector_single_post_inc // LD4_asisdlsop_SX4_r4s
                        when ('1', '1', !'11111', '101', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // LD4_asisdlsop_DX4_r4d
                        when ('1', '1', !'11111', '110', '0', _) => __encoding aarch64_memory_vector_single_post_inc // LD2R_asisdlsop_RX2_r
                        when ('1', '1', !'11111', '111', '0', _) => __encoding aarch64_memory_vector_single_post_inc // LD4R_asisdlsop_RX4_r
                        when ('1', '1', '11111', '000', _, _) => __encoding aarch64_memory_vector_single_post_inc // LD2_asisdlsop_B2_i2b
                        when ('1', '1', '11111', '001', _, _) => __encoding aarch64_memory_vector_single_post_inc // LD4_asisdlsop_B4_i4b
                        when ('1', '1', '11111', '010', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // LD2_asisdlsop_H2_i2h
                        when ('1', '1', '11111', '011', _, 'x0') => __encoding aarch64_memory_vector_single_post_inc // LD4_asisdlsop_H4_i4h
                        when ('1', '1', '11111', '100', _, '00') => __encoding aarch64_memory_vector_single_post_inc // LD2_asisdlsop_S2_i2s
                        when ('1', '1', '11111', '100', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // LD2_asisdlsop_D2_i2d
                        when ('1', '1', '11111', '101', _, '00') => __encoding aarch64_memory_vector_single_post_inc // LD4_asisdlsop_S4_i4s
                        when ('1', '1', '11111', '101', '0', '01') => __encoding aarch64_memory_vector_single_post_inc // LD4_asisdlsop_D4_i4d
                        when ('1', '1', '11111', '110', '0', _) => __encoding aarch64_memory_vector_single_post_inc // LD2R_asisdlsop_R2_i
                        when ('1', '1', '11111', '111', '0', _) => __encoding aarch64_memory_vector_single_post_inc // LD4R_asisdlsop_R4_i
                when ('0x00', _, '1', _, 'x0xx1xxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0xxx1xxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0xxxx1xxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0xxxxx1xxxxxxx', _) => __UNPREDICTABLE
                when ('0x01', _, '0', _, '1xx1xxxxx000010', _) => // rcwcomswap
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R) of
                        when ('0', '0', '0') => __encoding aarch64_memory_rcw_cas // RCWCAS_C64_rcwcomswap
                        when ('0', '0', '1') => __encoding aarch64_memory_rcw_cas // RCWCASL_C64_rcwcomswap
                        when ('0', '1', '0') => __encoding aarch64_memory_rcw_cas // RCWCASA_C64_rcwcomswap
                        when ('0', '1', '1') => __encoding aarch64_memory_rcw_cas // RCWCASAL_C64_rcwcomswap
                        when ('1', '0', '0') => __encoding aarch64_memory_rcws_cas // RCWSCAS_C64_rcwcomswap
                        when ('1', '0', '1') => __encoding aarch64_memory_rcws_cas // RCWSCASL_C64_rcwcomswap
                        when ('1', '1', '0') => __encoding aarch64_memory_rcws_cas // RCWSCASA_C64_rcwcomswap
                        when ('1', '1', '1') => __encoding aarch64_memory_rcws_cas // RCWSCASAL_C64_rcwcomswap
                when ('0x01', _, '0', _, '1xx1xxxxx000011', _) => // rcwcomswappr
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R) of
                        when ('0', '0', '0') => __encoding aarch64_memory_rcw_cas_128 // RCWCASP_C64_rcwcomswappr
                        when ('0', '0', '1') => __encoding aarch64_memory_rcw_cas_128 // RCWCASPL_C64_rcwcomswappr
                        when ('0', '1', '0') => __encoding aarch64_memory_rcw_cas_128 // RCWCASPA_C64_rcwcomswappr
                        when ('0', '1', '1') => __encoding aarch64_memory_rcw_cas_128 // RCWCASPAL_C64_rcwcomswappr
                        when ('1', '0', '0') => __encoding aarch64_memory_rcws_cas_128 // RCWSCASP_C64_rcwcomswappr
                        when ('1', '0', '1') => __encoding aarch64_memory_rcws_cas_128 // RCWSCASPL_C64_rcwcomswappr
                        when ('1', '1', '0') => __encoding aarch64_memory_rcws_cas_128 // RCWSCASPA_C64_rcwcomswappr
                        when ('1', '1', '1') => __encoding aarch64_memory_rcws_cas_128 // RCWSCASPAL_C64_rcwcomswappr
                when ('0x01', _, '0', _, '1xx1xxxxxxxxx00', _) => // memop_128
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rt2 16 +: 5
                    __field o3 15 +: 1
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R, o3, opc) of
                        when ('0', _, _, _, '1xx') => __UNALLOCATED
                        when ('0', _, _, '0', '0x0') => __UNALLOCATED
                        when ('0', '0', '0', '0', '001') => __encoding aarch64_memory_atomicops_ld_128_ldclrp // LDCLRP_128_memop_128
                        when ('0', '0', '0', '0', '011') => __encoding aarch64_memory_atomicops_ld_128_ldsetp // LDSETP_128_memop_128
                        when ('0', '0', '0', '1', '000') => __encoding aarch64_memory_atomicops_swp_128 // SWPP_128_memop_128
                        when ('0', '0', '0', '1', '001') => __encoding aarch64_memory_rcw_ld_128_rcwclrp // RCWCLRP_128_memop_128
                        when ('0', '0', '0', '1', '010') => __encoding aarch64_memory_rcw_swp_128 // RCWSWPP_128_memop_128
                        when ('0', '0', '0', '1', '011') => __encoding aarch64_memory_rcw_ld_128_rcwsetp // RCWSETP_128_memop_128
                        when ('0', '0', '1', '0', '001') => __encoding aarch64_memory_atomicops_ld_128_ldclrp // LDCLRPL_128_memop_128
                        when ('0', '0', '1', '0', '011') => __encoding aarch64_memory_atomicops_ld_128_ldsetp // LDSETPL_128_memop_128
                        when ('0', '0', '1', '1', '000') => __encoding aarch64_memory_atomicops_swp_128 // SWPPL_128_memop_128
                        when ('0', '0', '1', '1', '001') => __encoding aarch64_memory_rcw_ld_128_rcwclrp // RCWCLRPL_128_memop_128
                        when ('0', '0', '1', '1', '010') => __encoding aarch64_memory_rcw_swp_128 // RCWSWPPL_128_memop_128
                        when ('0', '0', '1', '1', '011') => __encoding aarch64_memory_rcw_ld_128_rcwsetp // RCWSETPL_128_memop_128
                        when ('0', '1', '0', '0', '001') => __encoding aarch64_memory_atomicops_ld_128_ldclrp // LDCLRPA_128_memop_128
                        when ('0', '1', '0', '0', '011') => __encoding aarch64_memory_atomicops_ld_128_ldsetp // LDSETPA_128_memop_128
                        when ('0', '1', '0', '1', '000') => __encoding aarch64_memory_atomicops_swp_128 // SWPPA_128_memop_128
                        when ('0', '1', '0', '1', '001') => __encoding aarch64_memory_rcw_ld_128_rcwclrp // RCWCLRPA_128_memop_128
                        when ('0', '1', '0', '1', '010') => __encoding aarch64_memory_rcw_swp_128 // RCWSWPPA_128_memop_128
                        when ('0', '1', '0', '1', '011') => __encoding aarch64_memory_rcw_ld_128_rcwsetp // RCWSETPA_128_memop_128
                        when ('0', '1', '1', '0', '001') => __encoding aarch64_memory_atomicops_ld_128_ldclrp // LDCLRPAL_128_memop_128
                        when ('0', '1', '1', '0', '011') => __encoding aarch64_memory_atomicops_ld_128_ldsetp // LDSETPAL_128_memop_128
                        when ('0', '1', '1', '1', '000') => __encoding aarch64_memory_atomicops_swp_128 // SWPPAL_128_memop_128
                        when ('0', '1', '1', '1', '001') => __encoding aarch64_memory_rcw_ld_128_rcwclrp // RCWCLRPAL_128_memop_128
                        when ('0', '1', '1', '1', '010') => __encoding aarch64_memory_rcw_swp_128 // RCWSWPPAL_128_memop_128
                        when ('0', '1', '1', '1', '011') => __encoding aarch64_memory_rcw_ld_128_rcwsetp // RCWSETPAL_128_memop_128
                        when ('1', _, _, '0', _) => __UNALLOCATED
                        when ('1', _, _, '1', '000') => __UNALLOCATED
                        when ('1', _, _, '1', '1xx') => __UNALLOCATED
                        when ('1', '0', '0', '1', '001') => __encoding aarch64_memory_rcws_ld_128_rcwsclrp // RCWSCLRP_128_memop_128
                        when ('1', '0', '0', '1', '010') => __encoding aarch64_memory_rcws_swp_128 // RCWSSWPP_128_memop_128
                        when ('1', '0', '0', '1', '011') => __encoding aarch64_memory_rcws_ld_128_rcwssetp // RCWSSETP_128_memop_128
                        when ('1', '0', '1', '1', '001') => __encoding aarch64_memory_rcws_ld_128_rcwsclrp // RCWSCLRPL_128_memop_128
                        when ('1', '0', '1', '1', '010') => __encoding aarch64_memory_rcws_swp_128 // RCWSSWPPL_128_memop_128
                        when ('1', '0', '1', '1', '011') => __encoding aarch64_memory_rcws_ld_128_rcwssetp // RCWSSETPL_128_memop_128
                        when ('1', '1', '0', '1', '001') => __encoding aarch64_memory_rcws_ld_128_rcwsclrp // RCWSCLRPA_128_memop_128
                        when ('1', '1', '0', '1', '010') => __encoding aarch64_memory_rcws_swp_128 // RCWSSWPPA_128_memop_128
                        when ('1', '1', '0', '1', '011') => __encoding aarch64_memory_rcws_ld_128_rcwssetp // RCWSSETPA_128_memop_128
                        when ('1', '1', '1', '1', '001') => __encoding aarch64_memory_rcws_ld_128_rcwsclrp // RCWSCLRPAL_128_memop_128
                        when ('1', '1', '1', '1', '010') => __encoding aarch64_memory_rcws_swp_128 // RCWSSWPPAL_128_memop_128
                        when ('1', '1', '1', '1', '011') => __encoding aarch64_memory_rcws_ld_128_rcwssetp // RCWSSETPAL_128_memop_128
                when ('1101', _, '0', _, '1000111110xxx11', _) => // ldst_gcs
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc) of
                        when ('000') => __encoding aarch64_memory_gcs_general_register // GCSSTR_64_ldst_gcs
                        when ('001') => __encoding aarch64_memory_gcs_general_register // GCSSTTR_64_ldst_gcs
                        when ('01x') => __UNALLOCATED
                        when ('1xx') => __UNALLOCATED
                when ('1101', _, '0', _, '1xx1xxxxxxxxxxx', _) => // ldsttags
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field op2 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, imm9, op2) of
                        when ('00', _, '01') => __encoding aarch64_integer_tags_mcsettagpost // STG_64Spost_ldsttags
                        when ('00', _, '10') => __encoding aarch64_integer_tags_mcsettag // STG_64Soffset_ldsttags
                        when ('00', _, '11') => __encoding aarch64_integer_tags_mcsettagpre // STG_64Spre_ldsttags
                        when ('00', '000000000', '00') => __encoding aarch64_integer_tags_mcsettagandzeroarray // STZGM_64bulk_ldsttags
                        when ('01', _, '00') => __encoding aarch64_integer_tags_mcgettag // LDG_64Loffset_ldsttags
                        when ('01', _, '01') => __encoding aarch64_integer_tags_mcsettagandzerodatapost // STZG_64Spost_ldsttags
                        when ('01', _, '10') => __encoding aarch64_integer_tags_mcsettagandzerodata // STZG_64Soffset_ldsttags
                        when ('01', _, '11') => __encoding aarch64_integer_tags_mcsettagandzerodatapre // STZG_64Spre_ldsttags
                        when ('10', _, '01') => __encoding aarch64_integer_tags_mcsettagpairpost // ST2G_64Spost_ldsttags
                        when ('10', _, '10') => __encoding aarch64_integer_tags_mcsettagpair // ST2G_64Soffset_ldsttags
                        when ('10', _, '11') => __encoding aarch64_integer_tags_mcsettagpairpre // ST2G_64Spre_ldsttags
                        when ('10', !'000000000', '00') => __UNALLOCATED
                        when ('10', '000000000', '00') => __encoding aarch64_integer_tags_mcsettagarray // STGM_64bulk_ldsttags
                        when ('11', _, '01') => __encoding aarch64_integer_tags_mcsettagpairandzerodatapost // STZ2G_64Spost_ldsttags
                        when ('11', _, '10') => __encoding aarch64_integer_tags_mcsettagpairandzerodata // STZ2G_64Soffset_ldsttags
                        when ('11', _, '11') => __encoding aarch64_integer_tags_mcsettagpairandzerodatapre // STZ2G_64Spre_ldsttags
                        when ('11', !'000000000', '00') => __UNALLOCATED
                        when ('11', '000000000', '00') => __encoding aarch64_integer_tags_mcgettagarray // LDGM_64bulk_ldsttags
                when ('1x00', _, '0', _, '00x1xxxxxxxxxxx', _) => // ldstexclp
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0) of
                        when ('0', '0', '0') => __encoding aarch64_memory_exclusive_pair // STXP_SP32_ldstexclp
                        when ('0', '0', '1') => __encoding aarch64_memory_exclusive_pair // STLXP_SP32_ldstexclp
                        when ('0', '1', '0') => __encoding aarch64_memory_exclusive_pair // LDXP_LP32_ldstexclp
                        when ('0', '1', '1') => __encoding aarch64_memory_exclusive_pair // LDAXP_LP32_ldstexclp
                        when ('1', '0', '0') => __encoding aarch64_memory_exclusive_pair // STXP_SP64_ldstexclp
                        when ('1', '0', '1') => __encoding aarch64_memory_exclusive_pair // STLXP_SP64_ldstexclp
                        when ('1', '1', '0') => __encoding aarch64_memory_exclusive_pair // LDXP_LP64_ldstexclp
                        when ('1', '1', '1') => __encoding aarch64_memory_exclusive_pair // LDAXP_LP64_ldstexclp
                when ('1x00', _, '1', _, _, _) => __UNPREDICTABLE
                when ('xx00', _, '0', _, '00x0xxxxxxxxxxx', _) => // ldstexclr
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0) of
                        when ('00', '0', '0') => __encoding aarch64_memory_exclusive_single // STXRB_SR32_ldstexclr
                        when ('00', '0', '1') => __encoding aarch64_memory_exclusive_single // STLXRB_SR32_ldstexclr
                        when ('00', '1', '0') => __encoding aarch64_memory_exclusive_single // LDXRB_LR32_ldstexclr
                        when ('00', '1', '1') => __encoding aarch64_memory_exclusive_single // LDAXRB_LR32_ldstexclr
                        when ('01', '0', '0') => __encoding aarch64_memory_exclusive_single // STXRH_SR32_ldstexclr
                        when ('01', '0', '1') => __encoding aarch64_memory_exclusive_single // STLXRH_SR32_ldstexclr
                        when ('01', '1', '0') => __encoding aarch64_memory_exclusive_single // LDXRH_LR32_ldstexclr
                        when ('01', '1', '1') => __encoding aarch64_memory_exclusive_single // LDAXRH_LR32_ldstexclr
                        when ('10', '0', '0') => __encoding aarch64_memory_exclusive_single // STXR_SR32_ldstexclr
                        when ('10', '0', '1') => __encoding aarch64_memory_exclusive_single // STLXR_SR32_ldstexclr
                        when ('10', '1', '0') => __encoding aarch64_memory_exclusive_single // LDXR_LR32_ldstexclr
                        when ('10', '1', '1') => __encoding aarch64_memory_exclusive_single // LDAXR_LR32_ldstexclr
                        when ('11', '0', '0') => __encoding aarch64_memory_exclusive_single // STXR_SR64_ldstexclr
                        when ('11', '0', '1') => __encoding aarch64_memory_exclusive_single // STLXR_SR64_ldstexclr
                        when ('11', '1', '0') => __encoding aarch64_memory_exclusive_single // LDXR_LR64_ldstexclr
                        when ('11', '1', '1') => __encoding aarch64_memory_exclusive_single // LDAXR_LR64_ldstexclr
                when ('xx00', _, '0', _, '01x0xxxxxxxxxxx', _) => // ldstord
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0) of
                        when ('00', '0', '0') => __encoding aarch64_memory_ordered // STLLRB_SL32_ldstord
                        when ('00', '0', '1') => __encoding aarch64_memory_ordered // STLRB_SL32_ldstord
                        when ('00', '1', '0') => __encoding aarch64_memory_ordered // LDLARB_LR32_ldstord
                        when ('00', '1', '1') => __encoding aarch64_memory_ordered // LDARB_LR32_ldstord
                        when ('01', '0', '0') => __encoding aarch64_memory_ordered // STLLRH_SL32_ldstord
                        when ('01', '0', '1') => __encoding aarch64_memory_ordered // STLRH_SL32_ldstord
                        when ('01', '1', '0') => __encoding aarch64_memory_ordered // LDLARH_LR32_ldstord
                        when ('01', '1', '1') => __encoding aarch64_memory_ordered // LDARH_LR32_ldstord
                        when ('10', '0', '0') => __encoding aarch64_memory_ordered // STLLR_SL32_ldstord
                        when ('10', '0', '1') => __encoding aarch64_memory_ordered // STLR_SL32_ldstord
                        when ('10', '1', '0') => __encoding aarch64_memory_ordered // LDLAR_LR32_ldstord
                        when ('10', '1', '1') => __encoding aarch64_memory_ordered // LDAR_LR32_ldstord
                        when ('11', '0', '0') => __encoding aarch64_memory_ordered // STLLR_SL64_ldstord
                        when ('11', '0', '1') => __encoding aarch64_memory_ordered // STLR_SL64_ldstord
                        when ('11', '1', '0') => __encoding aarch64_memory_ordered // LDLAR_LR64_ldstord
                        when ('11', '1', '1') => __encoding aarch64_memory_ordered // LDAR_LR64_ldstord
                when ('xx00', _, '0', _, '01x1xxxxxxxxxxx', _) => // comswap
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0, Rt2) of
                        when (_, _, _, !'11111') => __UNALLOCATED
                        when ('00', '0', '0', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASB_C32_comswap
                        when ('00', '0', '1', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASLB_C32_comswap
                        when ('00', '1', '0', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASAB_C32_comswap
                        when ('00', '1', '1', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASALB_C32_comswap
                        when ('01', '0', '0', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASH_C32_comswap
                        when ('01', '0', '1', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASLH_C32_comswap
                        when ('01', '1', '0', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASAH_C32_comswap
                        when ('01', '1', '1', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASALH_C32_comswap
                        when ('10', '0', '0', '11111') => __encoding aarch64_memory_atomicops_cas_single // CAS_C32_comswap
                        when ('10', '0', '1', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASL_C32_comswap
                        when ('10', '1', '0', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASA_C32_comswap
                        when ('10', '1', '1', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASAL_C32_comswap
                        when ('11', '0', '0', '11111') => __encoding aarch64_memory_atomicops_cas_single // CAS_C64_comswap
                        when ('11', '0', '1', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASL_C64_comswap
                        when ('11', '1', '0', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASA_C64_comswap
                        when ('11', '1', '1', '11111') => __encoding aarch64_memory_atomicops_cas_single // CASAL_C64_comswap
                when ('xx01', _, '0', _, '10x0xxxxxxxxx10', _) => // ldiappstilp
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rt2 16 +: 5
                    __field opc2 12 +: 4
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, opc2) of
                        when ('0x', _, _) => __UNALLOCATED
                        when ('1x', _, '001x') => __UNALLOCATED
                        when ('1x', _, '01xx') => __UNALLOCATED
                        when ('1x', _, '1xxx') => __UNALLOCATED
                        when ('10', '0', '0000') => __encoding aarch64_memory_ordered_pair_stilp // STILP_32SE_ldiappstilp
                        when ('10', '0', '0001') => __encoding aarch64_memory_ordered_pair_stilp // STILP_32S_ldiappstilp
                        when ('10', '1', '0000') => __encoding aarch64_memory_ordered_pair_ldiapp // LDIAPP_32LE_ldiappstilp
                        when ('10', '1', '0001') => __encoding aarch64_memory_ordered_pair_ldiapp // LDIAPP_32L_ldiappstilp
                        when ('11', '0', '0000') => __encoding aarch64_memory_ordered_pair_stilp // STILP_64SS_ldiappstilp
                        when ('11', '0', '0001') => __encoding aarch64_memory_ordered_pair_stilp // STILP_64S_ldiappstilp
                        when ('11', '1', '0000') => __encoding aarch64_memory_ordered_pair_ldiapp // LDIAPP_64LS_ldiappstilp
                        when ('11', '1', '0001') => __encoding aarch64_memory_ordered_pair_ldiapp // LDIAPP_64L_ldiappstilp
                when ('xx01', _, '0', _, '11x000000000010', _) => // ldapstl_writeback
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L) of
                        when ('0x', _) => __UNALLOCATED
                        when ('10', '0') => __encoding aarch64_memory_ordered_writeback // STLR_32S_ldapstl_writeback
                        when ('10', '1') => __encoding aarch64_memory_ordered_rcpc_writeback // LDAPR_32L_ldapstl_writeback
                        when ('11', '0') => __encoding aarch64_memory_ordered_writeback // STLR_64S_ldapstl_writeback
                        when ('11', '1') => __encoding aarch64_memory_ordered_rcpc_writeback // LDAPR_64L_ldapstl_writeback
                when ('xx01', _, '0', _, '1xx0xxxxxxxxx00', _) => // ldapstl_unscaled
                    __field size 30 +: 2
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, opc) of
                        when ('00', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // STLURB_32_ldapstl_unscaled
                        when ('00', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPURB_32_ldapstl_unscaled
                        when ('00', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPURSB_64_ldapstl_unscaled
                        when ('00', '11') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPURSB_32_ldapstl_unscaled
                        when ('01', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // STLURH_32_ldapstl_unscaled
                        when ('01', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPURH_32_ldapstl_unscaled
                        when ('01', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPURSH_64_ldapstl_unscaled
                        when ('01', '11') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPURSH_32_ldapstl_unscaled
                        when ('1x', '11') => __UNALLOCATED
                        when ('10', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // STLUR_32_ldapstl_unscaled
                        when ('10', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPUR_32_ldapstl_unscaled
                        when ('10', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPURSW_64_ldapstl_unscaled
                        when ('11', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // STLUR_64_ldapstl_unscaled
                        when ('11', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_lda_stl // LDAPUR_64_ldapstl_unscaled
                        when ('11', '10') => __UNALLOCATED
                when ('xx01', _, '1', _, '1xx0xxxxxxxxx10', _) => // ldapstl_simd
                    __field size 30 +: 2
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, opc) of
                        when ('00', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // STLUR_B_ldapstl_simd
                        when ('00', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // LDAPUR_B_ldapstl_simd
                        when ('00', '10') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // STLUR_Q_ldapstl_simd
                        when ('00', '11') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // LDAPUR_Q_ldapstl_simd
                        when ('01', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // STLUR_H_ldapstl_simd
                        when ('01', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // LDAPUR_H_ldapstl_simd
                        when ('01', '1x') => __UNALLOCATED
                        when ('1x', '1x') => __UNALLOCATED
                        when ('10', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // STLUR_S_ldapstl_simd
                        when ('10', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // LDAPUR_S_ldapstl_simd
                        when ('11', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // STLUR_D_ldapstl_simd
                        when ('11', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_ordered // LDAPUR_D_ldapstl_simd
                when ('xx01', _, _, _, '0xxxxxxxxxxxxxx', _) => // loadlit
                    __field opc 30 +: 2
                    __field V 26 +: 1
                    __field imm19 5 +: 19
                    __field Rt 0 +: 5
                    case (opc, V) of
                        when ('00', '0') => __encoding aarch64_memory_literal_general // LDR_32_loadlit
                        when ('00', '1') => __encoding aarch64_memory_literal_simdfp // LDR_S_loadlit
                        when ('01', '0') => __encoding aarch64_memory_literal_general // LDR_64_loadlit
                        when ('01', '1') => __encoding aarch64_memory_literal_simdfp // LDR_D_loadlit
                        when ('10', '0') => __encoding aarch64_memory_literal_general // LDRSW_64_loadlit
                        when ('10', '1') => __encoding aarch64_memory_literal_simdfp // LDR_Q_loadlit
                        when ('11', '0') => __encoding aarch64_memory_literal_general // PRFM_P_loadlit
                        when ('11', '1') => __UNALLOCATED
                when ('xx01', _, _, _, '1xx0xxxxxxxxx01', _) => // memcms
                    __field size 30 +: 2
                    __field o0 26 +: 1
                    __field op1 22 +: 2
                    __field Rs 16 +: 5
                    __field op2 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (o0, op1, op2) of
                        when ('0', '00', '0000') => __encoding aarch64_memory_mcpymset_cpyf // CPYFP_CPY_memcms
                        when ('0', '00', '0001') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPWT_CPY_memcms
                        when ('0', '00', '0010') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPRT_CPY_memcms
                        when ('0', '00', '0011') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPT_CPY_memcms
                        when ('0', '00', '0100') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPWN_CPY_memcms
                        when ('0', '00', '0101') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPWTWN_CPY_memcms
                        when ('0', '00', '0110') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPRTWN_CPY_memcms
                        when ('0', '00', '0111') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPTWN_CPY_memcms
                        when ('0', '00', '1000') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPRN_CPY_memcms
                        when ('0', '00', '1001') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPWTRN_CPY_memcms
                        when ('0', '00', '1010') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPRTRN_CPY_memcms
                        when ('0', '00', '1011') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPTRN_CPY_memcms
                        when ('0', '00', '1100') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPN_CPY_memcms
                        when ('0', '00', '1101') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPWTN_CPY_memcms
                        when ('0', '00', '1110') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPRTN_CPY_memcms
                        when ('0', '00', '1111') => __encoding aarch64_memory_mcpymset_cpyf // CPYFPTN_CPY_memcms
                        when ('0', '01', '0000') => __encoding aarch64_memory_mcpymset_cpyf // CPYFM_CPY_memcms
                        when ('0', '01', '0001') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMWT_CPY_memcms
                        when ('0', '01', '0010') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMRT_CPY_memcms
                        when ('0', '01', '0011') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMT_CPY_memcms
                        when ('0', '01', '0100') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMWN_CPY_memcms
                        when ('0', '01', '0101') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMWTWN_CPY_memcms
                        when ('0', '01', '0110') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMRTWN_CPY_memcms
                        when ('0', '01', '0111') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMTWN_CPY_memcms
                        when ('0', '01', '1000') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMRN_CPY_memcms
                        when ('0', '01', '1001') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMWTRN_CPY_memcms
                        when ('0', '01', '1010') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMRTRN_CPY_memcms
                        when ('0', '01', '1011') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMTRN_CPY_memcms
                        when ('0', '01', '1100') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMN_CPY_memcms
                        when ('0', '01', '1101') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMWTN_CPY_memcms
                        when ('0', '01', '1110') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMRTN_CPY_memcms
                        when ('0', '01', '1111') => __encoding aarch64_memory_mcpymset_cpyf // CPYFMTN_CPY_memcms
                        when ('0', '10', '0000') => __encoding aarch64_memory_mcpymset_cpyf // CPYFE_CPY_memcms
                        when ('0', '10', '0001') => __encoding aarch64_memory_mcpymset_cpyf // CPYFEWT_CPY_memcms
                        when ('0', '10', '0010') => __encoding aarch64_memory_mcpymset_cpyf // CPYFERT_CPY_memcms
                        when ('0', '10', '0011') => __encoding aarch64_memory_mcpymset_cpyf // CPYFET_CPY_memcms
                        when ('0', '10', '0100') => __encoding aarch64_memory_mcpymset_cpyf // CPYFEWN_CPY_memcms
                        when ('0', '10', '0101') => __encoding aarch64_memory_mcpymset_cpyf // CPYFEWTWN_CPY_memcms
                        when ('0', '10', '0110') => __encoding aarch64_memory_mcpymset_cpyf // CPYFERTWN_CPY_memcms
                        when ('0', '10', '0111') => __encoding aarch64_memory_mcpymset_cpyf // CPYFETWN_CPY_memcms
                        when ('0', '10', '1000') => __encoding aarch64_memory_mcpymset_cpyf // CPYFERN_CPY_memcms
                        when ('0', '10', '1001') => __encoding aarch64_memory_mcpymset_cpyf // CPYFEWTRN_CPY_memcms
                        when ('0', '10', '1010') => __encoding aarch64_memory_mcpymset_cpyf // CPYFERTRN_CPY_memcms
                        when ('0', '10', '1011') => __encoding aarch64_memory_mcpymset_cpyf // CPYFETRN_CPY_memcms
                        when ('0', '10', '1100') => __encoding aarch64_memory_mcpymset_cpyf // CPYFEN_CPY_memcms
                        when ('0', '10', '1101') => __encoding aarch64_memory_mcpymset_cpyf // CPYFEWTN_CPY_memcms
                        when ('0', '10', '1110') => __encoding aarch64_memory_mcpymset_cpyf // CPYFERTN_CPY_memcms
                        when ('0', '10', '1111') => __encoding aarch64_memory_mcpymset_cpyf // CPYFETN_CPY_memcms
                        when ('0', '11', '0000') => __encoding aarch64_memory_mcpymset_set // SETP_SET_memcms
                        when ('0', '11', '0001') => __encoding aarch64_memory_mcpymset_set // SETPT_SET_memcms
                        when ('0', '11', '0010') => __encoding aarch64_memory_mcpymset_set // SETPN_SET_memcms
                        when ('0', '11', '0011') => __encoding aarch64_memory_mcpymset_set // SETPTN_SET_memcms
                        when ('0', '11', '0100') => __encoding aarch64_memory_mcpymset_set // SETM_SET_memcms
                        when ('0', '11', '0101') => __encoding aarch64_memory_mcpymset_set // SETMT_SET_memcms
                        when ('0', '11', '0110') => __encoding aarch64_memory_mcpymset_set // SETMN_SET_memcms
                        when ('0', '11', '0111') => __encoding aarch64_memory_mcpymset_set // SETMTN_SET_memcms
                        when ('0', '11', '1000') => __encoding aarch64_memory_mcpymset_set // SETE_SET_memcms
                        when ('0', '11', '1001') => __encoding aarch64_memory_mcpymset_set // SETET_SET_memcms
                        when ('0', '11', '1010') => __encoding aarch64_memory_mcpymset_set // SETEN_SET_memcms
                        when ('0', '11', '1011') => __encoding aarch64_memory_mcpymset_set // SETETN_SET_memcms
                        when ('0', '11', '11xx') => __UNALLOCATED
                        when ('1', '00', '0000') => __encoding aarch64_memory_mcpymset_cpy // CPYP_CPY_memcms
                        when ('1', '00', '0001') => __encoding aarch64_memory_mcpymset_cpy // CPYPWT_CPY_memcms
                        when ('1', '00', '0010') => __encoding aarch64_memory_mcpymset_cpy // CPYPRT_CPY_memcms
                        when ('1', '00', '0011') => __encoding aarch64_memory_mcpymset_cpy // CPYPT_CPY_memcms
                        when ('1', '00', '0100') => __encoding aarch64_memory_mcpymset_cpy // CPYPWN_CPY_memcms
                        when ('1', '00', '0101') => __encoding aarch64_memory_mcpymset_cpy // CPYPWTWN_CPY_memcms
                        when ('1', '00', '0110') => __encoding aarch64_memory_mcpymset_cpy // CPYPRTWN_CPY_memcms
                        when ('1', '00', '0111') => __encoding aarch64_memory_mcpymset_cpy // CPYPTWN_CPY_memcms
                        when ('1', '00', '1000') => __encoding aarch64_memory_mcpymset_cpy // CPYPRN_CPY_memcms
                        when ('1', '00', '1001') => __encoding aarch64_memory_mcpymset_cpy // CPYPWTRN_CPY_memcms
                        when ('1', '00', '1010') => __encoding aarch64_memory_mcpymset_cpy // CPYPRTRN_CPY_memcms
                        when ('1', '00', '1011') => __encoding aarch64_memory_mcpymset_cpy // CPYPTRN_CPY_memcms
                        when ('1', '00', '1100') => __encoding aarch64_memory_mcpymset_cpy // CPYPN_CPY_memcms
                        when ('1', '00', '1101') => __encoding aarch64_memory_mcpymset_cpy // CPYPWTN_CPY_memcms
                        when ('1', '00', '1110') => __encoding aarch64_memory_mcpymset_cpy // CPYPRTN_CPY_memcms
                        when ('1', '00', '1111') => __encoding aarch64_memory_mcpymset_cpy // CPYPTN_CPY_memcms
                        when ('1', '01', '0000') => __encoding aarch64_memory_mcpymset_cpy // CPYM_CPY_memcms
                        when ('1', '01', '0001') => __encoding aarch64_memory_mcpymset_cpy // CPYMWT_CPY_memcms
                        when ('1', '01', '0010') => __encoding aarch64_memory_mcpymset_cpy // CPYMRT_CPY_memcms
                        when ('1', '01', '0011') => __encoding aarch64_memory_mcpymset_cpy // CPYMT_CPY_memcms
                        when ('1', '01', '0100') => __encoding aarch64_memory_mcpymset_cpy // CPYMWN_CPY_memcms
                        when ('1', '01', '0101') => __encoding aarch64_memory_mcpymset_cpy // CPYMWTWN_CPY_memcms
                        when ('1', '01', '0110') => __encoding aarch64_memory_mcpymset_cpy // CPYMRTWN_CPY_memcms
                        when ('1', '01', '0111') => __encoding aarch64_memory_mcpymset_cpy // CPYMTWN_CPY_memcms
                        when ('1', '01', '1000') => __encoding aarch64_memory_mcpymset_cpy // CPYMRN_CPY_memcms
                        when ('1', '01', '1001') => __encoding aarch64_memory_mcpymset_cpy // CPYMWTRN_CPY_memcms
                        when ('1', '01', '1010') => __encoding aarch64_memory_mcpymset_cpy // CPYMRTRN_CPY_memcms
                        when ('1', '01', '1011') => __encoding aarch64_memory_mcpymset_cpy // CPYMTRN_CPY_memcms
                        when ('1', '01', '1100') => __encoding aarch64_memory_mcpymset_cpy // CPYMN_CPY_memcms
                        when ('1', '01', '1101') => __encoding aarch64_memory_mcpymset_cpy // CPYMWTN_CPY_memcms
                        when ('1', '01', '1110') => __encoding aarch64_memory_mcpymset_cpy // CPYMRTN_CPY_memcms
                        when ('1', '01', '1111') => __encoding aarch64_memory_mcpymset_cpy // CPYMTN_CPY_memcms
                        when ('1', '10', '0000') => __encoding aarch64_memory_mcpymset_cpy // CPYE_CPY_memcms
                        when ('1', '10', '0001') => __encoding aarch64_memory_mcpymset_cpy // CPYEWT_CPY_memcms
                        when ('1', '10', '0010') => __encoding aarch64_memory_mcpymset_cpy // CPYERT_CPY_memcms
                        when ('1', '10', '0011') => __encoding aarch64_memory_mcpymset_cpy // CPYET_CPY_memcms
                        when ('1', '10', '0100') => __encoding aarch64_memory_mcpymset_cpy // CPYEWN_CPY_memcms
                        when ('1', '10', '0101') => __encoding aarch64_memory_mcpymset_cpy // CPYEWTWN_CPY_memcms
                        when ('1', '10', '0110') => __encoding aarch64_memory_mcpymset_cpy // CPYERTWN_CPY_memcms
                        when ('1', '10', '0111') => __encoding aarch64_memory_mcpymset_cpy // CPYETWN_CPY_memcms
                        when ('1', '10', '1000') => __encoding aarch64_memory_mcpymset_cpy // CPYERN_CPY_memcms
                        when ('1', '10', '1001') => __encoding aarch64_memory_mcpymset_cpy // CPYEWTRN_CPY_memcms
                        when ('1', '10', '1010') => __encoding aarch64_memory_mcpymset_cpy // CPYERTRN_CPY_memcms
                        when ('1', '10', '1011') => __encoding aarch64_memory_mcpymset_cpy // CPYETRN_CPY_memcms
                        when ('1', '10', '1100') => __encoding aarch64_memory_mcpymset_cpy // CPYEN_CPY_memcms
                        when ('1', '10', '1101') => __encoding aarch64_memory_mcpymset_cpy // CPYEWTN_CPY_memcms
                        when ('1', '10', '1110') => __encoding aarch64_memory_mcpymset_cpy // CPYERTN_CPY_memcms
                        when ('1', '10', '1111') => __encoding aarch64_memory_mcpymset_cpy // CPYETN_CPY_memcms
                        when ('1', '11', '0000') => __encoding aarch64_memory_mcpymset_setg // SETGP_SET_memcms
                        when ('1', '11', '0001') => __encoding aarch64_memory_mcpymset_setg // SETGPT_SET_memcms
                        when ('1', '11', '0010') => __encoding aarch64_memory_mcpymset_setg // SETGPN_SET_memcms
                        when ('1', '11', '0011') => __encoding aarch64_memory_mcpymset_setg // SETGPTN_SET_memcms
                        when ('1', '11', '0100') => __encoding aarch64_memory_mcpymset_setg // SETGM_SET_memcms
                        when ('1', '11', '0101') => __encoding aarch64_memory_mcpymset_setg // SETGMT_SET_memcms
                        when ('1', '11', '0110') => __encoding aarch64_memory_mcpymset_setg // SETGMN_SET_memcms
                        when ('1', '11', '0111') => __encoding aarch64_memory_mcpymset_setg // SETGMTN_SET_memcms
                        when ('1', '11', '1000') => __encoding aarch64_memory_mcpymset_setg // SETGE_SET_memcms
                        when ('1', '11', '1001') => __encoding aarch64_memory_mcpymset_setg // SETGET_SET_memcms
                        when ('1', '11', '1010') => __encoding aarch64_memory_mcpymset_setg // SETGEN_SET_memcms
                        when ('1', '11', '1011') => __encoding aarch64_memory_mcpymset_setg // SETGETN_SET_memcms
                        when ('1', '11', '11xx') => __UNALLOCATED
                when ('xx10', _, _, _, '00xxxxxxxxxxxxx', _) => // ldstnapair_offs
                    __field opc 30 +: 2
                    __field V 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, V, L) of
                        when ('00', '0', '0') => __encoding aarch64_memory_pair_general_no_alloc // STNP_32_ldstnapair_offs
                        when ('00', '0', '1') => __encoding aarch64_memory_pair_general_no_alloc // LDNP_32_ldstnapair_offs
                        when ('00', '1', '0') => __encoding aarch64_memory_pair_simdfp_no_alloc // STNP_S_ldstnapair_offs
                        when ('00', '1', '1') => __encoding aarch64_memory_pair_simdfp_no_alloc // LDNP_S_ldstnapair_offs
                        when ('01', '0', _) => __UNALLOCATED
                        when ('01', '1', '0') => __encoding aarch64_memory_pair_simdfp_no_alloc // STNP_D_ldstnapair_offs
                        when ('01', '1', '1') => __encoding aarch64_memory_pair_simdfp_no_alloc // LDNP_D_ldstnapair_offs
                        when ('10', '0', '0') => __encoding aarch64_memory_pair_general_no_alloc // STNP_64_ldstnapair_offs
                        when ('10', '0', '1') => __encoding aarch64_memory_pair_general_no_alloc // LDNP_64_ldstnapair_offs
                        when ('10', '1', '0') => __encoding aarch64_memory_pair_simdfp_no_alloc // STNP_Q_ldstnapair_offs
                        when ('10', '1', '1') => __encoding aarch64_memory_pair_simdfp_no_alloc // LDNP_Q_ldstnapair_offs
                        when ('11', _, _) => __UNALLOCATED
                when ('xx10', _, _, _, '01xxxxxxxxxxxxx', _) => // ldstpair_post
                    __field opc 30 +: 2
                    __field V 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, V, L) of
                        when ('00', '0', '0') => __encoding aarch64_memory_pair_general_post_idx // STP_32_ldstpair_post
                        when ('00', '0', '1') => __encoding aarch64_memory_pair_general_post_idx // LDP_32_ldstpair_post
                        when ('00', '1', '0') => __encoding aarch64_memory_pair_simdfp_post_idx // STP_S_ldstpair_post
                        when ('00', '1', '1') => __encoding aarch64_memory_pair_simdfp_post_idx // LDP_S_ldstpair_post
                        when ('01', '0', '0') => __encoding aarch64_integer_tags_mcsettaganddatapairpost // STGP_64_ldstpair_post
                        when ('01', '0', '1') => __encoding aarch64_memory_pair_general_post_idx // LDPSW_64_ldstpair_post
                        when ('01', '1', '0') => __encoding aarch64_memory_pair_simdfp_post_idx // STP_D_ldstpair_post
                        when ('01', '1', '1') => __encoding aarch64_memory_pair_simdfp_post_idx // LDP_D_ldstpair_post
                        when ('10', '0', '0') => __encoding aarch64_memory_pair_general_post_idx // STP_64_ldstpair_post
                        when ('10', '0', '1') => __encoding aarch64_memory_pair_general_post_idx // LDP_64_ldstpair_post
                        when ('10', '1', '0') => __encoding aarch64_memory_pair_simdfp_post_idx // STP_Q_ldstpair_post
                        when ('10', '1', '1') => __encoding aarch64_memory_pair_simdfp_post_idx // LDP_Q_ldstpair_post
                        when ('11', _, _) => __UNALLOCATED
                when ('xx10', _, _, _, '10xxxxxxxxxxxxx', _) => // ldstpair_off
                    __field opc 30 +: 2
                    __field V 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, V, L) of
                        when ('00', '0', '0') => __encoding aarch64_memory_pair_general_offset // STP_32_ldstpair_off
                        when ('00', '0', '1') => __encoding aarch64_memory_pair_general_offset // LDP_32_ldstpair_off
                        when ('00', '1', '0') => __encoding aarch64_memory_pair_simdfp_offset // STP_S_ldstpair_off
                        when ('00', '1', '1') => __encoding aarch64_memory_pair_simdfp_offset // LDP_S_ldstpair_off
                        when ('01', '0', '0') => __encoding aarch64_integer_tags_mcsettaganddatapair // STGP_64_ldstpair_off
                        when ('01', '0', '1') => __encoding aarch64_memory_pair_general_offset // LDPSW_64_ldstpair_off
                        when ('01', '1', '0') => __encoding aarch64_memory_pair_simdfp_offset // STP_D_ldstpair_off
                        when ('01', '1', '1') => __encoding aarch64_memory_pair_simdfp_offset // LDP_D_ldstpair_off
                        when ('10', '0', '0') => __encoding aarch64_memory_pair_general_offset // STP_64_ldstpair_off
                        when ('10', '0', '1') => __encoding aarch64_memory_pair_general_offset // LDP_64_ldstpair_off
                        when ('10', '1', '0') => __encoding aarch64_memory_pair_simdfp_offset // STP_Q_ldstpair_off
                        when ('10', '1', '1') => __encoding aarch64_memory_pair_simdfp_offset // LDP_Q_ldstpair_off
                        when ('11', _, _) => __UNALLOCATED
                when ('xx10', _, _, _, '11xxxxxxxxxxxxx', _) => // ldstpair_pre
                    __field opc 30 +: 2
                    __field V 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, V, L) of
                        when ('00', '0', '0') => __encoding aarch64_memory_pair_general_pre_idx // STP_32_ldstpair_pre
                        when ('00', '0', '1') => __encoding aarch64_memory_pair_general_pre_idx // LDP_32_ldstpair_pre
                        when ('00', '1', '0') => __encoding aarch64_memory_pair_simdfp_pre_idx // STP_S_ldstpair_pre
                        when ('00', '1', '1') => __encoding aarch64_memory_pair_simdfp_pre_idx // LDP_S_ldstpair_pre
                        when ('01', '0', '0') => __encoding aarch64_integer_tags_mcsettaganddatapairpre // STGP_64_ldstpair_pre
                        when ('01', '0', '1') => __encoding aarch64_memory_pair_general_pre_idx // LDPSW_64_ldstpair_pre
                        when ('01', '1', '0') => __encoding aarch64_memory_pair_simdfp_pre_idx // STP_D_ldstpair_pre
                        when ('01', '1', '1') => __encoding aarch64_memory_pair_simdfp_pre_idx // LDP_D_ldstpair_pre
                        when ('10', '0', '0') => __encoding aarch64_memory_pair_general_pre_idx // STP_64_ldstpair_pre
                        when ('10', '0', '1') => __encoding aarch64_memory_pair_general_pre_idx // LDP_64_ldstpair_pre
                        when ('10', '1', '0') => __encoding aarch64_memory_pair_simdfp_pre_idx // STP_Q_ldstpair_pre
                        when ('10', '1', '1') => __encoding aarch64_memory_pair_simdfp_pre_idx // LDP_Q_ldstpair_pre
                        when ('11', _, _) => __UNALLOCATED
                when ('xx11', _, _, _, '0xx0xxxxxxxxx00', _) => // ldst_unscaled
                    __field size 30 +: 2
                    __field V 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, V, opc) of
                        when ('x1', '1', '1x') => __UNALLOCATED
                        when ('00', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // STURB_32_ldst_unscaled
                        when ('00', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDURB_32_ldst_unscaled
                        when ('00', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDURSB_64_ldst_unscaled
                        when ('00', '0', '11') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDURSB_32_ldst_unscaled
                        when ('00', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // STUR_B_ldst_unscaled
                        when ('00', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // LDUR_B_ldst_unscaled
                        when ('00', '1', '10') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // STUR_Q_ldst_unscaled
                        when ('00', '1', '11') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // LDUR_Q_ldst_unscaled
                        when ('01', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // STURH_32_ldst_unscaled
                        when ('01', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDURH_32_ldst_unscaled
                        when ('01', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDURSH_64_ldst_unscaled
                        when ('01', '0', '11') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDURSH_32_ldst_unscaled
                        when ('01', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // STUR_H_ldst_unscaled
                        when ('01', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // LDUR_H_ldst_unscaled
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('1x', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // STUR_32_ldst_unscaled
                        when ('10', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDUR_32_ldst_unscaled
                        when ('10', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDURSW_64_ldst_unscaled
                        when ('10', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // STUR_S_ldst_unscaled
                        when ('10', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // LDUR_S_ldst_unscaled
                        when ('11', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // STUR_64_ldst_unscaled
                        when ('11', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // LDUR_64_ldst_unscaled
                        when ('11', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_normal // PRFUM_P_ldst_unscaled
                        when ('11', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // STUR_D_ldst_unscaled
                        when ('11', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_offset_normal // LDUR_D_ldst_unscaled
                when ('xx11', _, _, _, '0xx0xxxxxxxxx01', _) => // ldst_immpost
                    __field size 30 +: 2
                    __field V 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, V, opc) of
                        when ('x1', '1', '1x') => __UNALLOCATED
                        when ('00', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // STRB_32_ldst_immpost
                        when ('00', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDRB_32_ldst_immpost
                        when ('00', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDRSB_64_ldst_immpost
                        when ('00', '0', '11') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDRSB_32_ldst_immpost
                        when ('00', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // STR_B_ldst_immpost
                        when ('00', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // LDR_B_ldst_immpost
                        when ('00', '1', '10') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // STR_Q_ldst_immpost
                        when ('00', '1', '11') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // LDR_Q_ldst_immpost
                        when ('01', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // STRH_32_ldst_immpost
                        when ('01', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDRH_32_ldst_immpost
                        when ('01', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDRSH_64_ldst_immpost
                        when ('01', '0', '11') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDRSH_32_ldst_immpost
                        when ('01', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // STR_H_ldst_immpost
                        when ('01', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // LDR_H_ldst_immpost
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('1x', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // STR_32_ldst_immpost
                        when ('10', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDR_32_ldst_immpost
                        when ('10', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDRSW_64_ldst_immpost
                        when ('10', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // STR_S_ldst_immpost
                        when ('10', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // LDR_S_ldst_immpost
                        when ('11', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // STR_64_ldst_immpost
                        when ('11', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_post_idx // LDR_64_ldst_immpost
                        when ('11', '0', '10') => __UNALLOCATED
                        when ('11', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // STR_D_ldst_immpost
                        when ('11', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_post_idx // LDR_D_ldst_immpost
                when ('xx11', _, _, _, '0xx0xxxxxxxxx10', _) => // ldst_unpriv
                    __field size 30 +: 2
                    __field V 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, V, opc) of
                        when (_, '1', _) => __UNALLOCATED
                        when ('00', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // STTRB_32_ldst_unpriv
                        when ('00', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTRB_32_ldst_unpriv
                        when ('00', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTRSB_64_ldst_unpriv
                        when ('00', '0', '11') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTRSB_32_ldst_unpriv
                        when ('01', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // STTRH_32_ldst_unpriv
                        when ('01', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTRH_32_ldst_unpriv
                        when ('01', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTRSH_64_ldst_unpriv
                        when ('01', '0', '11') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTRSH_32_ldst_unpriv
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // STTR_32_ldst_unpriv
                        when ('10', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTR_32_ldst_unpriv
                        when ('10', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTRSW_64_ldst_unpriv
                        when ('11', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // STTR_64_ldst_unpriv
                        when ('11', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_offset_unpriv // LDTR_64_ldst_unpriv
                        when ('11', '0', '10') => __UNALLOCATED
                when ('xx11', _, _, _, '0xx0xxxxxxxxx11', _) => // ldst_immpre
                    __field size 30 +: 2
                    __field V 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, V, opc) of
                        when ('x1', '1', '1x') => __UNALLOCATED
                        when ('00', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // STRB_32_ldst_immpre
                        when ('00', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDRB_32_ldst_immpre
                        when ('00', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDRSB_64_ldst_immpre
                        when ('00', '0', '11') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDRSB_32_ldst_immpre
                        when ('00', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // STR_B_ldst_immpre
                        when ('00', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // LDR_B_ldst_immpre
                        when ('00', '1', '10') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // STR_Q_ldst_immpre
                        when ('00', '1', '11') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // LDR_Q_ldst_immpre
                        when ('01', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // STRH_32_ldst_immpre
                        when ('01', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDRH_32_ldst_immpre
                        when ('01', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDRSH_64_ldst_immpre
                        when ('01', '0', '11') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDRSH_32_ldst_immpre
                        when ('01', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // STR_H_ldst_immpre
                        when ('01', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // LDR_H_ldst_immpre
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('1x', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // STR_32_ldst_immpre
                        when ('10', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDR_32_ldst_immpre
                        when ('10', '0', '10') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDRSW_64_ldst_immpre
                        when ('10', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // STR_S_ldst_immpre
                        when ('10', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // LDR_S_ldst_immpre
                        when ('11', '0', '00') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // STR_64_ldst_immpre
                        when ('11', '0', '01') => __encoding aarch64_memory_single_general_immediate_signed_pre_idx // LDR_64_ldst_immpre
                        when ('11', '0', '10') => __UNALLOCATED
                        when ('11', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // STR_D_ldst_immpre
                        when ('11', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_signed_pre_idx // LDR_D_ldst_immpre
                when ('xx11', _, _, _, '0xx1xxxxxxxxx00', _) => // memop
                    __field size 30 +: 2
                    __field V 26 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field o3 15 +: 1
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, V, A, R, Rs, o3, opc) of
                        when (_, '0', _, _, _, '1', '11x') => __UNALLOCATED
                        when (_, '0', '0', _, _, '1', '100') => __UNALLOCATED
                        when (_, '0', '0', '1', _, '1', '101') => __UNALLOCATED
                        when (_, '0', '1', '0', _, '1', '101') => __UNALLOCATED
                        when (_, '0', '1', '1', _, '1', '100') => __UNALLOCATED
                        when (_, '0', '1', '1', _, '1', '101') => __UNALLOCATED
                        when (_, '1', _, _, _, _, _) => __UNALLOCATED
                        when ('00', '0', '0', '0', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDB_32_memop
                        when ('00', '0', '0', '0', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRB_32_memop
                        when ('00', '0', '0', '0', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORB_32_memop
                        when ('00', '0', '0', '0', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETB_32_memop
                        when ('00', '0', '0', '0', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXB_32_memop
                        when ('00', '0', '0', '0', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINB_32_memop
                        when ('00', '0', '0', '0', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXB_32_memop
                        when ('00', '0', '0', '0', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINB_32_memop
                        when ('00', '0', '0', '0', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPB_32_memop
                        when ('00', '0', '0', '0', _, '1', '001') => __encoding aarch64_memory_rcw_ld_rcwclr // RCWCLR_64_memop
                        when ('00', '0', '0', '0', _, '1', '010') => __encoding aarch64_memory_rcw_swp // RCWSWP_64_memop
                        when ('00', '0', '0', '0', _, '1', '011') => __encoding aarch64_memory_rcw_ld_rcwset // RCWSET_64_memop
                        when ('00', '0', '0', '0', _, '1', '101') => __UNALLOCATED
                        when ('00', '0', '0', '1', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINLB_32_memop
                        when ('00', '0', '0', '1', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPLB_32_memop
                        when ('00', '0', '0', '1', _, '1', '001') => __encoding aarch64_memory_rcw_ld_rcwclr // RCWCLRL_64_memop
                        when ('00', '0', '0', '1', _, '1', '010') => __encoding aarch64_memory_rcw_swp // RCWSWPL_64_memop
                        when ('00', '0', '0', '1', _, '1', '011') => __encoding aarch64_memory_rcw_ld_rcwset // RCWSETL_64_memop
                        when ('00', '0', '1', '0', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINAB_32_memop
                        when ('00', '0', '1', '0', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPAB_32_memop
                        when ('00', '0', '1', '0', _, '1', '001') => __encoding aarch64_memory_rcw_ld_rcwclr // RCWCLRA_64_memop
                        when ('00', '0', '1', '0', _, '1', '010') => __encoding aarch64_memory_rcw_swp // RCWSWPA_64_memop
                        when ('00', '0', '1', '0', _, '1', '011') => __encoding aarch64_memory_rcw_ld_rcwset // RCWSETA_64_memop
                        when ('00', '0', '1', '0', _, '1', '100') => __encoding aarch64_memory_ordered_rcpc // LDAPRB_32L_memop
                        when ('00', '0', '1', '1', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINALB_32_memop
                        when ('00', '0', '1', '1', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPALB_32_memop
                        when ('00', '0', '1', '1', _, '1', '001') => __encoding aarch64_memory_rcw_ld_rcwclr // RCWCLRAL_64_memop
                        when ('00', '0', '1', '1', _, '1', '010') => __encoding aarch64_memory_rcw_swp // RCWSWPAL_64_memop
                        when ('00', '0', '1', '1', _, '1', '011') => __encoding aarch64_memory_rcw_ld_rcwset // RCWSETAL_64_memop
                        when ('01', '0', '0', '0', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDH_32_memop
                        when ('01', '0', '0', '0', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRH_32_memop
                        when ('01', '0', '0', '0', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORH_32_memop
                        when ('01', '0', '0', '0', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETH_32_memop
                        when ('01', '0', '0', '0', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXH_32_memop
                        when ('01', '0', '0', '0', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINH_32_memop
                        when ('01', '0', '0', '0', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXH_32_memop
                        when ('01', '0', '0', '0', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINH_32_memop
                        when ('01', '0', '0', '0', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPH_32_memop
                        when ('01', '0', '0', '0', _, '1', '001') => __encoding aarch64_memory_rcws_ld_rcwsclr // RCWSCLR_64_memop
                        when ('01', '0', '0', '0', _, '1', '010') => __encoding aarch64_memory_rcws_swp // RCWSSWP_64_memop
                        when ('01', '0', '0', '0', _, '1', '011') => __encoding aarch64_memory_rcws_ld_rcwsset // RCWSSET_64_memop
                        when ('01', '0', '0', '0', _, '1', '101') => __UNALLOCATED
                        when ('01', '0', '0', '1', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINLH_32_memop
                        when ('01', '0', '0', '1', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPLH_32_memop
                        when ('01', '0', '0', '1', _, '1', '001') => __encoding aarch64_memory_rcws_ld_rcwsclr // RCWSCLRL_64_memop
                        when ('01', '0', '0', '1', _, '1', '010') => __encoding aarch64_memory_rcws_swp // RCWSSWPL_64_memop
                        when ('01', '0', '0', '1', _, '1', '011') => __encoding aarch64_memory_rcws_ld_rcwsset // RCWSSETL_64_memop
                        when ('01', '0', '1', '0', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINAH_32_memop
                        when ('01', '0', '1', '0', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPAH_32_memop
                        when ('01', '0', '1', '0', _, '1', '001') => __encoding aarch64_memory_rcws_ld_rcwsclr // RCWSCLRA_64_memop
                        when ('01', '0', '1', '0', _, '1', '010') => __encoding aarch64_memory_rcws_swp // RCWSSWPA_64_memop
                        when ('01', '0', '1', '0', _, '1', '011') => __encoding aarch64_memory_rcws_ld_rcwsset // RCWSSETA_64_memop
                        when ('01', '0', '1', '0', _, '1', '100') => __encoding aarch64_memory_ordered_rcpc // LDAPRH_32L_memop
                        when ('01', '0', '1', '1', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINALH_32_memop
                        when ('01', '0', '1', '1', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPALH_32_memop
                        when ('01', '0', '1', '1', _, '1', '001') => __encoding aarch64_memory_rcws_ld_rcwsclr // RCWSCLRAL_64_memop
                        when ('01', '0', '1', '1', _, '1', '010') => __encoding aarch64_memory_rcws_swp // RCWSSWPAL_64_memop
                        when ('01', '0', '1', '1', _, '1', '011') => __encoding aarch64_memory_rcws_ld_rcwsset // RCWSSETAL_64_memop
                        when ('1x', '0', '0', '1', _, '1', '001') => __UNALLOCATED
                        when ('1x', '0', '0', '1', _, '1', '010') => __UNALLOCATED
                        when ('1x', '0', '0', '1', _, '1', '011') => __UNALLOCATED
                        when ('1x', '0', '1', '0', _, '1', '001') => __UNALLOCATED
                        when ('1x', '0', '1', '0', _, '1', '010') => __UNALLOCATED
                        when ('1x', '0', '1', '0', _, '1', '011') => __UNALLOCATED
                        when ('1x', '0', '1', '1', _, '1', '001') => __UNALLOCATED
                        when ('1x', '0', '1', '1', _, '1', '010') => __UNALLOCATED
                        when ('1x', '0', '1', '1', _, '1', '011') => __UNALLOCATED
                        when ('10', '0', '0', '0', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADD_32_memop
                        when ('10', '0', '0', '0', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLR_32_memop
                        when ('10', '0', '0', '0', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEOR_32_memop
                        when ('10', '0', '0', '0', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSET_32_memop
                        when ('10', '0', '0', '0', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAX_32_memop
                        when ('10', '0', '0', '0', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMIN_32_memop
                        when ('10', '0', '0', '0', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAX_32_memop
                        when ('10', '0', '0', '0', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMIN_32_memop
                        when ('10', '0', '0', '0', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWP_32_memop
                        when ('10', '0', '0', '0', _, '1', '001') => __UNALLOCATED
                        when ('10', '0', '0', '0', _, '1', '010') => __UNALLOCATED
                        when ('10', '0', '0', '0', _, '1', '011') => __UNALLOCATED
                        when ('10', '0', '0', '0', _, '1', '101') => __UNALLOCATED
                        when ('10', '0', '0', '1', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDL_32_memop
                        when ('10', '0', '0', '1', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRL_32_memop
                        when ('10', '0', '0', '1', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORL_32_memop
                        when ('10', '0', '0', '1', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETL_32_memop
                        when ('10', '0', '0', '1', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXL_32_memop
                        when ('10', '0', '0', '1', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINL_32_memop
                        when ('10', '0', '0', '1', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXL_32_memop
                        when ('10', '0', '0', '1', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINL_32_memop
                        when ('10', '0', '0', '1', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPL_32_memop
                        when ('10', '0', '1', '0', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDA_32_memop
                        when ('10', '0', '1', '0', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRA_32_memop
                        when ('10', '0', '1', '0', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORA_32_memop
                        when ('10', '0', '1', '0', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETA_32_memop
                        when ('10', '0', '1', '0', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXA_32_memop
                        when ('10', '0', '1', '0', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINA_32_memop
                        when ('10', '0', '1', '0', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXA_32_memop
                        when ('10', '0', '1', '0', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINA_32_memop
                        when ('10', '0', '1', '0', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPA_32_memop
                        when ('10', '0', '1', '0', _, '1', '100') => __encoding aarch64_memory_ordered_rcpc // LDAPR_32L_memop
                        when ('10', '0', '1', '1', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINAL_32_memop
                        when ('10', '0', '1', '1', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPAL_32_memop
                        when ('11', '0', '0', '0', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADD_64_memop
                        when ('11', '0', '0', '0', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLR_64_memop
                        when ('11', '0', '0', '0', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEOR_64_memop
                        when ('11', '0', '0', '0', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSET_64_memop
                        when ('11', '0', '0', '0', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAX_64_memop
                        when ('11', '0', '0', '0', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMIN_64_memop
                        when ('11', '0', '0', '0', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAX_64_memop
                        when ('11', '0', '0', '0', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMIN_64_memop
                        when ('11', '0', '0', '0', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWP_64_memop
                        when ('11', '0', '0', '0', _, '1', '010') => __encoding aarch64_memory_atomicops_st_acc_st64bv0 // ST64BV0_64_memop
                        when ('11', '0', '0', '0', _, '1', '011') => __encoding aarch64_memory_atomicops_st_acc_st64bv // ST64BV_64_memop
                        when ('11', '0', '0', '0', '11111', '1', '001') => __encoding aarch64_memory_atomicops_st_acc_st64b // ST64B_64L_memop
                        when ('11', '0', '0', '0', '11111', '1', '101') => __encoding aarch64_memory_atomicops_ld_acc // LD64B_64L_memop
                        when ('11', '0', '0', '1', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDL_64_memop
                        when ('11', '0', '0', '1', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRL_64_memop
                        when ('11', '0', '0', '1', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORL_64_memop
                        when ('11', '0', '0', '1', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETL_64_memop
                        when ('11', '0', '0', '1', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXL_64_memop
                        when ('11', '0', '0', '1', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINL_64_memop
                        when ('11', '0', '0', '1', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXL_64_memop
                        when ('11', '0', '0', '1', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINL_64_memop
                        when ('11', '0', '0', '1', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPL_64_memop
                        when ('11', '0', '1', '0', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDA_64_memop
                        when ('11', '0', '1', '0', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRA_64_memop
                        when ('11', '0', '1', '0', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORA_64_memop
                        when ('11', '0', '1', '0', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETA_64_memop
                        when ('11', '0', '1', '0', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXA_64_memop
                        when ('11', '0', '1', '0', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINA_64_memop
                        when ('11', '0', '1', '0', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXA_64_memop
                        when ('11', '0', '1', '0', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINA_64_memop
                        when ('11', '0', '1', '0', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPA_64_memop
                        when ('11', '0', '1', '0', _, '1', '100') => __encoding aarch64_memory_ordered_rcpc // LDAPR_64L_memop
                        when ('11', '0', '1', '1', _, '0', '000') => __encoding aarch64_memory_atomicops_ld // LDADDAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '001') => __encoding aarch64_memory_atomicops_ld // LDCLRAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '010') => __encoding aarch64_memory_atomicops_ld // LDEORAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '011') => __encoding aarch64_memory_atomicops_ld // LDSETAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '100') => __encoding aarch64_memory_atomicops_ld // LDSMAXAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '101') => __encoding aarch64_memory_atomicops_ld // LDSMINAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '110') => __encoding aarch64_memory_atomicops_ld // LDUMAXAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '111') => __encoding aarch64_memory_atomicops_ld // LDUMINAL_64_memop
                        when ('11', '0', '1', '1', _, '1', '000') => __encoding aarch64_memory_atomicops_swp // SWPAL_64_memop
                when ('xx11', _, _, _, '0xx1xxxxxxxxx10', _) => // ldst_regoff
                    __field size 30 +: 2
                    __field V 26 +: 1
                    __field opc 22 +: 2
                    __field Rm 16 +: 5
                    __field option 13 +: 3
                    __field S 12 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, V, opc, option, Rt) of
                        when ('x1', '1', '1x', _, _) => __UNALLOCATED
                        when ('00', '0', '00', !'011', _) => __encoding aarch64_memory_single_general_register // STRB_32B_ldst_regoff
                        when ('00', '0', '00', '011', _) => __encoding aarch64_memory_single_general_register // STRB_32BL_ldst_regoff
                        when ('00', '0', '01', !'011', _) => __encoding aarch64_memory_single_general_register // LDRB_32B_ldst_regoff
                        when ('00', '0', '01', '011', _) => __encoding aarch64_memory_single_general_register // LDRB_32BL_ldst_regoff
                        when ('00', '0', '10', !'011', _) => __encoding aarch64_memory_single_general_register // LDRSB_64B_ldst_regoff
                        when ('00', '0', '10', '011', _) => __encoding aarch64_memory_single_general_register // LDRSB_64BL_ldst_regoff
                        when ('00', '0', '11', !'011', _) => __encoding aarch64_memory_single_general_register // LDRSB_32B_ldst_regoff
                        when ('00', '0', '11', '011', _) => __encoding aarch64_memory_single_general_register // LDRSB_32BL_ldst_regoff
                        when ('00', '1', '00', !'011', _) => __encoding aarch64_memory_single_simdfp_register // STR_B_ldst_regoff
                        when ('00', '1', '00', '011', _) => __encoding aarch64_memory_single_simdfp_register // STR_BL_ldst_regoff
                        when ('00', '1', '01', !'011', _) => __encoding aarch64_memory_single_simdfp_register // LDR_B_ldst_regoff
                        when ('00', '1', '01', '011', _) => __encoding aarch64_memory_single_simdfp_register // LDR_BL_ldst_regoff
                        when ('00', '1', '10', _, _) => __encoding aarch64_memory_single_simdfp_register // STR_Q_ldst_regoff
                        when ('00', '1', '11', _, _) => __encoding aarch64_memory_single_simdfp_register // LDR_Q_ldst_regoff
                        when ('01', '0', '00', _, _) => __encoding aarch64_memory_single_general_register // STRH_32_ldst_regoff
                        when ('01', '0', '01', _, _) => __encoding aarch64_memory_single_general_register // LDRH_32_ldst_regoff
                        when ('01', '0', '10', _, _) => __encoding aarch64_memory_single_general_register // LDRSH_64_ldst_regoff
                        when ('01', '0', '11', _, _) => __encoding aarch64_memory_single_general_register // LDRSH_32_ldst_regoff
                        when ('01', '1', '00', _, _) => __encoding aarch64_memory_single_simdfp_register // STR_H_ldst_regoff
                        when ('01', '1', '01', _, _) => __encoding aarch64_memory_single_simdfp_register // LDR_H_ldst_regoff
                        when ('1x', '0', '11', _, _) => __UNALLOCATED
                        when ('1x', '1', '1x', _, _) => __UNALLOCATED
                        when ('10', '0', '00', _, _) => __encoding aarch64_memory_single_general_register // STR_32_ldst_regoff
                        when ('10', '0', '01', _, _) => __encoding aarch64_memory_single_general_register // LDR_32_ldst_regoff
                        when ('10', '0', '10', _, _) => __encoding aarch64_memory_single_general_register // LDRSW_64_ldst_regoff
                        when ('10', '1', '00', _, _) => __encoding aarch64_memory_single_simdfp_register // STR_S_ldst_regoff
                        when ('10', '1', '01', _, _) => __encoding aarch64_memory_single_simdfp_register // LDR_S_ldst_regoff
                        when ('11', '0', '00', _, _) => __encoding aarch64_memory_single_general_register // STR_64_ldst_regoff
                        when ('11', '0', '01', _, _) => __encoding aarch64_memory_single_general_register // LDR_64_ldst_regoff
                        when ('11', '0', '10', 'x0x', _) => __UNALLOCATED
                        when ('11', '0', '10', 'x1x', !'11xxx') => __encoding aarch64_memory_single_general_register // PRFM_P_ldst_regoff
                        when ('11', '0', '10', 'x1x', '11xxx') => __encoding aarch64_memory_single_general_range // RPRFM_R_ldst_regoff
                        when ('11', '1', '00', _, _) => __encoding aarch64_memory_single_simdfp_register // STR_D_ldst_regoff
                        when ('11', '1', '01', _, _) => __encoding aarch64_memory_single_simdfp_register // LDR_D_ldst_regoff
                when ('xx11', _, _, _, '0xx1xxxxxxxxxx1', _) => // ldst_pac
                    __field size 30 +: 2
                    __field V 26 +: 1
                    __field M 23 +: 1
                    __field S 22 +: 1
                    __field imm9 12 +: 9
                    __field W 11 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, V, M, W) of
                        when (!'11', _, _, _) => __UNALLOCATED
                        when ('11', '0', '0', '0') => __encoding aarch64_memory_single_general_immediate_signed_pac // LDRAA_64_ldst_pac
                        when ('11', '0', '0', '1') => __encoding aarch64_memory_single_general_immediate_signed_pac // LDRAA_64W_ldst_pac
                        when ('11', '0', '1', '0') => __encoding aarch64_memory_single_general_immediate_signed_pac // LDRAB_64_ldst_pac
                        when ('11', '0', '1', '1') => __encoding aarch64_memory_single_general_immediate_signed_pac // LDRAB_64W_ldst_pac
                        when ('11', '1', _, _) => __UNALLOCATED
                when ('xx11', _, _, _, '1xxxxxxxxxxxxxx', _) => // ldst_pos
                    __field size 30 +: 2
                    __field V 26 +: 1
                    __field opc 22 +: 2
                    __field imm12 10 +: 12
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, V, opc) of
                        when ('x1', '1', '1x') => __UNALLOCATED
                        when ('00', '0', '00') => __encoding aarch64_memory_single_general_immediate_unsigned // STRB_32_ldst_pos
                        when ('00', '0', '01') => __encoding aarch64_memory_single_general_immediate_unsigned // LDRB_32_ldst_pos
                        when ('00', '0', '10') => __encoding aarch64_memory_single_general_immediate_unsigned // LDRSB_64_ldst_pos
                        when ('00', '0', '11') => __encoding aarch64_memory_single_general_immediate_unsigned // LDRSB_32_ldst_pos
                        when ('00', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // STR_B_ldst_pos
                        when ('00', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // LDR_B_ldst_pos
                        when ('00', '1', '10') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // STR_Q_ldst_pos
                        when ('00', '1', '11') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // LDR_Q_ldst_pos
                        when ('01', '0', '00') => __encoding aarch64_memory_single_general_immediate_unsigned // STRH_32_ldst_pos
                        when ('01', '0', '01') => __encoding aarch64_memory_single_general_immediate_unsigned // LDRH_32_ldst_pos
                        when ('01', '0', '10') => __encoding aarch64_memory_single_general_immediate_unsigned // LDRSH_64_ldst_pos
                        when ('01', '0', '11') => __encoding aarch64_memory_single_general_immediate_unsigned // LDRSH_32_ldst_pos
                        when ('01', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // STR_H_ldst_pos
                        when ('01', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // LDR_H_ldst_pos
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('1x', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding aarch64_memory_single_general_immediate_unsigned // STR_32_ldst_pos
                        when ('10', '0', '01') => __encoding aarch64_memory_single_general_immediate_unsigned // LDR_32_ldst_pos
                        when ('10', '0', '10') => __encoding aarch64_memory_single_general_immediate_unsigned // LDRSW_64_ldst_pos
                        when ('10', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // STR_S_ldst_pos
                        when ('10', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // LDR_S_ldst_pos
                        when ('11', '0', '00') => __encoding aarch64_memory_single_general_immediate_unsigned // STR_64_ldst_pos
                        when ('11', '0', '01') => __encoding aarch64_memory_single_general_immediate_unsigned // LDR_64_ldst_pos
                        when ('11', '0', '10') => __encoding aarch64_memory_single_general_immediate_unsigned // PRFM_P_ldst_pos
                        when ('11', '1', '00') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // STR_D_ldst_pos
                        when ('11', '1', '01') => __encoding aarch64_memory_single_simdfp_immediate_unsigned // LDR_D_ldst_pos
        when (_, _, 'x101', _) =>
            // dpreg
            case (31 +: 1, 30 +: 1, 29 +: 1, 28 +: 1, 25 +: 3, 21 +: 4, 16 +: 5, 10 +: 6, 0 +: 10) of
                when (_, '0', _, '1', _, '0110', _, _, _) => // dp_2src
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field opcode 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, opcode) of
                        when (_, _, '000001') => __UNALLOCATED
                        when (_, _, '1xxxxx') => __UNALLOCATED
                        when (_, '0', '00011x') => __UNALLOCATED
                        when (_, '0', '001101') => __UNALLOCATED
                        when (_, '0', '00111x') => __UNALLOCATED
                        when (_, '0', '0111xx') => __UNALLOCATED
                        when (_, '1', '00001x') => __UNALLOCATED
                        when (_, '1', '0001xx') => __UNALLOCATED
                        when (_, '1', '001xxx') => __UNALLOCATED
                        when (_, '1', '01xxxx') => __UNALLOCATED
                        when ('0', _, '000000') => __UNALLOCATED
                        when ('0', '0', '000010') => __encoding aarch64_integer_arithmetic_div // UDIV_32_dp_2src
                        when ('0', '0', '000011') => __encoding aarch64_integer_arithmetic_div // SDIV_32_dp_2src
                        when ('0', '0', '00010x') => __UNALLOCATED
                        when ('0', '0', '001000') => __encoding aarch64_integer_shift_variable // LSLV_32_dp_2src
                        when ('0', '0', '001001') => __encoding aarch64_integer_shift_variable // LSRV_32_dp_2src
                        when ('0', '0', '001010') => __encoding aarch64_integer_shift_variable // ASRV_32_dp_2src
                        when ('0', '0', '001011') => __encoding aarch64_integer_shift_variable // RORV_32_dp_2src
                        when ('0', '0', '001100') => __UNALLOCATED
                        when ('0', '0', '010x11') => __UNALLOCATED
                        when ('0', '0', '010000') => __encoding aarch64_integer_crc // CRC32B_32C_dp_2src
                        when ('0', '0', '010001') => __encoding aarch64_integer_crc // CRC32H_32C_dp_2src
                        when ('0', '0', '010010') => __encoding aarch64_integer_crc // CRC32W_32C_dp_2src
                        when ('0', '0', '010100') => __encoding aarch64_integer_crc // CRC32CB_32C_dp_2src
                        when ('0', '0', '010101') => __encoding aarch64_integer_crc // CRC32CH_32C_dp_2src
                        when ('0', '0', '010110') => __encoding aarch64_integer_crc // CRC32CW_32C_dp_2src
                        when ('0', '0', '011000') => __encoding aarch64_integer_arithmetic_max_min_smax_reg // SMAX_32_dp_2src
                        when ('0', '0', '011001') => __encoding aarch64_integer_arithmetic_max_min_umax_reg // UMAX_32_dp_2src
                        when ('0', '0', '011010') => __encoding aarch64_integer_arithmetic_max_min_smin_reg // SMIN_32_dp_2src
                        when ('0', '0', '011011') => __encoding aarch64_integer_arithmetic_max_min_umin_reg // UMIN_32_dp_2src
                        when ('1', '0', '000000') => __encoding aarch64_integer_arithmetic_pointer_mcsubtracttaggedaddress // SUBP_64S_dp_2src
                        when ('1', '0', '000010') => __encoding aarch64_integer_arithmetic_div // UDIV_64_dp_2src
                        when ('1', '0', '000011') => __encoding aarch64_integer_arithmetic_div // SDIV_64_dp_2src
                        when ('1', '0', '000100') => __encoding aarch64_integer_tags_mcinsertrandomtag // IRG_64I_dp_2src
                        when ('1', '0', '000101') => __encoding aarch64_integer_tags_mcinserttagmask // GMI_64G_dp_2src
                        when ('1', '0', '001000') => __encoding aarch64_integer_shift_variable // LSLV_64_dp_2src
                        when ('1', '0', '001001') => __encoding aarch64_integer_shift_variable // LSRV_64_dp_2src
                        when ('1', '0', '001010') => __encoding aarch64_integer_shift_variable // ASRV_64_dp_2src
                        when ('1', '0', '001011') => __encoding aarch64_integer_shift_variable // RORV_64_dp_2src
                        when ('1', '0', '001100') => __encoding aarch64_integer_pac_pacga_dp_2src // PACGA_64P_dp_2src
                        when ('1', '0', '010xx0') => __UNALLOCATED
                        when ('1', '0', '010x0x') => __UNALLOCATED
                        when ('1', '0', '010011') => __encoding aarch64_integer_crc // CRC32X_64C_dp_2src
                        when ('1', '0', '010111') => __encoding aarch64_integer_crc // CRC32CX_64C_dp_2src
                        when ('1', '0', '011000') => __encoding aarch64_integer_arithmetic_max_min_smax_reg // SMAX_64_dp_2src
                        when ('1', '0', '011001') => __encoding aarch64_integer_arithmetic_max_min_umax_reg // UMAX_64_dp_2src
                        when ('1', '0', '011010') => __encoding aarch64_integer_arithmetic_max_min_smin_reg // SMIN_64_dp_2src
                        when ('1', '0', '011011') => __encoding aarch64_integer_arithmetic_max_min_umin_reg // UMIN_64_dp_2src
                        when ('1', '1', '000000') => __encoding aarch64_integer_arithmetic_pointer_mcsubtracttaggedaddresssetflags // SUBPS_64S_dp_2src
                when (_, '1', _, '1', _, '0110', _, _, _) => // dp_1src
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field opcode2 16 +: 5
                    __field opcode 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, opcode2, opcode, Rn) of
                        when (_, _, _, '1xxxxx', _) => __UNALLOCATED
                        when (_, _, 'xxx1x', _, _) => __UNALLOCATED
                        when (_, _, 'xx1xx', _, _) => __UNALLOCATED
                        when (_, _, 'x1xxx', _, _) => __UNALLOCATED
                        when (_, _, '1xxxx', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '001001', _) => __UNALLOCATED
                        when (_, '0', '00000', '00101x', _) => __UNALLOCATED
                        when (_, '0', '00000', '0011xx', _) => __UNALLOCATED
                        when (_, '0', '00000', '01xxxx', _) => __UNALLOCATED
                        when (_, '1', _, _, _) => __UNALLOCATED
                        when ('0', _, '00001', _, _) => __UNALLOCATED
                        when ('0', '0', '00000', '000000', _) => __encoding aarch64_integer_arithmetic_rbit // RBIT_32_dp_1src
                        when ('0', '0', '00000', '000001', _) => __encoding aarch64_integer_arithmetic_rev // REV16_32_dp_1src
                        when ('0', '0', '00000', '000010', _) => __encoding aarch64_integer_arithmetic_rev // REV_32_dp_1src
                        when ('0', '0', '00000', '000011', _) => __UNALLOCATED
                        when ('0', '0', '00000', '000100', _) => __encoding aarch64_integer_arithmetic_cnt // CLZ_32_dp_1src
                        when ('0', '0', '00000', '000101', _) => __encoding aarch64_integer_arithmetic_cnt // CLS_32_dp_1src
                        when ('0', '0', '00000', '000110', _) => __encoding aarch64_integer_arithmetic_unary_ctz // CTZ_32_dp_1src
                        when ('0', '0', '00000', '000111', _) => __encoding aarch64_integer_arithmetic_unary_cnt // CNT_32_dp_1src
                        when ('0', '0', '00000', '001000', _) => __encoding aarch64_integer_arithmetic_unary_abs // ABS_32_dp_1src
                        when ('1', '0', '00000', '000000', _) => __encoding aarch64_integer_arithmetic_rbit // RBIT_64_dp_1src
                        when ('1', '0', '00000', '000001', _) => __encoding aarch64_integer_arithmetic_rev // REV16_64_dp_1src
                        when ('1', '0', '00000', '000010', _) => __encoding aarch64_integer_arithmetic_rev // REV32_64_dp_1src
                        when ('1', '0', '00000', '000011', _) => __encoding aarch64_integer_arithmetic_rev // REV_64_dp_1src
                        when ('1', '0', '00000', '000100', _) => __encoding aarch64_integer_arithmetic_cnt // CLZ_64_dp_1src
                        when ('1', '0', '00000', '000101', _) => __encoding aarch64_integer_arithmetic_cnt // CLS_64_dp_1src
                        when ('1', '0', '00000', '000110', _) => __encoding aarch64_integer_arithmetic_unary_ctz // CTZ_64_dp_1src
                        when ('1', '0', '00000', '000111', _) => __encoding aarch64_integer_arithmetic_unary_cnt // CNT_64_dp_1src
                        when ('1', '0', '00000', '001000', _) => __encoding aarch64_integer_arithmetic_unary_abs // ABS_64_dp_1src
                        when ('1', '0', '00001', '000000', _) => __encoding aarch64_integer_pac_pacia_dp_1src // PACIA_64P_dp_1src
                        when ('1', '0', '00001', '000001', _) => __encoding aarch64_integer_pac_pacib_dp_1src // PACIB_64P_dp_1src
                        when ('1', '0', '00001', '000010', _) => __encoding aarch64_integer_pac_pacda_dp_1src // PACDA_64P_dp_1src
                        when ('1', '0', '00001', '000011', _) => __encoding aarch64_integer_pac_pacdb_dp_1src // PACDB_64P_dp_1src
                        when ('1', '0', '00001', '000100', _) => __encoding aarch64_integer_pac_autia_dp_1src // AUTIA_64P_dp_1src
                        when ('1', '0', '00001', '000101', _) => __encoding aarch64_integer_pac_autib_dp_1src // AUTIB_64P_dp_1src
                        when ('1', '0', '00001', '000110', _) => __encoding aarch64_integer_pac_autda_dp_1src // AUTDA_64P_dp_1src
                        when ('1', '0', '00001', '000111', _) => __encoding aarch64_integer_pac_autdb_dp_1src // AUTDB_64P_dp_1src
                        when ('1', '0', '00001', '001000', '11111') => __encoding aarch64_integer_pac_pacia_dp_1src // PACIZA_64Z_dp_1src
                        when ('1', '0', '00001', '001001', '11111') => __encoding aarch64_integer_pac_pacib_dp_1src // PACIZB_64Z_dp_1src
                        when ('1', '0', '00001', '001010', '11111') => __encoding aarch64_integer_pac_pacda_dp_1src // PACDZA_64Z_dp_1src
                        when ('1', '0', '00001', '001011', '11111') => __encoding aarch64_integer_pac_pacdb_dp_1src // PACDZB_64Z_dp_1src
                        when ('1', '0', '00001', '001100', '11111') => __encoding aarch64_integer_pac_autia_dp_1src // AUTIZA_64Z_dp_1src
                        when ('1', '0', '00001', '001101', '11111') => __encoding aarch64_integer_pac_autib_dp_1src // AUTIZB_64Z_dp_1src
                        when ('1', '0', '00001', '001110', '11111') => __encoding aarch64_integer_pac_autda_dp_1src // AUTDZA_64Z_dp_1src
                        when ('1', '0', '00001', '001111', '11111') => __encoding aarch64_integer_pac_autdb_dp_1src // AUTDZB_64Z_dp_1src
                        when ('1', '0', '00001', '010000', '11111') => __encoding aarch64_integer_pac_strip_dp_1src // XPACI_64Z_dp_1src
                        when ('1', '0', '00001', '010001', '11111') => __encoding aarch64_integer_pac_strip_dp_1src // XPACD_64Z_dp_1src
                        when ('1', '0', '00001', '01001x', _) => __UNALLOCATED
                        when ('1', '0', '00001', '0101xx', _) => __UNALLOCATED
                        when ('1', '0', '00001', '011xxx', _) => __UNALLOCATED
                when (_, _, _, '0', _, '0xxx', _, _, _) => // log_shift
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field shift 22 +: 2
                    __field N 21 +: 1
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N, imm6) of
                        when ('0', _, _, '1xxxxx') => __UNALLOCATED
                        when ('0', '00', '0', _) => __encoding aarch64_integer_logical_shiftedreg // AND_32_log_shift
                        when ('0', '00', '1', _) => __encoding aarch64_integer_logical_shiftedreg // BIC_32_log_shift
                        when ('0', '01', '0', _) => __encoding aarch64_integer_logical_shiftedreg // ORR_32_log_shift
                        when ('0', '01', '1', _) => __encoding aarch64_integer_logical_shiftedreg // ORN_32_log_shift
                        when ('0', '10', '0', _) => __encoding aarch64_integer_logical_shiftedreg // EOR_32_log_shift
                        when ('0', '10', '1', _) => __encoding aarch64_integer_logical_shiftedreg // EON_32_log_shift
                        when ('0', '11', '0', _) => __encoding aarch64_integer_logical_shiftedreg // ANDS_32_log_shift
                        when ('0', '11', '1', _) => __encoding aarch64_integer_logical_shiftedreg // BICS_32_log_shift
                        when ('1', '00', '0', _) => __encoding aarch64_integer_logical_shiftedreg // AND_64_log_shift
                        when ('1', '00', '1', _) => __encoding aarch64_integer_logical_shiftedreg // BIC_64_log_shift
                        when ('1', '01', '0', _) => __encoding aarch64_integer_logical_shiftedreg // ORR_64_log_shift
                        when ('1', '01', '1', _) => __encoding aarch64_integer_logical_shiftedreg // ORN_64_log_shift
                        when ('1', '10', '0', _) => __encoding aarch64_integer_logical_shiftedreg // EOR_64_log_shift
                        when ('1', '10', '1', _) => __encoding aarch64_integer_logical_shiftedreg // EON_64_log_shift
                        when ('1', '11', '0', _) => __encoding aarch64_integer_logical_shiftedreg // ANDS_64_log_shift
                        when ('1', '11', '1', _) => __encoding aarch64_integer_logical_shiftedreg // BICS_64_log_shift
                when (_, _, _, '0', _, '1xx0', _, _, _) => // addsub_shift
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field shift 22 +: 2
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, shift, imm6) of
                        when (_, _, _, '11', _) => __UNALLOCATED
                        when ('0', _, _, _, '1xxxxx') => __UNALLOCATED
                        when ('0', '0', '0', _, _) => __encoding aarch64_integer_arithmetic_add_sub_shiftedreg // ADD_32_addsub_shift
                        when ('0', '0', '1', _, _) => __encoding aarch64_integer_arithmetic_add_sub_shiftedreg // ADDS_32_addsub_shift
                        when ('0', '1', '0', _, _) => __encoding aarch64_integer_arithmetic_add_sub_shiftedreg // SUB_32_addsub_shift
                        when ('0', '1', '1', _, _) => __encoding aarch64_integer_arithmetic_add_sub_shiftedreg // SUBS_32_addsub_shift
                        when ('1', '0', '0', _, _) => __encoding aarch64_integer_arithmetic_add_sub_shiftedreg // ADD_64_addsub_shift
                        when ('1', '0', '1', _, _) => __encoding aarch64_integer_arithmetic_add_sub_shiftedreg // ADDS_64_addsub_shift
                        when ('1', '1', '0', _, _) => __encoding aarch64_integer_arithmetic_add_sub_shiftedreg // SUB_64_addsub_shift
                        when ('1', '1', '1', _, _) => __encoding aarch64_integer_arithmetic_add_sub_shiftedreg // SUBS_64_addsub_shift
                when (_, _, _, '0', _, '1xx1', _, _, _) => // addsub_ext
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opt 22 +: 2
                    __field Rm 16 +: 5
                    __field option 13 +: 3
                    __field imm3 10 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, opt, imm3) of
                        when (_, _, _, _, '1x1') => __UNALLOCATED
                        when (_, _, _, _, '11x') => __UNALLOCATED
                        when (_, _, _, 'x1', _) => __UNALLOCATED
                        when (_, _, _, '1x', _) => __UNALLOCATED
                        when ('0', '0', '0', '00', _) => __encoding aarch64_integer_arithmetic_add_sub_extendedreg // ADD_32_addsub_ext
                        when ('0', '0', '1', '00', _) => __encoding aarch64_integer_arithmetic_add_sub_extendedreg // ADDS_32S_addsub_ext
                        when ('0', '1', '0', '00', _) => __encoding aarch64_integer_arithmetic_add_sub_extendedreg // SUB_32_addsub_ext
                        when ('0', '1', '1', '00', _) => __encoding aarch64_integer_arithmetic_add_sub_extendedreg // SUBS_32S_addsub_ext
                        when ('1', '0', '0', '00', _) => __encoding aarch64_integer_arithmetic_add_sub_extendedreg // ADD_64_addsub_ext
                        when ('1', '0', '1', '00', _) => __encoding aarch64_integer_arithmetic_add_sub_extendedreg // ADDS_64S_addsub_ext
                        when ('1', '1', '0', '00', _) => __encoding aarch64_integer_arithmetic_add_sub_extendedreg // SUB_64_addsub_ext
                        when ('1', '1', '1', '00', _) => __encoding aarch64_integer_arithmetic_add_sub_extendedreg // SUBS_64S_addsub_ext
                when (_, _, _, '1', _, '0000', _, '000000', _) => // addsub_carry
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', '0', '0') => __encoding aarch64_integer_arithmetic_add_sub_carry // ADC_32_addsub_carry
                        when ('0', '0', '1') => __encoding aarch64_integer_arithmetic_add_sub_carry // ADCS_32_addsub_carry
                        when ('0', '1', '0') => __encoding aarch64_integer_arithmetic_add_sub_carry // SBC_32_addsub_carry
                        when ('0', '1', '1') => __encoding aarch64_integer_arithmetic_add_sub_carry // SBCS_32_addsub_carry
                        when ('1', '0', '0') => __encoding aarch64_integer_arithmetic_add_sub_carry // ADC_64_addsub_carry
                        when ('1', '0', '1') => __encoding aarch64_integer_arithmetic_add_sub_carry // ADCS_64_addsub_carry
                        when ('1', '1', '0') => __encoding aarch64_integer_arithmetic_add_sub_carry // SBC_64_addsub_carry
                        when ('1', '1', '1') => __encoding aarch64_integer_arithmetic_add_sub_carry // SBCS_64_addsub_carry
                when (_, _, _, '1', _, '0000', _, 'x00001', _) => // rmif
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field imm6 15 +: 6
                    __field Rn 5 +: 5
                    __field o2 4 +: 1
                    __field mask 0 +: 4
                    case (sf, op, S, o2) of
                        when ('0', _, _, _) => __UNALLOCATED
                        when ('1', '0', '0', _) => __UNALLOCATED
                        when ('1', '0', '1', '0') => __encoding aarch64_integer_flags_rmif // RMIF_only_rmif
                        when ('1', '0', '1', '1') => __UNALLOCATED
                        when ('1', '1', _, _) => __UNALLOCATED
                when (_, _, _, '1', _, '0000', _, 'xx0010', _) => // setf
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opcode2 15 +: 6
                    __field sz 14 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field mask 0 +: 4
                    case (sf, op, S, opcode2, sz, o3, mask) of
                        when ('0', '0', '0', _, _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', !'000000', _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '0', !'1101') => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '1', _) => __UNALLOCATED
                        when ('0', '0', '1', '000000', '0', '0', '1101') => __encoding aarch64_integer_flags_setf // SETF8_only_setf
                        when ('0', '0', '1', '000000', '1', '0', '1101') => __encoding aarch64_integer_flags_setf // SETF16_only_setf
                        when ('0', '1', _, _, _, _, _) => __UNALLOCATED
                        when ('1', _, _, _, _, _, _) => __UNALLOCATED
                when (_, _, _, '1', _, '0010', _, 'xxxx0x', _) => // condcmp_reg
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field o2 10 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field nzcv 0 +: 4
                    case (sf, op, S, o2, o3) of
                        when (_, _, _, _, '1') => __UNALLOCATED
                        when (_, _, _, '1', _) => __UNALLOCATED
                        when (_, _, '0', _, _) => __UNALLOCATED
                        when ('0', '0', '1', '0', '0') => __encoding aarch64_integer_conditional_compare_register // CCMN_32_condcmp_reg
                        when ('0', '1', '1', '0', '0') => __encoding aarch64_integer_conditional_compare_register // CCMP_32_condcmp_reg
                        when ('1', '0', '1', '0', '0') => __encoding aarch64_integer_conditional_compare_register // CCMN_64_condcmp_reg
                        when ('1', '1', '1', '0', '0') => __encoding aarch64_integer_conditional_compare_register // CCMP_64_condcmp_reg
                when (_, _, _, '1', _, '0010', _, 'xxxx1x', _) => // condcmp_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field imm5 16 +: 5
                    __field cond 12 +: 4
                    __field o2 10 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field nzcv 0 +: 4
                    case (sf, op, S, o2, o3) of
                        when (_, _, _, _, '1') => __UNALLOCATED
                        when (_, _, _, '1', _) => __UNALLOCATED
                        when (_, _, '0', _, _) => __UNALLOCATED
                        when ('0', '0', '1', '0', '0') => __encoding aarch64_integer_conditional_compare_immediate // CCMN_32_condcmp_imm
                        when ('0', '1', '1', '0', '0') => __encoding aarch64_integer_conditional_compare_immediate // CCMP_32_condcmp_imm
                        when ('1', '0', '1', '0', '0') => __encoding aarch64_integer_conditional_compare_immediate // CCMN_64_condcmp_imm
                        when ('1', '1', '1', '0', '0') => __encoding aarch64_integer_conditional_compare_immediate // CCMP_64_condcmp_imm
                when (_, _, _, '1', _, '0100', _, _, _) => // condsel
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field op2 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, op2) of
                        when (_, _, _, '1x') => __UNALLOCATED
                        when (_, _, '1', _) => __UNALLOCATED
                        when ('0', '0', '0', '00') => __encoding aarch64_integer_conditional_select // CSEL_32_condsel
                        when ('0', '0', '0', '01') => __encoding aarch64_integer_conditional_select // CSINC_32_condsel
                        when ('0', '1', '0', '00') => __encoding aarch64_integer_conditional_select // CSINV_32_condsel
                        when ('0', '1', '0', '01') => __encoding aarch64_integer_conditional_select // CSNEG_32_condsel
                        when ('1', '0', '0', '00') => __encoding aarch64_integer_conditional_select // CSEL_64_condsel
                        when ('1', '0', '0', '01') => __encoding aarch64_integer_conditional_select // CSINC_64_condsel
                        when ('1', '1', '0', '00') => __encoding aarch64_integer_conditional_select // CSINV_64_condsel
                        when ('1', '1', '0', '01') => __encoding aarch64_integer_conditional_select // CSNEG_64_condsel
                when (_, _, _, '1', _, '1xxx', _, _, _) => // dp_3src
                    __field sf 31 +: 1
                    __field op54 29 +: 2
                    __field op31 21 +: 3
                    __field Rm 16 +: 5
                    __field o0 15 +: 1
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op54, op31, o0) of
                        when (_, '00', '010', '1') => __UNALLOCATED
                        when (_, '00', '011', _) => __UNALLOCATED
                        when (_, '00', '100', _) => __UNALLOCATED
                        when (_, '00', '110', '1') => __UNALLOCATED
                        when (_, '00', '111', _) => __UNALLOCATED
                        when (_, '01', _, _) => __UNALLOCATED
                        when (_, '1x', _, _) => __UNALLOCATED
                        when ('0', '00', '000', '0') => __encoding aarch64_integer_arithmetic_mul_uniform_add_sub // MADD_32A_dp_3src
                        when ('0', '00', '000', '1') => __encoding aarch64_integer_arithmetic_mul_uniform_add_sub // MSUB_32A_dp_3src
                        when ('0', '00', '001', '0') => __UNALLOCATED
                        when ('0', '00', '001', '1') => __UNALLOCATED
                        when ('0', '00', '010', '0') => __UNALLOCATED
                        when ('0', '00', '101', '0') => __UNALLOCATED
                        when ('0', '00', '101', '1') => __UNALLOCATED
                        when ('0', '00', '110', '0') => __UNALLOCATED
                        when ('1', '00', '000', '0') => __encoding aarch64_integer_arithmetic_mul_uniform_add_sub // MADD_64A_dp_3src
                        when ('1', '00', '000', '1') => __encoding aarch64_integer_arithmetic_mul_uniform_add_sub // MSUB_64A_dp_3src
                        when ('1', '00', '001', '0') => __encoding aarch64_integer_arithmetic_mul_widening_32_64 // SMADDL_64WA_dp_3src
                        when ('1', '00', '001', '1') => __encoding aarch64_integer_arithmetic_mul_widening_32_64 // SMSUBL_64WA_dp_3src
                        when ('1', '00', '010', '0') => __encoding aarch64_integer_arithmetic_mul_widening_64_128hi // SMULH_64_dp_3src
                        when ('1', '00', '101', '0') => __encoding aarch64_integer_arithmetic_mul_widening_32_64 // UMADDL_64WA_dp_3src
                        when ('1', '00', '101', '1') => __encoding aarch64_integer_arithmetic_mul_widening_32_64 // UMSUBL_64WA_dp_3src
                        when ('1', '00', '110', '0') => __encoding aarch64_integer_arithmetic_mul_widening_64_128hi // UMULH_64_dp_3src
        when (_, _, 'x111', _) =>
            // simd-dp
            case (28 +: 4, 25 +: 3, 23 +: 2, 19 +: 4, 10 +: 9, 0 +: 10) of
                when ('0000', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0010', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0100', _, '0x', 'x101', '00xxxxx10', _) => // cryptoaes
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when (_, 'x1xxx') => __UNALLOCATED
                        when (_, '000xx') => __UNALLOCATED
                        when (_, '1xxxx') => __UNALLOCATED
                        when ('x1', _) => __UNALLOCATED
                        when ('00', '00100') => __encoding aarch64_vector_crypto_aes_round // AESE_B_cryptoaes
                        when ('00', '00101') => __encoding aarch64_vector_crypto_aes_round // AESD_B_cryptoaes
                        when ('00', '00110') => __encoding aarch64_vector_crypto_aes_mix // AESMC_B_cryptoaes
                        when ('00', '00111') => __encoding aarch64_vector_crypto_aes_mix // AESIMC_B_cryptoaes
                        when ('1x', _) => __UNALLOCATED
                when ('0101', _, '0x', 'x0xx', 'xxx0xxx00', _) => // cryptosha3
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when (_, '111') => __UNALLOCATED
                        when ('x1', _) => __UNALLOCATED
                        when ('00', '000') => __encoding aarch64_vector_crypto_sha3op_sha1_hash_choose // SHA1C_QSV_cryptosha3
                        when ('00', '001') => __encoding aarch64_vector_crypto_sha3op_sha1_hash_parity // SHA1P_QSV_cryptosha3
                        when ('00', '010') => __encoding aarch64_vector_crypto_sha3op_sha1_hash_majority // SHA1M_QSV_cryptosha3
                        when ('00', '011') => __encoding aarch64_vector_crypto_sha3op_sha1_sched0 // SHA1SU0_VVV_cryptosha3
                        when ('00', '100') => __encoding aarch64_vector_crypto_sha3op_sha256_hash // SHA256H_QQV_cryptosha3
                        when ('00', '101') => __encoding aarch64_vector_crypto_sha3op_sha256_hash // SHA256H2_QQV_cryptosha3
                        when ('00', '110') => __encoding aarch64_vector_crypto_sha3op_sha256_sched1 // SHA256SU1_VVV_cryptosha3
                        when ('1x', _) => __UNALLOCATED
                when ('0101', _, '0x', 'x0xx', 'xxx0xxx10', _) => __UNPREDICTABLE
                when ('0101', _, '0x', 'x101', '00xxxxx10', _) => // cryptosha2
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when (_, 'xx1xx') => __UNALLOCATED
                        when (_, 'x1xxx') => __UNALLOCATED
                        when (_, '1xxxx') => __UNALLOCATED
                        when ('x1', _) => __UNALLOCATED
                        when ('00', '00000') => __encoding aarch64_vector_crypto_sha2op_sha1_hash // SHA1H_SS_cryptosha2
                        when ('00', '00001') => __encoding aarch64_vector_crypto_sha2op_sha1_sched1 // SHA1SU1_VV_cryptosha2
                        when ('00', '00010') => __encoding aarch64_vector_crypto_sha2op_sha256_sched0 // SHA256SU0_VV_cryptosha2
                        when ('00', '00011') => __UNALLOCATED
                        when ('1x', _) => __UNALLOCATED
                when ('0110', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0111', _, '0x', 'x0xx', 'xxx0xxxx0', _) => __UNPREDICTABLE
                when ('0111', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '00', '00xx', 'xxx0xxxx1', _) => // asisdone
                    __field op 29 +: 1
                    __field imm5 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (op, imm4) of
                        when ('0', 'xxx1') => __UNALLOCATED
                        when ('0', 'xx1x') => __UNALLOCATED
                        when ('0', 'x1xx') => __UNALLOCATED
                        when ('0', '0000') => __encoding aarch64_vector_transfer_vector_cpy_dup_sisd // DUP_asisdone_only
                        when ('0', '1xxx') => __UNALLOCATED
                        when ('1', _) => __UNALLOCATED
                when ('01x1', _, '01', '00xx', 'xxx0xxxx1', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '0111', '00xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '10xx', 'xxx00xxx1', _) => // asisdsamefp16
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field Rm 16 +: 5
                    __field opcode 11 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, '110') => __UNALLOCATED
                        when (_, '1', '011') => __UNALLOCATED
                        when ('0', '0', '011') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp16_extended_sisd // FMULX_asisdsamefp16_only
                        when ('0', '0', '100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_sisd // FCMEQ_asisdsamefp16_only
                        when ('0', '0', '101') => __UNALLOCATED
                        when ('0', '0', '111') => __encoding aarch64_vector_arithmetic_binary_uniform_recps_fp16_sisd // FRECPS_asisdsamefp16_only
                        when ('0', '1', '100') => __UNALLOCATED
                        when ('0', '1', '101') => __UNALLOCATED
                        when ('0', '1', '111') => __encoding aarch64_vector_arithmetic_binary_uniform_rsqrts_fp16_sisd // FRSQRTS_asisdsamefp16_only
                        when ('1', '0', '011') => __UNALLOCATED
                        when ('1', '0', '100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_sisd // FCMGE_asisdsamefp16_only
                        when ('1', '0', '101') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_sisd // FACGE_asisdsamefp16_only
                        when ('1', '0', '111') => __UNALLOCATED
                        when ('1', '1', '010') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_fp16_sisd // FABD_asisdsamefp16_only
                        when ('1', '1', '100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_sisd // FCMGT_asisdsamefp16_only
                        when ('1', '1', '101') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_sisd // FACGT_asisdsamefp16_only
                        when ('1', '1', '111') => __UNALLOCATED
                when ('01x1', _, '0x', '10xx', 'xxx01xxx1', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '1111', '00xxxxx10', _) => // asisdmiscfp16
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, '00xxx') => __UNALLOCATED
                        when (_, _, '010xx') => __UNALLOCATED
                        when (_, _, '10xxx') => __UNALLOCATED
                        when (_, _, '1100x') => __UNALLOCATED
                        when (_, _, '11110') => __UNALLOCATED
                        when (_, '0', '011xx') => __UNALLOCATED
                        when (_, '0', '11111') => __UNALLOCATED
                        when (_, '1', '01111') => __UNALLOCATED
                        when (_, '1', '11100') => __UNALLOCATED
                        when ('0', '0', '11010') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_sisd // FCVTNS_asisdmiscfp16_R
                        when ('0', '0', '11011') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_sisd // FCVTMS_asisdmiscfp16_R
                        when ('0', '0', '11100') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_tieaway_sisd // FCVTAS_asisdmiscfp16_R
                        when ('0', '0', '11101') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_int_sisd // SCVTF_asisdmiscfp16_R
                        when ('0', '1', '01100') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_bulk_sisd // FCMGT_asisdmiscfp16_FZ
                        when ('0', '1', '01101') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_bulk_sisd // FCMEQ_asisdmiscfp16_FZ
                        when ('0', '1', '01110') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_lessthan_sisd // FCMLT_asisdmiscfp16_FZ
                        when ('0', '1', '11010') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_sisd // FCVTPS_asisdmiscfp16_R
                        when ('0', '1', '11011') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_sisd // FCVTZS_asisdmiscfp16_R
                        when ('0', '1', '11101') => __encoding aarch64_vector_arithmetic_unary_special_recip_fp16_sisd // FRECPE_asisdmiscfp16_R
                        when ('0', '1', '11111') => __encoding aarch64_vector_arithmetic_unary_special_frecpx_fp16 // FRECPX_asisdmiscfp16_R
                        when ('1', '0', '11010') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_sisd // FCVTNU_asisdmiscfp16_R
                        when ('1', '0', '11011') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_sisd // FCVTMU_asisdmiscfp16_R
                        when ('1', '0', '11100') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_tieaway_sisd // FCVTAU_asisdmiscfp16_R
                        when ('1', '0', '11101') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_int_sisd // UCVTF_asisdmiscfp16_R
                        when ('1', '1', '01100') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_bulk_sisd // FCMGE_asisdmiscfp16_FZ
                        when ('1', '1', '01101') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_bulk_sisd // FCMLE_asisdmiscfp16_FZ
                        when ('1', '1', '01110') => __UNALLOCATED
                        when ('1', '1', '11010') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_sisd // FCVTPU_asisdmiscfp16_R
                        when ('1', '1', '11011') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_sisd // FCVTZU_asisdmiscfp16_R
                        when ('1', '1', '11101') => __encoding aarch64_vector_arithmetic_unary_special_sqrt_est_fp16_sisd // FRSQRTE_asisdmiscfp16_R
                        when ('1', '1', '11111') => __UNALLOCATED
                when ('01x1', _, '0x', 'x0xx', 'xxx1xxxx0', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', 'x0xx', 'xxx1xxxx1', _) => // asisdsame2
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when (_, '001x') => __UNALLOCATED
                        when (_, '01xx') => __UNALLOCATED
                        when (_, '1xxx') => __UNALLOCATED
                        when ('0', '0000') => __UNALLOCATED
                        when ('0', '0001') => __UNALLOCATED
                        when ('1', '0000') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd // SQRDMLAH_asisdsame2_only
                        when ('1', '0001') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_doubling_accum_sisd // SQRDMLSH_asisdsame2_only
                when ('01x1', _, '0x', 'x100', '00xxxxx10', _) => // asisdmisc
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '0000x') => __UNALLOCATED
                        when (_, _, '00010') => __UNALLOCATED
                        when (_, _, '0010x') => __UNALLOCATED
                        when (_, _, '00110') => __UNALLOCATED
                        when (_, _, '01111') => __UNALLOCATED
                        when (_, _, '1000x') => __UNALLOCATED
                        when (_, _, '10011') => __UNALLOCATED
                        when (_, _, '10101') => __UNALLOCATED
                        when (_, _, '10111') => __UNALLOCATED
                        when (_, _, '1100x') => __UNALLOCATED
                        when (_, _, '11110') => __UNALLOCATED
                        when (_, '0x', '011xx') => __UNALLOCATED
                        when (_, '0x', '11111') => __UNALLOCATED
                        when (_, '1x', '10110') => __UNALLOCATED
                        when (_, '1x', '11100') => __UNALLOCATED
                        when ('0', _, '00011') => __encoding aarch64_vector_arithmetic_unary_add_saturating_sisd // SUQADD_asisdmisc_R
                        when ('0', _, '00111') => __encoding aarch64_vector_arithmetic_unary_diff_neg_sat_sisd // SQABS_asisdmisc_R
                        when ('0', _, '01000') => __encoding aarch64_vector_arithmetic_unary_cmp_int_bulk_sisd // CMGT_asisdmisc_Z
                        when ('0', _, '01001') => __encoding aarch64_vector_arithmetic_unary_cmp_int_bulk_sisd // CMEQ_asisdmisc_Z
                        when ('0', _, '01010') => __encoding aarch64_vector_arithmetic_unary_cmp_int_lessthan_sisd // CMLT_asisdmisc_Z
                        when ('0', _, '01011') => __encoding aarch64_vector_arithmetic_unary_diff_neg_int_sisd // ABS_asisdmisc_R
                        when ('0', _, '10010') => __UNALLOCATED
                        when ('0', _, '10100') => __encoding aarch64_vector_arithmetic_unary_extract_sat_sisd // SQXTN_asisdmisc_N
                        when ('0', '0x', '10110') => __UNALLOCATED
                        when ('0', '0x', '11010') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_sisd // FCVTNS_asisdmisc_R
                        when ('0', '0x', '11011') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_sisd // FCVTMS_asisdmisc_R
                        when ('0', '0x', '11100') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_tieaway_sisd // FCVTAS_asisdmisc_R
                        when ('0', '0x', '11101') => __encoding aarch64_vector_arithmetic_unary_float_conv_int_sisd // SCVTF_asisdmisc_R
                        when ('0', '1x', '01100') => __encoding aarch64_vector_arithmetic_unary_cmp_float_bulk_sisd // FCMGT_asisdmisc_FZ
                        when ('0', '1x', '01101') => __encoding aarch64_vector_arithmetic_unary_cmp_float_bulk_sisd // FCMEQ_asisdmisc_FZ
                        when ('0', '1x', '01110') => __encoding aarch64_vector_arithmetic_unary_cmp_float_lessthan_sisd // FCMLT_asisdmisc_FZ
                        when ('0', '1x', '11010') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_sisd // FCVTPS_asisdmisc_R
                        when ('0', '1x', '11011') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_sisd // FCVTZS_asisdmisc_R
                        when ('0', '1x', '11101') => __encoding aarch64_vector_arithmetic_unary_special_recip_float_sisd // FRECPE_asisdmisc_R
                        when ('0', '1x', '11111') => __encoding aarch64_vector_arithmetic_unary_special_frecpx // FRECPX_asisdmisc_R
                        when ('1', _, '00011') => __encoding aarch64_vector_arithmetic_unary_add_saturating_sisd // USQADD_asisdmisc_R
                        when ('1', _, '00111') => __encoding aarch64_vector_arithmetic_unary_diff_neg_sat_sisd // SQNEG_asisdmisc_R
                        when ('1', _, '01000') => __encoding aarch64_vector_arithmetic_unary_cmp_int_bulk_sisd // CMGE_asisdmisc_Z
                        when ('1', _, '01001') => __encoding aarch64_vector_arithmetic_unary_cmp_int_bulk_sisd // CMLE_asisdmisc_Z
                        when ('1', _, '01010') => __UNALLOCATED
                        when ('1', _, '01011') => __encoding aarch64_vector_arithmetic_unary_diff_neg_int_sisd // NEG_asisdmisc_R
                        when ('1', _, '10010') => __encoding aarch64_vector_arithmetic_unary_extract_sqxtun_sisd // SQXTUN_asisdmisc_N
                        when ('1', _, '10100') => __encoding aarch64_vector_arithmetic_unary_extract_sat_sisd // UQXTN_asisdmisc_N
                        when ('1', '0x', '10110') => __encoding aarch64_vector_arithmetic_unary_float_xtn_sisd // FCVTXN_asisdmisc_N
                        when ('1', '0x', '11010') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_sisd // FCVTNU_asisdmisc_R
                        when ('1', '0x', '11011') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_sisd // FCVTMU_asisdmisc_R
                        when ('1', '0x', '11100') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_tieaway_sisd // FCVTAU_asisdmisc_R
                        when ('1', '0x', '11101') => __encoding aarch64_vector_arithmetic_unary_float_conv_int_sisd // UCVTF_asisdmisc_R
                        when ('1', '1x', '01100') => __encoding aarch64_vector_arithmetic_unary_cmp_float_bulk_sisd // FCMGE_asisdmisc_FZ
                        when ('1', '1x', '01101') => __encoding aarch64_vector_arithmetic_unary_cmp_float_bulk_sisd // FCMLE_asisdmisc_FZ
                        when ('1', '1x', '01110') => __UNALLOCATED
                        when ('1', '1x', '11010') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_sisd // FCVTPU_asisdmisc_R
                        when ('1', '1x', '11011') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_sisd // FCVTZU_asisdmisc_R
                        when ('1', '1x', '11101') => __encoding aarch64_vector_arithmetic_unary_special_sqrt_est_float_sisd // FRSQRTE_asisdmisc_R
                        when ('1', '1x', '11111') => __UNALLOCATED
                when ('01x1', _, '0x', 'x110', '00xxxxx10', _) => // asisdpair
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '00xxx') => __UNALLOCATED
                        when (_, _, '010xx') => __UNALLOCATED
                        when (_, _, '01110') => __UNALLOCATED
                        when (_, _, '10xxx') => __UNALLOCATED
                        when (_, _, '1100x') => __UNALLOCATED
                        when (_, _, '11010') => __UNALLOCATED
                        when (_, _, '111xx') => __UNALLOCATED
                        when (_, '1x', '01101') => __UNALLOCATED
                        when ('0', _, '11011') => __encoding aarch64_vector_reduce_add_sisd // ADDP_asisdpair_only
                        when ('0', '0x', '01100') => __encoding aarch64_vector_reduce_fp16_maxnm_sisd // FMAXNMP_asisdpair_only_H
                        when ('0', '0x', '01101') => __encoding aarch64_vector_reduce_fp16_add_sisd // FADDP_asisdpair_only_H
                        when ('0', '0x', '01111') => __encoding aarch64_vector_reduce_fp16_max_sisd // FMAXP_asisdpair_only_H
                        when ('0', '1x', '01100') => __encoding aarch64_vector_reduce_fp16_maxnm_sisd // FMINNMP_asisdpair_only_H
                        when ('0', '1x', '01111') => __encoding aarch64_vector_reduce_fp16_max_sisd // FMINP_asisdpair_only_H
                        when ('1', _, '11011') => __UNALLOCATED
                        when ('1', '0x', '01100') => __encoding aarch64_vector_reduce_fp_maxnm_sisd // FMAXNMP_asisdpair_only_SD
                        when ('1', '0x', '01101') => __encoding aarch64_vector_reduce_fp_add_sisd // FADDP_asisdpair_only_SD
                        when ('1', '0x', '01111') => __encoding aarch64_vector_reduce_fp_max_sisd // FMAXP_asisdpair_only_SD
                        when ('1', '1x', '01100') => __encoding aarch64_vector_reduce_fp_maxnm_sisd // FMINNMP_asisdpair_only_SD
                        when ('1', '1x', '01111') => __encoding aarch64_vector_reduce_fp_max_sisd // FMINP_asisdpair_only_SD
                when ('01x1', _, '0x', 'x1xx', '1xxxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', 'x1xx', 'x1xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', 'x1xx', 'xxxxxxx00', _) => // asisddiff
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when (_, '00xx') => __UNALLOCATED
                        when (_, '01xx') => __UNALLOCATED
                        when (_, '1000') => __UNALLOCATED
                        when (_, '1010') => __UNALLOCATED
                        when (_, '1100') => __UNALLOCATED
                        when (_, '111x') => __UNALLOCATED
                        when ('0', '1001') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_dmacc_sisd // SQDMLAL_asisddiff_only
                        when ('0', '1011') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_dmacc_sisd // SQDMLSL_asisddiff_only
                        when ('0', '1101') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_double_sisd // SQDMULL_asisddiff_only
                        when ('1', '1001') => __UNALLOCATED
                        when ('1', '1011') => __UNALLOCATED
                        when ('1', '1101') => __UNALLOCATED
                when ('01x1', _, '0x', 'x1xx', 'xxxxxxxx1', _) => // asisdsame
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '00000') => __UNALLOCATED
                        when (_, _, '0001x') => __UNALLOCATED
                        when (_, _, '00100') => __UNALLOCATED
                        when (_, _, '011xx') => __UNALLOCATED
                        when (_, _, '1001x') => __UNALLOCATED
                        when (_, '1x', '11011') => __UNALLOCATED
                        when ('0', _, '00001') => __encoding aarch64_vector_arithmetic_binary_uniform_add_saturating_sisd // SQADD_asisdsame_only
                        when ('0', _, '00101') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_saturating_sisd // SQSUB_asisdsame_only
                        when ('0', _, '00110') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_int_sisd // CMGT_asisdsame_only
                        when ('0', _, '00111') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_int_sisd // CMGE_asisdsame_only
                        when ('0', _, '01000') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_sisd // SSHL_asisdsame_only
                        when ('0', _, '01001') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_sisd // SQSHL_asisdsame_only
                        when ('0', _, '01010') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_sisd // SRSHL_asisdsame_only
                        when ('0', _, '01011') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_sisd // SQRSHL_asisdsame_only
                        when ('0', _, '10000') => __encoding aarch64_vector_arithmetic_binary_uniform_add_wrapping_single_sisd // ADD_asisdsame_only
                        when ('0', _, '10001') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_bitwise_sisd // CMTST_asisdsame_only
                        when ('0', _, '10100') => __UNALLOCATED
                        when ('0', _, '10101') => __UNALLOCATED
                        when ('0', _, '10110') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_doubling_sisd // SQDMULH_asisdsame_only
                        when ('0', _, '10111') => __UNALLOCATED
                        when ('0', '0x', '11000') => __UNALLOCATED
                        when ('0', '0x', '11001') => __UNALLOCATED
                        when ('0', '0x', '11010') => __UNALLOCATED
                        when ('0', '0x', '11011') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_extended_sisd // FMULX_asisdsame_only
                        when ('0', '0x', '11100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_sisd // FCMEQ_asisdsame_only
                        when ('0', '0x', '11101') => __UNALLOCATED
                        when ('0', '0x', '11110') => __UNALLOCATED
                        when ('0', '0x', '11111') => __encoding aarch64_vector_arithmetic_binary_uniform_recps_sisd // FRECPS_asisdsame_only
                        when ('0', '1x', '11000') => __UNALLOCATED
                        when ('0', '1x', '11001') => __UNALLOCATED
                        when ('0', '1x', '11010') => __UNALLOCATED
                        when ('0', '1x', '11100') => __UNALLOCATED
                        when ('0', '1x', '11101') => __UNALLOCATED
                        when ('0', '1x', '11110') => __UNALLOCATED
                        when ('0', '1x', '11111') => __encoding aarch64_vector_arithmetic_binary_uniform_rsqrts_sisd // FRSQRTS_asisdsame_only
                        when ('1', _, '00001') => __encoding aarch64_vector_arithmetic_binary_uniform_add_saturating_sisd // UQADD_asisdsame_only
                        when ('1', _, '00101') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_saturating_sisd // UQSUB_asisdsame_only
                        when ('1', _, '00110') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_int_sisd // CMHI_asisdsame_only
                        when ('1', _, '00111') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_int_sisd // CMHS_asisdsame_only
                        when ('1', _, '01000') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_sisd // USHL_asisdsame_only
                        when ('1', _, '01001') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_sisd // UQSHL_asisdsame_only
                        when ('1', _, '01010') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_sisd // URSHL_asisdsame_only
                        when ('1', _, '01011') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_sisd // UQRSHL_asisdsame_only
                        when ('1', _, '10000') => __encoding aarch64_vector_arithmetic_binary_uniform_add_wrapping_single_sisd // SUB_asisdsame_only
                        when ('1', _, '10001') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_bitwise_sisd // CMEQ_asisdsame_only
                        when ('1', _, '10100') => __UNALLOCATED
                        when ('1', _, '10101') => __UNALLOCATED
                        when ('1', _, '10110') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_doubling_sisd // SQRDMULH_asisdsame_only
                        when ('1', _, '10111') => __UNALLOCATED
                        when ('1', '0x', '11000') => __UNALLOCATED
                        when ('1', '0x', '11001') => __UNALLOCATED
                        when ('1', '0x', '11010') => __UNALLOCATED
                        when ('1', '0x', '11011') => __UNALLOCATED
                        when ('1', '0x', '11100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_sisd // FCMGE_asisdsame_only
                        when ('1', '0x', '11101') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_sisd // FACGE_asisdsame_only
                        when ('1', '0x', '11110') => __UNALLOCATED
                        when ('1', '0x', '11111') => __UNALLOCATED
                        when ('1', '1x', '11000') => __UNALLOCATED
                        when ('1', '1x', '11001') => __UNALLOCATED
                        when ('1', '1x', '11010') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_fp_sisd // FABD_asisdsame_only
                        when ('1', '1x', '11100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_sisd // FCMGT_asisdsame_only
                        when ('1', '1x', '11101') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_sisd // FACGT_asisdsame_only
                        when ('1', '1x', '11110') => __UNALLOCATED
                        when ('1', '1x', '11111') => __UNALLOCATED
                when ('01x1', _, '10', _, 'xxxxxxxx1', _) => // asisdshf
                    __field U 29 +: 1
                    __field immh 19 +: 4
                    __field immb 16 +: 3
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, immh, opcode) of
                        when (_, !'0000', '00001') => __UNALLOCATED
                        when (_, !'0000', '00011') => __UNALLOCATED
                        when (_, !'0000', '00101') => __UNALLOCATED
                        when (_, !'0000', '00111') => __UNALLOCATED
                        when (_, !'0000', '01001') => __UNALLOCATED
                        when (_, !'0000', '01011') => __UNALLOCATED
                        when (_, !'0000', '01101') => __UNALLOCATED
                        when (_, !'0000', '01111') => __UNALLOCATED
                        when (_, !'0000', '101xx') => __UNALLOCATED
                        when (_, !'0000', '110xx') => __UNALLOCATED
                        when (_, !'0000', '11101') => __UNALLOCATED
                        when (_, !'0000', '11110') => __UNALLOCATED
                        when (_, '0000', _) => __UNALLOCATED
                        when ('0', !'0000', '00000') => __encoding aarch64_vector_shift_right_sisd // SSHR_asisdshf_R
                        when ('0', !'0000', '00010') => __encoding aarch64_vector_shift_right_sisd // SSRA_asisdshf_R
                        when ('0', !'0000', '00100') => __encoding aarch64_vector_shift_right_sisd // SRSHR_asisdshf_R
                        when ('0', !'0000', '00110') => __encoding aarch64_vector_shift_right_sisd // SRSRA_asisdshf_R
                        when ('0', !'0000', '01000') => __UNALLOCATED
                        when ('0', !'0000', '01010') => __encoding aarch64_vector_shift_left_sisd // SHL_asisdshf_R
                        when ('0', !'0000', '01100') => __UNALLOCATED
                        when ('0', !'0000', '01110') => __encoding aarch64_vector_shift_left_sat_sisd // SQSHL_asisdshf_R
                        when ('0', !'0000', '10000') => __UNALLOCATED
                        when ('0', !'0000', '10001') => __UNALLOCATED
                        when ('0', !'0000', '10010') => __encoding aarch64_vector_shift_right_narrow_uniform_sisd // SQSHRN_asisdshf_N
                        when ('0', !'0000', '10011') => __encoding aarch64_vector_shift_right_narrow_uniform_sisd // SQRSHRN_asisdshf_N
                        when ('0', !'0000', '11100') => __encoding aarch64_vector_shift_conv_int_sisd // SCVTF_asisdshf_C
                        when ('0', !'0000', '11111') => __encoding aarch64_vector_shift_conv_float_sisd // FCVTZS_asisdshf_C
                        when ('1', !'0000', '00000') => __encoding aarch64_vector_shift_right_sisd // USHR_asisdshf_R
                        when ('1', !'0000', '00010') => __encoding aarch64_vector_shift_right_sisd // USRA_asisdshf_R
                        when ('1', !'0000', '00100') => __encoding aarch64_vector_shift_right_sisd // URSHR_asisdshf_R
                        when ('1', !'0000', '00110') => __encoding aarch64_vector_shift_right_sisd // URSRA_asisdshf_R
                        when ('1', !'0000', '01000') => __encoding aarch64_vector_shift_right_insert_sisd // SRI_asisdshf_R
                        when ('1', !'0000', '01010') => __encoding aarch64_vector_shift_left_insert_sisd // SLI_asisdshf_R
                        when ('1', !'0000', '01100') => __encoding aarch64_vector_shift_left_sat_sisd // SQSHLU_asisdshf_R
                        when ('1', !'0000', '01110') => __encoding aarch64_vector_shift_left_sat_sisd // UQSHL_asisdshf_R
                        when ('1', !'0000', '10000') => __encoding aarch64_vector_shift_right_narrow_nonuniform_sisd // SQSHRUN_asisdshf_N
                        when ('1', !'0000', '10001') => __encoding aarch64_vector_shift_right_narrow_nonuniform_sisd // SQRSHRUN_asisdshf_N
                        when ('1', !'0000', '10010') => __encoding aarch64_vector_shift_right_narrow_uniform_sisd // UQSHRN_asisdshf_N
                        when ('1', !'0000', '10011') => __encoding aarch64_vector_shift_right_narrow_uniform_sisd // UQRSHRN_asisdshf_N
                        when ('1', !'0000', '11100') => __encoding aarch64_vector_shift_conv_int_sisd // UCVTF_asisdshf_C
                        when ('1', !'0000', '11111') => __encoding aarch64_vector_shift_conv_float_sisd // FCVTZU_asisdshf_C
                when ('01x1', _, '11', _, 'xxxxxxxx1', _) => __UNPREDICTABLE
                when ('01x1', _, '1x', _, 'xxxxxxxx0', _) => // asisdelem
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field L 21 +: 1
                    __field M 20 +: 1
                    __field Rm 16 +: 4
                    __field opcode 12 +: 4
                    __field H 11 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '0000') => __UNALLOCATED
                        when (_, _, '0010') => __UNALLOCATED
                        when (_, _, '0100') => __UNALLOCATED
                        when (_, _, '0110') => __UNALLOCATED
                        when (_, _, '1000') => __UNALLOCATED
                        when (_, _, '1010') => __UNALLOCATED
                        when (_, _, '1110') => __UNALLOCATED
                        when (_, '01', '0001') => __UNALLOCATED
                        when (_, '01', '0101') => __UNALLOCATED
                        when (_, '01', '1001') => __UNALLOCATED
                        when ('0', _, '0011') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_double_sisd // SQDMLAL_asisdelem_L
                        when ('0', _, '0111') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_double_sisd // SQDMLSL_asisdelem_L
                        when ('0', _, '1011') => __encoding aarch64_vector_arithmetic_binary_element_mul_double_sisd // SQDMULL_asisdelem_L
                        when ('0', _, '1100') => __encoding aarch64_vector_arithmetic_binary_element_mul_high_sisd // SQDMULH_asisdelem_R
                        when ('0', _, '1101') => __encoding aarch64_vector_arithmetic_binary_element_mul_high_sisd // SQRDMULH_asisdelem_R
                        when ('0', _, '1111') => __UNALLOCATED
                        when ('0', '00', '0001') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_fp16_sisd // FMLA_asisdelem_RH_H
                        when ('0', '00', '0101') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_fp16_sisd // FMLS_asisdelem_RH_H
                        when ('0', '00', '1001') => __encoding aarch64_vector_arithmetic_binary_element_mul_fp16_sisd // FMUL_asisdelem_RH_H
                        when ('0', '1x', '0001') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_fp_sisd // FMLA_asisdelem_R_SD
                        when ('0', '1x', '0101') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_fp_sisd // FMLS_asisdelem_R_SD
                        when ('0', '1x', '1001') => __encoding aarch64_vector_arithmetic_binary_element_mul_fp_sisd // FMUL_asisdelem_R_SD
                        when ('1', _, '0011') => __UNALLOCATED
                        when ('1', _, '0111') => __UNALLOCATED
                        when ('1', _, '1011') => __UNALLOCATED
                        when ('1', _, '1100') => __UNALLOCATED
                        when ('1', _, '1101') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_high_sisd // SQRDMLAH_asisdelem_R
                        when ('1', _, '1111') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_high_sisd // SQRDMLSH_asisdelem_R
                        when ('1', '00', '0001') => __UNALLOCATED
                        when ('1', '00', '0101') => __UNALLOCATED
                        when ('1', '00', '1001') => __encoding aarch64_vector_arithmetic_binary_element_mul_fp16_sisd // FMULX_asisdelem_RH_H
                        when ('1', '1x', '0001') => __UNALLOCATED
                        when ('1', '1x', '0101') => __UNALLOCATED
                        when ('1', '1x', '1001') => __encoding aarch64_vector_arithmetic_binary_element_mul_fp_sisd // FMULX_asisdelem_R_SD
                when ('0x00', _, '0x', 'x0xx', 'xxx0xxx00', _) => // asimdtbl
                    __field Q 30 +: 1
                    __field op2 22 +: 2
                    __field Rm 16 +: 5
                    __field len 13 +: 2
                    __field op 12 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (op2, len, op) of
                        when ('x1', _, _) => __UNALLOCATED
                        when ('00', '00', '0') => __encoding aarch64_vector_transfer_vector_table // TBL_asimdtbl_L1_1
                        when ('00', '00', '1') => __encoding aarch64_vector_transfer_vector_table // TBX_asimdtbl_L1_1
                        when ('00', '01', '0') => __encoding aarch64_vector_transfer_vector_table // TBL_asimdtbl_L2_2
                        when ('00', '01', '1') => __encoding aarch64_vector_transfer_vector_table // TBX_asimdtbl_L2_2
                        when ('00', '10', '0') => __encoding aarch64_vector_transfer_vector_table // TBL_asimdtbl_L3_3
                        when ('00', '10', '1') => __encoding aarch64_vector_transfer_vector_table // TBX_asimdtbl_L3_3
                        when ('00', '11', '0') => __encoding aarch64_vector_transfer_vector_table // TBL_asimdtbl_L4_4
                        when ('00', '11', '1') => __encoding aarch64_vector_transfer_vector_table // TBX_asimdtbl_L4_4
                        when ('1x', _, _) => __UNALLOCATED
                when ('0x00', _, '0x', 'x0xx', 'xxx0xxx10', _) => // asimdperm
                    __field Q 30 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('000') => __UNALLOCATED
                        when ('001') => __encoding aarch64_vector_transfer_vector_permute_unzip // UZP1_asimdperm_only
                        when ('010') => __encoding aarch64_vector_transfer_vector_permute_transpose // TRN1_asimdperm_only
                        when ('011') => __encoding aarch64_vector_transfer_vector_permute_zip // ZIP1_asimdperm_only
                        when ('100') => __UNALLOCATED
                        when ('101') => __encoding aarch64_vector_transfer_vector_permute_unzip // UZP2_asimdperm_only
                        when ('110') => __encoding aarch64_vector_transfer_vector_permute_transpose // TRN2_asimdperm_only
                        when ('111') => __encoding aarch64_vector_transfer_vector_permute_zip // ZIP2_asimdperm_only
                when ('0x10', _, '0x', 'x0xx', 'xxx0xxxx0', _) => // asimdext
                    __field Q 30 +: 1
                    __field op2 22 +: 2
                    __field Rm 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (op2) of
                        when ('x1') => __UNALLOCATED
                        when ('00') => __encoding aarch64_vector_transfer_vector_extract // EXT_asimdext_only
                        when ('1x') => __UNALLOCATED
                when ('0xx0', _, '00', '00xx', 'xxx0xxxx1', _) => // asimdins
                    __field Q 30 +: 1
                    __field op 29 +: 1
                    __field imm5 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, op, imm5, imm4) of
                        when (_, _, 'x0000', _) => __UNALLOCATED
                        when (_, '0', _, '0000') => __encoding aarch64_vector_transfer_vector_cpy_dup_simd // DUP_asimdins_DV_v
                        when (_, '0', _, '0001') => __encoding aarch64_vector_transfer_integer_dup // DUP_asimdins_DR_r
                        when (_, '0', _, '0010') => __UNALLOCATED
                        when (_, '0', _, '0100') => __UNALLOCATED
                        when (_, '0', _, '0110') => __UNALLOCATED
                        when (_, '0', _, '1xxx') => __UNALLOCATED
                        when ('0', '0', _, '0011') => __UNALLOCATED
                        when ('0', '0', _, '0101') => __encoding aarch64_vector_transfer_integer_move_signed // SMOV_asimdins_W_w
                        when ('0', '0', _, '0111') => __encoding aarch64_vector_transfer_integer_move_unsigned // UMOV_asimdins_W_w
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', '0', _, '0011') => __encoding aarch64_vector_transfer_integer_insert // INS_asimdins_IR_r
                        when ('1', '0', _, '0101') => __encoding aarch64_vector_transfer_integer_move_signed // SMOV_asimdins_X_x
                        when ('1', '0', 'x1000', '0111') => __encoding aarch64_vector_transfer_integer_move_unsigned // UMOV_asimdins_X_x
                        when ('1', '1', _, _) => __encoding aarch64_vector_transfer_vector_insert // INS_asimdins_IV_v
                when ('0xx0', _, '01', '00xx', 'xxx0xxxx1', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '0111', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '10xx', 'xxx00xxx1', _) => // asimdsamefp16
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field Rm 16 +: 5
                    __field opcode 11 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when ('0', '0', '000') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp16_2008 // FMAXNM_asimdsamefp16_only
                        when ('0', '0', '001') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp16_fused // FMLA_asimdsamefp16_only
                        when ('0', '0', '010') => __encoding aarch64_vector_arithmetic_binary_uniform_add_fp16 // FADD_asimdsamefp16_only
                        when ('0', '0', '011') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp16_extended_simd // FMULX_asimdsamefp16_only
                        when ('0', '0', '100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_simd // FCMEQ_asimdsamefp16_only
                        when ('0', '0', '101') => __UNALLOCATED
                        when ('0', '0', '110') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp16_1985 // FMAX_asimdsamefp16_only
                        when ('0', '0', '111') => __encoding aarch64_vector_arithmetic_binary_uniform_recps_fp16_simd // FRECPS_asimdsamefp16_only
                        when ('0', '1', '000') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp16_2008 // FMINNM_asimdsamefp16_only
                        when ('0', '1', '001') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp16_fused // FMLS_asimdsamefp16_only
                        when ('0', '1', '010') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_fp16_simd // FSUB_asimdsamefp16_only
                        when ('0', '1', '011') => __UNALLOCATED
                        when ('0', '1', '100') => __UNALLOCATED
                        when ('0', '1', '101') => __UNALLOCATED
                        when ('0', '1', '110') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp16_1985 // FMIN_asimdsamefp16_only
                        when ('0', '1', '111') => __encoding aarch64_vector_arithmetic_binary_uniform_rsqrts_fp16_simd // FRSQRTS_asimdsamefp16_only
                        when ('1', '0', '000') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp16_2008 // FMAXNMP_asimdsamefp16_only
                        when ('1', '0', '001') => __UNALLOCATED
                        when ('1', '0', '010') => __encoding aarch64_vector_arithmetic_binary_uniform_add_fp16 // FADDP_asimdsamefp16_only
                        when ('1', '0', '011') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp16_product // FMUL_asimdsamefp16_only
                        when ('1', '0', '100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_simd // FCMGE_asimdsamefp16_only
                        when ('1', '0', '101') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_simd // FACGE_asimdsamefp16_only
                        when ('1', '0', '110') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp16_1985 // FMAXP_asimdsamefp16_only
                        when ('1', '0', '111') => __encoding aarch64_vector_arithmetic_binary_uniform_div_fp16 // FDIV_asimdsamefp16_only
                        when ('1', '1', '000') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp16_2008 // FMINNMP_asimdsamefp16_only
                        when ('1', '1', '001') => __UNALLOCATED
                        when ('1', '1', '010') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_fp16_simd // FABD_asimdsamefp16_only
                        when ('1', '1', '011') => __UNALLOCATED
                        when ('1', '1', '100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_simd // FCMGT_asimdsamefp16_only
                        when ('1', '1', '101') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp16_simd // FACGT_asimdsamefp16_only
                        when ('1', '1', '110') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp16_1985 // FMINP_asimdsamefp16_only
                        when ('1', '1', '111') => __UNALLOCATED
                when ('0xx0', _, '0x', '10xx', 'xxx01xxx1', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '1111', '00xxxxx10', _) => // asimdmiscfp16
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, '00xxx') => __UNALLOCATED
                        when (_, _, '010xx') => __UNALLOCATED
                        when (_, _, '10xxx') => __UNALLOCATED
                        when (_, _, '11110') => __UNALLOCATED
                        when (_, '0', '011xx') => __UNALLOCATED
                        when (_, '0', '11111') => __UNALLOCATED
                        when (_, '1', '11100') => __UNALLOCATED
                        when ('0', '0', '11000') => __encoding aarch64_vector_arithmetic_unary_fp16_round // FRINTN_asimdmiscfp16_R
                        when ('0', '0', '11001') => __encoding aarch64_vector_arithmetic_unary_fp16_round // FRINTM_asimdmiscfp16_R
                        when ('0', '0', '11010') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_simd // FCVTNS_asimdmiscfp16_R
                        when ('0', '0', '11011') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_simd // FCVTMS_asimdmiscfp16_R
                        when ('0', '0', '11100') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_tieaway_simd // FCVTAS_asimdmiscfp16_R
                        when ('0', '0', '11101') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_int_simd // SCVTF_asimdmiscfp16_R
                        when ('0', '1', '01100') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_bulk_simd // FCMGT_asimdmiscfp16_FZ
                        when ('0', '1', '01101') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_bulk_simd // FCMEQ_asimdmiscfp16_FZ
                        when ('0', '1', '01110') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_lessthan_simd // FCMLT_asimdmiscfp16_FZ
                        when ('0', '1', '01111') => __encoding aarch64_vector_arithmetic_unary_diff_neg_fp16 // FABS_asimdmiscfp16_R
                        when ('0', '1', '11000') => __encoding aarch64_vector_arithmetic_unary_fp16_round // FRINTP_asimdmiscfp16_R
                        when ('0', '1', '11001') => __encoding aarch64_vector_arithmetic_unary_fp16_round // FRINTZ_asimdmiscfp16_R
                        when ('0', '1', '11010') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_simd // FCVTPS_asimdmiscfp16_R
                        when ('0', '1', '11011') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_simd // FCVTZS_asimdmiscfp16_R
                        when ('0', '1', '11101') => __encoding aarch64_vector_arithmetic_unary_special_recip_fp16_simd // FRECPE_asimdmiscfp16_R
                        when ('0', '1', '11111') => __UNALLOCATED
                        when ('1', '0', '11000') => __encoding aarch64_vector_arithmetic_unary_fp16_round // FRINTA_asimdmiscfp16_R
                        when ('1', '0', '11001') => __encoding aarch64_vector_arithmetic_unary_fp16_round // FRINTX_asimdmiscfp16_R
                        when ('1', '0', '11010') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_simd // FCVTNU_asimdmiscfp16_R
                        when ('1', '0', '11011') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_simd // FCVTMU_asimdmiscfp16_R
                        when ('1', '0', '11100') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_tieaway_simd // FCVTAU_asimdmiscfp16_R
                        when ('1', '0', '11101') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_int_simd // UCVTF_asimdmiscfp16_R
                        when ('1', '1', '01100') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_bulk_simd // FCMGE_asimdmiscfp16_FZ
                        when ('1', '1', '01101') => __encoding aarch64_vector_arithmetic_unary_cmp_fp16_bulk_simd // FCMLE_asimdmiscfp16_FZ
                        when ('1', '1', '01110') => __UNALLOCATED
                        when ('1', '1', '01111') => __encoding aarch64_vector_arithmetic_unary_diff_neg_fp16 // FNEG_asimdmiscfp16_R
                        when ('1', '1', '11000') => __UNALLOCATED
                        when ('1', '1', '11001') => __encoding aarch64_vector_arithmetic_unary_fp16_round // FRINTI_asimdmiscfp16_R
                        when ('1', '1', '11010') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_simd // FCVTPU_asimdmiscfp16_R
                        when ('1', '1', '11011') => __encoding aarch64_vector_arithmetic_unary_fp16_conv_float_bulk_simd // FCVTZU_asimdmiscfp16_R
                        when ('1', '1', '11101') => __encoding aarch64_vector_arithmetic_unary_special_sqrt_est_fp16_simd // FRSQRTE_asimdmiscfp16_R
                        when ('1', '1', '11111') => __encoding aarch64_vector_arithmetic_unary_special_sqrt_fp16 // FSQRT_asimdmiscfp16_R
                when ('0xx0', _, '0x', 'x0xx', 'xxx1xxxx0', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x0xx', 'xxx1xxxx1', _) => // asimdsame2
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, U, size, opcode) of
                        when (_, _, '0x', '0011') => __UNALLOCATED
                        when (_, _, '11', '0011') => __UNALLOCATED
                        when (_, '0', _, '0000') => __UNALLOCATED
                        when (_, '0', _, '0001') => __UNALLOCATED
                        when (_, '0', _, '0010') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_dotp // SDOT_asimdsame2_D
                        when (_, '0', _, '1xxx') => __UNALLOCATED
                        when (_, '0', '10', '0011') => __encoding aarch64_vector_arithmetic_binary_uniform_mat_mul_int_usdot // USDOT_asimdsame2_D
                        when (_, '1', _, '0000') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_doubling_accum_simd // SQRDMLAH_asimdsame2_only
                        when (_, '1', _, '0001') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_doubling_accum_simd // SQRDMLSH_asimdsame2_only
                        when (_, '1', _, '0010') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_dotp // UDOT_asimdsame2_D
                        when (_, '1', _, '10xx') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_complex // FCMLA_asimdsame2_C
                        when (_, '1', _, '11x0') => __encoding aarch64_vector_arithmetic_binary_uniform_add_fp_complex // FCADD_asimdsame2_C
                        when (_, '1', '00', '1101') => __UNALLOCATED
                        when (_, '1', '00', '1111') => __UNALLOCATED
                        when (_, '1', '01', '1111') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_bfdot // BFDOT_asimdsame2_D
                        when (_, '1', '1x', '1101') => __UNALLOCATED
                        when (_, '1', '10', '0011') => __UNALLOCATED
                        when (_, '1', '10', '1111') => __UNALLOCATED
                        when (_, '1', '11', '1111') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_acc_bf16_long // BFMLAL_asimdsame2_F_
                        when ('0', _, _, '01xx') => __UNALLOCATED
                        when ('0', '1', '01', '1101') => __UNALLOCATED
                        when ('1', _, '0x', '01xx') => __UNALLOCATED
                        when ('1', _, '1x', '011x') => __UNALLOCATED
                        when ('1', '0', '10', '0100') => __encoding aarch64_vector_arithmetic_binary_uniform_mat_mul_int_mla // SMMLA_asimdsame2_G
                        when ('1', '0', '10', '0101') => __encoding aarch64_vector_arithmetic_binary_uniform_mat_mul_int_mla // USMMLA_asimdsame2_G
                        when ('1', '1', '01', '1101') => __encoding aarch64_vector_bfmmla // BFMMLA_asimdsame2_E
                        when ('1', '1', '10', '0100') => __encoding aarch64_vector_arithmetic_binary_uniform_mat_mul_int_mla // UMMLA_asimdsame2_G
                        when ('1', '1', '10', '0101') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x100', '00xxxxx10', _) => // asimdmisc
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '1000x') => __UNALLOCATED
                        when (_, _, '10101') => __UNALLOCATED
                        when (_, '0x', '011xx') => __UNALLOCATED
                        when (_, '1x', '10111') => __UNALLOCATED
                        when (_, '1x', '11110') => __UNALLOCATED
                        when (_, '11', '10110') => __UNALLOCATED
                        when ('0', _, '00000') => __encoding aarch64_vector_arithmetic_unary_rev // REV64_asimdmisc_R
                        when ('0', _, '00001') => __encoding aarch64_vector_arithmetic_unary_rev // REV16_asimdmisc_R
                        when ('0', _, '00010') => __encoding aarch64_vector_arithmetic_unary_add_pairwise // SADDLP_asimdmisc_P
                        when ('0', _, '00011') => __encoding aarch64_vector_arithmetic_unary_add_saturating_simd // SUQADD_asimdmisc_R
                        when ('0', _, '00100') => __encoding aarch64_vector_arithmetic_unary_clsz // CLS_asimdmisc_R
                        when ('0', _, '00101') => __encoding aarch64_vector_arithmetic_unary_cnt // CNT_asimdmisc_R
                        when ('0', _, '00110') => __encoding aarch64_vector_arithmetic_unary_add_pairwise // SADALP_asimdmisc_P
                        when ('0', _, '00111') => __encoding aarch64_vector_arithmetic_unary_diff_neg_sat_simd // SQABS_asimdmisc_R
                        when ('0', _, '01000') => __encoding aarch64_vector_arithmetic_unary_cmp_int_bulk_simd // CMGT_asimdmisc_Z
                        when ('0', _, '01001') => __encoding aarch64_vector_arithmetic_unary_cmp_int_bulk_simd // CMEQ_asimdmisc_Z
                        when ('0', _, '01010') => __encoding aarch64_vector_arithmetic_unary_cmp_int_lessthan_simd // CMLT_asimdmisc_Z
                        when ('0', _, '01011') => __encoding aarch64_vector_arithmetic_unary_diff_neg_int_simd // ABS_asimdmisc_R
                        when ('0', _, '10010') => __encoding aarch64_vector_arithmetic_unary_extract_nosat // XTN_asimdmisc_N
                        when ('0', _, '10011') => __UNALLOCATED
                        when ('0', _, '10100') => __encoding aarch64_vector_arithmetic_unary_extract_sat_simd // SQXTN_asimdmisc_N
                        when ('0', '0x', '10110') => __encoding aarch64_vector_arithmetic_unary_float_narrow // FCVTN_asimdmisc_N
                        when ('0', '0x', '10111') => __encoding aarch64_vector_arithmetic_unary_float_widen // FCVTL_asimdmisc_L
                        when ('0', '0x', '11000') => __encoding aarch64_vector_arithmetic_unary_float_round // FRINTN_asimdmisc_R
                        when ('0', '0x', '11001') => __encoding aarch64_vector_arithmetic_unary_float_round // FRINTM_asimdmisc_R
                        when ('0', '0x', '11010') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_simd // FCVTNS_asimdmisc_R
                        when ('0', '0x', '11011') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_simd // FCVTMS_asimdmisc_R
                        when ('0', '0x', '11100') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_tieaway_simd // FCVTAS_asimdmisc_R
                        when ('0', '0x', '11101') => __encoding aarch64_vector_arithmetic_unary_float_conv_int_simd // SCVTF_asimdmisc_R
                        when ('0', '0x', '11110') => __encoding aarch64_vector_arithmetic_unary_float_round_frint_32_64 // FRINT32Z_asimdmisc_R
                        when ('0', '0x', '11111') => __encoding aarch64_vector_arithmetic_unary_float_round_frint_32_64 // FRINT64Z_asimdmisc_R
                        when ('0', '1x', '01100') => __encoding aarch64_vector_arithmetic_unary_cmp_float_bulk_simd // FCMGT_asimdmisc_FZ
                        when ('0', '1x', '01101') => __encoding aarch64_vector_arithmetic_unary_cmp_float_bulk_simd // FCMEQ_asimdmisc_FZ
                        when ('0', '1x', '01110') => __encoding aarch64_vector_arithmetic_unary_cmp_float_lessthan_simd // FCMLT_asimdmisc_FZ
                        when ('0', '1x', '01111') => __encoding aarch64_vector_arithmetic_unary_diff_neg_float // FABS_asimdmisc_R
                        when ('0', '1x', '11000') => __encoding aarch64_vector_arithmetic_unary_float_round // FRINTP_asimdmisc_R
                        when ('0', '1x', '11001') => __encoding aarch64_vector_arithmetic_unary_float_round // FRINTZ_asimdmisc_R
                        when ('0', '1x', '11010') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_simd // FCVTPS_asimdmisc_R
                        when ('0', '1x', '11011') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_simd // FCVTZS_asimdmisc_R
                        when ('0', '1x', '11100') => __encoding aarch64_vector_arithmetic_unary_special_recip_int // URECPE_asimdmisc_R
                        when ('0', '1x', '11101') => __encoding aarch64_vector_arithmetic_unary_special_recip_float_simd // FRECPE_asimdmisc_R
                        when ('0', '1x', '11111') => __UNALLOCATED
                        when ('0', '10', '10110') => __encoding aarch64_vector_cvt_bf16_vector // BFCVTN_asimdmisc_4S
                        when ('1', _, '00000') => __encoding aarch64_vector_arithmetic_unary_rev // REV32_asimdmisc_R
                        when ('1', _, '00001') => __UNALLOCATED
                        when ('1', _, '00010') => __encoding aarch64_vector_arithmetic_unary_add_pairwise // UADDLP_asimdmisc_P
                        when ('1', _, '00011') => __encoding aarch64_vector_arithmetic_unary_add_saturating_simd // USQADD_asimdmisc_R
                        when ('1', _, '00100') => __encoding aarch64_vector_arithmetic_unary_clsz // CLZ_asimdmisc_R
                        when ('1', _, '00110') => __encoding aarch64_vector_arithmetic_unary_add_pairwise // UADALP_asimdmisc_P
                        when ('1', _, '00111') => __encoding aarch64_vector_arithmetic_unary_diff_neg_sat_simd // SQNEG_asimdmisc_R
                        when ('1', _, '01000') => __encoding aarch64_vector_arithmetic_unary_cmp_int_bulk_simd // CMGE_asimdmisc_Z
                        when ('1', _, '01001') => __encoding aarch64_vector_arithmetic_unary_cmp_int_bulk_simd // CMLE_asimdmisc_Z
                        when ('1', _, '01010') => __UNALLOCATED
                        when ('1', _, '01011') => __encoding aarch64_vector_arithmetic_unary_diff_neg_int_simd // NEG_asimdmisc_R
                        when ('1', _, '10010') => __encoding aarch64_vector_arithmetic_unary_extract_sqxtun_simd // SQXTUN_asimdmisc_N
                        when ('1', _, '10011') => __encoding aarch64_vector_arithmetic_unary_shift // SHLL_asimdmisc_S
                        when ('1', _, '10100') => __encoding aarch64_vector_arithmetic_unary_extract_sat_simd // UQXTN_asimdmisc_N
                        when ('1', '0x', '10110') => __encoding aarch64_vector_arithmetic_unary_float_xtn_simd // FCVTXN_asimdmisc_N
                        when ('1', '0x', '10111') => __UNALLOCATED
                        when ('1', '0x', '11000') => __encoding aarch64_vector_arithmetic_unary_float_round // FRINTA_asimdmisc_R
                        when ('1', '0x', '11001') => __encoding aarch64_vector_arithmetic_unary_float_round // FRINTX_asimdmisc_R
                        when ('1', '0x', '11010') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_simd // FCVTNU_asimdmisc_R
                        when ('1', '0x', '11011') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_simd // FCVTMU_asimdmisc_R
                        when ('1', '0x', '11100') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_tieaway_simd // FCVTAU_asimdmisc_R
                        when ('1', '0x', '11101') => __encoding aarch64_vector_arithmetic_unary_float_conv_int_simd // UCVTF_asimdmisc_R
                        when ('1', '0x', '11110') => __encoding aarch64_vector_arithmetic_unary_float_round_frint_32_64 // FRINT32X_asimdmisc_R
                        when ('1', '0x', '11111') => __encoding aarch64_vector_arithmetic_unary_float_round_frint_32_64 // FRINT64X_asimdmisc_R
                        when ('1', '00', '00101') => __encoding aarch64_vector_arithmetic_unary_not // NOT_asimdmisc_R
                        when ('1', '01', '00101') => __encoding aarch64_vector_arithmetic_unary_rbit // RBIT_asimdmisc_R
                        when ('1', '1x', '00101') => __UNALLOCATED
                        when ('1', '1x', '01100') => __encoding aarch64_vector_arithmetic_unary_cmp_float_bulk_simd // FCMGE_asimdmisc_FZ
                        when ('1', '1x', '01101') => __encoding aarch64_vector_arithmetic_unary_cmp_float_bulk_simd // FCMLE_asimdmisc_FZ
                        when ('1', '1x', '01110') => __UNALLOCATED
                        when ('1', '1x', '01111') => __encoding aarch64_vector_arithmetic_unary_diff_neg_float // FNEG_asimdmisc_R
                        when ('1', '1x', '11000') => __UNALLOCATED
                        when ('1', '1x', '11001') => __encoding aarch64_vector_arithmetic_unary_float_round // FRINTI_asimdmisc_R
                        when ('1', '1x', '11010') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_simd // FCVTPU_asimdmisc_R
                        when ('1', '1x', '11011') => __encoding aarch64_vector_arithmetic_unary_float_conv_float_bulk_simd // FCVTZU_asimdmisc_R
                        when ('1', '1x', '11100') => __encoding aarch64_vector_arithmetic_unary_special_sqrt_est_int // URSQRTE_asimdmisc_R
                        when ('1', '1x', '11101') => __encoding aarch64_vector_arithmetic_unary_special_sqrt_est_float_simd // FRSQRTE_asimdmisc_R
                        when ('1', '1x', '11111') => __encoding aarch64_vector_arithmetic_unary_special_sqrt // FSQRT_asimdmisc_R
                        when ('1', '10', '10110') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x110', '00xxxxx10', _) => // asimdall
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '0000x') => __UNALLOCATED
                        when (_, _, '00010') => __UNALLOCATED
                        when (_, _, '001xx') => __UNALLOCATED
                        when (_, _, '0100x') => __UNALLOCATED
                        when (_, _, '01011') => __UNALLOCATED
                        when (_, _, '01101') => __UNALLOCATED
                        when (_, _, '01110') => __UNALLOCATED
                        when (_, _, '10xxx') => __UNALLOCATED
                        when (_, _, '1100x') => __UNALLOCATED
                        when (_, _, '111xx') => __UNALLOCATED
                        when ('0', _, '00011') => __encoding aarch64_vector_reduce_add_long // SADDLV_asimdall_only
                        when ('0', _, '01010') => __encoding aarch64_vector_reduce_int_max // SMAXV_asimdall_only
                        when ('0', _, '11010') => __encoding aarch64_vector_reduce_int_max // SMINV_asimdall_only
                        when ('0', _, '11011') => __encoding aarch64_vector_reduce_add_simd // ADDV_asimdall_only
                        when ('0', '00', '01100') => __encoding aarch64_vector_reduce_fp16_maxnm_simd // FMAXNMV_asimdall_only_H
                        when ('0', '00', '01111') => __encoding aarch64_vector_reduce_fp16_max_simd // FMAXV_asimdall_only_H
                        when ('0', '01', '01100') => __UNALLOCATED
                        when ('0', '01', '01111') => __UNALLOCATED
                        when ('0', '10', '01100') => __encoding aarch64_vector_reduce_fp16_maxnm_simd // FMINNMV_asimdall_only_H
                        when ('0', '10', '01111') => __encoding aarch64_vector_reduce_fp16_max_simd // FMINV_asimdall_only_H
                        when ('0', '11', '01100') => __UNALLOCATED
                        when ('0', '11', '01111') => __UNALLOCATED
                        when ('1', _, '00011') => __encoding aarch64_vector_reduce_add_long // UADDLV_asimdall_only
                        when ('1', _, '01010') => __encoding aarch64_vector_reduce_int_max // UMAXV_asimdall_only
                        when ('1', _, '11010') => __encoding aarch64_vector_reduce_int_max // UMINV_asimdall_only
                        when ('1', _, '11011') => __UNALLOCATED
                        when ('1', '0x', '01100') => __encoding aarch64_vector_reduce_fp_maxnm_simd // FMAXNMV_asimdall_only_SD
                        when ('1', '0x', '01111') => __encoding aarch64_vector_reduce_fp_max_simd // FMAXV_asimdall_only_SD
                        when ('1', '1x', '01100') => __encoding aarch64_vector_reduce_fp_maxnm_simd // FMINNMV_asimdall_only_SD
                        when ('1', '1x', '01111') => __encoding aarch64_vector_reduce_fp_max_simd // FMINV_asimdall_only_SD
                when ('0xx0', _, '0x', 'x1xx', '1xxxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x1xx', 'x1xxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x1xx', 'xxxxxxx00', _) => // asimddiff
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when (_, '1111') => __UNALLOCATED
                        when ('0', '0000') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_long // SADDL_asimddiff_L
                        when ('0', '0001') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_wide // SADDW_asimddiff_W
                        when ('0', '0010') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_long // SSUBL_asimddiff_L
                        when ('0', '0011') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_wide // SSUBW_asimddiff_W
                        when ('0', '0100') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_narrow // ADDHN_asimddiff_N
                        when ('0', '0101') => __encoding aarch64_vector_arithmetic_binary_disparate_diff // SABAL_asimddiff_L
                        when ('0', '0110') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_narrow // SUBHN_asimddiff_N
                        when ('0', '0111') => __encoding aarch64_vector_arithmetic_binary_disparate_diff // SABDL_asimddiff_L
                        when ('0', '1000') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_accum // SMLAL_asimddiff_L
                        when ('0', '1001') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_dmacc_simd // SQDMLAL_asimddiff_L
                        when ('0', '1010') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_accum // SMLSL_asimddiff_L
                        when ('0', '1011') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_dmacc_simd // SQDMLSL_asimddiff_L
                        when ('0', '1100') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_product // SMULL_asimddiff_L
                        when ('0', '1101') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_double_simd // SQDMULL_asimddiff_L
                        when ('0', '1110') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_poly // PMULL_asimddiff_L
                        when ('1', '0000') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_long // UADDL_asimddiff_L
                        when ('1', '0001') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_wide // UADDW_asimddiff_W
                        when ('1', '0010') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_long // USUBL_asimddiff_L
                        when ('1', '0011') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_wide // USUBW_asimddiff_W
                        when ('1', '0100') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_narrow // RADDHN_asimddiff_N
                        when ('1', '0101') => __encoding aarch64_vector_arithmetic_binary_disparate_diff // UABAL_asimddiff_L
                        when ('1', '0110') => __encoding aarch64_vector_arithmetic_binary_disparate_add_sub_narrow // RSUBHN_asimddiff_N
                        when ('1', '0111') => __encoding aarch64_vector_arithmetic_binary_disparate_diff // UABDL_asimddiff_L
                        when ('1', '1000') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_accum // UMLAL_asimddiff_L
                        when ('1', '1001') => __UNALLOCATED
                        when ('1', '1010') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_accum // UMLSL_asimddiff_L
                        when ('1', '1011') => __UNALLOCATED
                        when ('1', '1100') => __encoding aarch64_vector_arithmetic_binary_disparate_mul_product // UMULL_asimddiff_L
                        when ('1', '1101') => __UNALLOCATED
                        when ('1', '1110') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x1xx', 'xxxxxxxx1', _) => // asimdsame
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when ('0', _, '00000') => __encoding aarch64_vector_arithmetic_binary_uniform_add_halving_truncating // SHADD_asimdsame_only
                        when ('0', _, '00001') => __encoding aarch64_vector_arithmetic_binary_uniform_add_saturating_simd // SQADD_asimdsame_only
                        when ('0', _, '00010') => __encoding aarch64_vector_arithmetic_binary_uniform_add_halving_rounding // SRHADD_asimdsame_only
                        when ('0', _, '00100') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_int // SHSUB_asimdsame_only
                        when ('0', _, '00101') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_saturating_simd // SQSUB_asimdsame_only
                        when ('0', _, '00110') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_int_simd // CMGT_asimdsame_only
                        when ('0', _, '00111') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_int_simd // CMGE_asimdsame_only
                        when ('0', _, '01000') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_simd // SSHL_asimdsame_only
                        when ('0', _, '01001') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_simd // SQSHL_asimdsame_only
                        when ('0', _, '01010') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_simd // SRSHL_asimdsame_only
                        when ('0', _, '01011') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_simd // SQRSHL_asimdsame_only
                        when ('0', _, '01100') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_single // SMAX_asimdsame_only
                        when ('0', _, '01101') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_single // SMIN_asimdsame_only
                        when ('0', _, '01110') => __encoding aarch64_vector_arithmetic_binary_uniform_diff // SABD_asimdsame_only
                        when ('0', _, '01111') => __encoding aarch64_vector_arithmetic_binary_uniform_diff // SABA_asimdsame_only
                        when ('0', _, '10000') => __encoding aarch64_vector_arithmetic_binary_uniform_add_wrapping_single_simd // ADD_asimdsame_only
                        when ('0', _, '10001') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_bitwise_simd // CMTST_asimdsame_only
                        when ('0', _, '10010') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_accum // MLA_asimdsame_only
                        when ('0', _, '10011') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_product // MUL_asimdsame_only
                        when ('0', _, '10100') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_pair // SMAXP_asimdsame_only
                        when ('0', _, '10101') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_pair // SMINP_asimdsame_only
                        when ('0', _, '10110') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_doubling_simd // SQDMULH_asimdsame_only
                        when ('0', _, '10111') => __encoding aarch64_vector_arithmetic_binary_uniform_add_wrapping_pair // ADDP_asimdsame_only
                        when ('0', '0x', '11000') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp_2008 // FMAXNM_asimdsame_only
                        when ('0', '0x', '11001') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_fused // FMLA_asimdsame_only
                        when ('0', '0x', '11010') => __encoding aarch64_vector_arithmetic_binary_uniform_add_fp // FADD_asimdsame_only
                        when ('0', '0x', '11011') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_extended_simd // FMULX_asimdsame_only
                        when ('0', '0x', '11100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_simd // FCMEQ_asimdsame_only
                        when ('0', '0x', '11110') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp_1985 // FMAX_asimdsame_only
                        when ('0', '0x', '11111') => __encoding aarch64_vector_arithmetic_binary_uniform_recps_simd // FRECPS_asimdsame_only
                        when ('0', '00', '00011') => __encoding aarch64_vector_arithmetic_binary_uniform_logical_and_orr // AND_asimdsame_only
                        when ('0', '00', '11101') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_mul_norounding_lower // FMLAL_asimdsame_F
                        when ('0', '01', '00011') => __encoding aarch64_vector_arithmetic_binary_uniform_logical_and_orr // BIC_asimdsame_only
                        when ('0', '01', '11101') => __UNALLOCATED
                        when ('0', '1x', '11000') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp_2008 // FMINNM_asimdsame_only
                        when ('0', '1x', '11001') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_fused // FMLS_asimdsame_only
                        when ('0', '1x', '11010') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_fp_simd // FSUB_asimdsame_only
                        when ('0', '1x', '11011') => __UNALLOCATED
                        when ('0', '1x', '11100') => __UNALLOCATED
                        when ('0', '1x', '11110') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp_1985 // FMIN_asimdsame_only
                        when ('0', '1x', '11111') => __encoding aarch64_vector_arithmetic_binary_uniform_rsqrts_simd // FRSQRTS_asimdsame_only
                        when ('0', '10', '00011') => __encoding aarch64_vector_arithmetic_binary_uniform_logical_and_orr // ORR_asimdsame_only
                        when ('0', '10', '11101') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_mul_norounding_lower // FMLSL_asimdsame_F
                        when ('0', '11', '00011') => __encoding aarch64_vector_arithmetic_binary_uniform_logical_and_orr // ORN_asimdsame_only
                        when ('0', '11', '11101') => __UNALLOCATED
                        when ('1', _, '00000') => __encoding aarch64_vector_arithmetic_binary_uniform_add_halving_truncating // UHADD_asimdsame_only
                        when ('1', _, '00001') => __encoding aarch64_vector_arithmetic_binary_uniform_add_saturating_simd // UQADD_asimdsame_only
                        when ('1', _, '00010') => __encoding aarch64_vector_arithmetic_binary_uniform_add_halving_rounding // URHADD_asimdsame_only
                        when ('1', _, '00100') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_int // UHSUB_asimdsame_only
                        when ('1', _, '00101') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_saturating_simd // UQSUB_asimdsame_only
                        when ('1', _, '00110') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_int_simd // CMHI_asimdsame_only
                        when ('1', _, '00111') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_int_simd // CMHS_asimdsame_only
                        when ('1', _, '01000') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_simd // USHL_asimdsame_only
                        when ('1', _, '01001') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_simd // UQSHL_asimdsame_only
                        when ('1', _, '01010') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_simd // URSHL_asimdsame_only
                        when ('1', _, '01011') => __encoding aarch64_vector_arithmetic_binary_uniform_shift_simd // UQRSHL_asimdsame_only
                        when ('1', _, '01100') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_single // UMAX_asimdsame_only
                        when ('1', _, '01101') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_single // UMIN_asimdsame_only
                        when ('1', _, '01110') => __encoding aarch64_vector_arithmetic_binary_uniform_diff // UABD_asimdsame_only
                        when ('1', _, '01111') => __encoding aarch64_vector_arithmetic_binary_uniform_diff // UABA_asimdsame_only
                        when ('1', _, '10000') => __encoding aarch64_vector_arithmetic_binary_uniform_add_wrapping_single_simd // SUB_asimdsame_only
                        when ('1', _, '10001') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_bitwise_simd // CMEQ_asimdsame_only
                        when ('1', _, '10010') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_accum // MLS_asimdsame_only
                        when ('1', _, '10011') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_product // PMUL_asimdsame_only
                        when ('1', _, '10100') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_pair // UMAXP_asimdsame_only
                        when ('1', _, '10101') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_pair // UMINP_asimdsame_only
                        when ('1', _, '10110') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_int_doubling_simd // SQRDMULH_asimdsame_only
                        when ('1', _, '10111') => __UNALLOCATED
                        when ('1', '0x', '11000') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp_2008 // FMAXNMP_asimdsame_only
                        when ('1', '0x', '11010') => __encoding aarch64_vector_arithmetic_binary_uniform_add_fp // FADDP_asimdsame_only
                        when ('1', '0x', '11011') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_product // FMUL_asimdsame_only
                        when ('1', '0x', '11100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_simd // FCMGE_asimdsame_only
                        when ('1', '0x', '11101') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_simd // FACGE_asimdsame_only
                        when ('1', '0x', '11110') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp_1985 // FMAXP_asimdsame_only
                        when ('1', '0x', '11111') => __encoding aarch64_vector_arithmetic_binary_uniform_div // FDIV_asimdsame_only
                        when ('1', '00', '00011') => __encoding aarch64_vector_arithmetic_binary_uniform_logical_bsl_eor // EOR_asimdsame_only
                        when ('1', '00', '11001') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_mul_norounding_upper // FMLAL2_asimdsame_F
                        when ('1', '01', '00011') => __encoding aarch64_vector_arithmetic_binary_uniform_logical_bsl_eor // BSL_asimdsame_only
                        when ('1', '01', '11001') => __UNALLOCATED
                        when ('1', '1x', '11000') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp_2008 // FMINNMP_asimdsame_only
                        when ('1', '1x', '11010') => __encoding aarch64_vector_arithmetic_binary_uniform_sub_fp_simd // FABD_asimdsame_only
                        when ('1', '1x', '11011') => __UNALLOCATED
                        when ('1', '1x', '11100') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_simd // FCMGT_asimdsame_only
                        when ('1', '1x', '11101') => __encoding aarch64_vector_arithmetic_binary_uniform_cmp_fp_simd // FACGT_asimdsame_only
                        when ('1', '1x', '11110') => __encoding aarch64_vector_arithmetic_binary_uniform_max_min_fp_1985 // FMINP_asimdsame_only
                        when ('1', '1x', '11111') => __UNALLOCATED
                        when ('1', '10', '00011') => __encoding aarch64_vector_arithmetic_binary_uniform_logical_bsl_eor // BIT_asimdsame_only
                        when ('1', '10', '11001') => __encoding aarch64_vector_arithmetic_binary_uniform_mul_fp_mul_norounding_upper // FMLSL2_asimdsame_F
                        when ('1', '11', '00011') => __encoding aarch64_vector_arithmetic_binary_uniform_logical_bsl_eor // BIF_asimdsame_only
                        when ('1', '11', '11001') => __UNALLOCATED
                when ('0xx0', _, '10', '0000', 'xxxxxxxx1', _) => // asimdimm
                    __field Q 30 +: 1
                    __field op 29 +: 1
                    __field a 18 +: 1
                    __field b 17 +: 1
                    __field c 16 +: 1
                    __field cmode 12 +: 4
                    __field o2 11 +: 1
                    __field d 9 +: 1
                    __field e 8 +: 1
                    __field f 7 +: 1
                    __field g 6 +: 1
                    __field h 5 +: 1
                    __field Rd 0 +: 5
                    case (Q, op, cmode, o2) of
                        when (_, '0', '0xxx', '1') => __UNALLOCATED
                        when (_, '0', '0xx0', '0') => __encoding aarch64_vector_logical // MOVI_asimdimm_L_sl
                        when (_, '0', '0xx1', '0') => __encoding aarch64_vector_logical // ORR_asimdimm_L_sl
                        when (_, '0', '10xx', '1') => __UNALLOCATED
                        when (_, '0', '10x0', '0') => __encoding aarch64_vector_logical // MOVI_asimdimm_L_hl
                        when (_, '0', '10x1', '0') => __encoding aarch64_vector_logical // ORR_asimdimm_L_hl
                        when (_, '0', '110x', '0') => __encoding aarch64_vector_logical // MOVI_asimdimm_M_sm
                        when (_, '0', '110x', '1') => __UNALLOCATED
                        when (_, '0', '1110', '0') => __encoding aarch64_vector_logical // MOVI_asimdimm_N_b
                        when (_, '0', '1110', '1') => __UNALLOCATED
                        when (_, '0', '1111', '0') => __encoding aarch64_vector_logical // FMOV_asimdimm_S_s
                        when (_, '0', '1111', '1') => __encoding aarch64_vector_fp16_movi // FMOV_asimdimm_H_h
                        when (_, '1', _, '1') => __UNALLOCATED
                        when (_, '1', '0xx0', '0') => __encoding aarch64_vector_logical // MVNI_asimdimm_L_sl
                        when (_, '1', '0xx1', '0') => __encoding aarch64_vector_logical // BIC_asimdimm_L_sl
                        when (_, '1', '10x0', '0') => __encoding aarch64_vector_logical // MVNI_asimdimm_L_hl
                        when (_, '1', '10x1', '0') => __encoding aarch64_vector_logical // BIC_asimdimm_L_hl
                        when (_, '1', '110x', '0') => __encoding aarch64_vector_logical // MVNI_asimdimm_M_sm
                        when ('0', '1', '1110', '0') => __encoding aarch64_vector_logical // MOVI_asimdimm_D_ds
                        when ('0', '1', '1111', '0') => __UNALLOCATED
                        when ('1', '1', '1110', '0') => __encoding aarch64_vector_logical // MOVI_asimdimm_D2_d
                        when ('1', '1', '1111', '0') => __encoding aarch64_vector_logical // FMOV_asimdimm_D2_d
                when ('0xx0', _, '10', !'0000', 'xxxxxxxx1', _) => // asimdshf
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field immh 19 +: 4
                    __field immb 16 +: 3
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when (_, '00001') => __UNALLOCATED
                        when (_, '00011') => __UNALLOCATED
                        when (_, '00101') => __UNALLOCATED
                        when (_, '00111') => __UNALLOCATED
                        when (_, '01001') => __UNALLOCATED
                        when (_, '01011') => __UNALLOCATED
                        when (_, '01101') => __UNALLOCATED
                        when (_, '01111') => __UNALLOCATED
                        when (_, '10101') => __UNALLOCATED
                        when (_, '1011x') => __UNALLOCATED
                        when (_, '110xx') => __UNALLOCATED
                        when (_, '11101') => __UNALLOCATED
                        when (_, '11110') => __UNALLOCATED
                        when ('0', '00000') => __encoding aarch64_vector_shift_right_simd // SSHR_asimdshf_R
                        when ('0', '00010') => __encoding aarch64_vector_shift_right_simd // SSRA_asimdshf_R
                        when ('0', '00100') => __encoding aarch64_vector_shift_right_simd // SRSHR_asimdshf_R
                        when ('0', '00110') => __encoding aarch64_vector_shift_right_simd // SRSRA_asimdshf_R
                        when ('0', '01000') => __UNALLOCATED
                        when ('0', '01010') => __encoding aarch64_vector_shift_left_simd // SHL_asimdshf_R
                        when ('0', '01100') => __UNALLOCATED
                        when ('0', '01110') => __encoding aarch64_vector_shift_left_sat_simd // SQSHL_asimdshf_R
                        when ('0', '10000') => __encoding aarch64_vector_shift_right_narrow_logical // SHRN_asimdshf_N
                        when ('0', '10001') => __encoding aarch64_vector_shift_right_narrow_logical // RSHRN_asimdshf_N
                        when ('0', '10010') => __encoding aarch64_vector_shift_right_narrow_uniform_simd // SQSHRN_asimdshf_N
                        when ('0', '10011') => __encoding aarch64_vector_shift_right_narrow_uniform_simd // SQRSHRN_asimdshf_N
                        when ('0', '10100') => __encoding aarch64_vector_shift_left_long // SSHLL_asimdshf_L
                        when ('0', '11100') => __encoding aarch64_vector_shift_conv_int_simd // SCVTF_asimdshf_C
                        when ('0', '11111') => __encoding aarch64_vector_shift_conv_float_simd // FCVTZS_asimdshf_C
                        when ('1', '00000') => __encoding aarch64_vector_shift_right_simd // USHR_asimdshf_R
                        when ('1', '00010') => __encoding aarch64_vector_shift_right_simd // USRA_asimdshf_R
                        when ('1', '00100') => __encoding aarch64_vector_shift_right_simd // URSHR_asimdshf_R
                        when ('1', '00110') => __encoding aarch64_vector_shift_right_simd // URSRA_asimdshf_R
                        when ('1', '01000') => __encoding aarch64_vector_shift_right_insert_simd // SRI_asimdshf_R
                        when ('1', '01010') => __encoding aarch64_vector_shift_left_insert_simd // SLI_asimdshf_R
                        when ('1', '01100') => __encoding aarch64_vector_shift_left_sat_simd // SQSHLU_asimdshf_R
                        when ('1', '01110') => __encoding aarch64_vector_shift_left_sat_simd // UQSHL_asimdshf_R
                        when ('1', '10000') => __encoding aarch64_vector_shift_right_narrow_nonuniform_simd // SQSHRUN_asimdshf_N
                        when ('1', '10001') => __encoding aarch64_vector_shift_right_narrow_nonuniform_simd // SQRSHRUN_asimdshf_N
                        when ('1', '10010') => __encoding aarch64_vector_shift_right_narrow_uniform_simd // UQSHRN_asimdshf_N
                        when ('1', '10011') => __encoding aarch64_vector_shift_right_narrow_uniform_simd // UQRSHRN_asimdshf_N
                        when ('1', '10100') => __encoding aarch64_vector_shift_left_long // USHLL_asimdshf_L
                        when ('1', '11100') => __encoding aarch64_vector_shift_conv_int_simd // UCVTF_asimdshf_C
                        when ('1', '11111') => __encoding aarch64_vector_shift_conv_float_simd // FCVTZU_asimdshf_C
                when ('0xx0', _, '11', _, 'xxxxxxxx1', _) => __UNPREDICTABLE
                when ('0xx0', _, '1x', _, 'xxxxxxxx0', _) => // asimdelem
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field L 21 +: 1
                    __field M 20 +: 1
                    __field Rm 16 +: 4
                    __field opcode 12 +: 4
                    __field H 11 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, '01', '1001') => __UNALLOCATED
                        when ('0', _, '0010') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_long // SMLAL_asimdelem_L
                        when ('0', _, '0011') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_double_simd // SQDMLAL_asimdelem_L
                        when ('0', _, '0110') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_long // SMLSL_asimdelem_L
                        when ('0', _, '0111') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_double_simd // SQDMLSL_asimdelem_L
                        when ('0', _, '1000') => __encoding aarch64_vector_arithmetic_binary_element_mul_int // MUL_asimdelem_R
                        when ('0', _, '1010') => __encoding aarch64_vector_arithmetic_binary_element_mul_long // SMULL_asimdelem_L
                        when ('0', _, '1011') => __encoding aarch64_vector_arithmetic_binary_element_mul_double_simd // SQDMULL_asimdelem_L
                        when ('0', _, '1100') => __encoding aarch64_vector_arithmetic_binary_element_mul_high_simd // SQDMULH_asimdelem_R
                        when ('0', _, '1101') => __encoding aarch64_vector_arithmetic_binary_element_mul_high_simd // SQRDMULH_asimdelem_R
                        when ('0', _, '1110') => __encoding aarch64_vector_arithmetic_binary_element_dotp // SDOT_asimdelem_D
                        when ('0', '0x', '0000') => __UNALLOCATED
                        when ('0', '0x', '0100') => __UNALLOCATED
                        when ('0', '00', '0001') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_fp16_simd // FMLA_asimdelem_RH_H
                        when ('0', '00', '0101') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_fp16_simd // FMLS_asimdelem_RH_H
                        when ('0', '00', '1001') => __encoding aarch64_vector_arithmetic_binary_element_mul_fp16_simd // FMUL_asimdelem_RH_H
                        when ('0', '00', '1111') => __encoding aarch64_vector_arithmetic_binary_element_mat_mul_int_dotp // SUDOT_asimdelem_D
                        when ('0', '01', '0001') => __UNALLOCATED
                        when ('0', '01', '0101') => __UNALLOCATED
                        when ('0', '01', '1111') => __encoding aarch64_vector_arithmetic_binary_element_bfdot // BFDOT_asimdelem_E
                        when ('0', '1x', '0001') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_fp_simd // FMLA_asimdelem_R_SD
                        when ('0', '1x', '0101') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_fp_simd // FMLS_asimdelem_R_SD
                        when ('0', '1x', '1001') => __encoding aarch64_vector_arithmetic_binary_element_mul_fp_simd // FMUL_asimdelem_R_SD
                        when ('0', '10', '0000') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_mul_norounding_i_lower // FMLAL_asimdelem_LH
                        when ('0', '10', '0100') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_mul_norounding_i_lower // FMLSL_asimdelem_LH
                        when ('0', '10', '1111') => __encoding aarch64_vector_arithmetic_binary_element_mat_mul_int_dotp // USDOT_asimdelem_D
                        when ('0', '11', '0000') => __UNALLOCATED
                        when ('0', '11', '0100') => __UNALLOCATED
                        when ('0', '11', '1111') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_bf16_long // BFMLAL_asimdelem_F
                        when ('1', _, '0000') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_int // MLA_asimdelem_R
                        when ('1', _, '0010') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_long // UMLAL_asimdelem_L
                        when ('1', _, '0100') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_int // MLS_asimdelem_R
                        when ('1', _, '0110') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_long // UMLSL_asimdelem_L
                        when ('1', _, '1010') => __encoding aarch64_vector_arithmetic_binary_element_mul_long // UMULL_asimdelem_L
                        when ('1', _, '1011') => __UNALLOCATED
                        when ('1', _, '1101') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_high_simd // SQRDMLAH_asimdelem_R
                        when ('1', _, '1110') => __encoding aarch64_vector_arithmetic_binary_element_dotp // UDOT_asimdelem_D
                        when ('1', _, '1111') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_high_simd // SQRDMLSH_asimdelem_R
                        when ('1', '0x', '1000') => __UNALLOCATED
                        when ('1', '0x', '1100') => __UNALLOCATED
                        when ('1', '00', '0001') => __UNALLOCATED
                        when ('1', '00', '0011') => __UNALLOCATED
                        when ('1', '00', '0101') => __UNALLOCATED
                        when ('1', '00', '0111') => __UNALLOCATED
                        when ('1', '00', '1001') => __encoding aarch64_vector_arithmetic_binary_element_mul_fp16_simd // FMULX_asimdelem_RH_H
                        when ('1', '01', '0xx1') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_complex // FCMLA_asimdelem_C_H
                        when ('1', '1x', '1001') => __encoding aarch64_vector_arithmetic_binary_element_mul_fp_simd // FMULX_asimdelem_R_SD
                        when ('1', '10', '0xx1') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_complex // FCMLA_asimdelem_C_S
                        when ('1', '10', '1000') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_mul_norounding_i_upper // FMLAL2_asimdelem_LH
                        when ('1', '10', '1100') => __encoding aarch64_vector_arithmetic_binary_element_mul_acc_mul_norounding_i_upper // FMLSL2_asimdelem_LH
                        when ('1', '11', '0001') => __UNALLOCATED
                        when ('1', '11', '0011') => __UNALLOCATED
                        when ('1', '11', '0101') => __UNALLOCATED
                        when ('1', '11', '0111') => __UNALLOCATED
                        when ('1', '11', '1000') => __UNALLOCATED
                        when ('1', '11', '1100') => __UNALLOCATED
                when ('1100', _, '00', '10xx', 'xxx10xxxx', _) => // crypto3_imm2
                    __field Rm 16 +: 5
                    __field imm2 12 +: 2
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('00') => __encoding aarch64_vector_crypto_sm3_sm3tt1a // SM3TT1A_VVV4_crypto3_imm2
                        when ('01') => __encoding aarch64_vector_crypto_sm3_sm3tt1b // SM3TT1B_VVV4_crypto3_imm2
                        when ('10') => __encoding aarch64_vector_crypto_sm3_sm3tt2a // SM3TT2A_VVV4_crypto3_imm2
                        when ('11') => __encoding aarch64_vector_crypto_sm3_sm3tt2b // SM3TT2B_VVV_crypto3_imm2
                when ('1100', _, '00', '11xx', 'xxx1x00xx', _) => // cryptosha512_3
                    __field Rm 16 +: 5
                    __field O 14 +: 1
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (O, opcode) of
                        when ('0', '00') => __encoding aarch64_vector_crypto_sha512_sha512h // SHA512H_QQV_cryptosha512_3
                        when ('0', '01') => __encoding aarch64_vector_crypto_sha512_sha512h2 // SHA512H2_QQV_cryptosha512_3
                        when ('0', '10') => __encoding aarch64_vector_crypto_sha512_sha512su1 // SHA512SU1_VVV2_cryptosha512_3
                        when ('0', '11') => __encoding aarch64_vector_crypto_sha3_rax1 // RAX1_VVV2_cryptosha512_3
                        when ('1', '00') => __encoding aarch64_vector_crypto_sm3_sm3partw1 // SM3PARTW1_VVV4_cryptosha512_3
                        when ('1', '01') => __encoding aarch64_vector_crypto_sm3_sm3partw2 // SM3PARTW2_VVV4_cryptosha512_3
                        when ('1', '10') => __encoding aarch64_vector_crypto_sm4_sm4enckey // SM4EKEY_VVV4_cryptosha512_3
                        when ('1', '11') => __UNALLOCATED
                when ('1100', _, '00', _, 'xxx0xxxxx', _) => // crypto4
                    __field Op0 21 +: 2
                    __field Rm 16 +: 5
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Op0) of
                        when ('00') => __encoding aarch64_vector_crypto_sha3_eor3 // EOR3_VVV16_crypto4
                        when ('01') => __encoding aarch64_vector_crypto_sha3_bcax // BCAX_VVV16_crypto4
                        when ('10') => __encoding aarch64_vector_crypto_sm3_sm3ss1 // SM3SS1_VVV4_crypto4
                        when ('11') => __UNALLOCATED
                when ('1100', _, '01', '00xx', _, _) => // crypto3_imm6
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case () of
                        when () => __encoding aarch64_vector_crypto_sha3_xar // XAR_VVV2_crypto3_imm6
                when ('1100', _, '01', '1000', '0001000xx', _) => // cryptosha512_2
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('00') => __encoding aarch64_vector_crypto_sha512_sha512su0 // SHA512SU0_VV2_cryptosha512_2
                        when ('01') => __encoding aarch64_vector_crypto_sm4_sm4enc // SM4E_VV4_cryptosha512_2
                        when ('1x') => __UNALLOCATED
                when ('1xx0', _, '1x', _, _, _) => __UNPREDICTABLE
                when ('x0x1', _, '0x', 'x0xx', _, _) => // float2fix
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field rmode 19 +: 2
                    __field opcode 16 +: 3
                    __field scale 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, ptype, rmode, opcode, scale) of
                        when (_, _, _, _, '1xx', _) => __UNALLOCATED
                        when (_, _, _, 'x0', '00x', _) => __UNALLOCATED
                        when (_, _, _, 'x1', '01x', _) => __UNALLOCATED
                        when (_, _, _, '0x', '00x', _) => __UNALLOCATED
                        when (_, _, _, '1x', '01x', _) => __UNALLOCATED
                        when (_, _, '10', _, _, _) => __UNALLOCATED
                        when (_, '1', _, _, _, _) => __UNALLOCATED
                        when ('0', _, _, _, _, '0xxxxx') => __UNALLOCATED
                        when ('0', '0', '00', '00', '010', _) => __encoding aarch64_float_convert_fix // SCVTF_S32_float2fix
                        when ('0', '0', '00', '00', '011', _) => __encoding aarch64_float_convert_fix // UCVTF_S32_float2fix
                        when ('0', '0', '00', '11', '000', _) => __encoding aarch64_float_convert_fix // FCVTZS_32S_float2fix
                        when ('0', '0', '00', '11', '001', _) => __encoding aarch64_float_convert_fix // FCVTZU_32S_float2fix
                        when ('0', '0', '01', '00', '010', _) => __encoding aarch64_float_convert_fix // SCVTF_D32_float2fix
                        when ('0', '0', '01', '00', '011', _) => __encoding aarch64_float_convert_fix // UCVTF_D32_float2fix
                        when ('0', '0', '01', '11', '000', _) => __encoding aarch64_float_convert_fix // FCVTZS_32D_float2fix
                        when ('0', '0', '01', '11', '001', _) => __encoding aarch64_float_convert_fix // FCVTZU_32D_float2fix
                        when ('0', '0', '11', '00', '010', _) => __encoding aarch64_float_convert_fix // SCVTF_H32_float2fix
                        when ('0', '0', '11', '00', '011', _) => __encoding aarch64_float_convert_fix // UCVTF_H32_float2fix
                        when ('0', '0', '11', '11', '000', _) => __encoding aarch64_float_convert_fix // FCVTZS_32H_float2fix
                        when ('0', '0', '11', '11', '001', _) => __encoding aarch64_float_convert_fix // FCVTZU_32H_float2fix
                        when ('1', '0', '00', '00', '010', _) => __encoding aarch64_float_convert_fix // SCVTF_S64_float2fix
                        when ('1', '0', '00', '00', '011', _) => __encoding aarch64_float_convert_fix // UCVTF_S64_float2fix
                        when ('1', '0', '00', '11', '000', _) => __encoding aarch64_float_convert_fix // FCVTZS_64S_float2fix
                        when ('1', '0', '00', '11', '001', _) => __encoding aarch64_float_convert_fix // FCVTZU_64S_float2fix
                        when ('1', '0', '01', '00', '010', _) => __encoding aarch64_float_convert_fix // SCVTF_D64_float2fix
                        when ('1', '0', '01', '00', '011', _) => __encoding aarch64_float_convert_fix // UCVTF_D64_float2fix
                        when ('1', '0', '01', '11', '000', _) => __encoding aarch64_float_convert_fix // FCVTZS_64D_float2fix
                        when ('1', '0', '01', '11', '001', _) => __encoding aarch64_float_convert_fix // FCVTZU_64D_float2fix
                        when ('1', '0', '11', '00', '010', _) => __encoding aarch64_float_convert_fix // SCVTF_H64_float2fix
                        when ('1', '0', '11', '00', '011', _) => __encoding aarch64_float_convert_fix // UCVTF_H64_float2fix
                        when ('1', '0', '11', '11', '000', _) => __encoding aarch64_float_convert_fix // FCVTZS_64H_float2fix
                        when ('1', '0', '11', '11', '001', _) => __encoding aarch64_float_convert_fix // FCVTZU_64H_float2fix
                when ('x0x1', _, '0x', 'x1xx', 'xxx000000', _) => // float2int
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field rmode 19 +: 2
                    __field opcode 16 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, ptype, rmode, opcode) of
                        when (_, _, _, 'x1', '01x') => __UNALLOCATED
                        when (_, _, _, 'x1', '10x') => __UNALLOCATED
                        when (_, _, _, '1x', '01x') => __UNALLOCATED
                        when (_, _, _, '1x', '10x') => __UNALLOCATED
                        when (_, '0', '10', _, '0xx') => __UNALLOCATED
                        when (_, '0', '10', _, '10x') => __UNALLOCATED
                        when (_, '1', _, _, _) => __UNALLOCATED
                        when ('0', '0', '00', 'x1', '11x') => __UNALLOCATED
                        when ('0', '0', '00', '00', '000') => __encoding aarch64_float_convert_int // FCVTNS_32S_float2int
                        when ('0', '0', '00', '00', '001') => __encoding aarch64_float_convert_int // FCVTNU_32S_float2int
                        when ('0', '0', '00', '00', '010') => __encoding aarch64_float_convert_int // SCVTF_S32_float2int
                        when ('0', '0', '00', '00', '011') => __encoding aarch64_float_convert_int // UCVTF_S32_float2int
                        when ('0', '0', '00', '00', '100') => __encoding aarch64_float_convert_int // FCVTAS_32S_float2int
                        when ('0', '0', '00', '00', '101') => __encoding aarch64_float_convert_int // FCVTAU_32S_float2int
                        when ('0', '0', '00', '00', '110') => __encoding aarch64_float_convert_int // FMOV_32S_float2int
                        when ('0', '0', '00', '00', '111') => __encoding aarch64_float_convert_int // FMOV_S32_float2int
                        when ('0', '0', '00', '01', '000') => __encoding aarch64_float_convert_int // FCVTPS_32S_float2int
                        when ('0', '0', '00', '01', '001') => __encoding aarch64_float_convert_int // FCVTPU_32S_float2int
                        when ('0', '0', '00', '1x', '11x') => __UNALLOCATED
                        when ('0', '0', '00', '10', '000') => __encoding aarch64_float_convert_int // FCVTMS_32S_float2int
                        when ('0', '0', '00', '10', '001') => __encoding aarch64_float_convert_int // FCVTMU_32S_float2int
                        when ('0', '0', '00', '11', '000') => __encoding aarch64_float_convert_int // FCVTZS_32S_float2int
                        when ('0', '0', '00', '11', '001') => __encoding aarch64_float_convert_int // FCVTZU_32S_float2int
                        when ('0', '0', '01', '0x', '11x') => __UNALLOCATED
                        when ('0', '0', '01', '00', '000') => __encoding aarch64_float_convert_int // FCVTNS_32D_float2int
                        when ('0', '0', '01', '00', '001') => __encoding aarch64_float_convert_int // FCVTNU_32D_float2int
                        when ('0', '0', '01', '00', '010') => __encoding aarch64_float_convert_int // SCVTF_D32_float2int
                        when ('0', '0', '01', '00', '011') => __encoding aarch64_float_convert_int // UCVTF_D32_float2int
                        when ('0', '0', '01', '00', '100') => __encoding aarch64_float_convert_int // FCVTAS_32D_float2int
                        when ('0', '0', '01', '00', '101') => __encoding aarch64_float_convert_int // FCVTAU_32D_float2int
                        when ('0', '0', '01', '01', '000') => __encoding aarch64_float_convert_int // FCVTPS_32D_float2int
                        when ('0', '0', '01', '01', '001') => __encoding aarch64_float_convert_int // FCVTPU_32D_float2int
                        when ('0', '0', '01', '10', '000') => __encoding aarch64_float_convert_int // FCVTMS_32D_float2int
                        when ('0', '0', '01', '10', '001') => __encoding aarch64_float_convert_int // FCVTMU_32D_float2int
                        when ('0', '0', '01', '10', '11x') => __UNALLOCATED
                        when ('0', '0', '01', '11', '000') => __encoding aarch64_float_convert_int // FCVTZS_32D_float2int
                        when ('0', '0', '01', '11', '001') => __encoding aarch64_float_convert_int // FCVTZU_32D_float2int
                        when ('0', '0', '01', '11', '110') => __encoding aarch64_float_convert_int // FJCVTZS_32D_float2int
                        when ('0', '0', '01', '11', '111') => __UNALLOCATED
                        when ('0', '0', '10', _, '11x') => __UNALLOCATED
                        when ('0', '0', '11', '00', '000') => __encoding aarch64_float_convert_int // FCVTNS_32H_float2int
                        when ('0', '0', '11', '00', '001') => __encoding aarch64_float_convert_int // FCVTNU_32H_float2int
                        when ('0', '0', '11', '00', '010') => __encoding aarch64_float_convert_int // SCVTF_H32_float2int
                        when ('0', '0', '11', '00', '011') => __encoding aarch64_float_convert_int // UCVTF_H32_float2int
                        when ('0', '0', '11', '00', '100') => __encoding aarch64_float_convert_int // FCVTAS_32H_float2int
                        when ('0', '0', '11', '00', '101') => __encoding aarch64_float_convert_int // FCVTAU_32H_float2int
                        when ('0', '0', '11', '00', '110') => __encoding aarch64_float_convert_int // FMOV_32H_float2int
                        when ('0', '0', '11', '00', '111') => __encoding aarch64_float_convert_int // FMOV_H32_float2int
                        when ('0', '0', '11', '01', '000') => __encoding aarch64_float_convert_int // FCVTPS_32H_float2int
                        when ('0', '0', '11', '01', '001') => __encoding aarch64_float_convert_int // FCVTPU_32H_float2int
                        when ('0', '0', '11', '10', '000') => __encoding aarch64_float_convert_int // FCVTMS_32H_float2int
                        when ('0', '0', '11', '10', '001') => __encoding aarch64_float_convert_int // FCVTMU_32H_float2int
                        when ('0', '0', '11', '11', '000') => __encoding aarch64_float_convert_int // FCVTZS_32H_float2int
                        when ('0', '0', '11', '11', '001') => __encoding aarch64_float_convert_int // FCVTZU_32H_float2int
                        when ('1', '0', '00', _, '11x') => __UNALLOCATED
                        when ('1', '0', '00', '00', '000') => __encoding aarch64_float_convert_int // FCVTNS_64S_float2int
                        when ('1', '0', '00', '00', '001') => __encoding aarch64_float_convert_int // FCVTNU_64S_float2int
                        when ('1', '0', '00', '00', '010') => __encoding aarch64_float_convert_int // SCVTF_S64_float2int
                        when ('1', '0', '00', '00', '011') => __encoding aarch64_float_convert_int // UCVTF_S64_float2int
                        when ('1', '0', '00', '00', '100') => __encoding aarch64_float_convert_int // FCVTAS_64S_float2int
                        when ('1', '0', '00', '00', '101') => __encoding aarch64_float_convert_int // FCVTAU_64S_float2int
                        when ('1', '0', '00', '01', '000') => __encoding aarch64_float_convert_int // FCVTPS_64S_float2int
                        when ('1', '0', '00', '01', '001') => __encoding aarch64_float_convert_int // FCVTPU_64S_float2int
                        when ('1', '0', '00', '10', '000') => __encoding aarch64_float_convert_int // FCVTMS_64S_float2int
                        when ('1', '0', '00', '10', '001') => __encoding aarch64_float_convert_int // FCVTMU_64S_float2int
                        when ('1', '0', '00', '11', '000') => __encoding aarch64_float_convert_int // FCVTZS_64S_float2int
                        when ('1', '0', '00', '11', '001') => __encoding aarch64_float_convert_int // FCVTZU_64S_float2int
                        when ('1', '0', '01', 'x1', '11x') => __UNALLOCATED
                        when ('1', '0', '01', '00', '000') => __encoding aarch64_float_convert_int // FCVTNS_64D_float2int
                        when ('1', '0', '01', '00', '001') => __encoding aarch64_float_convert_int // FCVTNU_64D_float2int
                        when ('1', '0', '01', '00', '010') => __encoding aarch64_float_convert_int // SCVTF_D64_float2int
                        when ('1', '0', '01', '00', '011') => __encoding aarch64_float_convert_int // UCVTF_D64_float2int
                        when ('1', '0', '01', '00', '100') => __encoding aarch64_float_convert_int // FCVTAS_64D_float2int
                        when ('1', '0', '01', '00', '101') => __encoding aarch64_float_convert_int // FCVTAU_64D_float2int
                        when ('1', '0', '01', '00', '110') => __encoding aarch64_float_convert_int // FMOV_64D_float2int
                        when ('1', '0', '01', '00', '111') => __encoding aarch64_float_convert_int // FMOV_D64_float2int
                        when ('1', '0', '01', '01', '000') => __encoding aarch64_float_convert_int // FCVTPS_64D_float2int
                        when ('1', '0', '01', '01', '001') => __encoding aarch64_float_convert_int // FCVTPU_64D_float2int
                        when ('1', '0', '01', '1x', '11x') => __UNALLOCATED
                        when ('1', '0', '01', '10', '000') => __encoding aarch64_float_convert_int // FCVTMS_64D_float2int
                        when ('1', '0', '01', '10', '001') => __encoding aarch64_float_convert_int // FCVTMU_64D_float2int
                        when ('1', '0', '01', '11', '000') => __encoding aarch64_float_convert_int // FCVTZS_64D_float2int
                        when ('1', '0', '01', '11', '001') => __encoding aarch64_float_convert_int // FCVTZU_64D_float2int
                        when ('1', '0', '10', 'x0', '11x') => __UNALLOCATED
                        when ('1', '0', '10', '01', '110') => __encoding aarch64_float_convert_int // FMOV_64VX_float2int
                        when ('1', '0', '10', '01', '111') => __encoding aarch64_float_convert_int // FMOV_V64I_float2int
                        when ('1', '0', '10', '1x', '11x') => __UNALLOCATED
                        when ('1', '0', '11', '00', '000') => __encoding aarch64_float_convert_int // FCVTNS_64H_float2int
                        when ('1', '0', '11', '00', '001') => __encoding aarch64_float_convert_int // FCVTNU_64H_float2int
                        when ('1', '0', '11', '00', '010') => __encoding aarch64_float_convert_int // SCVTF_H64_float2int
                        when ('1', '0', '11', '00', '011') => __encoding aarch64_float_convert_int // UCVTF_H64_float2int
                        when ('1', '0', '11', '00', '100') => __encoding aarch64_float_convert_int // FCVTAS_64H_float2int
                        when ('1', '0', '11', '00', '101') => __encoding aarch64_float_convert_int // FCVTAU_64H_float2int
                        when ('1', '0', '11', '00', '110') => __encoding aarch64_float_convert_int // FMOV_64H_float2int
                        when ('1', '0', '11', '00', '111') => __encoding aarch64_float_convert_int // FMOV_H64_float2int
                        when ('1', '0', '11', '01', '000') => __encoding aarch64_float_convert_int // FCVTPS_64H_float2int
                        when ('1', '0', '11', '01', '001') => __encoding aarch64_float_convert_int // FCVTPU_64H_float2int
                        when ('1', '0', '11', '10', '000') => __encoding aarch64_float_convert_int // FCVTMS_64H_float2int
                        when ('1', '0', '11', '10', '001') => __encoding aarch64_float_convert_int // FCVTMU_64H_float2int
                        when ('1', '0', '11', '11', '000') => __encoding aarch64_float_convert_int // FCVTZS_64H_float2int
                        when ('1', '0', '11', '11', '001') => __encoding aarch64_float_convert_int // FCVTZU_64H_float2int
                when ('x0x1', _, '0x', 'x1xx', 'xxxx10000', _) => // floatdp1
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field opcode 15 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ptype, opcode) of
                        when (_, _, _, '1xxxxx') => __UNALLOCATED
                        when (_, '1', _, _) => __UNALLOCATED
                        when ('0', '0', '00', '000000') => __encoding aarch64_float_arithmetic_unary // FMOV_S_floatdp1
                        when ('0', '0', '00', '000001') => __encoding aarch64_float_arithmetic_unary // FABS_S_floatdp1
                        when ('0', '0', '00', '000010') => __encoding aarch64_float_arithmetic_unary // FNEG_S_floatdp1
                        when ('0', '0', '00', '000011') => __encoding aarch64_float_arithmetic_unary // FSQRT_S_floatdp1
                        when ('0', '0', '00', '000100') => __UNALLOCATED
                        when ('0', '0', '00', '000101') => __encoding aarch64_float_convert_fp // FCVT_DS_floatdp1
                        when ('0', '0', '00', '000110') => __UNALLOCATED
                        when ('0', '0', '00', '000111') => __encoding aarch64_float_convert_fp // FCVT_HS_floatdp1
                        when ('0', '0', '00', '001000') => __encoding aarch64_float_arithmetic_round_frint // FRINTN_S_floatdp1
                        when ('0', '0', '00', '001001') => __encoding aarch64_float_arithmetic_round_frint // FRINTP_S_floatdp1
                        when ('0', '0', '00', '001010') => __encoding aarch64_float_arithmetic_round_frint // FRINTM_S_floatdp1
                        when ('0', '0', '00', '001011') => __encoding aarch64_float_arithmetic_round_frint // FRINTZ_S_floatdp1
                        when ('0', '0', '00', '001100') => __encoding aarch64_float_arithmetic_round_frint // FRINTA_S_floatdp1
                        when ('0', '0', '00', '001101') => __UNALLOCATED
                        when ('0', '0', '00', '001110') => __encoding aarch64_float_arithmetic_round_frint // FRINTX_S_floatdp1
                        when ('0', '0', '00', '001111') => __encoding aarch64_float_arithmetic_round_frint // FRINTI_S_floatdp1
                        when ('0', '0', '00', '010000') => __encoding aarch64_float_arithmetic_round_frint_32_64 // FRINT32Z_S_floatdp1
                        when ('0', '0', '00', '010001') => __encoding aarch64_float_arithmetic_round_frint_32_64 // FRINT32X_S_floatdp1
                        when ('0', '0', '00', '010010') => __encoding aarch64_float_arithmetic_round_frint_32_64 // FRINT64Z_S_floatdp1
                        when ('0', '0', '00', '010011') => __encoding aarch64_float_arithmetic_round_frint_32_64 // FRINT64X_S_floatdp1
                        when ('0', '0', '00', '0101xx') => __UNALLOCATED
                        when ('0', '0', '00', '011xxx') => __UNALLOCATED
                        when ('0', '0', '01', '000000') => __encoding aarch64_float_arithmetic_unary // FMOV_D_floatdp1
                        when ('0', '0', '01', '000001') => __encoding aarch64_float_arithmetic_unary // FABS_D_floatdp1
                        when ('0', '0', '01', '000010') => __encoding aarch64_float_arithmetic_unary // FNEG_D_floatdp1
                        when ('0', '0', '01', '000011') => __encoding aarch64_float_arithmetic_unary // FSQRT_D_floatdp1
                        when ('0', '0', '01', '000100') => __encoding aarch64_float_convert_fp // FCVT_SD_floatdp1
                        when ('0', '0', '01', '000101') => __UNALLOCATED
                        when ('0', '0', '01', '000110') => __encoding aarch64_vector_cvt_bf16_scalar // BFCVT_BS_floatdp1
                        when ('0', '0', '01', '000111') => __encoding aarch64_float_convert_fp // FCVT_HD_floatdp1
                        when ('0', '0', '01', '001000') => __encoding aarch64_float_arithmetic_round_frint // FRINTN_D_floatdp1
                        when ('0', '0', '01', '001001') => __encoding aarch64_float_arithmetic_round_frint // FRINTP_D_floatdp1
                        when ('0', '0', '01', '001010') => __encoding aarch64_float_arithmetic_round_frint // FRINTM_D_floatdp1
                        when ('0', '0', '01', '001011') => __encoding aarch64_float_arithmetic_round_frint // FRINTZ_D_floatdp1
                        when ('0', '0', '01', '001100') => __encoding aarch64_float_arithmetic_round_frint // FRINTA_D_floatdp1
                        when ('0', '0', '01', '001101') => __UNALLOCATED
                        when ('0', '0', '01', '001110') => __encoding aarch64_float_arithmetic_round_frint // FRINTX_D_floatdp1
                        when ('0', '0', '01', '001111') => __encoding aarch64_float_arithmetic_round_frint // FRINTI_D_floatdp1
                        when ('0', '0', '01', '010000') => __encoding aarch64_float_arithmetic_round_frint_32_64 // FRINT32Z_D_floatdp1
                        when ('0', '0', '01', '010001') => __encoding aarch64_float_arithmetic_round_frint_32_64 // FRINT32X_D_floatdp1
                        when ('0', '0', '01', '010010') => __encoding aarch64_float_arithmetic_round_frint_32_64 // FRINT64Z_D_floatdp1
                        when ('0', '0', '01', '010011') => __encoding aarch64_float_arithmetic_round_frint_32_64 // FRINT64X_D_floatdp1
                        when ('0', '0', '01', '0101xx') => __UNALLOCATED
                        when ('0', '0', '01', '011xxx') => __UNALLOCATED
                        when ('0', '0', '10', '0xxxxx') => __UNALLOCATED
                        when ('0', '0', '11', '000000') => __encoding aarch64_float_arithmetic_unary // FMOV_H_floatdp1
                        when ('0', '0', '11', '000001') => __encoding aarch64_float_arithmetic_unary // FABS_H_floatdp1
                        when ('0', '0', '11', '000010') => __encoding aarch64_float_arithmetic_unary // FNEG_H_floatdp1
                        when ('0', '0', '11', '000011') => __encoding aarch64_float_arithmetic_unary // FSQRT_H_floatdp1
                        when ('0', '0', '11', '000100') => __encoding aarch64_float_convert_fp // FCVT_SH_floatdp1
                        when ('0', '0', '11', '000101') => __encoding aarch64_float_convert_fp // FCVT_DH_floatdp1
                        when ('0', '0', '11', '00011x') => __UNALLOCATED
                        when ('0', '0', '11', '001000') => __encoding aarch64_float_arithmetic_round_frint // FRINTN_H_floatdp1
                        when ('0', '0', '11', '001001') => __encoding aarch64_float_arithmetic_round_frint // FRINTP_H_floatdp1
                        when ('0', '0', '11', '001010') => __encoding aarch64_float_arithmetic_round_frint // FRINTM_H_floatdp1
                        when ('0', '0', '11', '001011') => __encoding aarch64_float_arithmetic_round_frint // FRINTZ_H_floatdp1
                        when ('0', '0', '11', '001100') => __encoding aarch64_float_arithmetic_round_frint // FRINTA_H_floatdp1
                        when ('0', '0', '11', '001101') => __UNALLOCATED
                        when ('0', '0', '11', '001110') => __encoding aarch64_float_arithmetic_round_frint // FRINTX_H_floatdp1
                        when ('0', '0', '11', '001111') => __encoding aarch64_float_arithmetic_round_frint // FRINTI_H_floatdp1
                        when ('0', '0', '11', '01xxxx') => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxx1000', _) => // floatcmp
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field Rm 16 +: 5
                    __field op 14 +: 2
                    __field Rn 5 +: 5
                    __field opcode2 0 +: 5
                    case (M, S, ptype, op, opcode2) of
                        when (_, _, _, _, 'xxxx1') => __UNALLOCATED
                        when (_, _, _, _, 'xxx1x') => __UNALLOCATED
                        when (_, _, _, _, 'xx1xx') => __UNALLOCATED
                        when (_, _, _, 'x1', _) => __UNALLOCATED
                        when (_, _, _, '1x', _) => __UNALLOCATED
                        when (_, _, '10', _, _) => __UNALLOCATED
                        when (_, '1', _, _, _) => __UNALLOCATED
                        when ('0', '0', '00', '00', '00000') => __encoding aarch64_float_compare_uncond // FCMP_S_floatcmp
                        when ('0', '0', '00', '00', '01000') => __encoding aarch64_float_compare_uncond // FCMP_SZ_floatcmp
                        when ('0', '0', '00', '00', '10000') => __encoding aarch64_float_compare_uncond // FCMPE_S_floatcmp
                        when ('0', '0', '00', '00', '11000') => __encoding aarch64_float_compare_uncond // FCMPE_SZ_floatcmp
                        when ('0', '0', '01', '00', '00000') => __encoding aarch64_float_compare_uncond // FCMP_D_floatcmp
                        when ('0', '0', '01', '00', '01000') => __encoding aarch64_float_compare_uncond // FCMP_DZ_floatcmp
                        when ('0', '0', '01', '00', '10000') => __encoding aarch64_float_compare_uncond // FCMPE_D_floatcmp
                        when ('0', '0', '01', '00', '11000') => __encoding aarch64_float_compare_uncond // FCMPE_DZ_floatcmp
                        when ('0', '0', '11', '00', '00000') => __encoding aarch64_float_compare_uncond // FCMP_H_floatcmp
                        when ('0', '0', '11', '00', '01000') => __encoding aarch64_float_compare_uncond // FCMP_HZ_floatcmp
                        when ('0', '0', '11', '00', '10000') => __encoding aarch64_float_compare_uncond // FCMPE_H_floatcmp
                        when ('0', '0', '11', '00', '11000') => __encoding aarch64_float_compare_uncond // FCMPE_HZ_floatcmp
                        when ('1', _, _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxx100', _) => // floatimm
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field imm8 13 +: 8
                    __field imm5 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ptype, imm5) of
                        when (_, _, _, 'xxxx1') => __UNALLOCATED
                        when (_, _, _, 'xxx1x') => __UNALLOCATED
                        when (_, _, _, 'xx1xx') => __UNALLOCATED
                        when (_, _, _, 'x1xxx') => __UNALLOCATED
                        when (_, _, _, '1xxxx') => __UNALLOCATED
                        when (_, _, '10', _) => __UNALLOCATED
                        when (_, '1', _, _) => __UNALLOCATED
                        when ('0', '0', '00', '00000') => __encoding aarch64_float_move_fp_imm // FMOV_S_floatimm
                        when ('0', '0', '01', '00000') => __encoding aarch64_float_move_fp_imm // FMOV_D_floatimm
                        when ('0', '0', '11', '00000') => __encoding aarch64_float_move_fp_imm // FMOV_H_floatimm
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx01', _) => // floatccmp
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field Rn 5 +: 5
                    __field op 4 +: 1
                    __field nzcv 0 +: 4
                    case (M, S, ptype, op) of
                        when (_, _, '10', _) => __UNALLOCATED
                        when (_, '1', _, _) => __UNALLOCATED
                        when ('0', '0', '00', '0') => __encoding aarch64_float_compare_cond // FCCMP_S_floatccmp
                        when ('0', '0', '00', '1') => __encoding aarch64_float_compare_cond // FCCMPE_S_floatccmp
                        when ('0', '0', '01', '0') => __encoding aarch64_float_compare_cond // FCCMP_D_floatccmp
                        when ('0', '0', '01', '1') => __encoding aarch64_float_compare_cond // FCCMPE_D_floatccmp
                        when ('0', '0', '11', '0') => __encoding aarch64_float_compare_cond // FCCMP_H_floatccmp
                        when ('0', '0', '11', '1') => __encoding aarch64_float_compare_cond // FCCMPE_H_floatccmp
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx10', _) => // floatdp2
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ptype, opcode) of
                        when (_, _, _, '1xx1') => __UNALLOCATED
                        when (_, _, _, '1x1x') => __UNALLOCATED
                        when (_, _, _, '11xx') => __UNALLOCATED
                        when (_, _, '10', _) => __UNALLOCATED
                        when (_, '1', _, _) => __UNALLOCATED
                        when ('0', '0', '00', '0000') => __encoding aarch64_float_arithmetic_mul_product // FMUL_S_floatdp2
                        when ('0', '0', '00', '0001') => __encoding aarch64_float_arithmetic_div // FDIV_S_floatdp2
                        when ('0', '0', '00', '0010') => __encoding aarch64_float_arithmetic_add_sub // FADD_S_floatdp2
                        when ('0', '0', '00', '0011') => __encoding aarch64_float_arithmetic_add_sub // FSUB_S_floatdp2
                        when ('0', '0', '00', '0100') => __encoding aarch64_float_arithmetic_max_min // FMAX_S_floatdp2
                        when ('0', '0', '00', '0101') => __encoding aarch64_float_arithmetic_max_min // FMIN_S_floatdp2
                        when ('0', '0', '00', '0110') => __encoding aarch64_float_arithmetic_max_min // FMAXNM_S_floatdp2
                        when ('0', '0', '00', '0111') => __encoding aarch64_float_arithmetic_max_min // FMINNM_S_floatdp2
                        when ('0', '0', '00', '1000') => __encoding aarch64_float_arithmetic_mul_product // FNMUL_S_floatdp2
                        when ('0', '0', '01', '0000') => __encoding aarch64_float_arithmetic_mul_product // FMUL_D_floatdp2
                        when ('0', '0', '01', '0001') => __encoding aarch64_float_arithmetic_div // FDIV_D_floatdp2
                        when ('0', '0', '01', '0010') => __encoding aarch64_float_arithmetic_add_sub // FADD_D_floatdp2
                        when ('0', '0', '01', '0011') => __encoding aarch64_float_arithmetic_add_sub // FSUB_D_floatdp2
                        when ('0', '0', '01', '0100') => __encoding aarch64_float_arithmetic_max_min // FMAX_D_floatdp2
                        when ('0', '0', '01', '0101') => __encoding aarch64_float_arithmetic_max_min // FMIN_D_floatdp2
                        when ('0', '0', '01', '0110') => __encoding aarch64_float_arithmetic_max_min // FMAXNM_D_floatdp2
                        when ('0', '0', '01', '0111') => __encoding aarch64_float_arithmetic_max_min // FMINNM_D_floatdp2
                        when ('0', '0', '01', '1000') => __encoding aarch64_float_arithmetic_mul_product // FNMUL_D_floatdp2
                        when ('0', '0', '11', '0000') => __encoding aarch64_float_arithmetic_mul_product // FMUL_H_floatdp2
                        when ('0', '0', '11', '0001') => __encoding aarch64_float_arithmetic_div // FDIV_H_floatdp2
                        when ('0', '0', '11', '0010') => __encoding aarch64_float_arithmetic_add_sub // FADD_H_floatdp2
                        when ('0', '0', '11', '0011') => __encoding aarch64_float_arithmetic_add_sub // FSUB_H_floatdp2
                        when ('0', '0', '11', '0100') => __encoding aarch64_float_arithmetic_max_min // FMAX_H_floatdp2
                        when ('0', '0', '11', '0101') => __encoding aarch64_float_arithmetic_max_min // FMIN_H_floatdp2
                        when ('0', '0', '11', '0110') => __encoding aarch64_float_arithmetic_max_min // FMAXNM_H_floatdp2
                        when ('0', '0', '11', '0111') => __encoding aarch64_float_arithmetic_max_min // FMINNM_H_floatdp2
                        when ('0', '0', '11', '1000') => __encoding aarch64_float_arithmetic_mul_product // FNMUL_H_floatdp2
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx11', _) => // floatsel
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ptype) of
                        when (_, _, '10') => __UNALLOCATED
                        when (_, '1', _) => __UNALLOCATED
                        when ('0', '0', '00') => __encoding aarch64_float_move_fp_select // FCSEL_S_floatsel
                        when ('0', '0', '01') => __encoding aarch64_float_move_fp_select // FCSEL_D_floatsel
                        when ('0', '0', '11') => __encoding aarch64_float_move_fp_select // FCSEL_H_floatsel
                        when ('1', _, _) => __UNALLOCATED
                when ('x0x1', _, '1x', _, _, _) => // floatdp3
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ptype 22 +: 2
                    __field o1 21 +: 1
                    __field Rm 16 +: 5
                    __field o0 15 +: 1
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ptype, o1, o0) of
                        when (_, _, '10', _, _) => __UNALLOCATED
                        when (_, '1', _, _, _) => __UNALLOCATED
                        when ('0', '0', '00', '0', '0') => __encoding aarch64_float_arithmetic_mul_add_sub // FMADD_S_floatdp3
                        when ('0', '0', '00', '0', '1') => __encoding aarch64_float_arithmetic_mul_add_sub // FMSUB_S_floatdp3
                        when ('0', '0', '00', '1', '0') => __encoding aarch64_float_arithmetic_mul_add_sub // FNMADD_S_floatdp3
                        when ('0', '0', '00', '1', '1') => __encoding aarch64_float_arithmetic_mul_add_sub // FNMSUB_S_floatdp3
                        when ('0', '0', '01', '0', '0') => __encoding aarch64_float_arithmetic_mul_add_sub // FMADD_D_floatdp3
                        when ('0', '0', '01', '0', '1') => __encoding aarch64_float_arithmetic_mul_add_sub // FMSUB_D_floatdp3
                        when ('0', '0', '01', '1', '0') => __encoding aarch64_float_arithmetic_mul_add_sub // FNMADD_D_floatdp3
                        when ('0', '0', '01', '1', '1') => __encoding aarch64_float_arithmetic_mul_add_sub // FNMSUB_D_floatdp3
                        when ('0', '0', '11', '0', '0') => __encoding aarch64_float_arithmetic_mul_add_sub // FMADD_H_floatdp3
                        when ('0', '0', '11', '0', '1') => __encoding aarch64_float_arithmetic_mul_add_sub // FMSUB_H_floatdp3
                        when ('0', '0', '11', '1', '0') => __encoding aarch64_float_arithmetic_mul_add_sub // FNMADD_H_floatdp3
                        when ('0', '0', '11', '1', '1') => __encoding aarch64_float_arithmetic_mul_add_sub // FNMSUB_H_floatdp3
                        when ('1', _, _, _, _) => __UNALLOCATED

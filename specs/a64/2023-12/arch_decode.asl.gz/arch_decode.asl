__decode A64
    // A64
    case (31 +: 1, 29 +: 2, 25 +: 4, 0 +: 25) of
        when ('0', _, '0000', _) =>
            // reserved
            case (31 +: 1, 29 +: 2, 25 +: 4, 16 +: 9, 0 +: 16) of
                when (_, '00', _, '000000000', _) => // perm_undef
                    __field imm16 0 +: 16
                    case () of
                        when () => __encoding A64_reserved_perm_undef_UDF_only_perm_undef // UDF_only_perm_undef
                when (_, '00', _, '000000001', _) => __UNPREDICTABLE
                when (_, '00', _, '00000001x', _) => __UNPREDICTABLE
                when (_, '00', _, '0000001xx', _) => __UNPREDICTABLE
                when (_, '00', _, '000001xxx', _) => __UNPREDICTABLE
                when (_, '00', _, '00001xxxx', _) => __UNPREDICTABLE
                when (_, '00', _, '0001xxxxx', _) => __UNPREDICTABLE
                when (_, '00', _, '001xxxxxx', _) => __UNPREDICTABLE
                when (_, '00', _, '01xxxxxxx', _) => __UNPREDICTABLE
                when (_, '00', _, '1xxxxxxxx', _) => __UNPREDICTABLE
                when (_, '01', _, _, _) => __UNPREDICTABLE
                when (_, '1x', _, _, _) => __UNPREDICTABLE
        when ('1', _, '0000', _) =>
            // sme
            case (31 +: 1, 29 +: 2, 25 +: 4, 10 +: 15, 5 +: 5, 1 +: 4, 0 +: 1) of
                when (_, '0x', _, 'x10xxxxxxxxxxxx', _, 'xx1x', _) => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxxxxxxxxx', _, 'x0xx', _) =>
                    // mortlach_64bit_prod
                    case (30 +: 2, 29 +: 1, 25 +: 4, 24 +: 1, 22 +: 2, 21 +: 1, 4 +: 17, 3 +: 1, 0 +: 3) of
                        when (_, '0', _, '0', _, '0', _, _, _) => // mortlach_f64f64_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMOPA_ZA_PP_ZZ_64 // fmopa_za_pp_zz_64
                                when ('1') => __encoding FMOPS_ZA_PP_ZZ_64 // fmops_za_pp_zz_64
                        when (_, '0', _, '0', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _) => // mortlach_i16i64_prod
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 3
                            case (u0, u1, S) of
                                when ('0', '0', '0') => __encoding SMOPA_ZA_PP_ZZ_64 // smopa_za_pp_zz_64
                                when ('0', '0', '1') => __encoding SMOPS_ZA_PP_ZZ_64 // smops_za_pp_zz_64
                                when ('0', '1', '0') => __encoding SUMOPA_ZA_PP_ZZ_64 // sumopa_za_pp_zz_64
                                when ('0', '1', '1') => __encoding SUMOPS_ZA_PP_ZZ_64 // sumops_za_pp_zz_64
                                when ('1', '0', '0') => __encoding USMOPA_ZA_PP_ZZ_64 // usmopa_za_pp_zz_64
                                when ('1', '0', '1') => __encoding USMOPS_ZA_PP_ZZ_64 // usmops_za_pp_zz_64
                                when ('1', '1', '0') => __encoding UMOPA_ZA_PP_ZZ_64 // umopa_za_pp_zz_64
                                when ('1', '1', '1') => __encoding UMOPS_ZA_PP_ZZ_64 // umops_za_pp_zz_64
                when (_, '0x', _, 'x11xxxxxxxxxxxx', _, 'x1xx', _) => __UNPREDICTABLE
                when (_, '00', _, 'x0xxxxxxxxxxxxx', _, _, _) => __UNPREDICTABLE
                when (_, '00', _, 'x10xxxxxxxxxxxx', _, 'x00x', _) =>
                    // mortlach_32bit_fp_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 5 +: 16, 4 +: 1, 2 +: 2, 0 +: 2) of
                        when (_, '0', _, '0', _, _, _, _) => // mortlach_f32f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding FMOPA_ZA_PP_ZZ_32 // fmopa_za_pp_zz_32
                                when ('1') => __encoding FMOPS_ZA_PP_ZZ_32 // fmops_za_pp_zz_32
                        when (_, '0', _, '1', _, '0', _, _) => // mortlach_f8f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field ZAda 0 +: 2
                            case () of
                                when () => __encoding FMOPA_ZA32_PP_Z8Z8_8 // fmopa_za32_pp_z8z8_8
                        when (_, '0', _, '1', _, '1', _, _) => __UNPREDICTABLE
                        when (_, '1', _, '0', _, _, _, _) => // mortlach_b16f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding BFMOPA_ZA32_PP_ZZ__ // bfmopa_za32_pp_zz_
                                when ('1') => __encoding BFMOPS_ZA32_PP_ZZ__ // bfmops_za32_pp_zz_
                        when (_, '1', _, '1', _, _, _, _) => // mortlach_f16f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding FMOPA_ZA32_PP_ZZ_16 // fmopa_za32_pp_zz_16
                                when ('1') => __encoding FMOPS_ZA32_PP_ZZ_16 // fmops_za32_pp_zz_16
                when (_, '00', _, 'x10xxxxxxxxxxxx', _, 'x10x', _) =>
                    // mortlach2_misc_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 5 +: 16, 4 +: 1, 2 +: 2, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, '0', _, _, _, _, _) => // mortlach_bini32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding BMOPA_ZA_PP_ZZ_32 // bmopa_za_pp_zz_32
                                when ('1') => __encoding BMOPS_ZA_PP_ZZ_32 // bmops_za_pp_zz_32
                        when (_, '0', _, '1', _, '0', _, '0', _) => // mortlach_f8f16_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field ZAda 0 +: 1
                            case () of
                                when () => __encoding FMOPA_ZA16_PP_Z8Z8_8 // fmopa_za16_pp_z8z8_8
                        when (_, '0', _, '1', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, '0', _, _, _, '0', _) => // mortlach_f16f16_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 1
                            case (S) of
                                when ('0') => __encoding FMOPA_ZA_PP_ZZ_16 // fmopa_za_pp_zz_16
                                when ('1') => __encoding FMOPS_ZA_PP_ZZ_16 // fmops_za_pp_zz_16
                        when (_, '1', _, '1', _, _, _, '0', _) => // mortlach_b16b16_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 1
                            case (S) of
                                when ('0') => __encoding BFMOPA_ZA_PP_ZZ_16 // bfmopa_za_pp_zz_16
                                when ('1') => __encoding BFMOPS_ZA_PP_ZZ_16 // bfmops_za_pp_zz_16
                        when (_, '1', _, _, _, _, _, '1', _) => __UNPREDICTABLE
                when (_, '01', _, 'x10xxxxxxxxxxxx', _, 'xx0x', _) =>
                    // mortlach_32bit_int_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 4 +: 17, 3 +: 1, 2 +: 1, 0 +: 2) of
                        when (_, _, _, '0', _, '1', _, _) => // mortlach_i16i32_prod
                            __field u0 24 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (u0, S) of
                                when ('0', '0') => __encoding SMOPA_ZA32_PP_ZZ_16 // smopa_za32_pp_zz_16
                                when ('0', '1') => __encoding SMOPS_ZA32_PP_ZZ_16 // smops_za32_pp_zz_16
                                when ('1', '0') => __encoding UMOPA_ZA32_PP_ZZ_16 // umopa_za32_pp_zz_16
                                when ('1', '1') => __encoding UMOPS_ZA32_PP_ZZ_16 // umops_za32_pp_zz_16
                        when (_, _, _, '1', _, '1', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', _, _) => // mortlach_i8i32_prod
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (u0, u1, S) of
                                when ('0', '0', '0') => __encoding SMOPA_ZA_PP_ZZ_32 // smopa_za_pp_zz_32
                                when ('0', '0', '1') => __encoding SMOPS_ZA_PP_ZZ_32 // smops_za_pp_zz_32
                                when ('0', '1', '0') => __encoding SUMOPA_ZA_PP_ZZ_32 // sumopa_za_pp_zz_32
                                when ('0', '1', '1') => __encoding SUMOPS_ZA_PP_ZZ_32 // sumops_za_pp_zz_32
                                when ('1', '0', '0') => __encoding USMOPA_ZA_PP_ZZ_32 // usmopa_za_pp_zz_32
                                when ('1', '0', '1') => __encoding USMOPS_ZA_PP_ZZ_32 // usmops_za_pp_zz_32
                                when ('1', '1', '0') => __encoding UMOPA_ZA_PP_ZZ_32 // umopa_za_pp_zz_32
                                when ('1', '1', '1') => __encoding UMOPS_ZA_PP_ZZ_32 // umops_za_pp_zz_32
                when (_, '01', _, '00xxxxxxxxxxxxx', _, _, _) =>
                    // mortlach_multi_mem_ctg
                    case (23 +: 9, 20 +: 3, 16 +: 4, 15 +: 1, 2 +: 13, 1 +: 1, 0 +: 1) of
                        when (_, '00x', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZ_P_BR_2 // ld1b_mz_p_br_2
                                when ('00', '1') => __encoding LDNT1B_MZ_P_BR_2 // ldnt1b_mz_p_br_2
                                when ('01', '0') => __encoding LD1H_MZ_P_BR_2 // ld1h_mz_p_br_2
                                when ('01', '1') => __encoding LDNT1H_MZ_P_BR_2 // ldnt1h_mz_p_br_2
                                when ('10', '0') => __encoding LD1W_MZ_P_BR_2 // ld1w_mz_p_br_2
                                when ('10', '1') => __encoding LDNT1W_MZ_P_BR_2 // ldnt1w_mz_p_br_2
                                when ('11', '0') => __encoding LD1D_MZ_P_BR_2 // ld1d_mz_p_br_2
                                when ('11', '1') => __encoding LDNT1D_MZ_P_BR_2 // ldnt1d_mz_p_br_2
                        when (_, '00x', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZ_P_BR_4 // ld1b_mz_p_br_4
                                when ('00', '1') => __encoding LDNT1B_MZ_P_BR_4 // ldnt1b_mz_p_br_4
                                when ('01', '0') => __encoding LD1H_MZ_P_BR_4 // ld1h_mz_p_br_4
                                when ('01', '1') => __encoding LDNT1H_MZ_P_BR_4 // ldnt1h_mz_p_br_4
                                when ('10', '0') => __encoding LD1W_MZ_P_BR_4 // ld1w_mz_p_br_4
                                when ('10', '1') => __encoding LDNT1W_MZ_P_BR_4 // ldnt1w_mz_p_br_4
                                when ('11', '0') => __encoding LD1D_MZ_P_BR_4 // ld1d_mz_p_br_4
                                when ('11', '1') => __encoding LDNT1D_MZ_P_BR_4 // ldnt1d_mz_p_br_4
                        when (_, '01x', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZ_P_BR_2 // st1b_mz_p_br_2
                                when ('00', '1') => __encoding STNT1B_MZ_P_BR_2 // stnt1b_mz_p_br_2
                                when ('01', '0') => __encoding ST1H_MZ_P_BR_2 // st1h_mz_p_br_2
                                when ('01', '1') => __encoding STNT1H_MZ_P_BR_2 // stnt1h_mz_p_br_2
                                when ('10', '0') => __encoding ST1W_MZ_P_BR_2 // st1w_mz_p_br_2
                                when ('10', '1') => __encoding STNT1W_MZ_P_BR_2 // stnt1w_mz_p_br_2
                                when ('11', '0') => __encoding ST1D_MZ_P_BR_2 // st1d_mz_p_br_2
                                when ('11', '1') => __encoding STNT1D_MZ_P_BR_2 // stnt1d_mz_p_br_2
                        when (_, '01x', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZ_P_BR_4 // st1b_mz_p_br_4
                                when ('00', '1') => __encoding STNT1B_MZ_P_BR_4 // stnt1b_mz_p_br_4
                                when ('01', '0') => __encoding ST1H_MZ_P_BR_4 // st1h_mz_p_br_4
                                when ('01', '1') => __encoding STNT1H_MZ_P_BR_4 // stnt1h_mz_p_br_4
                                when ('10', '0') => __encoding ST1W_MZ_P_BR_4 // st1w_mz_p_br_4
                                when ('10', '1') => __encoding STNT1W_MZ_P_BR_4 // stnt1w_mz_p_br_4
                                when ('11', '0') => __encoding ST1D_MZ_P_BR_4 // st1d_mz_p_br_4
                                when ('11', '1') => __encoding STNT1D_MZ_P_BR_4 // stnt1d_mz_p_br_4
                        when (_, '0xx', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '100', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZ_P_BI_2 // ld1b_mz_p_bi_2
                                when ('00', '1') => __encoding LDNT1B_MZ_P_BI_2 // ldnt1b_mz_p_bi_2
                                when ('01', '0') => __encoding LD1H_MZ_P_BI_2 // ld1h_mz_p_bi_2
                                when ('01', '1') => __encoding LDNT1H_MZ_P_BI_2 // ldnt1h_mz_p_bi_2
                                when ('10', '0') => __encoding LD1W_MZ_P_BI_2 // ld1w_mz_p_bi_2
                                when ('10', '1') => __encoding LDNT1W_MZ_P_BI_2 // ldnt1w_mz_p_bi_2
                                when ('11', '0') => __encoding LD1D_MZ_P_BI_2 // ld1d_mz_p_bi_2
                                when ('11', '1') => __encoding LDNT1D_MZ_P_BI_2 // ldnt1d_mz_p_bi_2
                        when (_, '100', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZ_P_BI_4 // ld1b_mz_p_bi_4
                                when ('00', '1') => __encoding LDNT1B_MZ_P_BI_4 // ldnt1b_mz_p_bi_4
                                when ('01', '0') => __encoding LD1H_MZ_P_BI_4 // ld1h_mz_p_bi_4
                                when ('01', '1') => __encoding LDNT1H_MZ_P_BI_4 // ldnt1h_mz_p_bi_4
                                when ('10', '0') => __encoding LD1W_MZ_P_BI_4 // ld1w_mz_p_bi_4
                                when ('10', '1') => __encoding LDNT1W_MZ_P_BI_4 // ldnt1w_mz_p_bi_4
                                when ('11', '0') => __encoding LD1D_MZ_P_BI_4 // ld1d_mz_p_bi_4
                                when ('11', '1') => __encoding LDNT1D_MZ_P_BI_4 // ldnt1d_mz_p_bi_4
                        when (_, '110', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZ_P_BI_2 // st1b_mz_p_bi_2
                                when ('00', '1') => __encoding STNT1B_MZ_P_BI_2 // stnt1b_mz_p_bi_2
                                when ('01', '0') => __encoding ST1H_MZ_P_BI_2 // st1h_mz_p_bi_2
                                when ('01', '1') => __encoding STNT1H_MZ_P_BI_2 // stnt1h_mz_p_bi_2
                                when ('10', '0') => __encoding ST1W_MZ_P_BI_2 // st1w_mz_p_bi_2
                                when ('10', '1') => __encoding STNT1W_MZ_P_BI_2 // stnt1w_mz_p_bi_2
                                when ('11', '0') => __encoding ST1D_MZ_P_BI_2 // st1d_mz_p_bi_2
                                when ('11', '1') => __encoding STNT1D_MZ_P_BI_2 // stnt1d_mz_p_bi_2
                        when (_, '110', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZ_P_BI_4 // st1b_mz_p_bi_4
                                when ('00', '1') => __encoding STNT1B_MZ_P_BI_4 // stnt1b_mz_p_bi_4
                                when ('01', '0') => __encoding ST1H_MZ_P_BI_4 // st1h_mz_p_bi_4
                                when ('01', '1') => __encoding STNT1H_MZ_P_BI_4 // stnt1h_mz_p_bi_4
                                when ('10', '0') => __encoding ST1W_MZ_P_BI_4 // st1w_mz_p_bi_4
                                when ('10', '1') => __encoding STNT1W_MZ_P_BI_4 // stnt1w_mz_p_bi_4
                                when ('11', '0') => __encoding ST1D_MZ_P_BI_4 // st1d_mz_p_bi_4
                                when ('11', '1') => __encoding STNT1D_MZ_P_BI_4 // stnt1d_mz_p_bi_4
                        when (_, '1x0', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '1x1', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '01', _, '10xxxxxxxxxxxxx', _, _, _) =>
                    // mortlach_multi_mem_nctg
                    case (23 +: 9, 20 +: 3, 16 +: 4, 15 +: 1, 3 +: 12, 2 +: 1, 0 +: 2) of
                        when (_, '00x', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZx_P_BR_2x8 // ld1b_mzx_p_br_2x8
                                when ('00', '1') => __encoding LDNT1B_MZx_P_BR_2x8 // ldnt1b_mzx_p_br_2x8
                                when ('01', '0') => __encoding LD1H_MZx_P_BR_2x8 // ld1h_mzx_p_br_2x8
                                when ('01', '1') => __encoding LDNT1H_MZx_P_BR_2x8 // ldnt1h_mzx_p_br_2x8
                                when ('10', '0') => __encoding LD1W_MZx_P_BR_2x8 // ld1w_mzx_p_br_2x8
                                when ('10', '1') => __encoding LDNT1W_MZx_P_BR_2x8 // ldnt1w_mzx_p_br_2x8
                                when ('11', '0') => __encoding LD1D_MZx_P_BR_2x8 // ld1d_mzx_p_br_2x8
                                when ('11', '1') => __encoding LDNT1D_MZx_P_BR_2x8 // ldnt1d_mzx_p_br_2x8
                        when (_, '00x', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZx_P_BR_4x4 // ld1b_mzx_p_br_4x4
                                when ('00', '1') => __encoding LDNT1B_MZx_P_BR_4x4 // ldnt1b_mzx_p_br_4x4
                                when ('01', '0') => __encoding LD1H_MZx_P_BR_4x4 // ld1h_mzx_p_br_4x4
                                when ('01', '1') => __encoding LDNT1H_MZx_P_BR_4x4 // ldnt1h_mzx_p_br_4x4
                                when ('10', '0') => __encoding LD1W_MZx_P_BR_4x4 // ld1w_mzx_p_br_4x4
                                when ('10', '1') => __encoding LDNT1W_MZx_P_BR_4x4 // ldnt1w_mzx_p_br_4x4
                                when ('11', '0') => __encoding LD1D_MZx_P_BR_4x4 // ld1d_mzx_p_br_4x4
                                when ('11', '1') => __encoding LDNT1D_MZx_P_BR_4x4 // ldnt1d_mzx_p_br_4x4
                        when (_, '01x', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZx_P_BR_2x8 // st1b_mzx_p_br_2x8
                                when ('00', '1') => __encoding STNT1B_MZx_P_BR_2x8 // stnt1b_mzx_p_br_2x8
                                when ('01', '0') => __encoding ST1H_MZx_P_BR_2x8 // st1h_mzx_p_br_2x8
                                when ('01', '1') => __encoding STNT1H_MZx_P_BR_2x8 // stnt1h_mzx_p_br_2x8
                                when ('10', '0') => __encoding ST1W_MZx_P_BR_2x8 // st1w_mzx_p_br_2x8
                                when ('10', '1') => __encoding STNT1W_MZx_P_BR_2x8 // stnt1w_mzx_p_br_2x8
                                when ('11', '0') => __encoding ST1D_MZx_P_BR_2x8 // st1d_mzx_p_br_2x8
                                when ('11', '1') => __encoding STNT1D_MZx_P_BR_2x8 // stnt1d_mzx_p_br_2x8
                        when (_, '01x', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZx_P_BR_4x4 // st1b_mzx_p_br_4x4
                                when ('00', '1') => __encoding STNT1B_MZx_P_BR_4x4 // stnt1b_mzx_p_br_4x4
                                when ('01', '0') => __encoding ST1H_MZx_P_BR_4x4 // st1h_mzx_p_br_4x4
                                when ('01', '1') => __encoding STNT1H_MZx_P_BR_4x4 // stnt1h_mzx_p_br_4x4
                                when ('10', '0') => __encoding ST1W_MZx_P_BR_4x4 // st1w_mzx_p_br_4x4
                                when ('10', '1') => __encoding STNT1W_MZx_P_BR_4x4 // stnt1w_mzx_p_br_4x4
                                when ('11', '0') => __encoding ST1D_MZx_P_BR_4x4 // st1d_mzx_p_br_4x4
                                when ('11', '1') => __encoding STNT1D_MZx_P_BR_4x4 // stnt1d_mzx_p_br_4x4
                        when (_, '0xx', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '100', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZx_P_BI_2x8 // ld1b_mzx_p_bi_2x8
                                when ('00', '1') => __encoding LDNT1B_MZx_P_BI_2x8 // ldnt1b_mzx_p_bi_2x8
                                when ('01', '0') => __encoding LD1H_MZx_P_BI_2x8 // ld1h_mzx_p_bi_2x8
                                when ('01', '1') => __encoding LDNT1H_MZx_P_BI_2x8 // ldnt1h_mzx_p_bi_2x8
                                when ('10', '0') => __encoding LD1W_MZx_P_BI_2x8 // ld1w_mzx_p_bi_2x8
                                when ('10', '1') => __encoding LDNT1W_MZx_P_BI_2x8 // ldnt1w_mzx_p_bi_2x8
                                when ('11', '0') => __encoding LD1D_MZx_P_BI_2x8 // ld1d_mzx_p_bi_2x8
                                when ('11', '1') => __encoding LDNT1D_MZx_P_BI_2x8 // ldnt1d_mzx_p_bi_2x8
                        when (_, '100', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding LD1B_MZx_P_BI_4x4 // ld1b_mzx_p_bi_4x4
                                when ('00', '1') => __encoding LDNT1B_MZx_P_BI_4x4 // ldnt1b_mzx_p_bi_4x4
                                when ('01', '0') => __encoding LD1H_MZx_P_BI_4x4 // ld1h_mzx_p_bi_4x4
                                when ('01', '1') => __encoding LDNT1H_MZx_P_BI_4x4 // ldnt1h_mzx_p_bi_4x4
                                when ('10', '0') => __encoding LD1W_MZx_P_BI_4x4 // ld1w_mzx_p_bi_4x4
                                when ('10', '1') => __encoding LDNT1W_MZx_P_BI_4x4 // ldnt1w_mzx_p_bi_4x4
                                when ('11', '0') => __encoding LD1D_MZx_P_BI_4x4 // ld1d_mzx_p_bi_4x4
                                when ('11', '1') => __encoding LDNT1D_MZx_P_BI_4x4 // ldnt1d_mzx_p_bi_4x4
                        when (_, '110', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZx_P_BI_2x8 // st1b_mzx_p_bi_2x8
                                when ('00', '1') => __encoding STNT1B_MZx_P_BI_2x8 // stnt1b_mzx_p_bi_2x8
                                when ('01', '0') => __encoding ST1H_MZx_P_BI_2x8 // st1h_mzx_p_bi_2x8
                                when ('01', '1') => __encoding STNT1H_MZx_P_BI_2x8 // stnt1h_mzx_p_bi_2x8
                                when ('10', '0') => __encoding ST1W_MZx_P_BI_2x8 // st1w_mzx_p_bi_2x8
                                when ('10', '1') => __encoding STNT1W_MZx_P_BI_2x8 // stnt1w_mzx_p_bi_2x8
                                when ('11', '0') => __encoding ST1D_MZx_P_BI_2x8 // st1d_mzx_p_bi_2x8
                                when ('11', '1') => __encoding STNT1D_MZx_P_BI_2x8 // stnt1d_mzx_p_bi_2x8
                        when (_, '110', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zth 4 +: 1
                            __field N 3 +: 1
                            __field Ztl 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding ST1B_MZx_P_BI_4x4 // st1b_mzx_p_bi_4x4
                                when ('00', '1') => __encoding STNT1B_MZx_P_BI_4x4 // stnt1b_mzx_p_bi_4x4
                                when ('01', '0') => __encoding ST1H_MZx_P_BI_4x4 // st1h_mzx_p_bi_4x4
                                when ('01', '1') => __encoding STNT1H_MZx_P_BI_4x4 // stnt1h_mzx_p_bi_4x4
                                when ('10', '0') => __encoding ST1W_MZx_P_BI_4x4 // st1w_mzx_p_bi_4x4
                                when ('10', '1') => __encoding STNT1W_MZx_P_BI_4x4 // stnt1w_mzx_p_bi_4x4
                                when ('11', '0') => __encoding ST1D_MZx_P_BI_4x4 // st1d_mzx_p_bi_4x4
                                when ('11', '1') => __encoding STNT1D_MZx_P_BI_4x4 // stnt1d_mzx_p_bi_4x4
                        when (_, '1x0', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '1x1', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx000x0xxxxxxx', _, '0xxx', _) =>
                    // mortlach_ins
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 17 +: 1, 15 +: 2, 13 +: 2, 10 +: 3, 7 +: 3, 5 +: 2, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, '00', _, '1', _, '00', _, '010', _, 'x0', _, '0', _) => // mortlach_multi2_za_insert_ctg
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding MOVA_ZA_MZ2_1 // mova_za_mz2_1
                        when (_, '00', _, '1', _, '00', _, '011', _, '00', _, '0', _) => // mortlach_multi4_za_insert_ctg
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding MOVA_ZA_MZ4_1 // mova_za_mz4_1
                        when (_, '00', _, '1', _, '00', _, '0x0', _, 'x0', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0x0', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0x1', _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0x1', _, !'00', _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '000', _, 'x0', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '000', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '001', _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '001', _, !'00', _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '01x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '000', _, 'x0', _, '1', _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '000', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', _, '1x', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '01x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', _, _, _, _, _, _, _, _, _) => // mortlach_insert_pred
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field opc 0 +: 4
                            case (size, Q) of
                                when ('0x', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding MOVA_ZA_P_RZ_B // mova_za_p_rz_b
                                when ('01', '0') => __encoding MOVA_ZA_P_RZ_H // mova_za_p_rz_h
                                when ('10', '0') => __encoding MOVA_ZA_P_RZ_W // mova_za_p_rz_w
                                when ('10', '1') => __UNALLOCATED
                                when ('11', '0') => __encoding MOVA_ZA_P_RZ_D // mova_za_p_rz_d
                                when ('11', '1') => __encoding MOVA_ZA_P_RZ_Q // mova_za_p_rz_q
                        when (_, _, _, '1', _, '0x', _, '000', _, 'x0', _, '0', _) => // mortlach_multi2_insert_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Zn 6 +: 4
                            __field opc 0 +: 3
                            case (size) of
                                when ('00') => __encoding MOVA_ZA2_Z_B1 // mova_za2_z_b1
                                when ('01') => __encoding MOVA_ZA2_Z_H1 // mova_za2_z_h1
                                when ('10') => __encoding MOVA_ZA2_Z_W1 // mova_za2_z_w1
                                when ('11') => __encoding MOVA_ZA2_Z_D1 // mova_za2_z_d1
                        when (_, _, _, '1', _, '0x', _, '001', _, '00', _, '0', _) => // mortlach_multi4_insert_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Zn 7 +: 3
                            __field opc 0 +: 3
                            case (size, opc) of
                                when ('0x', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding MOVA_ZA4_Z_B1 // mova_za4_z_b1
                                when ('01', '0xx') => __encoding MOVA_ZA4_Z_H1 // mova_za4_z_h1
                                when ('10', '0xx') => __encoding MOVA_ZA4_Z_W1 // mova_za4_z_w1
                                when ('10', '1xx') => __UNALLOCATED
                                when ('11', _) => __encoding MOVA_ZA4_Z_D1 // mova_za4_z_d1
                        when (_, _, _, '1', _, '0x', _, '1xx', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '1x', _, _, _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx000x0xxxxxxx', _, '1xxx', _) => __UNPREDICTABLE
                when (_, '10', _, '0xx000x1xxxxxxx', _, _, _) =>
                    // mortlach_ext
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 17 +: 1, 15 +: 2, 13 +: 2, 10 +: 3, 8 +: 2, 2 +: 6, 0 +: 2) of
                        when (_, '00', _, '1', _, '00', _, '010', '00', _, 'x0') => // mortlach_multi2_za_extract_ctg
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding MOVA_MZ_ZA2_1 // mova_mz_za2_1
                        when (_, '00', _, '1', _, '00', _, '010', '10', _, 'x0') => // mortlach_multi2_za_extract_zero
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding MOVAZ_MZ_ZA2_1 // movaz_mz_za2_1
                        when (_, '00', _, '1', _, '00', _, '011', '00', _, '00') => // mortlach_multi4_za_extract_ctg
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding MOVA_MZ_ZA4_1 // mova_mz_za4_1
                        when (_, '00', _, '1', _, '00', _, '011', '10', _, '00') => // mortlach_multi4_za_extract_zero
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding MOVAZ_MZ_ZA4_1 // movaz_mz_za4_1
                        when (_, '00', _, '1', _, '00', _, '0x0', 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0x1', 'x0', _, !'00') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '00', _, '0xx', 'x1', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '000', 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '001', 'x0', _, !'00') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '00x', 'x1', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '01x', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '000', 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', 'x0', _, '01') => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '001', 'x0', _, '1x') => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '00x', 'x1', _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '01x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', _, _, _, '000', '1x', _, _) => // mortlach_extract_zero
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 4
                            __field Zd 0 +: 5
                            case (size, Q) of
                                when ('0x', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding MOVAZ_Z_RZA_B // movaz_z_rza_b
                                when ('01', '0') => __encoding MOVAZ_Z_RZA_H // movaz_z_rza_h
                                when ('10', '0') => __encoding MOVAZ_Z_RZA_W // movaz_z_rza_w
                                when ('10', '1') => __UNALLOCATED
                                when ('11', '0') => __encoding MOVAZ_Z_RZA_D // movaz_z_rza_d
                                when ('11', '1') => __encoding MOVAZ_Z_RZA_Q // movaz_z_rza_q
                        when (_, _, _, '0', _, _, _, !'000', '1x', _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', _, _, _, _, '0x', _, _) => // mortlach_extract_pred
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field opc 5 +: 4
                            __field Zd 0 +: 5
                            case (size, Q) of
                                when ('0x', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding MOVA_Z_P_RZA_B // mova_z_p_rza_b
                                when ('01', '0') => __encoding MOVA_Z_P_RZA_H // mova_z_p_rza_h
                                when ('10', '0') => __encoding MOVA_Z_P_RZA_W // mova_z_p_rza_w
                                when ('10', '1') => __UNALLOCATED
                                when ('11', '0') => __encoding MOVA_Z_P_RZA_D // mova_z_p_rza_d
                                when ('11', '1') => __encoding MOVA_Z_P_RZA_Q // mova_z_p_rza_q
                        when (_, _, _, '1', _, '0x', _, '000', '00', _, 'x0') => // mortlach_multi2_extract_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 1 +: 4
                            case (size) of
                                when ('00') => __encoding MOVA_MZ2_ZA_B1 // mova_mz2_za_b1
                                when ('01') => __encoding MOVA_MZ2_ZA_H1 // mova_mz2_za_h1
                                when ('10') => __encoding MOVA_MZ2_ZA_W1 // mova_mz2_za_w1
                                when ('11') => __encoding MOVA_MZ2_ZA_D1 // mova_mz2_za_d1
                        when (_, _, _, '1', _, '0x', _, '000', '10', _, 'x0') => // mortlach_multi2_extract_zero
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 1 +: 4
                            case (size) of
                                when ('00') => __encoding MOVAZ_MZ2_ZA_B1 // movaz_mz2_za_b1
                                when ('01') => __encoding MOVAZ_MZ2_ZA_H1 // movaz_mz2_za_h1
                                when ('10') => __encoding MOVAZ_MZ2_ZA_W1 // movaz_mz2_za_w1
                                when ('11') => __encoding MOVAZ_MZ2_ZA_D1 // movaz_mz2_za_d1
                        when (_, _, _, '1', _, '0x', _, '001', '00', _, '00') => // mortlach_multi4_extract_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when ('0x', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding MOVA_MZ4_ZA_B1 // mova_mz4_za_b1
                                when ('01', '0xx') => __encoding MOVA_MZ4_ZA_H1 // mova_mz4_za_h1
                                when ('10', '0xx') => __encoding MOVA_MZ4_ZA_W1 // mova_mz4_za_w1
                                when ('10', '1xx') => __UNALLOCATED
                                when ('11', _) => __encoding MOVA_MZ4_ZA_D1 // mova_mz4_za_d1
                        when (_, _, _, '1', _, '0x', _, '001', '10', _, '00') => // mortlach_multi4_extract_zero
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when ('0x', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding MOVAZ_MZ4_ZA_B1 // movaz_mz4_za_b1
                                when ('01', '0xx') => __encoding MOVAZ_MZ4_ZA_H1 // movaz_mz4_za_h1
                                when ('10', '0xx') => __encoding MOVAZ_MZ4_ZA_W1 // movaz_mz4_za_w1
                                when ('10', '1xx') => __UNALLOCATED
                                when ('11', _) => __encoding MOVAZ_MZ4_ZA_D1 // movaz_mz4_za_d1
                        when (_, _, _, '1', _, '0x', _, '1xx', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '1x', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx010xxxxxxxxx', _, 'x0xx', _) =>
                    // mortlach_hvadd
                    case (24 +: 8, 23 +: 1, 22 +: 1, 19 +: 3, 17 +: 2, 5 +: 12, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, '0', _, _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, '00', _, '0', _, _) => // mortlach_addhv
                            __field op 22 +: 1
                            __field V 16 +: 1
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field opc2 0 +: 3
                            case (op, V, opc2) of
                                when ('0', _, '1xx') => __UNALLOCATED
                                when ('0', '0', '0xx') => __encoding ADDHA_ZA_PP_Z_32 // addha_za_pp_z_32
                                when ('0', '1', '0xx') => __encoding ADDVA_ZA_PP_Z_32 // addva_za_pp_z_32
                                when ('1', '0', _) => __encoding ADDHA_ZA_PP_Z_64 // addha_za_pp_z_64
                                when ('1', '1', _) => __encoding ADDVA_ZA_PP_Z_64 // addva_za_pp_z_64
                        when (_, '1', _, _, '00', _, '1', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, !'00', _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx010xxxxxxxxx', _, 'x1xx', _) => __UNPREDICTABLE
                when (_, '10', _, '0xx1xxxxxxxxxxx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '00x011xxxxxxxxx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0000010xxxxxxxx', _, _, _) =>
                    // mortlach_zero
                    case (18 +: 14, 8 +: 10, 0 +: 8) of
                        when (_, '0000000000', _) => // mortlach_zero
                            __field imm8 0 +: 8
                            case () of
                                when () => __encoding ZERO_ZA_I__ // zero_za_i_
                        when (_, !'0000000000', _) => __UNPREDICTABLE
                when (_, '10', _, '0000011xxxxxxxx', _, _, _) =>
                    // mortlach_multizero
                    case (18 +: 14, 13 +: 5, 3 +: 10, 0 +: 3) of
                        when (_, _, '0000000000', _) => // mortlach_multi_zero
                            __field opc 15 +: 3
                            __field Rv 13 +: 2
                            __field opc2 0 +: 3
                            case (opc, opc2) of
                                when ('x1x', '1xx') => __UNALLOCATED
                                when ('000', _) => __encoding ZERO_ZA1_RI_2 // zero_za1_ri_2
                                when ('001', _) => __encoding ZERO_ZA2_RI_1 // zero_za2_ri_1
                                when ('010', '0xx') => __encoding ZERO_ZA2_RI_2 // zero_za2_ri_2
                                when ('011', '0xx') => __encoding ZERO_ZA2_RI_4 // zero_za2_ri_4
                                when ('100', _) => __encoding ZERO_ZA1_RI_4 // zero_za1_ri_4
                                when ('101', '0xx') => __encoding ZERO_ZA4_RI_1 // zero_za4_ri_1
                                when ('101', '1xx') => __UNALLOCATED
                                when ('11x', '01x') => __UNALLOCATED
                                when ('110', '00x') => __encoding ZERO_ZA4_RI_2 // zero_za4_ri_2
                                when ('111', '00x') => __encoding ZERO_ZA4_RI_4 // zero_za4_ri_4
                        when (_, _, !'0000000000', _) => __UNPREDICTABLE
                when (_, '10', _, '0010010xxxxxxxx', _, _, _) =>
                    // mortlach_zero_zt
                    case (18 +: 14, 4 +: 14, 0 +: 4) of
                        when (_, '00000000000000', _) => // mortlach_zero_zt
                            __field opc 0 +: 4
                            case (opc) of
                                when ('0000') => __UNALLOCATED
                                when ('0001') => __encoding ZERO_ZT_I__ // zero_zt_i_
                                when ('001x') => __UNALLOCATED
                                when ('01xx') => __UNALLOCATED
                                when ('1xxx') => __UNALLOCATED
                        when (_, !'00000000000000', _) => __UNPREDICTABLE
                when (_, '10', _, '0010011xxxxxxxx', _, _, _) =>
                    // mortlach_mov_zt
                    case (18 +: 14, 17 +: 1, 15 +: 2, 14 +: 1, 0 +: 14) of
                        when (_, '0', '00', _, _) => // mortlach_extract_zt
                            __field imm3 12 +: 3
                            __field opc 5 +: 7
                            __field Rt 0 +: 5
                            case (opc) of
                                when ('000xxxx') => __UNALLOCATED
                                when ('0010xxx') => __UNALLOCATED
                                when ('00110xx') => __UNALLOCATED
                                when ('001110x') => __UNALLOCATED
                                when ('0011110') => __UNALLOCATED
                                when ('0011111') => __encoding MOVT_R_ZT__ // movt_r_zt_
                                when ('01xxxxx') => __UNALLOCATED
                                when ('1xxxxxx') => __UNALLOCATED
                        when (_, '0', !'00', _, _) => __UNPREDICTABLE
                        when (_, '1', '00', _, _) => // mortlach_insert_zt
                            __field imm3 12 +: 3
                            __field opc 5 +: 7
                            __field Rt 0 +: 5
                            case (opc) of
                                when ('000xxxx') => __UNALLOCATED
                                when ('0010xxx') => __UNALLOCATED
                                when ('00110xx') => __UNALLOCATED
                                when ('001110x') => __UNALLOCATED
                                when ('0011110') => __UNALLOCATED
                                when ('0011111') => __encoding MOVT_ZT_R__ // movt_zt_r_
                                when ('01xxxxx') => __UNALLOCATED
                                when ('1xxxxxx') => __UNALLOCATED
                        when (_, '1', '10', '0', _) => // mortlach_move_to_zt
                            __field off2 12 +: 2
                            __field opc 5 +: 7
                            __field Zt 0 +: 5
                            case (opc) of
                                when ('000xxxx') => __UNALLOCATED
                                when ('0010xxx') => __UNALLOCATED
                                when ('00110xx') => __UNALLOCATED
                                when ('001110x') => __UNALLOCATED
                                when ('0011110') => __UNALLOCATED
                                when ('0011111') => __encoding MOVT_ZT_Z__ // movt_zt_z_
                                when ('01xxxxx') => __UNALLOCATED
                                when ('1xxxxxx') => __UNALLOCATED
                        when (_, '1', '10', '1', _) => __UNPREDICTABLE
                        when (_, '1', 'x1', _, _) => __UNPREDICTABLE
                when (_, '10', _, '01x001xxxxxxxxx', _, _, _) =>
                    // mortlach_zt_expand_ctg
                    case (23 +: 9, 22 +: 1, 19 +: 3, 14 +: 5, 6 +: 8, 5 +: 1, 2 +: 3, 0 +: 2) of
                        when (_, '0', _, '00x00', _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, '01000', _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, '01100', _, '0', _, '00') => // mortlach_expand_4dst2src_ctg
                            __field size 12 +: 2
                            __field opc 10 +: 2
                            __field Zn 6 +: 4
                            __field Zd 2 +: 3
                            case (opc) of
                                when ('00') => __encoding LUTI4_MZ4_ZTMZ2_1 // luti4_mz4_ztmz2_1
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, '0', _, '01100', _, '0', _, !'00') => __UNPREDICTABLE
                        when (_, '0', _, '01100', _, '1', _, _) => __UNPREDICTABLE
                        when (_, '0', _, '1xx00', _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, 'xxx10', _, _, _, '00') => // mortlach_expand_4dst_ctg
                            __field opc 16 +: 3
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            case (opc, opc2) of
                                when ('00x', _) => __UNALLOCATED
                                when ('01x', '00') => __encoding LUTI4_MZ4_ZTZ_1 // luti4_mz4_ztz_1
                                when ('01x', '01') => __UNALLOCATED
                                when ('01x', '1x') => __UNALLOCATED
                                when ('1xx', '00') => __encoding LUTI2_MZ4_ZTZ_1 // luti2_mz4_ztz_1
                                when ('1xx', '01') => __UNALLOCATED
                                when ('1xx', '1x') => __UNALLOCATED
                        when (_, '0', _, 'xxx10', _, _, _, !'00') => __UNPREDICTABLE
                        when (_, '0', _, 'xxxx1', _, _, _, 'x0') => // mortlach_expand_2dst_ctg
                            __field opc 15 +: 4
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            case (opc, opc2) of
                                when ('00xx', _) => __UNALLOCATED
                                when ('01xx', '00') => __encoding LUTI4_MZ2_ZTZ_1 // luti4_mz2_ztz_1
                                when ('01xx', '01') => __UNALLOCATED
                                when ('01xx', '1x') => __UNALLOCATED
                                when ('1xxx', '00') => __encoding LUTI2_MZ2_ZTZ_1 // luti2_mz2_ztz_1
                                when ('1xxx', '01') => __UNALLOCATED
                                when ('1xxx', '1x') => __UNALLOCATED
                        when (_, '0', _, 'xxxx1', _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _) => // mortlach_expand_1dst
                            __field opc 14 +: 5
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('00xxx', _) => __UNALLOCATED
                                when ('01xxx', '00') => __encoding LUTI4_Z_ZTZ__ // luti4_z_ztz_
                                when ('01xxx', '01') => __UNALLOCATED
                                when ('01xxx', '1x') => __UNALLOCATED
                                when ('1xxxx', '00') => __encoding LUTI2_Z_ZTZ__ // luti2_z_ztz_
                                when ('1xxxx', '01') => __UNALLOCATED
                                when ('1xxxx', '1x') => __UNALLOCATED
                when (_, '10', _, '010011xxxxxxxxx', _, _, _) =>
                    // mortlach_zt_expand_nctg
                    case (19 +: 13, 16 +: 3, 14 +: 2, 6 +: 8, 5 +: 1, 4 +: 1, 2 +: 2, 0 +: 2) of
                        when (_, '00x', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '010', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '011', '00', _, '0', _, '00', _) => // mortlach_expand_4dst2src_nctg
                            __field size 12 +: 2
                            __field opc 10 +: 2
                            __field Zn 6 +: 4
                            __field Zdh 4 +: 1
                            __field Zdl 0 +: 2
                            case (opc) of
                                when ('00') => __encoding LUTI4_MZ4_ZTMZ2_4 // luti4_mz4_ztmz2_4
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, '011', '00', _, '0', _, !'00', _) => __UNPREDICTABLE
                        when (_, '011', '00', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1xx', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, '10', _, _, _, '00', _) => // mortlach_expand_4dst_nctg
                            __field opc 16 +: 3
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zdh 4 +: 1
                            __field Zdl 0 +: 2
                            case (opc, opc2) of
                                when ('00x', _) => __UNALLOCATED
                                when ('01x', '00') => __encoding LUTI4_MZ4_ZTZ_4 // luti4_mz4_ztz_4
                                when ('01x', '01') => __UNALLOCATED
                                when ('01x', '1x') => __UNALLOCATED
                                when ('1xx', '00') => __encoding LUTI2_MZ4_ZTZ_4 // luti2_mz4_ztz_4
                                when ('1xx', '01') => __UNALLOCATED
                                when ('1xx', '1x') => __UNALLOCATED
                        when (_, _, '10', _, _, _, '01', _) => __UNPREDICTABLE
                        when (_, _, !'00', _, _, _, '1x', _) => __UNPREDICTABLE
                        when (_, _, 'x1', _, _, _, '0x', _) => // mortlach_expand_2dst_nctg
                            __field opc 15 +: 4
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zdh 4 +: 1
                            __field Zdl 0 +: 3
                            case (opc, opc2) of
                                when ('00xx', _) => __UNALLOCATED
                                when ('01xx', '00') => __encoding LUTI4_MZ2_ZTZ_8 // luti4_mz2_ztz_8
                                when ('01xx', '01') => __UNALLOCATED
                                when ('01xx', '1x') => __UNALLOCATED
                                when ('1xxx', '00') => __encoding LUTI2_MZ2_ZTZ_8 // luti2_mz2_ztz_8
                                when ('1xxx', '01') => __UNALLOCATED
                                when ('1xxx', '1x') => __UNALLOCATED
                when (_, '10', _, '011011xxxxxxxxx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx00xxxxxxxxxx', _, _, _) =>
                    // mortlach_multi_indexed_1
                    case (24 +: 8, 22 +: 2, 20 +: 2, 13 +: 7, 12 +: 1, 5 +: 7, 2 +: 3, 0 +: 2) of
                        when (_, '00', _, _, _, _, _, _) => // mortlach_multi1_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field i4h 15 +: 1
                            __field Rv 13 +: 2
                            __field i4l 10 +: 3
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (U, S, op) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding SMLALL_ZA_ZZi_S // smlall_za_zzi_s
                                when ('0', '0', '1') => __encoding USMLALL_ZA_ZZi_S // usmlall_za_zzi_s
                                when ('0', '1', '0') => __encoding SMLSLL_ZA_ZZi_S // smlsll_za_zzi_s
                                when ('1', '0', '0') => __encoding UMLALL_ZA_ZZi_S // umlall_za_zzi_s
                                when ('1', '0', '1') => __encoding SUMLALL_ZA_ZZi_S // sumlall_za_zzi_s
                                when ('1', '1', '0') => __encoding UMLSLL_ZA_ZZi_S // umlsll_za_zzi_s
                        when (_, '01', _, _, _, _, '000', _) => // mortlach_multi1_fp8_fma_long_long_idx
                            __field Zm 16 +: 4
                            __field i4h 15 +: 1
                            __field Rv 13 +: 2
                            __field i4l 10 +: 3
                            __field Zn 5 +: 5
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding FMLALL_ZA32_Z8Z8i_1 // fmlall_za32_z8z8i_1
                        when (_, '01', _, _, _, _, !'000', _) => __UNPREDICTABLE
                        when (_, '10', _, _, '0', _, 'xx0', _) => // mortlach_multi1_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLALL_ZA_ZZi_D // smlall_za_zzi_d
                                when ('0', '1') => __encoding SMLSLL_ZA_ZZi_D // smlsll_za_zzi_d
                                when ('1', '0') => __encoding UMLALL_ZA_ZZi_D // umlall_za_zzi_d
                                when ('1', '1') => __encoding UMLSLL_ZA_ZZi_D // umlsll_za_zzi_d
                        when (_, '10', _, _, '0', _, 'xx1', _) => __UNPREDICTABLE
                        when (_, '10', _, _, '1', _, _, _) => // mortlach_multi1_fma_long_idx
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZi_1 // fmlal_za_zzi_1
                                when ('0', '1') => __encoding FMLSL_ZA_ZZi_1 // fmlsl_za_zzi_1
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZi_1 // bfmlal_za_zzi_1
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZi_1 // bfmlsl_za_zzi_1
                        when (_, '11', _, _, '0', _, '0xx', _) => // mortlach_multi1_fp8_fma_long_idx
                            __field Zm 16 +: 4
                            __field i4A 15 +: 1
                            __field Rv 13 +: 2
                            __field i4B 10 +: 2
                            __field Zn 5 +: 5
                            __field i4C 3 +: 1
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding FMLAL_ZA_Z8Z8i_1 // fmlal_za_z8z8i_1
                        when (_, '11', _, _, '0', _, '1xx', _) => __UNPREDICTABLE
                        when (_, '11', _, _, '1', _, _, _) => // mortlach_multi1_mla_long_idx
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZi_1 // smlal_za_zzi_1
                                when ('0', '1') => __encoding SMLSL_ZA_ZZi_1 // smlsl_za_zzi_1
                                when ('1', '0') => __encoding UMLAL_ZA_ZZi_1 // umlal_za_zzi_1
                                when ('1', '1') => __encoding UMLSL_ZA_ZZi_1 // umlsl_za_zzi_1
                when (_, '10', _, '1xx01xxxx0xxxxx', _, _, _) =>
                    // mortlach_multi_indexed_2
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 11 +: 2, 6 +: 5, 5 +: 1, 3 +: 2, 0 +: 3) of
                        when (_, '00', _, _, _, _, '0x', _, _, _, _) => // mortlach_multi2_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 5 +: 1
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case (op, U, S) of
                                when ('0', '0', '0') => __encoding SMLALL_ZA_ZZi_S2xi // smlall_za_zzi_s2xi
                                when ('0', '0', '1') => __encoding SMLSLL_ZA_ZZi_S2xi // smlsll_za_zzi_s2xi
                                when ('0', '1', '0') => __encoding UMLALL_ZA_ZZi_S2xi // umlall_za_zzi_s2xi
                                when ('0', '1', '1') => __encoding UMLSLL_ZA_ZZi_S2xi // umlsll_za_zzi_s2xi
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding USMLALL_ZA_ZZi_S2xi // usmlall_za_zzi_s2xi
                                when ('1', '1', '0') => __encoding SUMLALL_ZA_ZZi_S2xi // sumlall_za_zzi_s2xi
                        when (_, '00', _, _, _, _, '1x', _, _, _, _) => // mortlach_multi2_zza_idx_h
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 5 +: 1
                            __field S 4 +: 1
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZi_H2xi // fmla_za_zzi_h2xi
                                when ('0', '1') => __encoding FMLS_ZA_ZZi_H2xi // fmls_za_zzi_h2xi
                                when ('1', '0') => __encoding BFMLA_ZA_ZZi_H2xi // bfmla_za_zzi_h2xi
                                when ('1', '1') => __encoding BFMLS_ZA_ZZi_H2xi // bfmls_za_zzi_h2xi
                        when (_, '01', _, _, _, _, _, _, _, _, _) => // mortlach_multi2_zza_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 12 +: 1
                            __field i2 10 +: 2
                            __field Zn 6 +: 4
                            __field opc2 3 +: 3
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '000') => __encoding FMLA_ZA_ZZi_S2xi // fmla_za_zzi_s2xi
                                when ('0', '001') => __encoding FVDOT_ZA_ZZi_2xi // fvdot_za_zzi_2xi
                                when ('0', '010') => __encoding FMLS_ZA_ZZi_S2xi // fmls_za_zzi_s2xi
                                when ('0', '011') => __encoding BFVDOT_ZA_ZZi_2xi // bfvdot_za_zzi_2xi
                                when ('0', '100') => __encoding SVDOT_ZA32_ZZi_2xi // svdot_za32_zzi_2xi
                                when ('0', '101') => __UNALLOCATED
                                when ('0', '110') => __encoding UVDOT_ZA32_ZZi_2xi // uvdot_za32_zzi_2xi
                                when ('0', '111') => __encoding FDOT_ZA32_Z8Z8i_2xi // fdot_za32_z8z8i_2xi
                                when ('1', '000') => __encoding SDOT_ZA32_ZZi_2xi // sdot_za32_zzi_2xi
                                when ('1', '001') => __encoding FDOT_ZA_ZZi_2xi // fdot_za_zzi_2xi
                                when ('1', '010') => __encoding UDOT_ZA32_ZZi_2xi // udot_za32_zzi_2xi
                                when ('1', '011') => __encoding BFDOT_ZA_ZZi_2xi // bfdot_za_zzi_2xi
                                when ('1', '100') => __encoding SDOT_ZA_ZZi_S2xi // sdot_za_zzi_s2xi
                                when ('1', '101') => __encoding USDOT_ZA_ZZi_S2xi // usdot_za_zzi_s2xi
                                when ('1', '110') => __encoding UDOT_ZA_ZZi_S2xi // udot_za_zzi_s2xi
                                when ('1', '111') => __encoding SUDOT_ZA_ZZi_S2xi // sudot_za_zzi_s2xi
                        when (_, '10', _, _, _, _, '00', _, '0', _, _) => // mortlach_multi2_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 1
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 1 +: 2
                            __field o1 0 +: 1
                            case (U, S) of
                                when ('0', '0') => __encoding SMLALL_ZA_ZZi_D2xi // smlall_za_zzi_d2xi
                                when ('0', '1') => __encoding SMLSLL_ZA_ZZi_D2xi // smlsll_za_zzi_d2xi
                                when ('1', '0') => __encoding UMLALL_ZA_ZZi_D2xi // umlall_za_zzi_d2xi
                                when ('1', '1') => __encoding UMLSLL_ZA_ZZi_D2xi // umlsll_za_zzi_d2xi
                        when (_, '10', _, _, _, _, '01', _, '0', _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '0x', _, '1', '00', _) => // mortlach_multi2_fp8_fma_long_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 6 +: 4
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding FMLALL_ZA32_Z8Z8i_2xi // fmlall_za32_z8z8i_2xi
                        when (_, '10', _, _, _, _, '0x', _, '1', !'00', _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '0', _, _) => // mortlach_multi2_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZi_2xi // fmlal_za_zzi_2xi
                                when ('0', '1') => __encoding FMLSL_ZA_ZZi_2xi // fmlsl_za_zzi_2xi
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZi_2xi // bfmlal_za_zzi_2xi
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZi_2xi // bfmlsl_za_zzi_2xi
                        when (_, '10', _, _, _, _, '1x', _, '1', '0x', _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '1', '1x', _) => // mortlach_multi2_fp8_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 6 +: 4
                            __field i4l 2 +: 2
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding FMLAL_ZA_Z8Z8i_2xi // fmlal_za_z8z8i_2xi
                        when (_, '11', _, _, _, _, '00', _, '0', _, _) => // mortlach_multi2_zza_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i1 10 +: 1
                            __field Zn 6 +: 4
                            __field opc 3 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding FMLA_ZA_ZZi_D2xi // fmla_za_zzi_d2xi
                                when ('01') => __encoding SDOT_ZA_ZZi_D2xi // sdot_za_zzi_d2xi
                                when ('10') => __encoding FMLS_ZA_ZZi_D2xi // fmls_za_zzi_d2xi
                                when ('11') => __encoding UDOT_ZA_ZZi_D2xi // udot_za_zzi_d2xi
                        when (_, '11', _, _, _, _, '01', _, '0', _, _) => // mortlach_multi2_fp8_fvdot_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i2h 10 +: 1
                            __field Zn 6 +: 4
                            __field T 4 +: 1
                            __field i2l 3 +: 1
                            __field off3 0 +: 3
                            case (T) of
                                when ('0') => __encoding FVDOTB_ZA32_Z8Z8i_2xi // fvdotb_za32_z8z8i_2xi
                                when ('1') => __encoding FVDOTT_ZA32_Z8Z8i_2xi // fvdott_za32_z8z8i_2xi
                        when (_, '11', _, _, _, _, '1x', _, '0', _, _) => // mortlach_multi2_mla_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZi_2xi // smlal_za_zzi_2xi
                                when ('0', '1') => __encoding SMLSL_ZA_ZZi_2xi // smlsl_za_zzi_2xi
                                when ('1', '0') => __encoding UMLAL_ZA_ZZi_2xi // umlal_za_zzi_2xi
                                when ('1', '1') => __encoding UMLSL_ZA_ZZi_2xi // umlsl_za_zzi_2xi
                        when (_, '11', _, _, _, _, _, _, '1', '0x', _) => // mortlach_multi2_fp8_fdot_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 12 +: 1
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case (op) of
                                when ('0') => __encoding FDOT_ZA_Z8Z8i_2xi // fdot_za_z8z8i_2xi
                                when ('1') => __encoding FVDOT_ZA_Z8Z8i_2xi // fvdot_za_z8z8i_2xi
                        when (_, '11', _, _, _, _, _, _, '1', '1x', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx01xxxx1xxxxx', _, _, _) =>
                    // mortlach_multi_indexed_3
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 11 +: 2, 7 +: 4, 4 +: 3, 3 +: 1, 0 +: 3) of
                        when (_, '00', _, _, _, _, '0x', _, '0xx', _, _) => // mortlach_multi4_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 5 +: 1
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case (op, U, S) of
                                when ('0', '0', '0') => __encoding SMLALL_ZA_ZZi_S4xi // smlall_za_zzi_s4xi
                                when ('0', '0', '1') => __encoding SMLSLL_ZA_ZZi_S4xi // smlsll_za_zzi_s4xi
                                when ('0', '1', '0') => __encoding UMLALL_ZA_ZZi_S4xi // umlall_za_zzi_s4xi
                                when ('0', '1', '1') => __encoding UMLSLL_ZA_ZZi_S4xi // umlsll_za_zzi_s4xi
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding USMLALL_ZA_ZZi_S4xi // usmlall_za_zzi_s4xi
                                when ('1', '1', '0') => __encoding SUMLALL_ZA_ZZi_S4xi // sumlall_za_zzi_s4xi
                        when (_, '00', _, _, _, _, '0x', _, '100', '0', _) => // mortlach_multi4_fp8_fma_long_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 7 +: 3
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding FMLALL_ZA32_Z8Z8i_4xi // fmlall_za32_z8z8i_4xi
                        when (_, '00', _, _, _, _, '0x', _, '100', '1', _) => __UNPREDICTABLE
                        when (_, '00', _, _, _, _, '1x', _, '0xx', _, _) => // mortlach_multi4_zza_idx_h
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 5 +: 1
                            __field S 4 +: 1
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZi_H4xi // fmla_za_zzi_h4xi
                                when ('0', '1') => __encoding FMLS_ZA_ZZi_H4xi // fmls_za_zzi_h4xi
                                when ('1', '0') => __encoding BFMLA_ZA_ZZi_H4xi // bfmla_za_zzi_h4xi
                                when ('1', '1') => __encoding BFMLS_ZA_ZZi_H4xi // bfmls_za_zzi_h4xi
                        when (_, '00', _, _, _, _, '1x', _, '100', _, _) => // mortlach_multi4_fp8_fdot_idx_h
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding FDOT_ZA_Z8Z8i_4xi // fdot_za_z8z8i_4xi
                        when (_, '00', _, _, _, _, _, _, '1!= 00', _, _) => __UNPREDICTABLE
                        when (_, '01', _, _, _, _, _, _, '0xx', _, _) => // mortlach_multi4_zza_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 12 +: 1
                            __field i2 10 +: 2
                            __field Zn 7 +: 3
                            __field opc2 3 +: 3
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '000') => __encoding FMLA_ZA_ZZi_S4xi // fmla_za_zzi_s4xi
                                when ('0', '001') => __encoding FDOT_ZA32_Z8Z8i_4xi // fdot_za32_z8z8i_4xi
                                when ('0', '010') => __encoding FMLS_ZA_ZZi_S4xi // fmls_za_zzi_s4xi
                                when ('0', '011') => __UNALLOCATED
                                when ('0', '100') => __encoding SVDOT_ZA_ZZi_S4xi // svdot_za_zzi_s4xi
                                when ('0', '101') => __encoding USVDOT_ZA_ZZi_S4xi // usvdot_za_zzi_s4xi
                                when ('0', '110') => __encoding UVDOT_ZA_ZZi_S4xi // uvdot_za_zzi_s4xi
                                when ('0', '111') => __encoding SUVDOT_ZA_ZZi_S4xi // suvdot_za_zzi_s4xi
                                when ('1', '000') => __encoding SDOT_ZA32_ZZi_4xi // sdot_za32_zzi_4xi
                                when ('1', '001') => __encoding FDOT_ZA_ZZi_4xi // fdot_za_zzi_4xi
                                when ('1', '010') => __encoding UDOT_ZA32_ZZi_4xi // udot_za32_zzi_4xi
                                when ('1', '011') => __encoding BFDOT_ZA_ZZi_4xi // bfdot_za_zzi_4xi
                                when ('1', '100') => __encoding SDOT_ZA_ZZi_S4xi // sdot_za_zzi_s4xi
                                when ('1', '101') => __encoding USDOT_ZA_ZZi_S4xi // usdot_za_zzi_s4xi
                                when ('1', '110') => __encoding UDOT_ZA_ZZi_S4xi // udot_za_zzi_s4xi
                                when ('1', '111') => __encoding SUDOT_ZA_ZZi_S4xi // sudot_za_zzi_s4xi
                        when (_, '10', _, _, _, _, '00', _, '00x', _, _) => // mortlach_multi4_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 1
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 1 +: 2
                            __field o1 0 +: 1
                            case (U, S) of
                                when ('0', '0') => __encoding SMLALL_ZA_ZZi_D4xi // smlall_za_zzi_d4xi
                                when ('0', '1') => __encoding SMLSLL_ZA_ZZi_D4xi // smlsll_za_zzi_d4xi
                                when ('1', '0') => __encoding UMLALL_ZA_ZZi_D4xi // umlall_za_zzi_d4xi
                                when ('1', '1') => __encoding UMLSLL_ZA_ZZi_D4xi // umlsll_za_zzi_d4xi
                        when (_, '10', _, _, _, _, '00', _, !'00x', _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '01', _, _, _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '00x', _, _) => // mortlach_multi4_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZi_4xi // fmlal_za_zzi_4xi
                                when ('0', '1') => __encoding FMLSL_ZA_ZZi_4xi // fmlsl_za_zzi_4xi
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZi_4xi // bfmlal_za_zzi_4xi
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZi_4xi // bfmlsl_za_zzi_4xi
                        when (_, '10', _, _, _, _, '1x', _, '010', _, _) => // mortlach_multi4_fp8_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 7 +: 3
                            __field i4l 2 +: 2
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding FMLAL_ZA_Z8Z8i_4xi // fmlal_za_z8z8i_4xi
                        when (_, '10', _, _, _, _, '1x', _, '011', _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '1xx', _, _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, _, '0x', _, '00x', _, _) => // mortlach_multi4_zza_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 11 +: 1
                            __field i1 10 +: 1
                            __field Zn 7 +: 3
                            __field opc2 3 +: 2
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '00') => __encoding FMLA_ZA_ZZi_D4xi // fmla_za_zzi_d4xi
                                when ('0', '01') => __encoding SDOT_ZA_ZZi_D4xi // sdot_za_zzi_d4xi
                                when ('0', '10') => __encoding FMLS_ZA_ZZi_D4xi // fmls_za_zzi_d4xi
                                when ('0', '11') => __encoding UDOT_ZA_ZZi_D4xi // udot_za_zzi_d4xi
                                when ('1', 'x0') => __UNALLOCATED
                                when ('1', '01') => __encoding SVDOT_ZA_ZZi_D4xi // svdot_za_zzi_d4xi
                                when ('1', '11') => __encoding UVDOT_ZA_ZZi_D4xi // uvdot_za_zzi_d4xi
                        when (_, '11', _, _, _, _, '1x', _, '00x', _, _) => // mortlach_multi4_mla_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZi_4xi // smlal_za_zzi_4xi
                                when ('0', '1') => __encoding SMLSL_ZA_ZZi_4xi // smlsl_za_zzi_4xi
                                when ('1', '0') => __encoding UMLAL_ZA_ZZi_4xi // umlal_za_zzi_4xi
                                when ('1', '1') => __encoding UMLSL_ZA_ZZi_4xi // umlsl_za_zzi_4xi
                        when (_, '11', _, _, _, _, _, _, '01x', _, _) => __UNPREDICTABLE
                        when (_, 'x1', _, _, _, _, _, _, '1xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx100xxx', _, _, _) =>
                    // mortlach_multi_sve_1
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 7 +: 6, 5 +: 2, 2 +: 3, 0 +: 2) of
                        when (_, _, _, _, '01', _, _, '00', _, '00') => // mortlach_multi4_select_int
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field PNg 10 +: 3
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding SEL_MZ_P_ZZ_4 // sel_mz_p_zz_4
                        when (_, _, _, _, '01', _, _, '00', _, !'00') => __UNPREDICTABLE
                        when (_, _, _, _, '01', _, _, !'00', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '11', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, 'x0', _, 'x0') => // mortlach_multi2_select_int
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field PNg 10 +: 3
                            __field Zn 6 +: 4
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding SEL_MZ_P_ZZ_2 // sel_mz_p_zz_2
                        when (_, _, _, _, 'x0', _, _, 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, 'x1', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx110xxx', _, _, _) =>
                    // mortlach_multi_sve_3
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 2 +: 8, 1 +: 1, 0 +: 1) of
                        when (_, '00', _, _, _, '101', _, _, _) => // mortlach_multi2_z_z_long_zip
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding ZIP_MZ_ZZ_2Q // zip_mz_zz_2q
                                when ('1') => __encoding UZP_MZ_ZZ_2Q // uzp_mz_zz_2q
                        when (_, '01', _, _, _, '101', _, _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, '101', _, _, _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, '101', _, _, _) => // mortlach_multi2_qrshr
                            __field op 20 +: 1
                            __field imm4 16 +: 4
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SQRSHR_Z_MZ2__ // sqrshr_z_mz2_
                                when ('0', '1') => __encoding UQRSHR_Z_MZ2__ // uqrshr_z_mz2_
                                when ('1', '0') => __encoding SQRSHRU_Z_MZ2__ // sqrshru_z_mz2_
                                when ('1', '1') => __UNALLOCATED
                        when (_, _, _, _, _, '000', _, _, _) => // mortlach_multi2_fclamp
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field op 0 +: 1
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when (!'00', '0') => __encoding FCLAMP_MZ_ZZ_2 // fclamp_mz_zz_2
                                when ('00', '0') => __encoding BFCLAMP_MZ_ZZ_2 // bfclamp_mz_zz_2
                        when (_, _, _, _, _, '001', _, _, _) => // mortlach_multi2_clamp_int
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding SCLAMP_MZ_ZZ_2 // sclamp_mz_zz_2
                                when ('1') => __encoding UCLAMP_MZ_ZZ_2 // uclamp_mz_zz_2
                        when (_, _, _, _, _, '010', _, '0', _) => // mortlach_multi4_fclamp
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            __field op 0 +: 1
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when (!'00', '0') => __encoding FCLAMP_MZ_ZZ_4 // fclamp_mz_zz_4
                                when ('00', '0') => __encoding BFCLAMP_MZ_ZZ_4 // bfclamp_mz_zz_4
                        when (_, _, _, _, _, '011', _, '0', _) => // mortlach_multi4_clamp_int
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding SCLAMP_MZ_ZZ_4 // sclamp_mz_zz_4
                                when ('1') => __encoding UCLAMP_MZ_ZZ_4 // uclamp_mz_zz_4
                        when (_, _, _, _, _, '01x', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '100', _, _, _) => // mortlach_multi2_z_z_zip
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding ZIP_MZ_ZZ_2 // zip_mz_zz_2
                                when ('1') => __encoding UZP_MZ_ZZ_2 // uzp_mz_zz_2
                        when (_, _, _, _, _, '11x', _, _, _) => // mortlach_multi4_qrshr
                            __field tsize 22 +: 2
                            __field imm5 16 +: 5
                            __field N 10 +: 1
                            __field Zn 7 +: 3
                            __field op 6 +: 1
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (N, op, U) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding SQRSHR_Z_MZ4__ // sqrshr_z_mz4_
                                when ('0', '0', '1') => __encoding UQRSHR_Z_MZ4__ // uqrshr_z_mz4_
                                when ('0', '1', '0') => __encoding SQRSHRU_Z_MZ4__ // sqrshru_z_mz4_
                                when ('1', '0', '0') => __encoding SQRSHRN_Z_MZ4__ // sqrshrn_z_mz4_
                                when ('1', '0', '1') => __encoding UQRSHRN_Z_MZ4__ // uqrshrn_z_mz4_
                                when ('1', '1', '0') => __encoding SQRSHRUN_Z_MZ4__ // sqrshrun_z_mz4_
                when (_, '10', _, '1xx1xxxxx111000', _, _, _) =>
                    // mortlach_multi_sve_4
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 10 +: 6, 7 +: 3, 5 +: 2, 2 +: 3, 0 +: 2) of
                        when (_, '00', _, '000', '01', _, _, _, _, 'x0') => // mortlach_multi2_fpint_cvrt
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 1 +: 4
                            case (U) of
                                when ('0') => __encoding FCVTZS_MZ_Z_2 // fcvtzs_mz_z_2
                                when ('1') => __encoding FCVTZU_MZ_Z_2 // fcvtzu_mz_z_2
                        when (_, '00', _, '000', '01', _, _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '000', '10', _, _, _, _, 'x0') => // mortlach_multi2_intfp_cvrt
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 1 +: 4
                            case (U) of
                                when ('0') => __encoding SCVTF_MZ_Z_2 // scvtf_mz_z_2
                                when ('1') => __encoding UCVTF_MZ_Z_2 // ucvtf_mz_z_2
                        when (_, '00', _, '000', '10', _, _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '001', '11', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '100', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '100', '01', _, _, '0x', _, '00') => // mortlach_multi4_fpint_cvrt
                            __field Zn 7 +: 3
                            __field U 5 +: 1
                            __field Zd 2 +: 3
                            case (U) of
                                when ('0') => __encoding FCVTZS_MZ_Z_4 // fcvtzs_mz_z_4
                                when ('1') => __encoding FCVTZU_MZ_Z_4 // fcvtzu_mz_z_4
                        when (_, '00', _, '100', '01', _, _, '0x', _, !'00') => __UNPREDICTABLE
                        when (_, '00', _, '100', '01', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '100', '10', _, _, '0x', _, '00') => // mortlach_multi4_intfp_cvrt
                            __field Zn 7 +: 3
                            __field U 5 +: 1
                            __field Zd 2 +: 3
                            case (U) of
                                when ('0') => __encoding SCVTF_MZ_Z_4 // scvtf_mz_z_4
                                when ('1') => __encoding UCVTF_MZ_Z_4 // ucvtf_mz_z_4
                        when (_, '00', _, '100', '10', _, _, '0x', _, !'00') => __UNPREDICTABLE
                        when (_, '00', _, '100', '10', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '101', '00', _, _, '0x', _, _) => // mortlach_multi4_narrow_fp8_cvrt
                            __field Zn 7 +: 3
                            __field N 5 +: 1
                            __field Zd 0 +: 5
                            case (N) of
                                when ('0') => __encoding FCVT_Z8_MZ4__ // fcvt_z8_mz4_
                                when ('1') => __encoding FCVTN_Z8_MZ4__ // fcvtn_z8_mz4_
                        when (_, '00', _, '101', '00', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, '00', _, '101', '11', _, _, '00', _, 'x0') => // mortlach_multi4_z_z_long_zip
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            __field op 1 +: 1
                            case (op) of
                                when ('0') => __encoding ZIP_MZ_Z_4Q // zip_mz_z_4q
                                when ('1') => __encoding UZP_MZ_Z_4Q // uzp_mz_z_4q
                        when (_, '00', _, '101', '1x', _, _, '00', _, 'x1') => __UNPREDICTABLE
                        when (_, '00', _, '101', '1x', _, _, !'00', _, _) => __UNPREDICTABLE
                        when (_, '01', _, '000', '01', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '01', _, '101', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '01', _, 'x00', '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0x', _, '000', '00', _, _, _, _, _) => // mortlach_multi2_narrow_fp_cvrt
                            __field op 22 +: 1
                            __field Zn 6 +: 4
                            __field N 5 +: 1
                            __field Zd 0 +: 5
                            case (op, N) of
                                when ('0', '0') => __encoding FCVT_Z_MZ2__ // fcvt_z_mz2_
                                when ('0', '1') => __encoding FCVTN_Z_MZ2__ // fcvtn_z_mz2_
                                when ('1', '0') => __encoding BFCVT_Z_MZ2__ // bfcvt_z_mz2_
                                when ('1', '1') => __encoding BFCVTN_Z_MZ2__ // bfcvtn_z_mz2_
                        when (_, '0x', _, '000', '11', _, _, _, _, _) => // mortlach_multi2_narrow_int_cvrt
                            __field op 22 +: 1
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SQCVT_Z_MZ2__ // sqcvt_z_mz2_
                                when ('0', '1') => __encoding UQCVT_Z_MZ2__ // uqcvt_z_mz2_
                                when ('1', '0') => __encoding SQCVTU_Z_MZ2__ // sqcvtu_z_mz2_
                                when ('1', '1') => __UNALLOCATED
                        when (_, '0x', _, '001', '00', _, _, 'x0', _, _) => // mortlach_multi2_narrow_fp8_cvrt
                            __field op 22 +: 1
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding FCVT_Z8_MZ2__ // fcvt_z8_mz2_
                                when ('1') => __encoding BFCVT_Z8_MZ2__ // bfcvt_z8_mz2_
                        when (_, '0x', _, '001', '00', _, _, 'x1', _, _) => __UNPREDICTABLE
                        when (_, '10', _, '000', '00', _, _, _, _, _) => // mortlach_multi2_wide_fp_cvrt
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field L 0 +: 1
                            case (L) of
                                when ('0') => __encoding FCVT_MZ2_Z__ // fcvt_mz2_z_
                                when ('1') => __encoding FCVTL_MZ2_Z__ // fcvtl_mz2_z_
                        when (_, '10', _, '000', !'00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '11', _, '000', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1x', _, '100', '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1x', _, 'x01', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '100', '0x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '101', '10', _, _, '00', _, 'x1') => __UNPREDICTABLE
                        when (_, !'00', _, '101', '10', _, _, '01', _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '101', '10', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, !'00', _, 'x01', '11', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '001', '01', _, _, _, _, _) => // mortlach_multi2_wide_int
                            __field size 22 +: 2
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding SUNPK_MZ_Z_2 // sunpk_mz_z_2
                                when ('1') => __encoding UUNPK_MZ_Z_2 // uunpk_mz_z_2
                        when (_, _, _, '001', '10', _, _, _, _, _) => // mortlach_multi2_wide_fp8_cvrt
                            __field opc 22 +: 2
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field L 0 +: 1
                            case (opc, L) of
                                when ('00', '0') => __encoding F1CVT_MZ2_Z8__ // f1cvt_mz2_z8_
                                when ('00', '1') => __encoding F1CVTL_MZ2_Z8__ // f1cvtl_mz2_z8_
                                when ('01', '0') => __encoding BF1CVT_MZ2_Z8__ // bf1cvt_mz2_z8_
                                when ('01', '1') => __encoding BF1CVTL_MZ2_Z8__ // bf1cvtl_mz2_z8_
                                when ('10', '0') => __encoding F2CVT_MZ2_Z8__ // f2cvt_mz2_z8_
                                when ('10', '1') => __encoding F2CVTL_MZ2_Z8__ // f2cvtl_mz2_z8_
                                when ('11', '0') => __encoding BF2CVT_MZ2_Z8__ // bf2cvt_mz2_z8_
                                when ('11', '1') => __encoding BF2CVTL_MZ2_Z8__ // bf2cvtl_mz2_z8_
                        when (_, _, _, '01x', _, _, _, 'x0', _, 'x0') => // mortlach_multi2_frint
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Zn 6 +: 4
                            __field Zd 1 +: 4
                            case (size, opc) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '000') => __encoding FRINTN_MZ_Z_2 // frintn_mz_z_2
                                when ('10', '001') => __encoding FRINTP_MZ_Z_2 // frintp_mz_z_2
                                when ('10', '010') => __encoding FRINTM_MZ_Z_2 // frintm_mz_z_2
                                when ('10', '011') => __UNALLOCATED
                                when ('10', '100') => __encoding FRINTA_MZ_Z_2 // frinta_mz_z_2
                                when ('10', '101') => __UNALLOCATED
                                when ('10', '11x') => __UNALLOCATED
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '01x', _, _, _, 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, '01x', _, _, _, 'x1', _, _) => __UNPREDICTABLE
                        when (_, _, _, '100', '11', _, _, _, _, _) => // mortlach_multi4_narrow_int_cvrt
                            __field sz 23 +: 1
                            __field op 22 +: 1
                            __field Zn 7 +: 3
                            __field N 6 +: 1
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, N, U) of
                                when ('0', '0', '0') => __encoding SQCVT_Z_MZ4__ // sqcvt_z_mz4_
                                when ('0', '0', '1') => __encoding UQCVT_Z_MZ4__ // uqcvt_z_mz4_
                                when ('0', '1', '0') => __encoding SQCVTN_Z_MZ4__ // sqcvtn_z_mz4_
                                when ('0', '1', '1') => __encoding UQCVTN_Z_MZ4__ // uqcvtn_z_mz4_
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding SQCVTU_Z_MZ4__ // sqcvtu_z_mz4_
                                when ('1', '1', '0') => __encoding SQCVTUN_Z_MZ4__ // sqcvtun_z_mz4_
                        when (_, _, _, '101', '01', _, _, 'x0', _, '0x') => // mortlach_multi4_wide_int
                            __field size 22 +: 2
                            __field Zn 6 +: 4
                            __field Zd 2 +: 3
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding SUNPK_MZ_Z_4 // sunpk_mz_z_4
                                when ('1') => __encoding UUNPK_MZ_Z_4 // uunpk_mz_z_4
                        when (_, _, _, '101', '01', _, _, 'x0', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, '101', '01', _, _, 'x1', _, _) => __UNPREDICTABLE
                        when (_, _, _, '101', '10', _, _, '00', _, 'x0') => // mortlach_multi4_z_z_zip
                            __field size 22 +: 2
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            __field op 1 +: 1
                            case (op) of
                                when ('0') => __encoding ZIP_MZ_Z_4 // zip_mz_z_4
                                when ('1') => __encoding UZP_MZ_Z_4 // uzp_mz_z_4
                        when (_, _, _, '11x', _, _, _, '00', _, '00') => // mortlach_multi4_frint
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '000') => __encoding FRINTN_MZ_Z_4 // frintn_mz_z_4
                                when ('10', '001') => __encoding FRINTP_MZ_Z_4 // frintp_mz_z_4
                                when ('10', '010') => __encoding FRINTM_MZ_Z_4 // frintm_mz_z_4
                                when ('10', '011') => __UNALLOCATED
                                when ('10', '100') => __encoding FRINTA_MZ_Z_4 // frinta_mz_z_4
                                when ('10', '101') => __UNALLOCATED
                                when ('10', '11x') => __UNALLOCATED
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '11x', _, _, _, '00', _, !'00') => __UNPREDICTABLE
                        when (_, _, _, '11x', _, _, _, !'00', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx111001', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx11101x', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxx0101100', _, _, _) =>
                    // mortlach_multi_sve_2c0
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 10 +: 7, 7 +: 3, 0 +: 7) of
                        when (_, _, _, _, _, '000', _) => // mortlach_multi2_z_z_minmax_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 2
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('00', '0') => __encoding SMAX_MZ_ZZW_2x2 // smax_mz_zzw_2x2
                                when ('00', '1') => __encoding UMAX_MZ_ZZW_2x2 // umax_mz_zzw_2x2
                                when ('01', '0') => __encoding SMIN_MZ_ZZW_2x2 // smin_mz_zzw_2x2
                                when ('01', '1') => __encoding UMIN_MZ_ZZW_2x2 // umin_mz_zzw_2x2
                                when ('1x', _) => __UNALLOCATED
                        when (_, _, _, _, _, '001', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '010', _) => // mortlach_multi2_z_z_fminmax_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 2
                            __field Zdn 1 +: 4
                            __field o2 0 +: 1
                            case (size, opc, o2) of
                                when (_, '10', '0') => __encoding FAMAX_MZ_ZZW_2x2 // famax_mz_zzw_2x2
                                when (_, '10', '1') => __encoding FAMIN_MZ_ZZW_2x2 // famin_mz_zzw_2x2
                                when (_, '11', _) => __UNALLOCATED
                                when (!'00', '00', '0') => __encoding FMAX_MZ_ZZW_2x2 // fmax_mz_zzw_2x2
                                when (!'00', '00', '1') => __encoding FMIN_MZ_ZZW_2x2 // fmin_mz_zzw_2x2
                                when (!'00', '01', '0') => __encoding FMAXNM_MZ_ZZW_2x2 // fmaxnm_mz_zzw_2x2
                                when (!'00', '01', '1') => __encoding FMINNM_MZ_ZZW_2x2 // fminnm_mz_zzw_2x2
                                when ('00', '00', '0') => __encoding BFMAX_MZ_ZZW_2x2 // bfmax_mz_zzw_2x2
                                when ('00', '00', '1') => __encoding BFMIN_MZ_ZZW_2x2 // bfmin_mz_zzw_2x2
                                when ('00', '01', '0') => __encoding BFMAXNM_MZ_ZZW_2x2 // bfmaxnm_mz_zzw_2x2
                                when ('00', '01', '1') => __encoding BFMINNM_MZ_ZZW_2x2 // bfminnm_mz_zzw_2x2
                        when (_, _, _, _, _, '011', _) => // mortlach_multi2_z_z_fscale_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 2
                            __field Zdn 1 +: 4
                            __field o2 0 +: 1
                            case (opc, o2) of
                                when ('00', '0') => __encoding FSCALE_MZ_ZZW_2x2 // fscale_mz_zzw_2x2
                                when ('00', '1') => __UNALLOCATED
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                        when (_, _, _, _, _, '10x', _) => // mortlach_multi2_z_z_shift_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 3
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('000', _) => __UNALLOCATED
                                when ('001', '0') => __encoding SRSHL_MZ_ZZW_2x2 // srshl_mz_zzw_2x2
                                when ('001', '1') => __encoding URSHL_MZ_ZZW_2x2 // urshl_mz_zzw_2x2
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, _, _, '11x', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxx0101101', _, _, _) =>
                    // mortlach_multi_sve_2c1
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 10 +: 7, 5 +: 5, 0 +: 5) of
                        when (_, _, _, _, _, '00000', _) => // mortlach_multi2_z_z_sqdmulh_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field Zdn 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding SQDMULH_MZ_ZZW_2x2 // sqdmulh_mz_zzw_2x2
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, !'00000', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxx00101110', _, 'xxx0', _) =>
                    // mortlach_multi_sve_2d0
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 10 +: 8, 7 +: 3, 2 +: 5, 1 +: 1, 0 +: 1) of
                        when (_, _, _, _, _, '000', _, _, _) => // mortlach_multi4_z_z_minmax_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 2
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('00', '0') => __encoding SMAX_MZ_ZZW_4x4 // smax_mz_zzw_4x4
                                when ('00', '1') => __encoding UMAX_MZ_ZZW_4x4 // umax_mz_zzw_4x4
                                when ('01', '0') => __encoding SMIN_MZ_ZZW_4x4 // smin_mz_zzw_4x4
                                when ('01', '1') => __encoding UMIN_MZ_ZZW_4x4 // umin_mz_zzw_4x4
                                when ('1x', _) => __UNALLOCATED
                        when (_, _, _, _, _, '001', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '010', _, _, _) => // mortlach_multi4_z_z_fminmax_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 2
                            __field Zdn 2 +: 3
                            __field o2 0 +: 1
                            case (size, opc, o2) of
                                when (_, '10', '0') => __encoding FAMAX_MZ_ZZW_4x4 // famax_mz_zzw_4x4
                                when (_, '10', '1') => __encoding FAMIN_MZ_ZZW_4x4 // famin_mz_zzw_4x4
                                when (_, '11', _) => __UNALLOCATED
                                when (!'00', '00', '0') => __encoding FMAX_MZ_ZZW_4x4 // fmax_mz_zzw_4x4
                                when (!'00', '00', '1') => __encoding FMIN_MZ_ZZW_4x4 // fmin_mz_zzw_4x4
                                when (!'00', '01', '0') => __encoding FMAXNM_MZ_ZZW_4x4 // fmaxnm_mz_zzw_4x4
                                when (!'00', '01', '1') => __encoding FMINNM_MZ_ZZW_4x4 // fminnm_mz_zzw_4x4
                                when ('00', '00', '0') => __encoding BFMAX_MZ_ZZW_4x4 // bfmax_mz_zzw_4x4
                                when ('00', '00', '1') => __encoding BFMIN_MZ_ZZW_4x4 // bfmin_mz_zzw_4x4
                                when ('00', '01', '0') => __encoding BFMAXNM_MZ_ZZW_4x4 // bfmaxnm_mz_zzw_4x4
                                when ('00', '01', '1') => __encoding BFMINNM_MZ_ZZW_4x4 // bfminnm_mz_zzw_4x4
                        when (_, _, _, _, _, '011', _, _, _) => // mortlach_multi4_z_z_fscale_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 2
                            __field Zdn 2 +: 3
                            __field o2 0 +: 1
                            case (opc, o2) of
                                when ('00', '0') => __encoding FSCALE_MZ_ZZW_4x4 // fscale_mz_zzw_4x4
                                when ('00', '1') => __UNALLOCATED
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                        when (_, _, _, _, _, '10x', _, _, _) => // mortlach_multi4_z_z_shift_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 3
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('000', _) => __UNALLOCATED
                                when ('001', '0') => __encoding SRSHL_MZ_ZZW_4x4 // srshl_mz_zzw_4x4
                                when ('001', '1') => __encoding URSHL_MZ_ZZW_4x4 // urshl_mz_zzw_4x4
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, _, _, '11x', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxx00101111', _, 'xxx0', _) =>
                    // mortlach_multi_sve_2d1
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 10 +: 8, 5 +: 5, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, _, _, _, _, '00000', _, _, _) => // mortlach_multi4_z_z_sqdmulh_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field Zdn 2 +: 3
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding SQDMULH_MZ_ZZW_4x4 // sqdmulh_mz_zzw_4x4
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, !'00000', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxx1010111x', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxxx10100x', _, _, _) =>
                    // mortlach_multi_sve_2a
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 11 +: 5, 10 +: 1, 8 +: 2, 5 +: 3, 0 +: 5) of
                        when (_, _, _, _, _, '0', '00', '00x', _) => // mortlach_multi2_z_z_minmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (op, U) of
                                when ('0', '0') => __encoding SMAX_MZ_ZZV_2x1 // smax_mz_zzv_2x1
                                when ('0', '1') => __encoding UMAX_MZ_ZZV_2x1 // umax_mz_zzv_2x1
                                when ('1', '0') => __encoding SMIN_MZ_ZZV_2x1 // smin_mz_zzv_2x1
                                when ('1', '1') => __encoding UMIN_MZ_ZZV_2x1 // umin_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '01', '00x', _) => // mortlach_multi2_z_z_fminmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 1 +: 4
                            __field o2 0 +: 1
                            case (size, op, o2) of
                                when (!'00', '0', '0') => __encoding FMAX_MZ_ZZV_2x1 // fmax_mz_zzv_2x1
                                when (!'00', '0', '1') => __encoding FMIN_MZ_ZZV_2x1 // fmin_mz_zzv_2x1
                                when (!'00', '1', '0') => __encoding FMAXNM_MZ_ZZV_2x1 // fmaxnm_mz_zzv_2x1
                                when (!'00', '1', '1') => __encoding FMINNM_MZ_ZZV_2x1 // fminnm_mz_zzv_2x1
                                when ('00', '0', '0') => __encoding BFMAX_MZ_ZZV_2x1 // bfmax_mz_zzv_2x1
                                when ('00', '0', '1') => __encoding BFMIN_MZ_ZZV_2x1 // bfmin_mz_zzv_2x1
                                when ('00', '1', '0') => __encoding BFMAXNM_MZ_ZZV_2x1 // bfmaxnm_mz_zzv_2x1
                                when ('00', '1', '1') => __encoding BFMINNM_MZ_ZZV_2x1 // bfminnm_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '01', '100', _) => // mortlach_multi2_z_z_fscale_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding FSCALE_MZ_ZZV_2x1 // fscale_mz_zzv_2x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '0', '01', '101', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '01', 'x1x', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '10', _, _) => // mortlach_multi2_z_z_shift_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field opc 5 +: 3
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('000', _) => __UNALLOCATED
                                when ('001', '0') => __encoding SRSHL_MZ_ZZV_2x1 // srshl_mz_zzv_2x1
                                when ('001', '1') => __encoding URSHL_MZ_ZZV_2x1 // urshl_mz_zzv_2x1
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, _, _, '0', '11', '000', _) => // mortlach_multi2_z_z_add_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding ADD_MZ_ZZV_2x1 // add_mz_zzv_2x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '0', '11', !'000', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00', '000', _) => // mortlach_multi2_z_z_sqdmulh_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding SQDMULH_MZ_ZZV_2x1 // sqdmulh_mz_zzv_2x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '1', '00', '001', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', !'00', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00', !'00x', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxxx10101x', _, 'xxx0', _) =>
                    // mortlach_multi_sve_2b
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 11 +: 5, 10 +: 1, 8 +: 2, 5 +: 3, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, _, _, _, _, '0', '00', '00x', _, _, _) => // mortlach_multi4_z_z_minmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (op, U) of
                                when ('0', '0') => __encoding SMAX_MZ_ZZV_4x1 // smax_mz_zzv_4x1
                                when ('0', '1') => __encoding UMAX_MZ_ZZV_4x1 // umax_mz_zzv_4x1
                                when ('1', '0') => __encoding SMIN_MZ_ZZV_4x1 // smin_mz_zzv_4x1
                                when ('1', '1') => __encoding UMIN_MZ_ZZV_4x1 // umin_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '01', '00x', _, _, _) => // mortlach_multi4_z_z_fminmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 2 +: 3
                            __field o2 0 +: 1
                            case (size, op, o2) of
                                when (!'00', '0', '0') => __encoding FMAX_MZ_ZZV_4x1 // fmax_mz_zzv_4x1
                                when (!'00', '0', '1') => __encoding FMIN_MZ_ZZV_4x1 // fmin_mz_zzv_4x1
                                when (!'00', '1', '0') => __encoding FMAXNM_MZ_ZZV_4x1 // fmaxnm_mz_zzv_4x1
                                when (!'00', '1', '1') => __encoding FMINNM_MZ_ZZV_4x1 // fminnm_mz_zzv_4x1
                                when ('00', '0', '0') => __encoding BFMAX_MZ_ZZV_4x1 // bfmax_mz_zzv_4x1
                                when ('00', '0', '1') => __encoding BFMIN_MZ_ZZV_4x1 // bfmin_mz_zzv_4x1
                                when ('00', '1', '0') => __encoding BFMAXNM_MZ_ZZV_4x1 // bfmaxnm_mz_zzv_4x1
                                when ('00', '1', '1') => __encoding BFMINNM_MZ_ZZV_4x1 // bfminnm_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '01', '100', _, _, _) => // mortlach_multi4_z_z_fscale_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 2 +: 3
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding FSCALE_MZ_ZZV_4x1 // fscale_mz_zzv_4x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '0', '01', '101', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '01', 'x1x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '10', _, _, _, _) => // mortlach_multi4_z_z_shift_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field opc 5 +: 3
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('000', _) => __UNALLOCATED
                                when ('001', '0') => __encoding SRSHL_MZ_ZZV_4x1 // srshl_mz_zzv_4x1
                                when ('001', '1') => __encoding URSHL_MZ_ZZV_4x1 // urshl_mz_zzv_4x1
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, _, _, '0', '11', '000', _, _, _) => // mortlach_multi4_z_z_add_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 2 +: 3
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding ADD_MZ_ZZV_4x1 // add_mz_zzv_4x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '0', '11', !'000', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00', '000', _, _, _) => // mortlach_multi4_z_z_sqdmulh_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 2 +: 3
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding SQDMULH_MZ_ZZV_4x1 // sqdmulh_mz_zzv_4x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '1', '00', '001', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', !'00', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00', !'00x', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxx01111xx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxx11x11xx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xx00101x1x', _, 'xxx1', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xx0110101x', _, 'xxx1', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xx1x10101x', _, 'xxx1', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx11xxxx1111xx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx11xxx01010xx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx11xxx1101xxx', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx11xx0010111x', _, 'xxx1', _) => __UNPREDICTABLE
                when (_, '10', _, '10x10xxxx0xxxxx', _, _, _) =>
                    // mortlach_multi_array_1a
                    case (23 +: 9, 22 +: 1, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 10 +: 3, 5 +: 5, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, _, _, _, '000', _, '000', '1', _) => // mortlach_multi2_zz_za_fp8_fma_long_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding FMLALL_ZA32_Z8Z8V_2x1 // fmlall_za32_z8z8v_2x1
                        when (_, '0', _, _, _, _, '000', _, !'000', '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '010', _, _, _, _) => // mortlach_multi2_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field o2 2 +: 1
                            __field off2 0 +: 2
                            case (op, S, o2) of
                                when ('0', '0', '0') => __encoding FMLAL_ZA_ZZV_2x1 // fmlal_za_zzv_2x1
                                when ('0', '0', '1') => __encoding FMLAL_ZA_Z8Z8V_2x1 // fmlal_za_z8z8v_2x1
                                when ('0', '1', '0') => __encoding FMLSL_ZA_ZZV_2x1 // fmlsl_za_zzv_2x1
                                when ('0', '1', '1') => __UNALLOCATED
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding BFMLAL_ZA_ZZV_2x1 // bfmlal_za_zzv_2x1
                                when ('1', '1', '0') => __encoding BFMLSL_ZA_ZZV_2x1 // bfmlsl_za_zzv_2x1
                        when (_, '0', _, _, _, _, '011', _, _, _, _) => // mortlach_multi1_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZV_1 // fmlal_za_zzv_1
                                when ('0', '1') => __encoding FMLSL_ZA_ZZV_1 // fmlsl_za_zzv_1
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZV_1 // bfmlal_za_zzv_1
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZV_1 // bfmlsl_za_zzv_1
                        when (_, '0', _, _, _, _, '100', _, _, _, _) => // mortlach_multi2_z_za_fpdot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field opc 3 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding FDOT_ZA_ZZV_2x1 // fdot_za_zzv_2x1
                                when ('01') => __encoding FDOT_ZA_Z8Z8V_2x1 // fdot_za_z8z8v_2x1
                                when ('10') => __encoding BFDOT_ZA_ZZV_2x1 // bfdot_za_zzv_2x1
                                when ('11') => __encoding FDOT_ZA32_Z8Z8V_2x1 // fdot_za32_z8z8v_2x1
                        when (_, '0', _, _, _, _, '101', _, 'x1x', _, _) => // mortlach_multi2_z_za_mixed_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding USDOT_ZA_ZZV_S2x1 // usdot_za_zzv_s2x1
                                when ('1') => __encoding SUDOT_ZA_ZZV_S2x1 // sudot_za_zzv_s2x1
                        when (_, '1', _, _, _, _, '000', _, _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '010', _, _, _, _) => // mortlach_multi2_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (U, S, op) of
                                when (_, _, '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding SMLAL_ZA_ZZV_2x1 // smlal_za_zzv_2x1
                                when ('0', '1', '0') => __encoding SMLSL_ZA_ZZV_2x1 // smlsl_za_zzv_2x1
                                when ('1', '0', '0') => __encoding UMLAL_ZA_ZZV_2x1 // umlal_za_zzv_2x1
                                when ('1', '1', '0') => __encoding UMLSL_ZA_ZZV_2x1 // umlsl_za_zzv_2x1
                        when (_, '1', _, _, _, _, '011', _, _, _, _) => // mortlach_multi1_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZV_1 // smlal_za_zzv_1
                                when ('0', '1') => __encoding SMLSL_ZA_ZZV_1 // smlsl_za_zzv_1
                                when ('1', '0') => __encoding UMLAL_ZA_ZZV_1 // umlal_za_zzv_1
                                when ('1', '1') => __encoding UMLSL_ZA_ZZV_1 // umlsl_za_zzv_1
                        when (_, '1', _, _, _, _, '100', _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '101', _, 'x1x', _, _) => // mortlach_multi2_z_za_2way_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA32_ZZV_2x1 // sdot_za32_zzv_2x1
                                when ('1') => __encoding UDOT_ZA32_ZZV_2x1 // udot_za32_zzv_2x1
                        when (_, _, _, _, _, _, '000', _, _, '0', _) => // mortlach_multi2_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZV_2x1 // smlall_za_zzv_2x1
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZV_2x1 // smlsll_za_zzv_2x1
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZV_2x1 // umlall_za_zzv_2x1
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZV_2x1 // umlsll_za_zzv_2x1
                                when ('0', _, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZV_S2x1 // usmlall_za_zzv_s2x1
                                when ('0', '1', '0', '1') => __encoding SUMLALL_ZA_ZZV_S2x1 // sumlall_za_zzv_s2x1
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, '001', _, _, _, _) => // mortlach_multi1_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZV_1 // smlall_za_zzv_1
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZV_1 // smlsll_za_zzv_1
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZV_1 // umlall_za_zzv_1
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZV_1 // umlsll_za_zzv_1
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZV_S // usmlall_za_zzv_s
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, '101', _, 'x0x', _, _) => // mortlach_multi2_z_za_4way_dot_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA_ZZV_2x1 // sdot_za_zzv_2x1
                                when ('1') => __encoding UDOT_ZA_ZZV_2x1 // udot_za_zzv_2x1
                        when (_, _, _, _, _, _, '110', _, '0xx', _, _) => // mortlach_multi2_zz_za_float_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMLA_ZA_ZZV_2x1 // fmla_za_zzv_2x1
                                when ('1') => __encoding FMLS_ZA_ZZV_2x1 // fmls_za_zzv_2x1
                        when (_, _, _, _, _, _, '110', _, '1xx', _, _) => // mortlach_multi2_zz_za_int_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZZV_2x1 // add_za_zzv_2x1
                                when ('1') => __encoding SUB_ZA_ZZV_2x1 // sub_za_zzv_2x1
                        when (_, _, _, _, _, _, '111', _, '0xx', _, _) => // mortlach_multi2_zz_za_f16_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZV_2x1_16 // fmla_za_zzv_2x1_16
                                when ('0', '1') => __encoding FMLS_ZA_ZZV_2x1_16 // fmls_za_zzv_2x1_16
                                when ('1', '0') => __encoding BFMLA_ZA_ZZV_2x1_16 // bfmla_za_zzv_2x1_16
                                when ('1', '1') => __encoding BFMLS_ZA_ZZV_2x1_16 // bfmls_za_zzv_2x1_16
                        when (_, _, _, _, _, _, '111', _, '1xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '10x11xxxx0xxxxx', _, _, _) =>
                    // mortlach_multi_array_1b
                    case (23 +: 9, 22 +: 1, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 10 +: 3, 5 +: 5, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, _, _, _, '000', _, '000', '1', _) => // mortlach_multi4_zz_za_fp8_fma_long_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding FMLALL_ZA32_Z8Z8V_4x1 // fmlall_za32_z8z8v_4x1
                        when (_, '0', _, _, _, _, '000', _, !'000', '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '001', _, '000', _, _) => // mortlach_multi1_zz_za_fp8_fma_long_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding FMLALL_ZA32_Z8Z8V_1 // fmlall_za32_z8z8v_1
                        when (_, '0', _, _, _, _, '001', _, '001', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '010', _, _, _, _) => // mortlach_multi4_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field o2 2 +: 1
                            __field off2 0 +: 2
                            case (op, S, o2) of
                                when ('0', '0', '0') => __encoding FMLAL_ZA_ZZV_4x1 // fmlal_za_zzv_4x1
                                when ('0', '0', '1') => __encoding FMLAL_ZA_Z8Z8V_4x1 // fmlal_za_z8z8v_4x1
                                when ('0', '1', '0') => __encoding FMLSL_ZA_ZZV_4x1 // fmlsl_za_zzv_4x1
                                when ('0', '1', '1') => __UNALLOCATED
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding BFMLAL_ZA_ZZV_4x1 // bfmlal_za_zzv_4x1
                                when ('1', '1', '0') => __encoding BFMLSL_ZA_ZZV_4x1 // bfmlsl_za_zzv_4x1
                        when (_, '0', _, _, _, _, '011', _, '00x', _, _) => // mortlach_multi1_zz_za_fp8_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding FMLAL_ZA_Z8Z8V_1 // fmlal_za_z8z8v_1
                        when (_, '0', _, _, _, _, '0x1', _, !'00x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '100', _, _, _, _) => // mortlach_multi4_z_za_fpdot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field opc 3 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding FDOT_ZA_ZZV_4x1 // fdot_za_zzv_4x1
                                when ('01') => __encoding FDOT_ZA_Z8Z8V_4x1 // fdot_za_z8z8v_4x1
                                when ('10') => __encoding BFDOT_ZA_ZZV_4x1 // bfdot_za_zzv_4x1
                                when ('11') => __encoding FDOT_ZA32_Z8Z8V_4x1 // fdot_za32_z8z8v_4x1
                        when (_, '0', _, _, _, _, '101', _, 'x1x', _, _) => // mortlach_multi4_z_za_mixed_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding USDOT_ZA_ZZV_S4x1 // usdot_za_zzv_s4x1
                                when ('1') => __encoding SUDOT_ZA_ZZV_S4x1 // sudot_za_zzv_s4x1
                        when (_, '1', _, _, _, _, '000', _, _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '010', _, _, _, _) => // mortlach_multi4_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (U, S, op) of
                                when (_, _, '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding SMLAL_ZA_ZZV_4x1 // smlal_za_zzv_4x1
                                when ('0', '1', '0') => __encoding SMLSL_ZA_ZZV_4x1 // smlsl_za_zzv_4x1
                                when ('1', '0', '0') => __encoding UMLAL_ZA_ZZV_4x1 // umlal_za_zzv_4x1
                                when ('1', '1', '0') => __encoding UMLSL_ZA_ZZV_4x1 // umlsl_za_zzv_4x1
                        when (_, '1', _, _, _, _, '0x1', _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '100', _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '101', _, 'x1x', _, _) => // mortlach_multi4_z_za_2way_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA32_ZZV_4x1 // sdot_za32_zzv_4x1
                                when ('1') => __encoding UDOT_ZA32_ZZV_4x1 // udot_za32_zzv_4x1
                        when (_, _, _, _, _, _, '000', _, _, '0', _) => // mortlach_multi4_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZV_4x1 // smlall_za_zzv_4x1
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZV_4x1 // smlsll_za_zzv_4x1
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZV_4x1 // umlall_za_zzv_4x1
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZV_4x1 // umlsll_za_zzv_4x1
                                when ('0', _, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZV_S4x1 // usmlall_za_zzv_s4x1
                                when ('0', '1', '0', '1') => __encoding SUMLALL_ZA_ZZV_S4x1 // sumlall_za_zzv_s4x1
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, '101', _, 'x0x', _, _) => // mortlach_multi4_z_za_4way_dot_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA_ZZV_4x1 // sdot_za_zzv_4x1
                                when ('1') => __encoding UDOT_ZA_ZZV_4x1 // udot_za_zzv_4x1
                        when (_, _, _, _, _, _, '110', _, '0xx', _, _) => // mortlach_multi4_zz_za_float_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMLA_ZA_ZZV_4x1 // fmla_za_zzv_4x1
                                when ('1') => __encoding FMLS_ZA_ZZV_4x1 // fmls_za_zzv_4x1
                        when (_, _, _, _, _, _, '110', _, '1xx', _, _) => // mortlach_multi4_zz_za_int_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZZV_4x1 // add_za_zzv_4x1
                                when ('1') => __encoding SUB_ZA_ZZV_4x1 // sub_za_zzv_4x1
                        when (_, _, _, _, _, _, '111', _, '0xx', _, _) => // mortlach_multi4_zz_za_f16_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZV_4x1_16 // fmla_za_zzv_4x1_16
                                when ('0', '1') => __encoding FMLS_ZA_ZZV_4x1_16 // fmls_za_zzv_4x1_16
                                when ('1', '0') => __encoding BFMLA_ZA_ZZV_4x1_16 // bfmla_za_zzv_4x1_16
                                when ('1', '1') => __encoding BFMLS_ZA_ZZV_4x1_16 // bfmls_za_zzv_4x1_16
                        when (_, _, _, _, _, _, '111', _, '1xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '11x1xxxx00xxxxx', _, _, _) =>
                    // mortlach_multi_array_2a
                    case (23 +: 9, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 15 +: 2, 13 +: 2, 10 +: 3, 6 +: 4, 5 +: 1, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, '00', 'x0', _, _, '11x', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '000', _, '1', '000', '0', _) => // mortlach_multi2_zz_za_fp8_fma_long_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding FMLALL_ZA32_Z8Z8W_2x2 // fmlall_za32_z8z8w_2x2
                        when (_, '0', _, _, _, _, _, '000', _, '1', '000', '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '010', _, '0', 'xx0', _, _) => // mortlach_multi2_zz_za_fma_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZW_2x2 // fmlal_za_zzw_2x2
                                when ('0', '1') => __encoding FMLSL_ZA_ZZW_2x2 // fmlsl_za_zzw_2x2
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZW_2x2 // bfmlal_za_zzw_2x2
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZW_2x2 // bfmlsl_za_zzw_2x2
                        when (_, '0', _, _, _, _, _, '010', _, '1', '000', _, _) => // mortlach_multi2_zz_za_fp8_fma_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding FMLAL_ZA_Z8Z8W_2x2 // fmlal_za_z8z8w_2x2
                        when (_, '0', _, _, _, _, _, '0x0', _, '1', !'000', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '100', _, '1', 'x1x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '100', _, _, 'x0x', _, _) => // mortlach_multi2_z_za_fpdot_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field opc 4 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding FDOT_ZA_ZZW_2x2 // fdot_za_zzw_2x2
                                when ('01') => __encoding BFDOT_ZA_ZZW_2x2 // bfdot_za_zzw_2x2
                                when ('10') => __encoding FDOT_ZA_Z8Z8W_2x2 // fdot_za_z8z8w_2x2
                                when ('11') => __encoding FDOT_ZA32_Z8Z8W_2x2 // fdot_za32_z8z8w_2x2
                        when (_, '0', _, _, _, _, _, '101', _, '0', '01x', _, _) => // mortlach_multi2_z_za_mixed_dot_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding USDOT_ZA_ZZW_S2x2 // usdot_za_zzw_s2x2
                        when (_, '0', _, _, _, _, _, '101', _, '0', '11x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '101', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, '00', 'x0', _, _, '1xx', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, '00', 'x1', _, _, '10x', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, !'00', _, _, _, '10x', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, '010', _, '0', 'xx0', _, _) => // mortlach_multi2_zz_za_mla_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZW_2x2 // smlal_za_zzw_2x2
                                when ('0', '1') => __encoding SMLSL_ZA_ZZW_2x2 // smlsl_za_zzw_2x2
                                when ('1', '0') => __encoding UMLAL_ZA_ZZW_2x2 // umlal_za_zzw_2x2
                                when ('1', '1') => __encoding UMLSL_ZA_ZZW_2x2 // umlsl_za_zzw_2x2
                        when (_, '1', _, _, _, _, _, '0x0', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, '100', _, '0', 'x0x', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, '101', _, '0', 'x1x', _, _) => // mortlach_multi2_z_za_2way_dot_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA32_ZZW_2x2 // sdot_za32_zzw_2x2
                                when ('1') => __encoding UDOT_ZA32_ZZW_2x2 // udot_za32_zzw_2x2
                        when (_, _, _, '00', '00', _, _, '111', _, '0', '0xx', _, _) => // mortlach_multi2_z_za_float_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FADD_ZA_ZW_2x2 // fadd_za_zw_2x2
                                when ('1') => __encoding FSUB_ZA_ZW_2x2 // fsub_za_zw_2x2
                        when (_, _, _, '00', '00', _, _, '111', _, '0', '1xx', _, _) => // mortlach_multi2_z_za_int_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZW_2x2 // add_za_zw_2x2
                                when ('1') => __encoding SUB_ZA_ZW_2x2 // sub_za_zw_2x2
                        when (_, _, _, '00', '10', _, _, '111', _, '0', '0xx', _, _) => // mortlach_multi2_z_za_f16_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FADD_ZA_ZW_2x2_16 // fadd_za_zw_2x2_16
                                when ('0', '1') => __encoding FSUB_ZA_ZW_2x2_16 // fsub_za_zw_2x2_16
                                when ('1', '0') => __encoding BFADD_ZA_ZW_2x2_16 // bfadd_za_zw_2x2_16
                                when ('1', '1') => __encoding BFSUB_ZA_ZW_2x2_16 // bfsub_za_zw_2x2_16
                        when (_, _, _, '00', '10', _, _, '111', _, '0', '1xx', _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x1', _, _, '110', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x1', _, _, '111', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', _, _, _, '110', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', _, _, _, '111', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '000', _, '0', _, '0', _) => // mortlach_multi2_zz_za_mla_long_long_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZW_2x2 // smlall_za_zzw_2x2
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZW_2x2 // smlsll_za_zzw_2x2
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZW_2x2 // umlall_za_zzw_2x2
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZW_2x2 // umlsll_za_zzw_2x2
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZW_S2x2 // usmlall_za_zzw_s2x2
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, _, '000', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '010', _, '0', 'xx1', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '0x1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '100', _, '0', 'x1x', _, _) => // mortlach_multi2_zz_za_f16_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 4 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZW_2x2_16 // fmla_za_zzw_2x2_16
                                when ('0', '1') => __encoding FMLS_ZA_ZZW_2x2_16 // fmls_za_zzw_2x2_16
                                when ('1', '0') => __encoding BFMLA_ZA_ZZW_2x2_16 // bfmla_za_zzw_2x2_16
                                when ('1', '1') => __encoding BFMLS_ZA_ZZW_2x2_16 // bfmls_za_zzw_2x2_16
                        when (_, _, _, _, _, _, _, '101', _, '0', 'x0x', _, _) => // mortlach_multi2_z_za_4way_dot_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA_ZZW_2x2 // sdot_za_zzw_2x2
                                when ('1') => __encoding UDOT_ZA_ZZW_2x2 // udot_za_zzw_2x2
                        when (_, _, _, _, _, _, _, '110', _, '0', '0xx', _, _) => // mortlach_multi2_zz_za_float_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMLA_ZA_ZZW_2x2 // fmla_za_zzw_2x2
                                when ('1') => __encoding FMLS_ZA_ZZW_2x2 // fmls_za_zzw_2x2
                        when (_, _, _, _, _, _, _, '110', _, '0', '1xx', _, _) => // mortlach_multi2_zz_za_int_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZZW_2x2 // add_za_zzw_2x2
                                when ('1') => __encoding SUB_ZA_ZZW_2x2 // sub_za_zzw_2x2
                when (_, '10', _, '11x1xxxx10xxxxx', _, _, _) =>
                    // mortlach_multi_array_2b
                    case (23 +: 9, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 15 +: 2, 13 +: 2, 10 +: 3, 7 +: 3, 5 +: 2, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, '00', 'x0', _, _, '11x', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '000', _, '01', '000', '0', _) => // mortlach_multi4_zz_za_fp8_fma_long_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding FMLALL_ZA32_Z8Z8W_4x4 // fmlall_za32_z8z8w_4x4
                        when (_, '0', _, _, 'x0', _, _, '000', _, '01', '000', '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '010', _, '00', 'xx0', _, _) => // mortlach_multi4_zz_za_fma_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding FMLAL_ZA_ZZW_4x4 // fmlal_za_zzw_4x4
                                when ('0', '1') => __encoding FMLSL_ZA_ZZW_4x4 // fmlsl_za_zzw_4x4
                                when ('1', '0') => __encoding BFMLAL_ZA_ZZW_4x4 // bfmlal_za_zzw_4x4
                                when ('1', '1') => __encoding BFMLSL_ZA_ZZW_4x4 // bfmlsl_za_zzw_4x4
                        when (_, '0', _, _, 'x0', _, _, '010', _, '01', '000', _, _) => // mortlach_multi4_zz_za_fp8_fma_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding FMLAL_ZA_Z8Z8W_4x4 // fmlal_za_z8z8w_4x4
                        when (_, '0', _, _, 'x0', _, _, '0x0', _, '01', !'000', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '100', _, '01', 'x1x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '100', _, '0x', 'x0x', _, _) => // mortlach_multi4_z_za_fpdot_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field opc 4 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding FDOT_ZA_ZZW_4x4 // fdot_za_zzw_4x4
                                when ('01') => __encoding BFDOT_ZA_ZZW_4x4 // bfdot_za_zzw_4x4
                                when ('10') => __encoding FDOT_ZA_Z8Z8W_4x4 // fdot_za_z8z8w_4x4
                                when ('11') => __encoding FDOT_ZA32_Z8Z8W_4x4 // fdot_za32_z8z8w_4x4
                        when (_, '0', _, _, 'x0', _, _, '101', _, '00', '01x', _, _) => // mortlach_multi4_z_za_mixed_dot_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding USDOT_ZA_ZZW_S4x4 // usdot_za_zzw_s4x4
                        when (_, '0', _, _, 'x0', _, _, '101', _, '00', '11x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '101', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, '00', 'x0', _, _, '1xx', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, !'00', 'x0', _, _, '10x', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, 'x0', _, _, '010', _, '00', 'xx0', _, _) => // mortlach_multi4_zz_za_mla_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding SMLAL_ZA_ZZW_4x4 // smlal_za_zzw_4x4
                                when ('0', '1') => __encoding SMLSL_ZA_ZZW_4x4 // smlsl_za_zzw_4x4
                                when ('1', '0') => __encoding UMLAL_ZA_ZZW_4x4 // umlal_za_zzw_4x4
                                when ('1', '1') => __encoding UMLSL_ZA_ZZW_4x4 // umlsl_za_zzw_4x4
                        when (_, '1', _, _, 'x0', _, _, '0x0', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, 'x0', _, _, '100', _, '00', 'x0x', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, 'x0', _, _, '101', _, '00', 'x1x', _, _) => // mortlach_multi4_z_za_2way_dot_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA32_ZZW_4x4 // sdot_za32_zzw_4x4
                                when ('1') => __encoding UDOT_ZA32_ZZW_4x4 // udot_za32_zzw_4x4
                        when (_, _, _, '00', '00', _, _, '111', _, '00', '0xx', _, _) => // mortlach_multi4_z_za_float_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FADD_ZA_ZW_4x4 // fadd_za_zw_4x4
                                when ('1') => __encoding FSUB_ZA_ZW_4x4 // fsub_za_zw_4x4
                        when (_, _, _, '00', '00', _, _, '111', _, '00', '1xx', _, _) => // mortlach_multi4_z_za_int_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZW_4x4 // add_za_zw_4x4
                                when ('1') => __encoding SUB_ZA_ZW_4x4 // sub_za_zw_4x4
                        when (_, _, _, '00', '10', _, _, '111', _, '00', '0xx', _, _) => // mortlach_multi4_z_za_f16_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FADD_ZA_ZW_4x4_16 // fadd_za_zw_4x4_16
                                when ('0', '1') => __encoding FSUB_ZA_ZW_4x4_16 // fsub_za_zw_4x4_16
                                when ('1', '0') => __encoding BFADD_ZA_ZW_4x4_16 // bfadd_za_zw_4x4_16
                                when ('1', '1') => __encoding BFSUB_ZA_ZW_4x4_16 // bfsub_za_zw_4x4_16
                        when (_, _, _, '00', '10', _, _, '111', _, '00', '1xx', _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x0', _, _, '1xx', _, '1x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', 'x0', _, _, '10x', _, '1x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', 'x0', _, _, '110', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', 'x0', _, _, '110', _, '1x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00', 'x0', _, _, '111', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '000', _, '00', _, '0', _) => // mortlach_multi4_zz_za_mla_long_long_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding SMLALL_ZA_ZZW_4x4 // smlall_za_zzw_4x4
                                when (_, '0', '1', '0') => __encoding SMLSLL_ZA_ZZW_4x4 // smlsll_za_zzw_4x4
                                when (_, '1', '0', '0') => __encoding UMLALL_ZA_ZZW_4x4 // umlall_za_zzw_4x4
                                when (_, '1', '1', '0') => __encoding UMLSLL_ZA_ZZW_4x4 // umlsll_za_zzw_4x4
                                when ('0', '0', '0', '1') => __encoding USMLALL_ZA_ZZW_S4x4 // usmlall_za_zzw_s4x4
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, 'x0', _, _, '000', _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '010', _, '00', 'xx1', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '0x0', _, '1x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '0x1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '100', _, '00', 'x1x', _, _) => // mortlach_multi4_zz_za_f16_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 4 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding FMLA_ZA_ZZW_4x4_16 // fmla_za_zzw_4x4_16
                                when ('0', '1') => __encoding FMLS_ZA_ZZW_4x4_16 // fmls_za_zzw_4x4_16
                                when ('1', '0') => __encoding BFMLA_ZA_ZZW_4x4_16 // bfmla_za_zzw_4x4_16
                                when ('1', '1') => __encoding BFMLS_ZA_ZZW_4x4_16 // bfmls_za_zzw_4x4_16
                        when (_, _, _, _, 'x0', _, _, '101', _, '00', 'x0x', _, _) => // mortlach_multi4_z_za_4way_dot_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding SDOT_ZA_ZZW_4x4 // sdot_za_zzw_4x4
                                when ('1') => __encoding UDOT_ZA_ZZW_4x4 // udot_za_zzw_4x4
                        when (_, _, _, _, 'x0', _, _, '110', _, '00', '0xx', _, _) => // mortlach_multi4_zz_za_float_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding FMLA_ZA_ZZW_4x4 // fmla_za_zzw_4x4
                                when ('1') => __encoding FMLS_ZA_ZZW_4x4 // fmls_za_zzw_4x4
                        when (_, _, _, _, 'x0', _, _, '110', _, '00', '1xx', _, _) => // mortlach_multi4_zz_za_int_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding ADD_ZA_ZZW_4x4 // add_za_zzw_4x4
                                when ('1') => __encoding SUB_ZA_ZZW_4x4 // sub_za_zzw_4x4
                        when (_, _, _, _, 'x1', _, _, _, _, _, _, _, _) => __UNPREDICTABLE
                when (_, '11', _, _, _, _, _) =>
                    // mortlach_mem
                    case (25 +: 7, 21 +: 4, 16 +: 5, 15 +: 1, 10 +: 5, 5 +: 5, 2 +: 3, 0 +: 2) of
                        when (_, '0xx0', _, _, _, _, '0xx', _) => // mortlach_contig_load
                            __field msz 22 +: 2
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field opc 0 +: 4
                            case (msz) of
                                when ('00') => __encoding LD1B_ZA_P_RRR__ // ld1b_za_p_rrr_
                                when ('01') => __encoding LD1H_ZA_P_RRR__ // ld1h_za_p_rrr_
                                when ('10') => __encoding LD1W_ZA_P_RRR__ // ld1w_za_p_rrr_
                                when ('11') => __encoding LD1D_ZA_P_RRR__ // ld1d_za_p_rrr_
                        when (_, '0xx1', _, _, _, _, '0xx', _) => // mortlach_contig_store
                            __field msz 22 +: 2
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field opc 0 +: 4
                            case (msz) of
                                when ('00') => __encoding ST1B_ZA_P_RRR__ // st1b_za_p_rrr_
                                when ('01') => __encoding ST1H_ZA_P_RRR__ // st1h_za_p_rrr_
                                when ('10') => __encoding ST1W_ZA_P_RRR__ // st1w_za_p_rrr_
                                when ('11') => __encoding ST1D_ZA_P_RRR__ // st1d_za_p_rrr_
                        when (_, '0xxx', _, _, _, _, '1xx', _) => __UNPREDICTABLE
                        when (_, '100x', '00000', '0', 'xx000', _, '0xx', _) => // mortlach_ctxt_ldst
                            __field op 21 +: 1
                            __field Rv 13 +: 2
                            __field Rn 5 +: 5
                            __field imm4 0 +: 4
                            case (op) of
                                when ('0') => __encoding LDR_ZA_RI__ // ldr_za_ri_
                                when ('1') => __encoding STR_ZA_RI__ // str_za_ri_
                        when (_, '100x', '00000', '0', 'xx000', _, '1xx', _) => __UNPREDICTABLE
                        when (_, '100x', '00000', '0', 'xx!= 000', _, _, _) => __UNPREDICTABLE
                        when (_, '100x', !'00000', '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, '100x', _, '1', '00000', _, '000', _) => // mortlach_zt_ldst
                            __field opc 16 +: 6
                            __field Rn 5 +: 5
                            __field opc2 0 +: 2
                            case (opc, opc2) of
                                when ('x0xxxx', _) => __UNALLOCATED
                                when ('x10xxx', _) => __UNALLOCATED
                                when ('x110xx', _) => __UNALLOCATED
                                when ('x1110x', _) => __UNALLOCATED
                                when ('x11110', _) => __UNALLOCATED
                                when ('x11111', '01') => __UNALLOCATED
                                when ('x11111', '1x') => __UNALLOCATED
                                when ('011111', '00') => __encoding LDR_ZT_BR__ // ldr_zt_br_
                                when ('111111', '00') => __encoding STR_ZT_BR__ // str_zt_br_
                        when (_, '100x', _, '1', '00000', _, !'000', _) => __UNPREDICTABLE
                        when (_, '100x', _, '1', !'00000', _, _, _) => __UNPREDICTABLE
                        when (_, '101x', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '110x', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1110', _, _, _, _, '0xx', _) => // mortlach_contig_qload
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field ZAt 0 +: 4
                            case () of
                                when () => __encoding LD1Q_ZA_P_RRR__ // ld1q_za_p_rrr_
                        when (_, '1111', _, _, _, _, '0xx', _) => // mortlach_contig_qstore
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field ZAt 0 +: 4
                            case () of
                                when () => __encoding ST1Q_ZA_P_RRR__ // st1q_za_p_rrr_
                        when (_, '111x', _, _, _, _, '1xx', _) => __UNPREDICTABLE
        when (_, _, '0001', _) => __UNPREDICTABLE
        when (_, _, '0010', _) =>
            // sve
            case (29 +: 3, 25 +: 4, 17 +: 8, 16 +: 1, 10 +: 6, 5 +: 5, 4 +: 1, 0 +: 4) of
                when ('000', _, '0xx0xxxx', _, 'x1xxxx', _, _, _) =>
                    // sve_int_muladd_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 14 +: 1, 0 +: 14) of
                        when (_, _, _, _, '0', _, _) => // sve_int_mlas_vvv_pred
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op) of
                                when ('0') => __encoding MLA_Z_P_ZZZ__ // mla_z_p_zzz_
                                when ('1') => __encoding MLS_Z_P_ZZZ__ // mls_z_p_zzz_
                        when (_, _, _, _, '1', _, _) => // sve_int_mladdsub_vvv_pred
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field Pg 10 +: 3
                            __field Za 5 +: 5
                            __field Zdn 0 +: 5
                            case (op) of
                                when ('0') => __encoding MAD_Z_P_ZZZ__ // mad_z_p_zzz_
                                when ('1') => __encoding MSB_Z_P_ZZZ__ // msb_z_p_zzz_
                when ('000', _, '0xx0xxxx', _, '000xxx', _, _, _) =>
                    // sve_int_pred_bin
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '00x', _, _, _) => // sve_int_bin_pred_arit_0
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, opc) of
                                when (_, '000') => __encoding ADD_Z_P_ZZ__ // add_z_p_zz_
                                when (_, '001') => __encoding SUB_Z_P_ZZ__ // sub_z_p_zz_
                                when (_, '010') => __UNALLOCATED
                                when (_, '011') => __encoding SUBR_Z_P_ZZ__ // subr_z_p_zz_
                                when ('0x', '1xx') => __UNALLOCATED
                                when ('10', '1xx') => __UNALLOCATED
                                when ('11', '100') => __encoding ADDPT_Z_P_ZZ__ // addpt_z_p_zz_
                                when ('11', '101') => __encoding SUBPT_Z_P_ZZ__ // subpt_z_p_zz_
                                when ('11', '11x') => __UNALLOCATED
                        when (_, _, _, '01x', _, _, _) => // sve_int_bin_pred_arit_1
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, U) of
                                when ('00', '0') => __encoding SMAX_Z_P_ZZ__ // smax_z_p_zz_
                                when ('00', '1') => __encoding UMAX_Z_P_ZZ__ // umax_z_p_zz_
                                when ('01', '0') => __encoding SMIN_Z_P_ZZ__ // smin_z_p_zz_
                                when ('01', '1') => __encoding UMIN_Z_P_ZZ__ // umin_z_p_zz_
                                when ('10', '0') => __encoding SABD_Z_P_ZZ__ // sabd_z_p_zz_
                                when ('10', '1') => __encoding UABD_Z_P_ZZ__ // uabd_z_p_zz_
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '100', _, _, _) => // sve_int_bin_pred_arit_2
                            __field size 22 +: 2
                            __field H 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (H, U) of
                                when ('0', '0') => __encoding MUL_Z_P_ZZ__ // mul_z_p_zz_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', '0') => __encoding SMULH_Z_P_ZZ__ // smulh_z_p_zz_
                                when ('1', '1') => __encoding UMULH_Z_P_ZZ__ // umulh_z_p_zz_
                        when (_, _, _, '101', _, _, _) => // sve_int_bin_pred_div
                            __field size 22 +: 2
                            __field R 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, U) of
                                when ('0', '0') => __encoding SDIV_Z_P_ZZ__ // sdiv_z_p_zz_
                                when ('0', '1') => __encoding UDIV_Z_P_ZZ__ // udiv_z_p_zz_
                                when ('1', '0') => __encoding SDIVR_Z_P_ZZ__ // sdivr_z_p_zz_
                                when ('1', '1') => __encoding UDIVR_Z_P_ZZ__ // udivr_z_p_zz_
                        when (_, _, _, '11x', _, _, _) => // sve_int_bin_pred_log
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding ORR_Z_P_ZZ__ // orr_z_p_zz_
                                when ('001') => __encoding EOR_Z_P_ZZ__ // eor_z_p_zz_
                                when ('010') => __encoding AND_Z_P_ZZ__ // and_z_p_zz_
                                when ('011') => __encoding BIC_Z_P_ZZ__ // bic_z_p_zz_
                                when ('1xx') => __UNALLOCATED
                when ('000', _, '0xx0xxxx', _, '001xxx', _, _, _) =>
                    // sve_int_pred_red
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '000', _, _, _) => // sve_int_reduce_0
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SADDV_R_P_Z__ // saddv_r_p_z_
                                when ('0', '1') => __encoding UADDV_R_P_Z__ // uaddv_r_p_z_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '001', _, _, _) => // sve_int_reduce_0q
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __UNALLOCATED
                                when ('0', '1') => __encoding ADDQV_Z_P_Z__ // addqv_z_p_z_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '010', _, _, _) => // sve_int_reduce_1
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SMAXV_R_P_Z__ // smaxv_r_p_z_
                                when ('0', '1') => __encoding UMAXV_R_P_Z__ // umaxv_r_p_z_
                                when ('1', '0') => __encoding SMINV_R_P_Z__ // sminv_r_p_z_
                                when ('1', '1') => __encoding UMINV_R_P_Z__ // uminv_r_p_z_
                        when (_, _, _, '011', _, _, _) => // sve_int_reduce_1q
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding SMAXQV_Z_P_Z__ // smaxqv_z_p_z_
                                when ('0', '1') => __encoding UMAXQV_Z_P_Z__ // umaxqv_z_p_z_
                                when ('1', '0') => __encoding SMINQV_Z_P_Z__ // sminqv_z_p_z_
                                when ('1', '1') => __encoding UMINQV_Z_P_Z__ // uminqv_z_p_z_
                        when (_, _, _, '10x', _, _, _) => // sve_int_movprfx_pred
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field M 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding MOVPRFX_Z_P_Z__ // movprfx_z_p_z_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '110', _, _, _) => // sve_int_reduce_2
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ORV_R_P_Z__ // orv_r_p_z_
                                when ('01') => __encoding EORV_R_P_Z__ // eorv_r_p_z_
                                when ('10') => __encoding ANDV_R_P_Z__ // andv_r_p_z_
                                when ('11') => __UNALLOCATED
                        when (_, _, _, '111', _, _, _) => // sve_int_reduce_2q
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ORQV_Z_P_Z__ // orqv_z_p_z_
                                when ('01') => __encoding EORQV_Z_P_Z__ // eorqv_z_p_z_
                                when ('10') => __encoding ANDQV_Z_P_Z__ // andqv_z_p_z_
                                when ('11') => __UNALLOCATED
                when ('000', _, '0xx0xxxx', _, '100xxx', _, _, _) =>
                    // sve_int_pred_shift
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '0x', _, _, _) => // sve_int_bin_pred_shift_0
                            __field tszh 22 +: 2
                            __field opc 18 +: 2
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field tszl 8 +: 2
                            __field imm3 5 +: 3
                            __field Zdn 0 +: 5
                            case (opc, L, U) of
                                when ('00', '0', '0') => __encoding ASR_Z_P_ZI__ // asr_z_p_zi_
                                when ('00', '0', '1') => __encoding LSR_Z_P_ZI__ // lsr_z_p_zi_
                                when ('00', '1', '0') => __UNALLOCATED
                                when ('00', '1', '1') => __encoding LSL_Z_P_ZI__ // lsl_z_p_zi_
                                when ('01', '0', '0') => __encoding ASRD_Z_P_ZI__ // asrd_z_p_zi_
                                when ('01', '0', '1') => __UNALLOCATED
                                when ('01', '1', '0') => __encoding SQSHL_Z_P_ZI__ // sqshl_z_p_zi_
                                when ('01', '1', '1') => __encoding UQSHL_Z_P_ZI__ // uqshl_z_p_zi_
                                when ('10', _, _) => __UNALLOCATED
                                when ('11', '0', '0') => __encoding SRSHR_Z_P_ZI__ // srshr_z_p_zi_
                                when ('11', '0', '1') => __encoding URSHR_Z_P_ZI__ // urshr_z_p_zi_
                                when ('11', '1', '0') => __UNALLOCATED
                                when ('11', '1', '1') => __encoding SQSHLU_Z_P_ZI__ // sqshlu_z_p_zi_
                        when (_, _, _, '10', _, _, _) => // sve_int_bin_pred_shift_1
                            __field size 22 +: 2
                            __field R 18 +: 1
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, L, U) of
                                when (_, '1', '0') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding ASR_Z_P_ZZ__ // asr_z_p_zz_
                                when ('0', '0', '1') => __encoding LSR_Z_P_ZZ__ // lsr_z_p_zz_
                                when ('0', '1', '1') => __encoding LSL_Z_P_ZZ__ // lsl_z_p_zz_
                                when ('1', '0', '0') => __encoding ASRR_Z_P_ZZ__ // asrr_z_p_zz_
                                when ('1', '0', '1') => __encoding LSRR_Z_P_ZZ__ // lsrr_z_p_zz_
                                when ('1', '1', '1') => __encoding LSLR_Z_P_ZZ__ // lslr_z_p_zz_
                        when (_, _, _, '11', _, _, _) => // sve_int_bin_pred_shift_2
                            __field size 22 +: 2
                            __field R 18 +: 1
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, L, U) of
                                when ('0', '0', '0') => __encoding ASR_Z_P_ZW__ // asr_z_p_zw_
                                when ('0', '0', '1') => __encoding LSR_Z_P_ZW__ // lsr_z_p_zw_
                                when ('0', '1', '0') => __UNALLOCATED
                                when ('0', '1', '1') => __encoding LSL_Z_P_ZW__ // lsl_z_p_zw_
                                when ('1', _, _) => __UNALLOCATED
                when ('000', _, '0xx0xxxx', _, '101xxx', _, _, _) =>
                    // sve_int_pred_un
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '0x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10', _, _, _) => // sve_int_un_pred_arit_0
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding SXTB_Z_P_Z__ // sxtb_z_p_z_
                                when ('001') => __encoding UXTB_Z_P_Z__ // uxtb_z_p_z_
                                when ('010') => __encoding SXTH_Z_P_Z__ // sxth_z_p_z_
                                when ('011') => __encoding UXTH_Z_P_Z__ // uxth_z_p_z_
                                when ('100') => __encoding SXTW_Z_P_Z__ // sxtw_z_p_z_
                                when ('101') => __encoding UXTW_Z_P_Z__ // uxtw_z_p_z_
                                when ('110') => __encoding ABS_Z_P_Z__ // abs_z_p_z_
                                when ('111') => __encoding NEG_Z_P_Z__ // neg_z_p_z_
                        when (_, _, _, '11', _, _, _) => // sve_int_un_pred_arit_1
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding CLS_Z_P_Z__ // cls_z_p_z_
                                when ('001') => __encoding CLZ_Z_P_Z__ // clz_z_p_z_
                                when ('010') => __encoding CNT_Z_P_Z__ // cnt_z_p_z_
                                when ('011') => __encoding CNOT_Z_P_Z__ // cnot_z_p_z_
                                when ('100') => __encoding FABS_Z_P_Z__ // fabs_z_p_z_
                                when ('101') => __encoding FNEG_Z_P_Z__ // fneg_z_p_z_
                                when ('110') => __encoding NOT_Z_P_Z__ // not_z_p_z_
                                when ('111') => __UNALLOCATED
                when ('000', _, '0xx1xxxx', _, '000xxx', _, _, _) => // sve_int_bin_cons_arit_0
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size, opc) of
                        when (_, '000') => __encoding ADD_Z_ZZ__ // add_z_zz_
                        when (_, '001') => __encoding SUB_Z_ZZ__ // sub_z_zz_
                        when (_, '100') => __encoding SQADD_Z_ZZ__ // sqadd_z_zz_
                        when (_, '101') => __encoding UQADD_Z_ZZ__ // uqadd_z_zz_
                        when (_, '110') => __encoding SQSUB_Z_ZZ__ // sqsub_z_zz_
                        when (_, '111') => __encoding UQSUB_Z_ZZ__ // uqsub_z_zz_
                        when ('0x', '01x') => __UNALLOCATED
                        when ('10', '01x') => __UNALLOCATED
                        when ('11', '010') => __encoding ADDPT_Z_ZZ__ // addpt_z_zz_
                        when ('11', '011') => __encoding SUBPT_Z_ZZ__ // subpt_z_zz_
                when ('000', _, '0xx1xxxx', _, '001xxx', _, _, _) =>
                    // sve_int_unpred_logical
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 0 +: 10) of
                        when (_, _, _, _, _, '0xx', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '100', _) => // sve_int_bin_cons_log
                            __field opc 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding AND_Z_ZZ__ // and_z_zz_
                                when ('01') => __encoding ORR_Z_ZZ__ // orr_z_zz_
                                when ('10') => __encoding EOR_Z_ZZ__ // eor_z_zz_
                                when ('11') => __encoding BIC_Z_ZZ__ // bic_z_zz_
                        when (_, _, _, _, _, '101', _) => // sve_int_rotate_imm
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding XAR_Z_ZZI__ // xar_z_zzi_
                        when (_, _, _, _, _, '11x', _) => // sve_int_tern_log
                            __field opc 22 +: 2
                            __field Zm 16 +: 5
                            __field o2 10 +: 1
                            __field Zk 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when ('00', '0') => __encoding EOR3_Z_ZZZ__ // eor3_z_zzz_
                                when ('00', '1') => __encoding BSL_Z_ZZZ__ // bsl_z_zzz_
                                when ('01', '0') => __encoding BCAX_Z_ZZZ__ // bcax_z_zzz_
                                when ('01', '1') => __encoding BSL1N_Z_ZZZ__ // bsl1n_z_zzz_
                                when ('1x', '0') => __UNALLOCATED
                                when ('10', '1') => __encoding BSL2N_Z_ZZZ__ // bsl2n_z_zzz_
                                when ('11', '1') => __encoding NBSL_Z_ZZZ__ // nbsl_z_zzz_
                when ('000', _, '0xx1xxxx', _, '0100xx', _, _, _) =>
                    // sve_index
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 12 +: 4, 10 +: 2, 0 +: 10) of
                        when (_, _, _, _, _, '00', _) => // sve_int_index_ii
                            __field size 22 +: 2
                            __field imm5b 16 +: 5
                            __field imm5 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding INDEX_Z_II__ // index_z_ii_
                        when (_, _, _, _, _, '01', _) => // sve_int_index_ri
                            __field size 22 +: 2
                            __field imm5 16 +: 5
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding INDEX_Z_RI__ // index_z_ri_
                        when (_, _, _, _, _, '10', _) => // sve_int_index_ir
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field imm5 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding INDEX_Z_IR__ // index_z_ir_
                        when (_, _, _, _, _, '11', _) => // sve_int_index_rr
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding INDEX_Z_RR__ // index_z_rr_
                when ('000', _, '0xx1xxxx', _, '0101xx', _, _, _) =>
                    // sve_alloca
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 12 +: 4, 11 +: 1, 0 +: 11) of
                        when (_, '0', _, _, _, _, '0', _) => // sve_int_arith_vl
                            __field op 22 +: 1
                            __field Rn 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op) of
                                when ('0') => __encoding ADDVL_R_RI__ // addvl_r_ri_
                                when ('1') => __encoding ADDPL_R_RI__ // addpl_r_ri_
                        when (_, '0', _, _, _, _, '1', _) => // sve_int_arith_svl
                            __field op 22 +: 1
                            __field Rn 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op) of
                                when ('0') => __encoding ADDSVL_R_RI__ // addsvl_r_ri_
                                when ('1') => __encoding ADDSPL_R_RI__ // addspl_r_ri_
                        when (_, '1', _, _, _, _, '0', _) => // sve_int_read_vl_a
                            __field op 22 +: 1
                            __field opc2 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op, opc2) of
                                when ('0', '0xxxx') => __UNALLOCATED
                                when ('0', '10xxx') => __UNALLOCATED
                                when ('0', '110xx') => __UNALLOCATED
                                when ('0', '1110x') => __UNALLOCATED
                                when ('0', '11110') => __UNALLOCATED
                                when ('0', '11111') => __encoding RDVL_R_I__ // rdvl_r_i_
                                when ('1', _) => __UNALLOCATED
                        when (_, '1', _, _, _, _, '1', _) => // sve_int_read_svl_a
                            __field op 22 +: 1
                            __field opc2 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op, opc2) of
                                when ('0', '0xxxx') => __UNALLOCATED
                                when ('0', '10xxx') => __UNALLOCATED
                                when ('0', '110xx') => __UNALLOCATED
                                when ('0', '1110x') => __UNALLOCATED
                                when ('0', '11110') => __UNALLOCATED
                                when ('0', '11111') => __encoding RDSVL_R_I__ // rdsvl_r_i_
                                when ('1', _) => __UNALLOCATED
                when ('000', _, '0xx1xxxx', _, '011xxx', _, _, _) =>
                    // sve_int_unpred_arit_b
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 11 +: 2, 0 +: 11) of
                        when (_, _, _, _, _, '0x', _) => // sve_int_mul_b
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, opc) of
                                when (_, '00') => __encoding MUL_Z_ZZ__ // mul_z_zz_
                                when (_, '10') => __encoding SMULH_Z_ZZ__ // smulh_z_zz_
                                when (_, '11') => __encoding UMULH_Z_ZZ__ // umulh_z_zz_
                                when ('00', '01') => __encoding PMUL_Z_ZZ__ // pmul_z_zz_
                                when ('01', '01') => __UNALLOCATED
                                when ('1x', '01') => __UNALLOCATED
                        when (_, _, _, _, _, '10', _) => // sve_int_sqdmulh
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field R 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (R) of
                                when ('0') => __encoding SQDMULH_Z_ZZ__ // sqdmulh_z_zz_
                                when ('1') => __encoding SQRDMULH_Z_ZZ__ // sqrdmulh_z_zz_
                        when (_, _, _, _, _, '11', _) => __UNPREDICTABLE
                when ('000', _, '0xx1xxxx', _, '100xxx', _, _, _) =>
                    // sve_int_unpred_shift
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 12 +: 1, 0 +: 12) of
                        when (_, _, _, _, _, '0', _) => // sve_int_bin_cons_shift_a
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ASR_Z_ZW__ // asr_z_zw_
                                when ('01') => __encoding LSR_Z_ZW__ // lsr_z_zw_
                                when ('10') => __UNALLOCATED
                                when ('11') => __encoding LSL_Z_ZW__ // lsl_z_zw_
                        when (_, _, _, _, _, '1', _) => // sve_int_bin_cons_shift_b
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ASR_Z_ZI__ // asr_z_zi_
                                when ('01') => __encoding LSR_Z_ZI__ // lsr_z_zi_
                                when ('10') => __UNALLOCATED
                                when ('11') => __encoding LSL_Z_ZI__ // lsl_z_zi_
                when ('000', _, '0xx1xxxx', _, '1010xx', _, _, _) => // sve_int_bin_cons_misc_0_a
                    __field opc 22 +: 2
                    __field Zm 16 +: 5
                    __field msz 10 +: 2
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('00') => __encoding ADR_Z_AZ_D_s32_scaled // adr_z_az_d_s32_scaled
                        when ('01') => __encoding ADR_Z_AZ_D_u32_scaled // adr_z_az_d_u32_scaled
                        when ('1x') => __encoding ADR_Z_AZ_SD_same_scaled // adr_z_az_sd_same_scaled
                when ('000', _, '0xx1xxxx', _, '1011xx', _, _, _) =>
                    // sve_int_unpred_misc
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 12 +: 4, 10 +: 2, 0 +: 10) of
                        when (_, _, _, _, _, '0x', _) => // sve_int_bin_cons_misc_0_b
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding FTSSEL_Z_ZZ__ // ftssel_z_zz_
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '10', _) => // sve_int_bin_cons_misc_0_c
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00000') => __encoding FEXPA_Z_Z__ // fexpa_z_z_
                                when ('00001') => __UNALLOCATED
                                when ('0001x') => __UNALLOCATED
                                when ('001xx') => __UNALLOCATED
                                when ('01xxx') => __UNALLOCATED
                                when ('1xxxx') => __UNALLOCATED
                        when (_, _, _, _, _, '11', _) => // sve_int_bin_cons_misc_0_d
                            __field opc 22 +: 2
                            __field opc2 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('00', '00000') => __encoding MOVPRFX_Z_Z__ // movprfx_z_z_
                                when ('00', '00001') => __UNALLOCATED
                                when ('00', '0001x') => __UNALLOCATED
                                when ('00', '001xx') => __UNALLOCATED
                                when ('00', '01xxx') => __UNALLOCATED
                                when ('00', '1xxxx') => __UNALLOCATED
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                when ('000', _, '0xx1xxxx', _, '11xxxx', _, _, _) =>
                    // sve_countelt
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 16 +: 4, 14 +: 2, 11 +: 3, 0 +: 11) of
                        when (_, _, _, '0', _, _, '00x', _) => // sve_int_countvlv0
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 11 +: 1
                            __field U 10 +: 1
                            __field pattern 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, D, U) of
                                when ('00', _, _) => __UNALLOCATED
                                when ('01', '0', '0') => __encoding SQINCH_Z_ZS__ // sqinch_z_zs_
                                when ('01', '0', '1') => __encoding UQINCH_Z_ZS__ // uqinch_z_zs_
                                when ('01', '1', '0') => __encoding SQDECH_Z_ZS__ // sqdech_z_zs_
                                when ('01', '1', '1') => __encoding UQDECH_Z_ZS__ // uqdech_z_zs_
                                when ('10', '0', '0') => __encoding SQINCW_Z_ZS__ // sqincw_z_zs_
                                when ('10', '0', '1') => __encoding UQINCW_Z_ZS__ // uqincw_z_zs_
                                when ('10', '1', '0') => __encoding SQDECW_Z_ZS__ // sqdecw_z_zs_
                                when ('10', '1', '1') => __encoding UQDECW_Z_ZS__ // uqdecw_z_zs_
                                when ('11', '0', '0') => __encoding SQINCD_Z_ZS__ // sqincd_z_zs_
                                when ('11', '0', '1') => __encoding UQINCD_Z_ZS__ // uqincd_z_zs_
                                when ('11', '1', '0') => __encoding SQDECD_Z_ZS__ // sqdecd_z_zs_
                                when ('11', '1', '1') => __encoding UQDECD_Z_ZS__ // uqdecd_z_zs_
                        when (_, _, _, '0', _, _, '100', _) => // sve_int_count
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field op 10 +: 1
                            __field pattern 5 +: 5
                            __field Rd 0 +: 5
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when ('00', '0') => __encoding CNTB_R_S__ // cntb_r_s_
                                when ('01', '0') => __encoding CNTH_R_S__ // cnth_r_s_
                                when ('10', '0') => __encoding CNTW_R_S__ // cntw_r_s_
                                when ('11', '0') => __encoding CNTD_R_S__ // cntd_r_s_
                        when (_, _, _, '0', _, _, '101', _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, _, '000', _) => // sve_int_countvlv1
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 10 +: 1
                            __field pattern 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, D) of
                                when ('00', _) => __UNALLOCATED
                                when ('01', '0') => __encoding INCH_Z_ZS__ // inch_z_zs_
                                when ('01', '1') => __encoding DECH_Z_ZS__ // dech_z_zs_
                                when ('10', '0') => __encoding INCW_Z_ZS__ // incw_z_zs_
                                when ('10', '1') => __encoding DECW_Z_ZS__ // decw_z_zs_
                                when ('11', '0') => __encoding INCD_Z_ZS__ // incd_z_zs_
                                when ('11', '1') => __encoding DECD_Z_ZS__ // decd_z_zs_
                        when (_, _, _, '1', _, _, '100', _) => // sve_int_pred_pattern_a
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 10 +: 1
                            __field pattern 5 +: 5
                            __field Rdn 0 +: 5
                            case (size, D) of
                                when ('00', '0') => __encoding INCB_R_RS__ // incb_r_rs_
                                when ('00', '1') => __encoding DECB_R_RS__ // decb_r_rs_
                                when ('01', '0') => __encoding INCH_R_RS__ // inch_r_rs_
                                when ('01', '1') => __encoding DECH_R_RS__ // dech_r_rs_
                                when ('10', '0') => __encoding INCW_R_RS__ // incw_r_rs_
                                when ('10', '1') => __encoding DECW_R_RS__ // decw_r_rs_
                                when ('11', '0') => __encoding INCD_R_RS__ // incd_r_rs_
                                when ('11', '1') => __encoding DECD_R_RS__ // decd_r_rs_
                        when (_, _, _, '1', _, _, 'x01', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '01x', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '11x', _) => // sve_int_pred_pattern_b
                            __field size 22 +: 2
                            __field sf 20 +: 1
                            __field imm4 16 +: 4
                            __field D 11 +: 1
                            __field U 10 +: 1
                            __field pattern 5 +: 5
                            __field Rdn 0 +: 5
                            case (size, sf, D, U) of
                                when ('00', '0', '0', '0') => __encoding SQINCB_R_RS_SX // sqincb_r_rs_sx
                                when ('00', '0', '0', '1') => __encoding UQINCB_R_RS_UW // uqincb_r_rs_uw
                                when ('00', '0', '1', '0') => __encoding SQDECB_R_RS_SX // sqdecb_r_rs_sx
                                when ('00', '0', '1', '1') => __encoding UQDECB_R_RS_UW // uqdecb_r_rs_uw
                                when ('00', '1', '0', '0') => __encoding SQINCB_R_RS_X // sqincb_r_rs_x
                                when ('00', '1', '0', '1') => __encoding UQINCB_R_RS_X // uqincb_r_rs_x
                                when ('00', '1', '1', '0') => __encoding SQDECB_R_RS_X // sqdecb_r_rs_x
                                when ('00', '1', '1', '1') => __encoding UQDECB_R_RS_X // uqdecb_r_rs_x
                                when ('01', '0', '0', '0') => __encoding SQINCH_R_RS_SX // sqinch_r_rs_sx
                                when ('01', '0', '0', '1') => __encoding UQINCH_R_RS_UW // uqinch_r_rs_uw
                                when ('01', '0', '1', '0') => __encoding SQDECH_R_RS_SX // sqdech_r_rs_sx
                                when ('01', '0', '1', '1') => __encoding UQDECH_R_RS_UW // uqdech_r_rs_uw
                                when ('01', '1', '0', '0') => __encoding SQINCH_R_RS_X // sqinch_r_rs_x
                                when ('01', '1', '0', '1') => __encoding UQINCH_R_RS_X // uqinch_r_rs_x
                                when ('01', '1', '1', '0') => __encoding SQDECH_R_RS_X // sqdech_r_rs_x
                                when ('01', '1', '1', '1') => __encoding UQDECH_R_RS_X // uqdech_r_rs_x
                                when ('10', '0', '0', '0') => __encoding SQINCW_R_RS_SX // sqincw_r_rs_sx
                                when ('10', '0', '0', '1') => __encoding UQINCW_R_RS_UW // uqincw_r_rs_uw
                                when ('10', '0', '1', '0') => __encoding SQDECW_R_RS_SX // sqdecw_r_rs_sx
                                when ('10', '0', '1', '1') => __encoding UQDECW_R_RS_UW // uqdecw_r_rs_uw
                                when ('10', '1', '0', '0') => __encoding SQINCW_R_RS_X // sqincw_r_rs_x
                                when ('10', '1', '0', '1') => __encoding UQINCW_R_RS_X // uqincw_r_rs_x
                                when ('10', '1', '1', '0') => __encoding SQDECW_R_RS_X // sqdecw_r_rs_x
                                when ('10', '1', '1', '1') => __encoding UQDECW_R_RS_X // uqdecw_r_rs_x
                                when ('11', '0', '0', '0') => __encoding SQINCD_R_RS_SX // sqincd_r_rs_sx
                                when ('11', '0', '0', '1') => __encoding UQINCD_R_RS_UW // uqincd_r_rs_uw
                                when ('11', '0', '1', '0') => __encoding SQDECD_R_RS_SX // sqdecd_r_rs_sx
                                when ('11', '0', '1', '1') => __encoding UQDECD_R_RS_UW // uqdecd_r_rs_uw
                                when ('11', '1', '0', '0') => __encoding SQINCD_R_RS_X // sqincd_r_rs_x
                                when ('11', '1', '0', '1') => __encoding UQINCD_R_RS_X // uqincd_r_rs_x
                                when ('11', '1', '1', '0') => __encoding SQDECD_R_RS_X // sqdecd_r_rs_x
                                when ('11', '1', '1', '1') => __encoding UQDECD_R_RS_X // uqdecd_r_rs_x
                when ('000', _, '1xx00xxx', _, _, _, _, _) =>
                    // sve_maskimm
                    case (24 +: 8, 22 +: 2, 20 +: 2, 18 +: 2, 0 +: 18) of
                        when (_, '11', _, '00', _) => // sve_int_dup_mask_imm
                            __field imm13 5 +: 13
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding DUPM_Z_I__ // dupm_z_i_
                        when (_, !'11', _, '00', _) => // sve_int_log_imm
                            __field opc 22 +: 2
                            __field imm13 5 +: 13
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('00') => __encoding ORR_Z_ZI__ // orr_z_zi_
                                when ('01') => __encoding EOR_Z_ZI__ // eor_z_zi_
                                when ('10') => __encoding AND_Z_ZI__ // and_z_zi_
                        when (_, _, _, !'00', _) => __UNPREDICTABLE
                when ('000', _, '1xx01xxx', _, _, _, _, _) =>
                    // sve_wideimm_pred
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 13 +: 3, 0 +: 13) of
                        when (_, _, _, _, '0xx', _) => // sve_int_dup_imm_pred
                            __field size 22 +: 2
                            __field Pg 16 +: 4
                            __field M 14 +: 1
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (M) of
                                when ('0') => __encoding CPY_Z_O_I__ // cpy_z_o_i_
                                when ('1') => __encoding CPY_Z_P_I__ // cpy_z_p_i_
                        when (_, _, _, _, '10x', _) => __UNPREDICTABLE
                        when (_, _, _, _, '110', _) => // sve_int_dup_fpimm_pred
                            __field size 22 +: 2
                            __field Pg 16 +: 4
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding FCPY_Z_P_I__ // fcpy_z_p_i_
                        when (_, _, _, _, '111', _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '001000', _, _, _) => // sve_int_perm_dup_i
                    __field imm2 22 +: 2
                    __field tsz 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding DUP_Z_Zi__ // dup_z_zi_
                when ('000', _, '1xx1xxxx', _, '001001', _, _, _) =>
                    // sve_perm_quads_a
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 16 +: 4, 10 +: 6, 0 +: 10) of
                        when (_, '00', _, _, _, _, _) => // sve_int_perm_dupq_i
                            __field i1 20 +: 1
                            __field tsz 16 +: 4
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding DUPQ_Z_Zi__ // dupq_z_zi_
                        when (_, '01', _, '0', _, _, _) => // sve_int_perm_extq
                            __field imm4 16 +: 4
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding EXTQ_Z_ZI_Des // extq_z_zi_des
                        when (_, '01', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1x', _, _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '00101x', _, _, _) => // sve_int_perm_tbl_3src
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field op 10 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (op) of
                        when ('0') => __encoding TBL_Z_ZZ_2 // tbl_z_zz_2
                        when ('1') => __encoding TBX_Z_ZZ__ // tbx_z_zz_
                when ('000', _, '1xx1xxxx', _, '001100', _, _, _) => // sve_int_perm_tbl
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding TBL_Z_ZZ_1 // tbl_z_zz_1
                when ('000', _, '1xx1xxxx', _, '001101', _, _, _) => // sve_int_perm_tbxquads
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding TBXQ_Z_ZZ__ // tbxq_z_zz_
                when ('000', _, '1xx1xxxx', _, '001110', _, _, _) =>
                    // sve_perm_unpred_d
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 10 +: 6, 9 +: 1, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '00', '000', _, _, _, _, _) => // sve_int_perm_dup_r
                            __field size 22 +: 2
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding DUP_Z_R__ // dup_z_r_
                        when (_, _, _, '00', '100', _, _, _, _, _) => // sve_int_perm_insrs
                            __field size 22 +: 2
                            __field Rm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding INSR_Z_R__ // insr_z_r_
                        when (_, _, _, '00', 'x10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'xx1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '01', 'xx0', _, _, _, '0', _) => // sve_int_mov_v2p
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field Zn 5 +: 5
                            __field Pd 0 +: 4
                            case (opc, opc2) of
                                when ('00', '00') => __UNALLOCATED
                                when ('00', '01') => __encoding PMOV_P_ZI_B // pmov_p_zi_b
                                when ('00', '1x') => __encoding PMOV_P_ZI_H // pmov_p_zi_h
                                when ('01', _) => __encoding PMOV_P_ZI_S // pmov_p_zi_s
                                when ('1x', _) => __encoding PMOV_P_ZI_D // pmov_p_zi_d
                        when (_, _, _, '01', 'xx0', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '01', 'xx1', _, '0', _, _, _) => // sve_int_mov_p2v
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field Pn 5 +: 4
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('00', '00') => __UNALLOCATED
                                when ('00', '01') => __encoding PMOV_Z_PI_B // pmov_z_pi_b
                                when ('00', '1x') => __encoding PMOV_Z_PI_H // pmov_z_pi_h
                                when ('01', _) => __encoding PMOV_Z_PI_S // pmov_z_pi_s
                                when ('1x', _) => __encoding PMOV_Z_PI_D // pmov_z_pi_d
                        when (_, _, _, '01', 'xx1', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10', '0xx', _, _, _, _, _) => // sve_int_perm_unpk
                            __field size 22 +: 2
                            __field U 17 +: 1
                            __field H 16 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (U, H) of
                                when ('0', '0') => __encoding SUNPKLO_Z_Z__ // sunpklo_z_z_
                                when ('0', '1') => __encoding SUNPKHI_Z_Z__ // sunpkhi_z_z_
                                when ('1', '0') => __encoding UUNPKLO_Z_Z__ // uunpklo_z_z_
                                when ('1', '1') => __encoding UUNPKHI_Z_Z__ // uunpkhi_z_z_
                        when (_, _, _, '10', '100', _, _, _, _, _) => // sve_int_perm_insrv
                            __field size 22 +: 2
                            __field Vm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding INSR_Z_V__ // insr_z_v_
                        when (_, _, _, '10', '110', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10', '1x1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '11', '000', _, _, _, _, _) => // sve_int_perm_reverse_z
                            __field size 22 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding REV_Z_Z__ // rev_z_z_
                        when (_, _, _, '11', !'000', _, _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '001111', _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '010xxx', _, _, _) =>
                    // sve_perm_predicates
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 9 +: 4, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, '00', _, '1000x', _, '0000', _, '0', _) => // sve_int_perm_punpk
                            __field H 16 +: 1
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case (H) of
                                when ('0') => __encoding PUNPKLO_P_P__ // punpklo_p_p_
                                when ('1') => __encoding PUNPKHI_P_P__ // punpkhi_p_p_
                        when (_, '01', _, '1000x', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, '10', _, '1000x', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, '11', _, '1000x', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0xxxx', _, 'xxx0', _, '0', _) => // sve_int_perm_bin_perm_pp
                            __field size 22 +: 2
                            __field Pm 16 +: 4
                            __field opc 11 +: 2
                            __field H 10 +: 1
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case (opc, H) of
                                when ('00', '0') => __encoding ZIP1_P_PP__ // zip1_p_pp_
                                when ('00', '1') => __encoding ZIP2_P_PP__ // zip2_p_pp_
                                when ('01', '0') => __encoding UZP1_P_PP__ // uzp1_p_pp_
                                when ('01', '1') => __encoding UZP2_P_PP__ // uzp2_p_pp_
                                when ('10', '0') => __encoding TRN1_P_PP__ // trn1_p_pp_
                                when ('10', '1') => __encoding TRN2_P_PP__ // trn2_p_pp_
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '0xxxx', _, 'xxx1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10100', _, '0000', _, '0', _) => // sve_int_perm_reverse_p
                            __field size 22 +: 2
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case () of
                                when () => __encoding REV_P_P__ // rev_p_p_
                        when (_, _, _, '10101', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, '1000', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, 'x100', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, 'xx10', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, 'xxx1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x1x', _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '11xxx', _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '1', _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '011xxx', _, _, _) => // sve_int_perm_bin_perm_zz
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding ZIP1_Z_ZZ__ // zip1_z_zz_
                        when ('001') => __encoding ZIP2_Z_ZZ__ // zip2_z_zz_
                        when ('010') => __encoding UZP1_Z_ZZ__ // uzp1_z_zz_
                        when ('011') => __encoding UZP2_Z_ZZ__ // uzp2_z_zz_
                        when ('100') => __encoding TRN1_Z_ZZ__ // trn1_z_zz_
                        when ('101') => __encoding TRN2_Z_ZZ__ // trn2_z_zz_
                        when ('11x') => __UNALLOCATED
                when ('000', _, '1xx1xxxx', _, '10xxxx', _, _, _) =>
                    // sve_perm_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 17 +: 3, 16 +: 1, 14 +: 2, 13 +: 1, 0 +: 13) of
                        when (_, _, _, '0', '000', '0', _, '0', _) => // sve_int_perm_cpy_v
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Vn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding CPY_Z_P_V__ // cpy_z_p_v_
                        when (_, _, _, '0', '000', '1', _, '0', _) => // sve_int_perm_compact
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding COMPACT_Z_P_Z__ // compact_z_p_z_
                        when (_, _, _, '0', '000', _, _, '1', _) => // sve_int_perm_last_r
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Rd 0 +: 5
                            case (B) of
                                when ('0') => __encoding LASTA_R_P_Z__ // lasta_r_p_z_
                                when ('1') => __encoding LASTB_R_P_Z__ // lastb_r_p_z_
                        when (_, _, _, '0', '001', _, _, '0', _) => // sve_int_perm_last_v
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (B) of
                                when ('0') => __encoding LASTA_V_P_Z__ // lasta_v_p_z_
                                when ('1') => __encoding LASTB_V_P_Z__ // lastb_v_p_z_
                        when (_, _, _, '0', '01x', _, _, '0', _) => // sve_int_perm_rev
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding REVB_Z_Z__ // revb_z_z_
                                when ('01') => __encoding REVH_Z_Z__ // revh_z_z_
                                when ('10') => __encoding REVW_Z_Z__ // revw_z_z_
                                when ('11') => __encoding RBIT_Z_P_Z__ // rbit_z_p_z_
                        when (_, _, _, '0', '01x', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '100', '0', _, '1', _) => // sve_int_perm_cpy_r
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding CPY_Z_P_R__ // cpy_z_p_r_
                        when (_, _, _, '0', '100', '1', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '100', _, _, '0', _) => // sve_int_perm_clast_zz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding CLASTA_Z_P_ZZ__ // clasta_z_p_zz_
                                when ('1') => __encoding CLASTB_Z_P_ZZ__ // clastb_z_p_zz_
                        when (_, _, _, '0', '101', _, _, '0', _) => // sve_int_perm_clast_vz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Vdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding CLASTA_V_P_Z__ // clasta_v_p_z_
                                when ('1') => __encoding CLASTB_V_P_Z__ // clastb_v_p_z_
                        when (_, _, _, '0', '110', '0', _, '0', _) => // sve_int_perm_splice
                            __field size 22 +: 2
                            __field Pv 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding SPLICE_Z_P_ZZ_Des // splice_z_p_zz_des
                        when (_, _, _, '0', '110', '1', _, '0', _) => // sve_intx_perm_splice
                            __field size 22 +: 2
                            __field Pv 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding SPLICE_Z_P_ZZ_Con // splice_z_p_zz_con
                        when (_, _, _, '0', '110', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '111', '0', _, '0', _) => // sve_int_perm_revd
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size) of
                                when ('00') => __encoding REVD_Z_P_Z__ // revd_z_p_z_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '0', '111', '0', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '111', '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', 'x01', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '1', '000', _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1', '000', _, _, '1', _) => // sve_int_perm_clast_rz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Rdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding CLASTA_R_P_Z__ // clasta_r_p_z_
                                when ('1') => __encoding CLASTB_R_P_Z__ // clastb_r_p_z_
                        when (_, _, _, '1', !'000', _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '11xxxx', _, _, _) => // sve_int_sel_vvv
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pv 10 +: 4
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding SEL_Z_P_ZZ__ // sel_z_p_zz_
                when ('000', _, '10x1xxxx', _, '000xxx', _, _, _) =>
                    // sve_perm_extract
                    case (23 +: 9, 22 +: 1, 21 +: 1, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, '0', _, _, _, _) => // sve_int_perm_extract_i
                            __field imm8h 16 +: 5
                            __field imm8l 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding EXT_Z_ZI_Des // ext_z_zi_des
                        when (_, '1', _, _, _, _) => // sve_intx_perm_extract_i
                            __field imm8h 16 +: 5
                            __field imm8l 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding EXT_Z_ZI_Con // ext_z_zi_con
                when ('000', _, '11x1xxxx', _, '000xxx', _, _, _) =>
                    // sve_perm_inter_long
                    case (23 +: 9, 22 +: 1, 21 +: 1, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, '0', _, _, _, _) => // sve_int_perm_bin_long_perm_zz
                            __field Zm 16 +: 5
                            __field opc 11 +: 2
                            __field H 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, H) of
                                when ('00', '0') => __encoding ZIP1_Z_ZZ_Q // zip1_z_zz_q
                                when ('00', '1') => __encoding ZIP2_Z_ZZ_Q // zip2_z_zz_q
                                when ('01', '0') => __encoding UZP1_Z_ZZ_Q // uzp1_z_zz_q
                                when ('01', '1') => __encoding UZP2_Z_ZZ_Q // uzp2_z_zz_q
                                when ('10', _) => __UNALLOCATED
                                when ('11', '0') => __encoding TRN1_Z_ZZ_Q // trn1_z_zz_q
                                when ('11', '1') => __encoding TRN2_Z_ZZ_Q // trn2_z_zz_q
                        when (_, '1', _, _, _, _) => __UNPREDICTABLE
                when ('001', _, '0xx0xxxx', _, _, _, _, _) =>
                    // sve_cmpvec
                    case (24 +: 8, 22 +: 2, 21 +: 1, 15 +: 6, 14 +: 1, 0 +: 14) of
                        when (_, _, _, _, '0', _) => // sve_int_cmp_0
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 15 +: 1
                            __field o2 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (op, o2, ne) of
                                when ('0', '0', '0') => __encoding CMPHS_P_P_ZZ__ // cmphs_p_p_zz_
                                when ('0', '0', '1') => __encoding CMPHI_P_P_ZZ__ // cmphi_p_p_zz_
                                when ('0', '1', '0') => __encoding CMPEQ_P_P_ZW__ // cmpeq_p_p_zw_
                                when ('0', '1', '1') => __encoding CMPNE_P_P_ZW__ // cmpne_p_p_zw_
                                when ('1', '0', '0') => __encoding CMPGE_P_P_ZZ__ // cmpge_p_p_zz_
                                when ('1', '0', '1') => __encoding CMPGT_P_P_ZZ__ // cmpgt_p_p_zz_
                                when ('1', '1', '0') => __encoding CMPEQ_P_P_ZZ__ // cmpeq_p_p_zz_
                                when ('1', '1', '1') => __encoding CMPNE_P_P_ZZ__ // cmpne_p_p_zz_
                        when (_, _, _, _, '1', _) => // sve_int_cmp_1
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 15 +: 1
                            __field lt 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (U, lt, ne) of
                                when ('0', '0', '0') => __encoding CMPGE_P_P_ZW__ // cmpge_p_p_zw_
                                when ('0', '0', '1') => __encoding CMPGT_P_P_ZW__ // cmpgt_p_p_zw_
                                when ('0', '1', '0') => __encoding CMPLT_P_P_ZW__ // cmplt_p_p_zw_
                                when ('0', '1', '1') => __encoding CMPLE_P_P_ZW__ // cmple_p_p_zw_
                                when ('1', '0', '0') => __encoding CMPHS_P_P_ZW__ // cmphs_p_p_zw_
                                when ('1', '0', '1') => __encoding CMPHI_P_P_ZW__ // cmphi_p_p_zw_
                                when ('1', '1', '0') => __encoding CMPLO_P_P_ZW__ // cmplo_p_p_zw_
                                when ('1', '1', '1') => __encoding CMPLS_P_P_ZW__ // cmpls_p_p_zw_
                when ('001', _, '0xx1xxxx', _, _, _, _, _) => // sve_int_ucmp_vi
                    __field size 22 +: 2
                    __field imm7 14 +: 7
                    __field lt 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field ne 4 +: 1
                    __field Pd 0 +: 4
                    case (lt, ne) of
                        when ('0', '0') => __encoding CMPHS_P_P_ZI__ // cmphs_p_p_zi_
                        when ('0', '1') => __encoding CMPHI_P_P_ZI__ // cmphi_p_p_zi_
                        when ('1', '0') => __encoding CMPLO_P_P_ZI__ // cmplo_p_p_zi_
                        when ('1', '1') => __encoding CMPLS_P_P_ZI__ // cmpls_p_p_zi_
                when ('001', _, '1xx0xxxx', _, 'x0xxxx', _, _, _) => // sve_int_scmp_vi
                    __field size 22 +: 2
                    __field imm5 16 +: 5
                    __field op 15 +: 1
                    __field o2 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field ne 4 +: 1
                    __field Pd 0 +: 4
                    case (op, o2, ne) of
                        when ('0', '0', '0') => __encoding CMPGE_P_P_ZI__ // cmpge_p_p_zi_
                        when ('0', '0', '1') => __encoding CMPGT_P_P_ZI__ // cmpgt_p_p_zi_
                        when ('0', '1', '0') => __encoding CMPLT_P_P_ZI__ // cmplt_p_p_zi_
                        when ('0', '1', '1') => __encoding CMPLE_P_P_ZI__ // cmple_p_p_zi_
                        when ('1', '0', '0') => __encoding CMPEQ_P_P_ZI__ // cmpeq_p_p_zi_
                        when ('1', '0', '1') => __encoding CMPNE_P_P_ZI__ // cmpne_p_p_zi_
                        when ('1', '1', _) => __UNALLOCATED
                when ('001', _, '1xx00xxx', _, '01xxxx', _, _, _) => // sve_int_pred_log
                    __field op 23 +: 1
                    __field S 22 +: 1
                    __field Pm 16 +: 4
                    __field Pg 10 +: 4
                    __field o2 9 +: 1
                    __field Pn 5 +: 4
                    __field o3 4 +: 1
                    __field Pd 0 +: 4
                    case (op, S, o2, o3) of
                        when ('0', '0', '0', '0') => __encoding AND_P_P_PP_Z // and_p_p_pp_z
                        when ('0', '0', '0', '1') => __encoding BIC_P_P_PP_Z // bic_p_p_pp_z
                        when ('0', '0', '1', '0') => __encoding EOR_P_P_PP_Z // eor_p_p_pp_z
                        when ('0', '0', '1', '1') => __encoding SEL_P_P_PP__ // sel_p_p_pp_
                        when ('0', '1', '0', '0') => __encoding ANDS_P_P_PP_Z // ands_p_p_pp_z
                        when ('0', '1', '0', '1') => __encoding BICS_P_P_PP_Z // bics_p_p_pp_z
                        when ('0', '1', '1', '0') => __encoding EORS_P_P_PP_Z // eors_p_p_pp_z
                        when ('0', '1', '1', '1') => __UNALLOCATED
                        when ('1', '0', '0', '0') => __encoding ORR_P_P_PP_Z // orr_p_p_pp_z
                        when ('1', '0', '0', '1') => __encoding ORN_P_P_PP_Z // orn_p_p_pp_z
                        when ('1', '0', '1', '0') => __encoding NOR_P_P_PP_Z // nor_p_p_pp_z
                        when ('1', '0', '1', '1') => __encoding NAND_P_P_PP_Z // nand_p_p_pp_z
                        when ('1', '1', '0', '0') => __encoding ORRS_P_P_PP_Z // orrs_p_p_pp_z
                        when ('1', '1', '0', '1') => __encoding ORNS_P_P_PP_Z // orns_p_p_pp_z
                        when ('1', '1', '1', '0') => __encoding NORS_P_P_PP_Z // nors_p_p_pp_z
                        when ('1', '1', '1', '1') => __encoding NANDS_P_P_PP_Z // nands_p_p_pp_z
                when ('001', _, '1xx00xxx', _, '11xxxx', _, _, _) =>
                    // sve_pred_gen_b
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 14 +: 2, 10 +: 4, 9 +: 1, 0 +: 9) of
                        when (_, _, _, _, _, _, '0', _) => // sve_int_brkp
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pm 16 +: 4
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field B 4 +: 1
                            __field Pd 0 +: 4
                            case (op, S, B) of
                                when ('0', '0', '0') => __encoding BRKPA_P_P_PP__ // brkpa_p_p_pp_
                                when ('0', '0', '1') => __encoding BRKPB_P_P_PP__ // brkpb_p_p_pp_
                                when ('0', '1', '0') => __encoding BRKPAS_P_P_PP__ // brkpas_p_p_pp_
                                when ('0', '1', '1') => __encoding BRKPBS_P_P_PP__ // brkpbs_p_p_pp_
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, _, _, _, '1', _) => __UNPREDICTABLE
                when ('001', _, '1xx01xxx', _, '01xxxx', _, _, _) =>
                    // sve_pred_gen_c
                    case (24 +: 8, 23 +: 1, 22 +: 1, 20 +: 2, 16 +: 4, 14 +: 2, 10 +: 4, 9 +: 1, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, '1000', _, _, '0', _, '0', _) => // sve_int_brkn
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field Pdm 0 +: 4
                            case (S) of
                                when ('0') => __encoding BRKN_P_P_PP__ // brkn_p_p_pp_
                                when ('1') => __encoding BRKNS_P_P_PP__ // brkns_p_p_pp_
                        when (_, '0', _, _, '1000', _, _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x000', _, _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x1xx', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'xx1x', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'xxx1', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, '0000', _, _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, !'0000', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '0000', _, _, '0', _, _, _) => // sve_int_break
                            __field B 23 +: 1
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field M 4 +: 1
                            __field Pd 0 +: 4
                            case (B, S, M) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', _) => __encoding BRKA_P_P_P__ // brka_p_p_p_
                                when ('0', '1', '0') => __encoding BRKAS_P_P_P_Z // brkas_p_p_p_z
                                when ('1', '0', _) => __encoding BRKB_P_P_P__ // brkb_p_p_p_
                                when ('1', '1', '0') => __encoding BRKBS_P_P_P_Z // brkbs_p_p_p_z
                when ('001', _, '1xx01xxx', _, '11xxxx', _, _, _) =>
                    // sve_pred_gen_d
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 14 +: 2, 11 +: 3, 9 +: 2, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0000', _, _, 'x0', _, '0', _) => // sve_int_ptest
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field opc2 0 +: 4
                            case (op, S, opc2) of
                                when ('0', '0', _) => __UNALLOCATED
                                when ('0', '1', '0000') => __encoding PTEST__P_P__ // ptest_p_p_
                                when ('0', '1', '0001') => __UNALLOCATED
                                when ('0', '1', '001x') => __UNALLOCATED
                                when ('0', '1', '01xx') => __UNALLOCATED
                                when ('0', '1', '1xxx') => __UNALLOCATED
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, '0100', _, _, 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0x10', _, _, 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0xx1', _, _, 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0xxx', _, _, 'x1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '000', '00', _, '0', _) => // sve_int_pfirst
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 5 +: 4
                            __field Pdn 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __UNALLOCATED
                                when ('0', '1') => __encoding PFIRST_P_P_P__ // pfirst_p_p_p_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1000', _, '000', !'00', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '100', '10', '0000', '0', _) => // sve_int_pfalse
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding PFALSE_P__ // pfalse_p_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1000', _, '100', '10', !'0000', '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '110', '00', _, '0', _) => // sve_int_rdffr
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 5 +: 4
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding RDFFR_P_P_F__ // rdffr_p_p_f_
                                when ('0', '1') => __encoding RDFFRS_P_P_F__ // rdffrs_p_p_f_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1001', _, '000', '0x', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1001', _, '000', '10', _, '0', _) => // sve_int_pnext
                            __field size 22 +: 2
                            __field Pv 5 +: 4
                            __field Pdn 0 +: 4
                            case () of
                                when () => __encoding PNEXT_P_P_P__ // pnext_p_p_p_
                        when (_, _, _, '1001', _, '000', '11', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1001', _, '100', '10', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1001', _, '110', '00', '0000', '0', _) => // sve_int_rdffr_2
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding RDFFR_P_F__ // rdffr_p_f_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1001', _, '110', '00', !'0000', '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '010', _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '100', '0x', _, '0', _) => // sve_int_ptrue
                            __field size 22 +: 2
                            __field S 16 +: 1
                            __field pattern 5 +: 5
                            __field Pd 0 +: 4
                            case (S) of
                                when ('0') => __encoding PTRUE_P_S__ // ptrue_p_s_
                                when ('1') => __encoding PTRUES_P_S__ // ptrues_p_s_
                        when (_, _, _, '100x', _, '100', '11', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '110', !'00', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, 'xx1', _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '110x', _, _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1x1x', _, _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, _, '1', _) => __UNPREDICTABLE
                when ('001', _, '1xx1xxxx', _, '00xxxx', _, _, _) =>
                    // sve_cmpgpr
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 14 +: 2, 12 +: 2, 10 +: 2, 4 +: 6, 0 +: 4) of
                        when (_, _, _, _, _, '0x', _, _, _) => // sve_int_while_rr
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field sf 12 +: 1
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field eq 4 +: 1
                            __field Pd 0 +: 4
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding WHILEGE_P_P_RR__ // whilege_p_p_rr_
                                when ('0', '0', '1') => __encoding WHILEGT_P_P_RR__ // whilegt_p_p_rr_
                                when ('0', '1', '0') => __encoding WHILELT_P_P_RR__ // whilelt_p_p_rr_
                                when ('0', '1', '1') => __encoding WHILELE_P_P_RR__ // whilele_p_p_rr_
                                when ('1', '0', '0') => __encoding WHILEHS_P_P_RR__ // whilehs_p_p_rr_
                                when ('1', '0', '1') => __encoding WHILEHI_P_P_RR__ // whilehi_p_p_rr_
                                when ('1', '1', '0') => __encoding WHILELO_P_P_RR__ // whilelo_p_p_rr_
                                when ('1', '1', '1') => __encoding WHILELS_P_P_RR__ // whilels_p_p_rr_
                        when (_, _, _, _, _, '10', '00', _, '0000') => // sve_int_cterm
                            __field op 23 +: 1
                            __field sz 22 +: 1
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field ne 4 +: 1
                            case (op, ne) of
                                when ('0', _) => __UNALLOCATED
                                when ('1', '0') => __encoding CTERMEQ_RR__ // ctermeq_rr_
                                when ('1', '1') => __encoding CTERMNE_RR__ // ctermne_rr_
                        when (_, _, _, _, _, '10', '00', _, !'0000') => __UNPREDICTABLE
                        when (_, _, _, _, _, '11', '00', _, _) => // sve_int_whilenc
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field rw 4 +: 1
                            __field Pd 0 +: 4
                            case (rw) of
                                when ('0') => __encoding WHILEWR_P_RR__ // whilewr_p_rr_
                                when ('1') => __encoding WHILERW_P_RR__ // whilerw_p_rr_
                        when (_, _, _, _, _, '1x', !'00', _, _) => __UNPREDICTABLE
                when ('001', _, '1xx1xxxx', _, '01xxxx', _, '0', _) => // sve_int_pred_dup
                    __field i1 23 +: 1
                    __field tszh 22 +: 1
                    __field tszl 18 +: 3
                    __field Rv 16 +: 2
                    __field Pn 10 +: 4
                    __field S 9 +: 1
                    __field Pm 5 +: 4
                    __field Pd 0 +: 4
                    case (S) of
                        when ('0') => __encoding PSEL_P_PPi__ // psel_p_ppi_
                        when ('1') => __UNALLOCATED
                when ('001', _, '1xx1xxxx', _, '01xxxx', _, '1', _) =>
                    // sve_while_pn
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 14 +: 2, 11 +: 3, 5 +: 6, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, _, _, '00000', _, '110', _, _, _, _) => // sve_int_ctr_to_mask
                            __field size 22 +: 2
                            __field opc 8 +: 3
                            __field PNn 5 +: 3
                            __field Pd 0 +: 4
                            case (opc) of
                                when ('0xx') => __encoding PEXT_PN_RR__ // pext_pn_rr_
                                when ('10x') => __encoding PEXT_PP_RR__ // pext_pp_rr_
                                when ('11x') => __UNALLOCATED
                        when (_, _, _, '00000', _, '111', '000000', _, '0', _) => // sve_int_pn_ptrue
                            __field size 22 +: 2
                            __field PNd 0 +: 3
                            case () of
                                when () => __encoding PTRUE_PN_I__ // ptrue_pn_i_
                        when (_, _, _, '00000', _, '111', '000000', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '00000', _, '111', !'000000', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'00000', _, '11x', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '01x', _, _, _, _) => // sve_int_while_rr_pair
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field Pd 1 +: 3
                            __field eq 0 +: 1
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding WHILEGE_PP_RR__ // whilege_pp_rr_
                                when ('0', '0', '1') => __encoding WHILEGT_PP_RR__ // whilegt_pp_rr_
                                when ('0', '1', '0') => __encoding WHILELT_PP_RR__ // whilelt_pp_rr_
                                when ('0', '1', '1') => __encoding WHILELE_PP_RR__ // whilele_pp_rr_
                                when ('1', '0', '0') => __encoding WHILEHS_PP_RR__ // whilehs_pp_rr_
                                when ('1', '0', '1') => __encoding WHILEHI_PP_RR__ // whilehi_pp_rr_
                                when ('1', '1', '0') => __encoding WHILELO_PP_RR__ // whilelo_pp_rr_
                                when ('1', '1', '1') => __encoding WHILELS_PP_RR__ // whilels_pp_rr_
                        when (_, _, _, _, _, 'x0x', _, _, _, _) => // sve_int_while_rr_pn
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field vl 13 +: 1
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field eq 3 +: 1
                            __field PNd 0 +: 3
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding WHILEGE_PN_RR__ // whilege_pn_rr_
                                when ('0', '0', '1') => __encoding WHILEGT_PN_RR__ // whilegt_pn_rr_
                                when ('0', '1', '0') => __encoding WHILELT_PN_RR__ // whilelt_pn_rr_
                                when ('0', '1', '1') => __encoding WHILELE_PN_RR__ // whilele_pn_rr_
                                when ('1', '0', '0') => __encoding WHILEHS_PN_RR__ // whilehs_pn_rr_
                                when ('1', '0', '1') => __encoding WHILEHI_PN_RR__ // whilehi_pn_rr_
                                when ('1', '1', '0') => __encoding WHILELO_PN_RR__ // whilelo_pn_rr_
                                when ('1', '1', '1') => __encoding WHILELS_PN_RR__ // whilels_pn_rr_
                when ('001', _, '1xx1xxxx', _, '11xxxx', _, _, _) =>
                    // sve_wideimm_unpred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 17 +: 2, 16 +: 1, 14 +: 2, 0 +: 14) of
                        when (_, _, _, '00', _, _, _, _) => // sve_int_arith_imm0
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding ADD_Z_ZI__ // add_z_zi_
                                when ('001') => __encoding SUB_Z_ZI__ // sub_z_zi_
                                when ('010') => __UNALLOCATED
                                when ('011') => __encoding SUBR_Z_ZI__ // subr_z_zi_
                                when ('100') => __encoding SQADD_Z_ZI__ // sqadd_z_zi_
                                when ('101') => __encoding UQADD_Z_ZI__ // uqadd_z_zi_
                                when ('110') => __encoding SQSUB_Z_ZI__ // sqsub_z_zi_
                                when ('111') => __encoding UQSUB_Z_ZI__ // uqsub_z_zi_
                        when (_, _, _, '01', _, _, _, _) => // sve_int_arith_imm1
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when ('0xx', '1') => __UNALLOCATED
                                when ('000', '0') => __encoding SMAX_Z_ZI__ // smax_z_zi_
                                when ('001', '0') => __encoding UMAX_Z_ZI__ // umax_z_zi_
                                when ('010', '0') => __encoding SMIN_Z_ZI__ // smin_z_zi_
                                when ('011', '0') => __encoding UMIN_Z_ZI__ // umin_z_zi_
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, '10', _, _, _, _) => // sve_int_arith_imm2
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when ('000', '0') => __encoding MUL_Z_ZI__ // mul_z_zi_
                                when ('000', '1') => __UNALLOCATED
                                when ('001', _) => __UNALLOCATED
                                when ('01x', _) => __UNALLOCATED
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, '11', _, '0', _, _) => // sve_int_dup_imm
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding DUP_Z_I__ // dup_z_i_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '11', _, '1', _, _) => // sve_int_dup_fpimm
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (opc, o2) of
                                when ('00', '0') => __encoding FDUP_Z_I__ // fdup_z_i_
                                when ('00', '1') => __UNALLOCATED
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                when ('001', _, '1xx100xx', _, '10xxxx', _, _, _) =>
                    // sve_pred_count_a
                    case (24 +: 8, 22 +: 2, 19 +: 3, 16 +: 3, 14 +: 2, 11 +: 3, 10 +: 1, 9 +: 1, 0 +: 9) of
                        when (_, _, _, _, _, '000', _, '1', _) => // sve_int_pcount_pn
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field vl 10 +: 1
                            __field PNn 5 +: 4
                            __field Rd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding CNTP_R_PN__ // cntp_r_pn_
                                when ('001') => __UNALLOCATED
                                when ('01x') => __UNALLOCATED
                                when ('1xx') => __UNALLOCATED
                        when (_, _, _, _, _, !'000', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '0', _) => // sve_int_pcount_pred
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field Rd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding CNTP_R_P_P__ // cntp_r_p_p_
                                when ('001') => __UNALLOCATED
                                when ('01x') => __UNALLOCATED
                                when ('1xx') => __UNALLOCATED
                when ('001', _, '1xx101xx', _, '1000xx', _, _, _) =>
                    // sve_pred_count_b
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 12 +: 4, 11 +: 1, 0 +: 11) of
                        when (_, _, _, '0', _, _, '0', _) => // sve_int_count_v_sat
                            __field size 22 +: 2
                            __field D 17 +: 1
                            __field U 16 +: 1
                            __field opc 9 +: 2
                            __field Pm 5 +: 4
                            __field Zdn 0 +: 5
                            case (D, U, opc) of
                                when (_, _, '01') => __UNALLOCATED
                                when (_, _, '1x') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding SQINCP_Z_P_Z__ // sqincp_z_p_z_
                                when ('0', '1', '00') => __encoding UQINCP_Z_P_Z__ // uqincp_z_p_z_
                                when ('1', '0', '00') => __encoding SQDECP_Z_P_Z__ // sqdecp_z_p_z_
                                when ('1', '1', '00') => __encoding UQDECP_Z_P_Z__ // uqdecp_z_p_z_
                        when (_, _, _, '0', _, _, '1', _) => // sve_int_count_r_sat
                            __field size 22 +: 2
                            __field D 17 +: 1
                            __field U 16 +: 1
                            __field sf 10 +: 1
                            __field op 9 +: 1
                            __field Pm 5 +: 4
                            __field Rdn 0 +: 5
                            case (D, U, sf, op) of
                                when (_, _, _, '1') => __UNALLOCATED
                                when ('0', '0', '0', '0') => __encoding SQINCP_R_P_R_SX // sqincp_r_p_r_sx
                                when ('0', '0', '1', '0') => __encoding SQINCP_R_P_R_X // sqincp_r_p_r_x
                                when ('0', '1', '0', '0') => __encoding UQINCP_R_P_R_UW // uqincp_r_p_r_uw
                                when ('0', '1', '1', '0') => __encoding UQINCP_R_P_R_X // uqincp_r_p_r_x
                                when ('1', '0', '0', '0') => __encoding SQDECP_R_P_R_SX // sqdecp_r_p_r_sx
                                when ('1', '0', '1', '0') => __encoding SQDECP_R_P_R_X // sqdecp_r_p_r_x
                                when ('1', '1', '0', '0') => __encoding UQDECP_R_P_R_UW // uqdecp_r_p_r_uw
                                when ('1', '1', '1', '0') => __encoding UQDECP_R_P_R_X // uqdecp_r_p_r_x
                        when (_, _, _, '1', _, _, '0', _) => // sve_int_count_v
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field D 16 +: 1
                            __field opc2 9 +: 2
                            __field Pm 5 +: 4
                            __field Zdn 0 +: 5
                            case (op, D, opc2) of
                                when ('0', _, '01') => __UNALLOCATED
                                when ('0', _, '1x') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding INCP_Z_P_Z__ // incp_z_p_z_
                                when ('0', '1', '00') => __encoding DECP_Z_P_Z__ // decp_z_p_z_
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, '1', _, _, '1', _) => // sve_int_count_r
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field D 16 +: 1
                            __field opc2 9 +: 2
                            __field Pm 5 +: 4
                            __field Rdn 0 +: 5
                            case (op, D, opc2) of
                                when ('0', _, '01') => __UNALLOCATED
                                when ('0', _, '1x') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding INCP_R_P_R__ // incp_r_p_r_
                                when ('0', '1', '00') => __encoding DECP_R_P_R__ // decp_r_p_r_
                                when ('1', _, _) => __UNALLOCATED
                when ('001', _, '1xx101xx', _, '1001xx', _, _, _) =>
                    // sve_pred_wrffr
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 12 +: 4, 9 +: 3, 5 +: 4, 0 +: 5) of
                        when (_, _, _, '0', '00', _, '000', _, '00000') => // sve_int_wrffr
                            __field opc 22 +: 2
                            __field Pn 5 +: 4
                            case (opc) of
                                when ('00') => __encoding WRFFR_F_P__ // wrffr_f_p_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '1', '00', _, '000', '0000', '00000') => // sve_int_setffr
                            __field opc 22 +: 2
                            case (opc) of
                                when ('00') => __encoding SETFFR_F__ // setffr_f_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '1', '00', _, '000', '1xxx', '00000') => __UNPREDICTABLE
                        when (_, _, _, '1', '00', _, '000', 'x1xx', '00000') => __UNPREDICTABLE
                        when (_, _, _, '1', '00', _, '000', 'xx1x', '00000') => __UNPREDICTABLE
                        when (_, _, _, '1', '00', _, '000', 'xxx1', '00000') => __UNPREDICTABLE
                        when (_, _, _, _, '00', _, '000', _, !'00000') => __UNPREDICTABLE
                        when (_, _, _, _, '00', _, !'000', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, !'00', _, _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx101xx', _, '101xxx', _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx11xxx', _, '10xxxx', _, _, _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxx', _, '0xxxxx', _, _, _) =>
                    // sve_intx_muladd_unpred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 10 +: 5, 0 +: 10) of
                        when (_, _, _, _, _, '0000x', _) => // sve_intx_dot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding SDOT_Z_ZZZ__ // sdot_z_zzz_
                                when ('1') => __encoding UDOT_Z_ZZZ__ // udot_z_zzz_
                        when (_, _, _, _, _, '0001x', _) => // sve_intx_qdmlalbt
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S) of
                                when ('0') => __encoding SQDMLALBT_Z_ZZZ__ // sqdmlalbt_z_zzz_
                                when ('1') => __encoding SQDMLSLBT_Z_ZZZ__ // sqdmlslbt_z_zzz_
                        when (_, _, _, _, _, '001xx', _) => // sve_intx_cdot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case () of
                                when () => __encoding CDOT_Z_ZZZ__ // cdot_z_zzz_
                        when (_, _, _, _, _, '01xxx', _) => // sve_intx_cmla
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 12 +: 1
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op) of
                                when ('0') => __encoding CMLA_Z_ZZZ__ // cmla_z_zzz_
                                when ('1') => __encoding SQRDCMLAH_Z_ZZZ__ // sqrdcmlah_z_zzz_
                        when (_, _, _, _, _, '10xxx', _) => // sve_intx_mlal_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S, U, T) of
                                when ('0', '0', '0') => __encoding SMLALB_Z_ZZZ__ // smlalb_z_zzz_
                                when ('0', '0', '1') => __encoding SMLALT_Z_ZZZ__ // smlalt_z_zzz_
                                when ('0', '1', '0') => __encoding UMLALB_Z_ZZZ__ // umlalb_z_zzz_
                                when ('0', '1', '1') => __encoding UMLALT_Z_ZZZ__ // umlalt_z_zzz_
                                when ('1', '0', '0') => __encoding SMLSLB_Z_ZZZ__ // smlslb_z_zzz_
                                when ('1', '0', '1') => __encoding SMLSLT_Z_ZZZ__ // smlslt_z_zzz_
                                when ('1', '1', '0') => __encoding UMLSLB_Z_ZZZ__ // umlslb_z_zzz_
                                when ('1', '1', '1') => __encoding UMLSLT_Z_ZZZ__ // umlslt_z_zzz_
                        when (_, _, _, _, _, '110xx', _) => // sve_intx_qdmlal_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S, T) of
                                when ('0', '0') => __encoding SQDMLALB_Z_ZZZ__ // sqdmlalb_z_zzz_
                                when ('0', '1') => __encoding SQDMLALT_Z_ZZZ__ // sqdmlalt_z_zzz_
                                when ('1', '0') => __encoding SQDMLSLB_Z_ZZZ__ // sqdmlslb_z_zzz_
                                when ('1', '1') => __encoding SQDMLSLT_Z_ZZZ__ // sqdmlslt_z_zzz_
                        when (_, _, _, _, _, '1110x', _) => // sve_intx_qrdmlah
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S) of
                                when ('0') => __encoding SQRDMLAH_Z_ZZZ__ // sqrdmlah_z_zzz_
                                when ('1') => __encoding SQRDMLSH_Z_ZZZ__ // sqrdmlsh_z_zzz_
                        when (_, _, _, _, _, '11110', _) => // sve_intx_mixed_dot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding USDOT_Z_ZZZ_S // usdot_z_zzz_s
                                when ('11') => __UNALLOCATED
                        when (_, _, _, _, _, '11111', _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxx', _, '10xxxx', _, _, _) =>
                    // sve_intx_predicated
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 16 +: 1, 14 +: 2, 13 +: 1, 0 +: 13) of
                        when (_, _, _, '0010', _, _, '1', _) => // sve_intx_accumulate_long_pairs
                            __field size 22 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding SADALP_Z_P_Z__ // sadalp_z_p_z_
                                when ('1') => __encoding UADALP_Z_P_Z__ // uadalp_z_p_z_
                        when (_, _, _, '0011', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '011x', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0x0x', _, _, '1', _) => // sve_intx_pred_arith_unary
                            __field size 22 +: 2
                            __field Q 19 +: 1
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (Q, opc) of
                                when (_, '1x') => __UNALLOCATED
                                when ('0', '00') => __encoding URECPE_Z_P_Z__ // urecpe_z_p_z_
                                when ('0', '01') => __encoding URSQRTE_Z_P_Z__ // ursqrte_z_p_z_
                                when ('1', '00') => __encoding SQABS_Z_P_Z__ // sqabs_z_p_z_
                                when ('1', '01') => __encoding SQNEG_Z_P_Z__ // sqneg_z_p_z_
                        when (_, _, _, '0xxx', _, _, '0', _) => // sve_intx_bin_pred_shift_sat_round
                            __field size 22 +: 2
                            __field Q 19 +: 1
                            __field R 18 +: 1
                            __field N 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (Q, R, N, U) of
                                when ('0', _, '0', _) => __UNALLOCATED
                                when ('0', '0', '1', '0') => __encoding SRSHL_Z_P_ZZ__ // srshl_z_p_zz_
                                when ('0', '0', '1', '1') => __encoding URSHL_Z_P_ZZ__ // urshl_z_p_zz_
                                when ('0', '1', '1', '0') => __encoding SRSHLR_Z_P_ZZ__ // srshlr_z_p_zz_
                                when ('0', '1', '1', '1') => __encoding URSHLR_Z_P_ZZ__ // urshlr_z_p_zz_
                                when ('1', '0', '0', '0') => __encoding SQSHL_Z_P_ZZ__ // sqshl_z_p_zz_
                                when ('1', '0', '0', '1') => __encoding UQSHL_Z_P_ZZ__ // uqshl_z_p_zz_
                                when ('1', '0', '1', '0') => __encoding SQRSHL_Z_P_ZZ__ // sqrshl_z_p_zz_
                                when ('1', '0', '1', '1') => __encoding UQRSHL_Z_P_ZZ__ // uqrshl_z_p_zz_
                                when ('1', '1', '0', '0') => __encoding SQSHLR_Z_P_ZZ__ // sqshlr_z_p_zz_
                                when ('1', '1', '0', '1') => __encoding UQSHLR_Z_P_ZZ__ // uqshlr_z_p_zz_
                                when ('1', '1', '1', '0') => __encoding SQRSHLR_Z_P_ZZ__ // sqrshlr_z_p_zz_
                                when ('1', '1', '1', '1') => __encoding UQRSHLR_Z_P_ZZ__ // uqrshlr_z_p_zz_
                        when (_, _, _, '10xx', _, _, '0', _) => // sve_intx_pred_arith_binary
                            __field size 22 +: 2
                            __field R 18 +: 1
                            __field S 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, S, U) of
                                when ('0', '0', '0') => __encoding SHADD_Z_P_ZZ__ // shadd_z_p_zz_
                                when ('0', '0', '1') => __encoding UHADD_Z_P_ZZ__ // uhadd_z_p_zz_
                                when ('0', '1', '0') => __encoding SHSUB_Z_P_ZZ__ // shsub_z_p_zz_
                                when ('0', '1', '1') => __encoding UHSUB_Z_P_ZZ__ // uhsub_z_p_zz_
                                when ('1', '0', '0') => __encoding SRHADD_Z_P_ZZ__ // srhadd_z_p_zz_
                                when ('1', '0', '1') => __encoding URHADD_Z_P_ZZ__ // urhadd_z_p_zz_
                                when ('1', '1', '0') => __encoding SHSUBR_Z_P_ZZ__ // shsubr_z_p_zz_
                                when ('1', '1', '1') => __encoding UHSUBR_Z_P_ZZ__ // uhsubr_z_p_zz_
                        when (_, _, _, '10xx', _, _, '1', _) => // sve_intx_arith_binary_pairs
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, U) of
                                when ('00', '0') => __UNALLOCATED
                                when ('00', '1') => __encoding ADDP_Z_P_ZZ__ // addp_z_p_zz_
                                when ('01', _) => __UNALLOCATED
                                when ('10', '0') => __encoding SMAXP_Z_P_ZZ__ // smaxp_z_p_zz_
                                when ('10', '1') => __encoding UMAXP_Z_P_ZZ__ // umaxp_z_p_zz_
                                when ('11', '0') => __encoding SMINP_Z_P_ZZ__ // sminp_z_p_zz_
                                when ('11', '1') => __encoding UMINP_Z_P_ZZ__ // uminp_z_p_zz_
                        when (_, _, _, '11xx', _, _, '0', _) => // sve_intx_pred_arith_binary_sat
                            __field size 22 +: 2
                            __field op 18 +: 1
                            __field S 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (op, S, U) of
                                when ('0', '0', '0') => __encoding SQADD_Z_P_ZZ__ // sqadd_z_p_zz_
                                when ('0', '0', '1') => __encoding UQADD_Z_P_ZZ__ // uqadd_z_p_zz_
                                when ('0', '1', '0') => __encoding SQSUB_Z_P_ZZ__ // sqsub_z_p_zz_
                                when ('0', '1', '1') => __encoding UQSUB_Z_P_ZZ__ // uqsub_z_p_zz_
                                when ('1', '0', '0') => __encoding SUQADD_Z_P_ZZ__ // suqadd_z_p_zz_
                                when ('1', '0', '1') => __encoding USQADD_Z_P_ZZ__ // usqadd_z_p_zz_
                                when ('1', '1', '0') => __encoding SQSUBR_Z_P_ZZ__ // sqsubr_z_p_zz_
                                when ('1', '1', '1') => __encoding UQSUBR_Z_P_ZZ__ // uqsubr_z_p_zz_
                        when (_, _, _, '11xx', _, _, '1', _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxx', _, '11000x', _, _, _) => // sve_intx_clamp
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (U) of
                        when ('0') => __encoding SCLAMP_Z_ZZ__ // sclamp_z_zz_
                        when ('1') => __encoding UCLAMP_Z_ZZ__ // uclamp_z_zz_
                when ('010', _, '0xx0xxxx', _, '1101xx', _, _, _) => // sve_ptr_muladd_unpred
                    __field opc 22 +: 2
                    __field Zm 16 +: 5
                    __field opc2 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (opc, opc2) of
                        when ('0x', _) => __UNALLOCATED
                        when ('10', _) => __UNALLOCATED
                        when ('11', 'x1') => __UNALLOCATED
                        when ('11', '00') => __encoding MLAPT_Z_ZZZ__ // mlapt_z_zzz_
                        when ('11', '10') => __encoding MADPT_Z_ZZZ__ // madpt_z_zzz_
                when ('010', _, '0xx0xxxx', _, '111xxx', _, _, _) => // sve_int_perm_binquads
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding ZIPQ1_Z_ZZ__ // zipq1_z_zz_
                        when ('001') => __encoding ZIPQ2_Z_ZZ__ // zipq2_z_zz_
                        when ('010') => __encoding UZPQ1_Z_ZZ__ // uzpq1_z_zz_
                        when ('011') => __encoding UZPQ2_Z_ZZ__ // uzpq2_z_zz_
                        when ('10x') => __UNALLOCATED
                        when ('110') => __encoding TBLQ_Z_ZZ__ // tblq_z_zz_
                        when ('111') => __UNALLOCATED
                when ('010', _, '0xx1xxxx', _, _, _, _, _) =>
                    // sve_intx_by_indexed_elem
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 10 +: 6, 0 +: 10) of
                        when (_, _, _, _, '00000x', _) => // sve_intx_dot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, U) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '0') => __encoding SDOT_Z_ZZZi_S // sdot_z_zzzi_s
                                when ('10', '1') => __encoding UDOT_Z_ZZZi_S // udot_z_zzzi_s
                                when ('11', '0') => __encoding SDOT_Z_ZZZi_D // sdot_z_zzzi_d
                                when ('11', '1') => __encoding UDOT_Z_ZZZi_D // udot_z_zzzi_d
                        when (_, _, _, _, '00001x', _) => // sve_intx_mla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S) of
                                when ('0x', '0') => __encoding MLA_Z_ZZZi_H // mla_z_zzzi_h
                                when ('0x', '1') => __encoding MLS_Z_ZZZi_H // mls_z_zzzi_h
                                when ('10', '0') => __encoding MLA_Z_ZZZi_S // mla_z_zzzi_s
                                when ('10', '1') => __encoding MLS_Z_ZZZi_S // mls_z_zzzi_s
                                when ('11', '0') => __encoding MLA_Z_ZZZi_D // mla_z_zzzi_d
                                when ('11', '1') => __encoding MLS_Z_ZZZi_D // mls_z_zzzi_d
                        when (_, _, _, _, '00010x', _) => // sve_intx_qrdmlah_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S) of
                                when ('0x', '0') => __encoding SQRDMLAH_Z_ZZZi_H // sqrdmlah_z_zzzi_h
                                when ('0x', '1') => __encoding SQRDMLSH_Z_ZZZi_H // sqrdmlsh_z_zzzi_h
                                when ('10', '0') => __encoding SQRDMLAH_Z_ZZZi_S // sqrdmlah_z_zzzi_s
                                when ('10', '1') => __encoding SQRDMLSH_Z_ZZZi_S // sqrdmlsh_z_zzzi_s
                                when ('11', '0') => __encoding SQRDMLAH_Z_ZZZi_D // sqrdmlah_z_zzzi_d
                                when ('11', '1') => __encoding SQRDMLSH_Z_ZZZi_D // sqrdmlsh_z_zzzi_d
                        when (_, _, _, _, '00011x', _) => // sve_intx_mixed_dot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, U) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '0') => __encoding USDOT_Z_ZZZi_S // usdot_z_zzzi_s
                                when ('10', '1') => __encoding SUDOT_Z_ZZZi_S // sudot_z_zzzi_s
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, _, '001xxx', _) => // sve_intx_qdmla_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S, T) of
                                when ('0x', _, _) => __UNALLOCATED
                                when ('10', '0', '0') => __encoding SQDMLALB_Z_ZZZi_S // sqdmlalb_z_zzzi_s
                                when ('10', '0', '1') => __encoding SQDMLALT_Z_ZZZi_S // sqdmlalt_z_zzzi_s
                                when ('10', '1', '0') => __encoding SQDMLSLB_Z_ZZZi_S // sqdmlslb_z_zzzi_s
                                when ('10', '1', '1') => __encoding SQDMLSLT_Z_ZZZi_S // sqdmlslt_z_zzzi_s
                                when ('11', '0', '0') => __encoding SQDMLALB_Z_ZZZi_D // sqdmlalb_z_zzzi_d
                                when ('11', '0', '1') => __encoding SQDMLALT_Z_ZZZi_D // sqdmlalt_z_zzzi_d
                                when ('11', '1', '0') => __encoding SQDMLSLB_Z_ZZZi_D // sqdmlslb_z_zzzi_d
                                when ('11', '1', '1') => __encoding SQDMLSLT_Z_ZZZi_D // sqdmlslt_z_zzzi_d
                        when (_, _, _, _, '0100xx', _) => // sve_intx_cdot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding CDOT_Z_ZZZi_S // cdot_z_zzzi_s
                                when ('11') => __encoding CDOT_Z_ZZZi_D // cdot_z_zzzi_d
                        when (_, _, _, _, '0101xx', _) => __UNPREDICTABLE
                        when (_, _, _, _, '0110xx', _) => // sve_intx_cmla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding CMLA_Z_ZZZi_H // cmla_z_zzzi_h
                                when ('11') => __encoding CMLA_Z_ZZZi_S // cmla_z_zzzi_s
                        when (_, _, _, _, '0111xx', _) => // sve_intx_qrdcmla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding SQRDCMLAH_Z_ZZZi_H // sqrdcmlah_z_zzzi_h
                                when ('11') => __encoding SQRDCMLAH_Z_ZZZi_S // sqrdcmlah_z_zzzi_s
                        when (_, _, _, _, '10xxxx', _) => // sve_intx_mla_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 13 +: 1
                            __field U 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S, U, T) of
                                when ('0x', _, _, _) => __UNALLOCATED
                                when ('10', '0', '0', '0') => __encoding SMLALB_Z_ZZZi_S // smlalb_z_zzzi_s
                                when ('10', '0', '0', '1') => __encoding SMLALT_Z_ZZZi_S // smlalt_z_zzzi_s
                                when ('10', '0', '1', '0') => __encoding UMLALB_Z_ZZZi_S // umlalb_z_zzzi_s
                                when ('10', '0', '1', '1') => __encoding UMLALT_Z_ZZZi_S // umlalt_z_zzzi_s
                                when ('10', '1', '0', '0') => __encoding SMLSLB_Z_ZZZi_S // smlslb_z_zzzi_s
                                when ('10', '1', '0', '1') => __encoding SMLSLT_Z_ZZZi_S // smlslt_z_zzzi_s
                                when ('10', '1', '1', '0') => __encoding UMLSLB_Z_ZZZi_S // umlslb_z_zzzi_s
                                when ('10', '1', '1', '1') => __encoding UMLSLT_Z_ZZZi_S // umlslt_z_zzzi_s
                                when ('11', '0', '0', '0') => __encoding SMLALB_Z_ZZZi_D // smlalb_z_zzzi_d
                                when ('11', '0', '0', '1') => __encoding SMLALT_Z_ZZZi_D // smlalt_z_zzzi_d
                                when ('11', '0', '1', '0') => __encoding UMLALB_Z_ZZZi_D // umlalb_z_zzzi_d
                                when ('11', '0', '1', '1') => __encoding UMLALT_Z_ZZZi_D // umlalt_z_zzzi_d
                                when ('11', '1', '0', '0') => __encoding SMLSLB_Z_ZZZi_D // smlslb_z_zzzi_d
                                when ('11', '1', '0', '1') => __encoding SMLSLT_Z_ZZZi_D // smlslt_z_zzzi_d
                                when ('11', '1', '1', '0') => __encoding UMLSLB_Z_ZZZi_D // umlslb_z_zzzi_d
                                when ('11', '1', '1', '1') => __encoding UMLSLT_Z_ZZZi_D // umlslt_z_zzzi_d
                        when (_, _, _, _, '110xxx', _) => // sve_intx_mul_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, U, T) of
                                when ('0x', _, _) => __UNALLOCATED
                                when ('10', '0', '0') => __encoding SMULLB_Z_ZZi_S // smullb_z_zzi_s
                                when ('10', '0', '1') => __encoding SMULLT_Z_ZZi_S // smullt_z_zzi_s
                                when ('10', '1', '0') => __encoding UMULLB_Z_ZZi_S // umullb_z_zzi_s
                                when ('10', '1', '1') => __encoding UMULLT_Z_ZZi_S // umullt_z_zzi_s
                                when ('11', '0', '0') => __encoding SMULLB_Z_ZZi_D // smullb_z_zzi_d
                                when ('11', '0', '1') => __encoding SMULLT_Z_ZZi_D // smullt_z_zzi_d
                                when ('11', '1', '0') => __encoding UMULLB_Z_ZZi_D // umullb_z_zzi_d
                                when ('11', '1', '1') => __encoding UMULLT_Z_ZZi_D // umullt_z_zzi_d
                        when (_, _, _, _, '1110xx', _) => // sve_intx_qdmul_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, T) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '0') => __encoding SQDMULLB_Z_ZZi_S // sqdmullb_z_zzi_s
                                when ('10', '1') => __encoding SQDMULLT_Z_ZZi_S // sqdmullt_z_zzi_s
                                when ('11', '0') => __encoding SQDMULLB_Z_ZZi_D // sqdmullb_z_zzi_d
                                when ('11', '1') => __encoding SQDMULLT_Z_ZZi_D // sqdmullt_z_zzi_d
                        when (_, _, _, _, '11110x', _) => // sve_intx_qdmulh_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field R 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, R) of
                                when ('0x', '0') => __encoding SQDMULH_Z_ZZi_H // sqdmulh_z_zzi_h
                                when ('0x', '1') => __encoding SQRDMULH_Z_ZZi_H // sqrdmulh_z_zzi_h
                                when ('10', '0') => __encoding SQDMULH_Z_ZZi_S // sqdmulh_z_zzi_s
                                when ('10', '1') => __encoding SQRDMULH_Z_ZZi_S // sqrdmulh_z_zzi_s
                                when ('11', '0') => __encoding SQDMULH_Z_ZZi_D // sqdmulh_z_zzi_d
                                when ('11', '1') => __encoding SQRDMULH_Z_ZZi_D // sqrdmulh_z_zzi_d
                        when (_, _, _, _, '111110', _) => // sve_intx_mul_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size) of
                                when ('0x') => __encoding MUL_Z_ZZi_H // mul_z_zzi_h
                                when ('10') => __encoding MUL_Z_ZZi_S // mul_z_zzi_s
                                when ('11') => __encoding MUL_Z_ZZi_D // mul_z_zzi_d
                        when (_, _, _, _, '111111', _) => __UNPREDICTABLE
                when ('010', _, '0x10xxxx', _, '11001x', _, _, _) => __UNPREDICTABLE
                when ('010', _, '0000xxxx', _, '11001x', _, _, _) => // sve_intx_dot2
                    __field Zm 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (U) of
                        when ('0') => __encoding SDOT_Z32_ZZZ__ // sdot_z32_zzz_
                        when ('1') => __encoding UDOT_Z32_ZZZ__ // udot_z32_zzz_
                when ('010', _, '0100xxxx', _, '11001x', _, _, _) => // sve_intx_dot2_by_indexed_elem
                    __field opc 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (U) of
                        when ('0') => __encoding SDOT_Z32_ZZZi__ // sdot_z32_zzzi_
                        when ('1') => __encoding UDOT_Z32_ZZZi__ // udot_z32_zzzi_
                when ('010', _, '1xx0xxxx', _, '0xxxxx', _, _, _) =>
                    // sve_intx_cons_widening
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 13 +: 2, 0 +: 13) of
                        when (_, _, _, _, _, '0x', _) => // sve_intx_cons_arith_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op, S, U, T) of
                                when ('0', '0', '0', '0') => __encoding SADDLB_Z_ZZ__ // saddlb_z_zz_
                                when ('0', '0', '0', '1') => __encoding SADDLT_Z_ZZ__ // saddlt_z_zz_
                                when ('0', '0', '1', '0') => __encoding UADDLB_Z_ZZ__ // uaddlb_z_zz_
                                when ('0', '0', '1', '1') => __encoding UADDLT_Z_ZZ__ // uaddlt_z_zz_
                                when ('0', '1', '0', '0') => __encoding SSUBLB_Z_ZZ__ // ssublb_z_zz_
                                when ('0', '1', '0', '1') => __encoding SSUBLT_Z_ZZ__ // ssublt_z_zz_
                                when ('0', '1', '1', '0') => __encoding USUBLB_Z_ZZ__ // usublb_z_zz_
                                when ('0', '1', '1', '1') => __encoding USUBLT_Z_ZZ__ // usublt_z_zz_
                                when ('1', '0', _, _) => __UNALLOCATED
                                when ('1', '1', '0', '0') => __encoding SABDLB_Z_ZZ__ // sabdlb_z_zz_
                                when ('1', '1', '0', '1') => __encoding SABDLT_Z_ZZ__ // sabdlt_z_zz_
                                when ('1', '1', '1', '0') => __encoding UABDLB_Z_ZZ__ // uabdlb_z_zz_
                                when ('1', '1', '1', '1') => __encoding UABDLT_Z_ZZ__ // uabdlt_z_zz_
                        when (_, _, _, _, _, '10', _) => // sve_intx_cons_arith_wide
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, U, T) of
                                when ('0', '0', '0') => __encoding SADDWB_Z_ZZ__ // saddwb_z_zz_
                                when ('0', '0', '1') => __encoding SADDWT_Z_ZZ__ // saddwt_z_zz_
                                when ('0', '1', '0') => __encoding UADDWB_Z_ZZ__ // uaddwb_z_zz_
                                when ('0', '1', '1') => __encoding UADDWT_Z_ZZ__ // uaddwt_z_zz_
                                when ('1', '0', '0') => __encoding SSUBWB_Z_ZZ__ // ssubwb_z_zz_
                                when ('1', '0', '1') => __encoding SSUBWT_Z_ZZ__ // ssubwt_z_zz_
                                when ('1', '1', '0') => __encoding USUBWB_Z_ZZ__ // usubwb_z_zz_
                                when ('1', '1', '1') => __encoding USUBWT_Z_ZZ__ // usubwt_z_zz_
                        when (_, _, _, _, _, '11', _) => // sve_intx_cons_mul_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, op, U, T) of
                                when (_, '0', '0', '0') => __encoding SQDMULLB_Z_ZZ__ // sqdmullb_z_zz_
                                when (_, '0', '0', '1') => __encoding SQDMULLT_Z_ZZ__ // sqdmullt_z_zz_
                                when (_, '1', '0', '0') => __encoding SMULLB_Z_ZZ__ // smullb_z_zz_
                                when (_, '1', '0', '1') => __encoding SMULLT_Z_ZZ__ // smullt_z_zz_
                                when (_, '1', '1', '0') => __encoding UMULLB_Z_ZZ__ // umullb_z_zz_
                                when (_, '1', '1', '1') => __encoding UMULLT_Z_ZZ__ // umullt_z_zz_
                                when (!'00', '0', '1', '0') => __encoding PMULLB_Z_ZZ__ // pmullb_z_zz_
                                when (!'00', '0', '1', '1') => __encoding PMULLT_Z_ZZ__ // pmullt_z_zz_
                                when ('00', '0', '1', '0') => __encoding PMULLB_Z_ZZ_Q // pmullb_z_zz_q
                                when ('00', '0', '1', '1') => __encoding PMULLT_Z_ZZ_Q // pmullt_z_zz_q
                when ('010', _, '1xx0xxxx', _, '10xxxx', _, _, _) =>
                    // sve_intx_constructive
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 10 +: 4, 0 +: 10) of
                        when (_, '0', _, _, _, _, '10xx', _) => // sve_intx_shift_long
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (U, T) of
                                when ('0', '0') => __encoding SSHLLB_Z_ZI__ // sshllb_z_zi_
                                when ('0', '1') => __encoding SSHLLT_Z_ZI__ // sshllt_z_zi_
                                when ('1', '0') => __encoding USHLLB_Z_ZI__ // ushllb_z_zi_
                                when ('1', '1') => __encoding USHLLT_Z_ZI__ // ushllt_z_zi_
                        when (_, '1', _, _, _, _, '10xx', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00xx', _) => // sve_intx_clong
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 11 +: 1
                            __field tb 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, tb) of
                                when ('0', '0') => __encoding SADDLBT_Z_ZZ__ // saddlbt_z_zz_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', '0') => __encoding SSUBLBT_Z_ZZ__ // ssublbt_z_zz_
                                when ('1', '1') => __encoding SSUBLTB_Z_ZZ__ // ssubltb_z_zz_
                        when (_, _, _, _, _, _, '010x', _) => // sve_intx_eorx
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field tb 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (tb) of
                                when ('0') => __encoding EORBT_Z_ZZ__ // eorbt_z_zz_
                                when ('1') => __encoding EORTB_Z_ZZ__ // eortb_z_zz_
                        when (_, _, _, _, _, _, '0110', _) => // sve_intx_mmla
                            __field uns 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (uns) of
                                when ('00') => __encoding SMMLA_Z_ZZZ__ // smmla_z_zzz_
                                when ('01') => __UNALLOCATED
                                when ('10') => __encoding USMMLA_Z_ZZZ__ // usmmla_z_zzz_
                                when ('11') => __encoding UMMLA_Z_ZZZ__ // ummla_z_zzz_
                        when (_, _, _, _, _, _, '0111', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '11xx', _) => // sve_intx_perm_bit
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding BEXT_Z_ZZ__ // bext_z_zz_
                                when ('01') => __encoding BDEP_Z_ZZ__ // bdep_z_zz_
                                when ('10') => __encoding BGRP_Z_ZZ__ // bgrp_z_zz_
                                when ('11') => __UNALLOCATED
                when ('010', _, '1xx0xxxx', _, '11xxxx', _, _, _) =>
                    // sve_intx_acc
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 16 +: 1, 14 +: 2, 11 +: 3, 0 +: 11) of
                        when (_, _, _, '0000', _, _, '011', _) => // sve_intx_cadd
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field rot 10 +: 1
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (op) of
                                when ('0') => __encoding CADD_Z_ZZ__ // cadd_z_zz_
                                when ('1') => __encoding SQCADD_Z_ZZ__ // sqcadd_z_zz_
                        when (_, _, _, !'0000', _, _, '011', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00x', _) => // sve_intx_aba_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U, T) of
                                when ('0', '0') => __encoding SABALB_Z_ZZZ__ // sabalb_z_zzz_
                                when ('0', '1') => __encoding SABALT_Z_ZZZ__ // sabalt_z_zzz_
                                when ('1', '0') => __encoding UABALB_Z_ZZZ__ // uabalb_z_zzz_
                                when ('1', '1') => __encoding UABALT_Z_ZZZ__ // uabalt_z_zzz_
                        when (_, _, _, _, _, _, '010', _) => // sve_intx_adc_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, T) of
                                when ('0x', '0') => __encoding ADCLB_Z_ZZZ__ // adclb_z_zzz_
                                when ('0x', '1') => __encoding ADCLT_Z_ZZZ__ // adclt_z_zzz_
                                when ('1x', '0') => __encoding SBCLB_Z_ZZZ__ // sbclb_z_zzz_
                                when ('1x', '1') => __encoding SBCLT_Z_ZZZ__ // sbclt_z_zzz_
                        when (_, _, _, _, _, _, '10x', _) => // sve_intx_sra
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field R 11 +: 1
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (R, U) of
                                when ('0', '0') => __encoding SSRA_Z_ZI__ // ssra_z_zi_
                                when ('0', '1') => __encoding USRA_Z_ZI__ // usra_z_zi_
                                when ('1', '0') => __encoding SRSRA_Z_ZI__ // srsra_z_zi_
                                when ('1', '1') => __encoding URSRA_Z_ZI__ // ursra_z_zi_
                        when (_, _, _, _, _, _, '110', _) => // sve_intx_shift_insert
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding SRI_Z_ZZI__ // sri_z_zzi_
                                when ('1') => __encoding SLI_Z_ZZI__ // sli_z_zzi_
                        when (_, _, _, _, _, _, '111', _) => // sve_intx_aba
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding SABA_Z_ZZZ__ // saba_z_zzz_
                                when ('1') => __encoding UABA_Z_ZZZ__ // uaba_z_zzz_
                when ('010', _, '1xx1xxxx', _, '0xxxxx', _, _, _) =>
                    // sve_intx_narrowing
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 16 +: 1, 15 +: 1, 13 +: 2, 11 +: 2, 10 +: 1, 6 +: 4, 5 +: 1, 0 +: 5) of
                        when (_, '0', _, _, _, '00', '0', _, '10', _, _, _, _, _) => // sve_intx_extract_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field opc 11 +: 2
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, T) of
                                when ('00', '0') => __encoding SQXTNB_Z_ZZ__ // sqxtnb_z_zz_
                                when ('00', '1') => __encoding SQXTNT_Z_ZZ__ // sqxtnt_z_zz_
                                when ('01', '0') => __encoding UQXTNB_Z_ZZ__ // uqxtnb_z_zz_
                                when ('01', '1') => __encoding UQXTNT_Z_ZZ__ // uqxtnt_z_zz_
                                when ('10', '0') => __encoding SQXTUNB_Z_ZZ__ // sqxtunb_z_zz_
                                when ('10', '1') => __encoding SQXTUNT_Z_ZZ__ // sqxtunt_z_zz_
                                when ('11', _) => __UNALLOCATED
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '0', _, '0', _) => // sve_intx_multi_extract_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field opc 11 +: 2
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (tszh, tszl, opc) of
                                when ('0', '0x', _) => __UNALLOCATED
                                when ('0', '10', '00') => __encoding SQCVTN_Z_MZ2__ // sqcvtn_z_mz2_
                                when ('0', '10', '01') => __encoding UQCVTN_Z_MZ2__ // uqcvtn_z_mz2_
                                when ('0', '10', '10') => __encoding SQCVTUN_Z_MZ2__ // sqcvtun_z_mz2_
                                when ('0', '10', '11') => __UNALLOCATED
                                when ('0', '11', _) => __UNALLOCATED
                                when ('1', _, _) => __UNALLOCATED
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, !'00', _, _, '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, _, '0x', _, _, _, _, _) => // sve_intx_shift_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field op 13 +: 1
                            __field U 12 +: 1
                            __field R 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op, U, R, T) of
                                when ('0', '0', '0', '0') => __encoding SQSHRUNB_Z_ZI__ // sqshrunb_z_zi_
                                when ('0', '0', '0', '1') => __encoding SQSHRUNT_Z_ZI__ // sqshrunt_z_zi_
                                when ('0', '0', '1', '0') => __encoding SQRSHRUNB_Z_ZI__ // sqrshrunb_z_zi_
                                when ('0', '0', '1', '1') => __encoding SQRSHRUNT_Z_ZI__ // sqrshrunt_z_zi_
                                when ('0', '1', '0', '0') => __encoding SHRNB_Z_ZI__ // shrnb_z_zi_
                                when ('0', '1', '0', '1') => __encoding SHRNT_Z_ZI__ // shrnt_z_zi_
                                when ('0', '1', '1', '0') => __encoding RSHRNB_Z_ZI__ // rshrnb_z_zi_
                                when ('0', '1', '1', '1') => __encoding RSHRNT_Z_ZI__ // rshrnt_z_zi_
                                when ('1', '0', '0', '0') => __encoding SQSHRNB_Z_ZI__ // sqshrnb_z_zi_
                                when ('1', '0', '0', '1') => __encoding SQSHRNT_Z_ZI__ // sqshrnt_z_zi_
                                when ('1', '0', '1', '0') => __encoding SQRSHRNB_Z_ZI__ // sqrshrnb_z_zi_
                                when ('1', '0', '1', '1') => __encoding SQRSHRNT_Z_ZI__ // sqrshrnt_z_zi_
                                when ('1', '1', '0', '0') => __encoding UQSHRNB_Z_ZI__ // uqshrnb_z_zi_
                                when ('1', '1', '0', '1') => __encoding UQSHRNT_Z_ZI__ // uqshrnt_z_zi_
                                when ('1', '1', '1', '0') => __encoding UQRSHRNB_Z_ZI__ // uqrshrnb_z_zi_
                                when ('1', '1', '1', '1') => __encoding UQRSHRNT_Z_ZI__ // uqrshrnt_z_zi_
                        when (_, '1', _, _, _, _, _, _, '0x', _, '0', _, '0', _) => // sve_intx_multi_shift_narrow
                            __field tszh 22 +: 1
                            __field tszl 20 +: 1
                            __field imm4 16 +: 4
                            __field op 13 +: 1
                            __field U 12 +: 1
                            __field R 11 +: 1
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (tszh, tszl, op, U, R) of
                                when ('0', '0', _, _, _) => __UNALLOCATED
                                when ('0', '1', '0', '0', '0') => __UNALLOCATED
                                when ('0', '1', '0', '0', '1') => __encoding SQRSHRUN_Z_MZ2__ // sqrshrun_z_mz2_
                                when ('0', '1', '0', '1', _) => __UNALLOCATED
                                when ('0', '1', '1', _, '0') => __UNALLOCATED
                                when ('0', '1', '1', '0', '1') => __encoding SQRSHRN_Z_MZ2__ // sqrshrn_z_mz2_
                                when ('0', '1', '1', '1', '1') => __encoding UQRSHRN_Z_MZ2__ // uqrshrn_z_mz2_
                                when ('1', _, _, _, _) => __UNALLOCATED
                        when (_, '1', _, _, _, _, _, _, '0x', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, '0x', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, _, '11', _, _, _, _, _) => // sve_intx_arith_narrow
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field R 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, R, T) of
                                when ('0', '0', '0') => __encoding ADDHNB_Z_ZZ__ // addhnb_z_zz_
                                when ('0', '0', '1') => __encoding ADDHNT_Z_ZZ__ // addhnt_z_zz_
                                when ('0', '1', '0') => __encoding RADDHNB_Z_ZZ__ // raddhnb_z_zz_
                                when ('0', '1', '1') => __encoding RADDHNT_Z_ZZ__ // raddhnt_z_zz_
                                when ('1', '0', '0') => __encoding SUBHNB_Z_ZZ__ // subhnb_z_zz_
                                when ('1', '0', '1') => __encoding SUBHNT_Z_ZZ__ // subhnt_z_zz_
                                when ('1', '1', '0') => __encoding RSUBHNB_Z_ZZ__ // rsubhnb_z_zz_
                                when ('1', '1', '1') => __encoding RSUBHNT_Z_ZZ__ // rsubhnt_z_zz_
                when ('010', _, '1xx1xxxx', _, '100xxx', _, _, _) => // sve_intx_match
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field op 4 +: 1
                    __field Pd 0 +: 4
                    case (op) of
                        when ('0') => __encoding MATCH_P_P_ZZ__ // match_p_p_zz_
                        when ('1') => __encoding NMATCH_P_P_ZZ__ // nmatch_p_p_zz_
                when ('010', _, '1xx1xxxx', _, '101xxx', _, _, _) =>
                    // sve_intx_histseg_lut
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 0 +: 10) of
                        when (_, _, '0', _, _, _, '0x1', _) => __UNPREDICTABLE
                        when (_, _, '1', _, _, _, '001', _) => // sve_intx_lut4_8
                            __field i1 23 +: 1
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding LUTI4_Z_ZZ_8 // luti4_z_zz_8
                        when (_, _, '1', _, _, _, '011', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '000', _) => // sve_intx_histseg
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding HISTSEG_Z_ZZ__ // histseg_z_zz_
                        when (_, _, _, _, _, _, '100', _) => // sve_intx_lut2_8
                            __field i2 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding LUTI2_Z_ZZ_8 // luti2_z_zz_8
                        when (_, _, _, _, _, _, '1x1', _) => // sve_intx_lut4_16
                            __field i2 22 +: 2
                            __field Zm 16 +: 5
                            __field op 11 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding LUTI4_Z_ZZ_2x16 // luti4_z_zz_2x16
                                when ('1') => __encoding LUTI4_Z_ZZ_1x16 // luti4_z_zz_1x16
                        when (_, _, _, _, _, _, 'x10', _) => // sve_intx_lut2_16
                            __field i3h 22 +: 2
                            __field Zm 16 +: 5
                            __field i3l 12 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding LUTI2_Z_ZZ_16 // luti2_z_zz_16
                when ('010', _, '1xx1xxxx', _, '110xxx', _, _, _) => // sve_intx_histcnt
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding HISTCNT_Z_P_ZZ__ // histcnt_z_p_zz_
                when ('010', _, '1xx1xxxx', _, '111xxx', _, _, _) =>
                    // sve_intx_crypto
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 11 +: 2, 10 +: 1, 5 +: 5, 0 +: 5) of
                        when (_, _, _, '000', '00', _, '00', _, '00000', _) => // sve_crypto_unary
                            __field size 22 +: 2
                            __field op 10 +: 1
                            __field Zdn 0 +: 5
                            case (size, op) of
                                when ('00', '0') => __encoding AESMC_Z_Z__ // aesmc_z_z_
                                when ('00', '1') => __encoding AESIMC_Z_Z__ // aesimc_z_z_
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                        when (_, _, _, '000', '00', _, '00', _, !'00000', _) => __UNPREDICTABLE
                        when (_, _, _, '000', '00', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '000', '01', _, '0x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '000', '01', _, '11', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '000', '1x', _, '00', _, _, _) => // sve_crypto_binary_dest
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field o2 10 +: 1
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, op, o2) of
                                when ('00', '0', '0') => __encoding AESE_Z_ZZ__ // aese_z_zz_
                                when ('00', '0', '1') => __encoding AESD_Z_ZZ__ // aesd_z_zz_
                                when ('00', '1', '0') => __encoding SM4E_Z_ZZ__ // sm4e_z_zz_
                                when ('00', '1', '1') => __UNALLOCATED
                                when ('01', _, _) => __UNALLOCATED
                                when ('1x', _, _) => __UNALLOCATED
                        when (_, _, _, '000', '1x', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'000', _, _, '0x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'000', _, _, '11', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '10', _, _, _) => // sve_crypto_binary_const
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, op) of
                                when ('00', '0') => __encoding SM4EKEY_Z_ZZ__ // sm4ekey_z_zz_
                                when ('00', '1') => __encoding RAX1_Z_ZZ__ // rax1_z_zz_
                                when ('01', _) => __UNALLOCATED
                                when ('1x', _) => __UNALLOCATED
                when ('011', _, '0xx0xxxx', _, '0xxxxx', _, _, _) => // sve_fp_fcmla
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field rot 13 +: 2
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case () of
                        when () => __encoding FCMLA_Z_P_ZZZ__ // fcmla_z_p_zzz_
                when ('011', _, '0xx00x1x', _, '1xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00000', _, '100xxx', _, _, _) => // sve_fp_fcadd
                    __field size 22 +: 2
                    __field rot 16 +: 1
                    __field Pg 10 +: 3
                    __field Zm 5 +: 5
                    __field Zdn 0 +: 5
                    case () of
                        when () => __encoding FCADD_Z_P_ZZ__ // fcadd_z_p_zz_
                when ('011', _, '0xx00000', _, '101xxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00000', _, '11xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00001', _, '1xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx0010x', _, '100xxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx0010x', _, '101xxx', _, _, _) => // sve_fp_fcvt2
                    __field opc 22 +: 2
                    __field opc2 16 +: 2
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc, opc2) of
                        when ('x0', '11') => __UNALLOCATED
                        when ('00', '0x') => __UNALLOCATED
                        when ('00', '10') => __encoding FCVTXNT_Z_P_Z_D2S // fcvtxnt_z_p_z_d2s
                        when ('01', _) => __UNALLOCATED
                        when ('10', '00') => __encoding FCVTNT_Z_P_Z_S2H // fcvtnt_z_p_z_s2h
                        when ('10', '01') => __encoding FCVTLT_Z_P_Z_H2S // fcvtlt_z_p_z_h2s
                        when ('10', '10') => __encoding BFCVTNT_Z_P_Z_S2BF // bfcvtnt_z_p_z_s2bf
                        when ('11', '0x') => __UNALLOCATED
                        when ('11', '10') => __encoding FCVTNT_Z_P_Z_D2S // fcvtnt_z_p_z_d2s
                        when ('11', '11') => __encoding FCVTLT_Z_P_Z_S2D // fcvtlt_z_p_z_s2d
                when ('011', _, '0xx0010x', _, '11xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx010xx', _, '100xxx', _, _, _) => // sve_fp_pairwise
                    __field size 22 +: 2
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zm 5 +: 5
                    __field Zdn 0 +: 5
                    case (opc) of
                        when ('000') => __encoding FADDP_Z_P_ZZ__ // faddp_z_p_zz_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding FMAXNMP_Z_P_ZZ__ // fmaxnmp_z_p_zz_
                        when ('101') => __encoding FMINNMP_Z_P_ZZ__ // fminnmp_z_p_zz_
                        when ('110') => __encoding FMAXP_Z_P_ZZ__ // fmaxp_z_p_zz_
                        when ('111') => __encoding FMINP_Z_P_ZZ__ // fminp_z_p_zz_
                when ('011', _, '0xx010xx', _, '101xxx', _, _, _) => // sve_fp_fast_redq
                    __field size 22 +: 2
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Vd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding FADDQV_Z_P_Z__ // faddqv_z_p_z_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding FMAXNMQV_Z_P_Z__ // fmaxnmqv_z_p_z_
                        when ('101') => __encoding FMINNMQV_Z_P_Z__ // fminnmqv_z_p_z_
                        when ('110') => __encoding FMAXQV_Z_P_Z__ // fmaxqv_z_p_z_
                        when ('111') => __encoding FMINQV_Z_P_Z__ // fminqv_z_p_z_
                when ('011', _, '0xx010xx', _, '11xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx011xx', _, '1xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxx', _, '0000xx', _, _, _) => // sve_fp_fma_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field o2 11 +: 1
                    __field op 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (size, o2, op) of
                        when ('0x', '0', '0') => __encoding FMLA_Z_ZZZi_H // fmla_z_zzzi_h
                        when ('0x', '0', '1') => __encoding FMLS_Z_ZZZi_H // fmls_z_zzzi_h
                        when ('0x', '1', '0') => __encoding BFMLA_Z_ZZZi_H // bfmla_z_zzzi_h
                        when ('0x', '1', '1') => __encoding BFMLS_Z_ZZZi_H // bfmls_z_zzzi_h
                        when ('1x', '1', _) => __UNALLOCATED
                        when ('10', '0', '0') => __encoding FMLA_Z_ZZZi_S // fmla_z_zzzi_s
                        when ('10', '0', '1') => __encoding FMLS_Z_ZZZi_S // fmls_z_zzzi_s
                        when ('11', '0', '0') => __encoding FMLA_Z_ZZZi_D // fmla_z_zzzi_d
                        when ('11', '0', '1') => __encoding FMLS_Z_ZZZi_D // fmls_z_zzzi_d
                when ('011', _, '0xx1xxxx', _, '0001xx', _, _, _) => // sve_fp_fcmla_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field rot 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (size) of
                        when ('0x') => __UNALLOCATED
                        when ('10') => __encoding FCMLA_Z_ZZZi_H // fcmla_z_zzzi_h
                        when ('11') => __encoding FCMLA_Z_ZZZi_S // fcmla_z_zzzi_s
                when ('011', _, '0xx1xxxx', _, '0010x0', _, _, _) => // sve_fp_fmul_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field o2 11 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size, o2) of
                        when ('0x', '0') => __encoding FMUL_Z_ZZi_H // fmul_z_zzi_h
                        when ('0x', '1') => __encoding BFMUL_Z_ZZi_H // bfmul_z_zzi_h
                        when ('1x', '1') => __UNALLOCATED
                        when ('10', '0') => __encoding FMUL_Z_ZZi_S // fmul_z_zzi_s
                        when ('11', '0') => __encoding FMUL_Z_ZZi_D // fmul_z_zzi_d
                when ('011', _, '0xx1xxxx', _, '001001', _, _, _) => // sve_fp_clamp
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size) of
                        when (!'00') => __encoding FCLAMP_Z_ZZ__ // fclamp_z_zz_
                        when ('00') => __encoding BFCLAMP_Z_ZZ__ // bfclamp_z_zz_
                when ('011', _, '0xx1xxxx', _, '001011', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxx', _, '01x0xx', _, _, _) =>
                    // sve_fp_fma_w_by_indexed_elem
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 13 +: 1, 12 +: 1, 0 +: 12) of
                        when (_, '0', _, _, _, _, '0', _, _) => // sve_fp_fdot_by_indexed_elem
                            __field op 22 +: 1
                            __field i2 19 +: 2
                            __field Zm 16 +: 3
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op, opc2) of
                                when ('0', 'x1') => __encoding FDOT_Z_ZZ8Z8i__ // fdot_z_zz8z8i_
                                when ('0', '00') => __encoding FDOT_Z_ZZZi__ // fdot_z_zzzi_
                                when ('0', '10') => __UNALLOCATED
                                when ('1', '00') => __encoding BFDOT_Z_ZZZi__ // bfdot_z_zzzi_
                                when ('1', '01') => __encoding FDOT_Z32_ZZ8Z8i__ // fdot_z32_zz8z8i_
                                when ('1', '1x') => __UNALLOCATED
                        when (_, '0', _, _, _, _, '1', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _) => // sve_fp_fma_long_by_indexed_elem
                            __field o2 22 +: 1
                            __field i3h 19 +: 2
                            __field Zm 16 +: 3
                            __field op 13 +: 1
                            __field i3l 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (o2, op, T) of
                                when ('0', '0', '0') => __encoding FMLALB_Z_ZZZi_S // fmlalb_z_zzzi_s
                                when ('0', '0', '1') => __encoding FMLALT_Z_ZZZi_S // fmlalt_z_zzzi_s
                                when ('0', '1', '0') => __encoding FMLSLB_Z_ZZZi_S // fmlslb_z_zzzi_s
                                when ('0', '1', '1') => __encoding FMLSLT_Z_ZZZi_S // fmlslt_z_zzzi_s
                                when ('1', '0', '0') => __encoding BFMLALB_Z_ZZZi__ // bfmlalb_z_zzzi_
                                when ('1', '0', '1') => __encoding BFMLALT_Z_ZZZi__ // bfmlalt_z_zzzi_
                                when ('1', '1', '0') => __encoding BFMLSLB_Z_ZZZi__ // bfmlslb_z_zzzi_
                                when ('1', '1', '1') => __encoding BFMLSLT_Z_ZZZi__ // bfmlslt_z_zzzi_
                when ('011', _, '0xx1xxxx', _, '10x00x', _, _, _) =>
                    // sve_fp_fma_w
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 13 +: 1, 11 +: 2, 0 +: 11) of
                        when (_, '0', _, _, _, _, '0', _, _) => // sve_fp_fdot
                            __field op 22 +: 1
                            __field Zm 16 +: 5
                            __field o2 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op, o2) of
                                when ('0', '0') => __encoding FDOT_Z_ZZZ__ // fdot_z_zzz_
                                when ('0', '1') => __encoding FDOT_Z_ZZ8Z8__ // fdot_z_zz8z8_
                                when ('1', '0') => __encoding BFDOT_Z_ZZZ__ // bfdot_z_zzz_
                                when ('1', '1') => __encoding FDOT_Z32_ZZ8Z8__ // fdot_z32_zz8z8_
                        when (_, '0', _, _, _, _, '1', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _) => // sve_fp_fma_long
                            __field o2 22 +: 1
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (o2, op, T) of
                                when ('0', '0', '0') => __encoding FMLALB_Z_ZZZ__ // fmlalb_z_zzz_
                                when ('0', '0', '1') => __encoding FMLALT_Z_ZZZ__ // fmlalt_z_zzz_
                                when ('0', '1', '0') => __encoding FMLSLB_Z_ZZZ__ // fmlslb_z_zzz_
                                when ('0', '1', '1') => __encoding FMLSLT_Z_ZZZ__ // fmlslt_z_zzz_
                                when ('1', '0', '0') => __encoding BFMLALB_Z_ZZZ__ // bfmlalb_z_zzz_
                                when ('1', '0', '1') => __encoding BFMLALT_Z_ZZZ__ // bfmlalt_z_zzz_
                                when ('1', '1', '0') => __encoding BFMLSLB_Z_ZZZ__ // bfmlslb_z_zzz_
                                when ('1', '1', '1') => __encoding BFMLSLT_Z_ZZZ__ // bfmlslt_z_zzz_
                when ('011', _, '0xx1xxxx', _, '1100xx', _, _, _) => // sve_fp8_fma_long_long_by_indexed_elem
                    __field TT 22 +: 2
                    __field i4h 19 +: 2
                    __field Zm 16 +: 3
                    __field i4l 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (TT) of
                        when ('00') => __encoding FMLALLBB_Z32_Z8Z8Z8i__ // fmlallbb_z32_z8z8z8i_
                        when ('01') => __encoding FMLALLBT_Z32_Z8Z8Z8i__ // fmlallbt_z32_z8z8z8i_
                        when ('10') => __encoding FMLALLTB_Z32_Z8Z8Z8i__ // fmlalltb_z32_z8z8z8i_
                        when ('11') => __encoding FMLALLTT_Z32_Z8Z8Z8i__ // fmlalltt_z32_z8z8z8i_
                when ('011', _, '0xx1xxxx', _, '111000', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxx', _, '111001', _, _, _) => // sve_fp_fmmla
                    __field opc 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (opc) of
                        when ('00') => __UNALLOCATED
                        when ('01') => __encoding BFMMLA_Z_ZZZ__ // bfmmla_z_zzz_
                        when ('10') => __encoding FMMLA_Z_ZZZ_S // fmmla_z_zzz_s
                        when ('11') => __encoding FMMLA_Z_ZZZ_D // fmmla_z_zzz_d
                when ('011', _, '0xx1xxxx', _, '11101x', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '0x11xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '0101xx', _, _, _) => // sve_fp8_fma_long_by_indexed_elem
                    __field T 23 +: 1
                    __field i4h 19 +: 2
                    __field Zm 16 +: 3
                    __field i4l 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (T) of
                        when ('0') => __encoding FMLALB_Z_Z8Z8Z8i__ // fmlalb_z_z8z8z8i_
                        when ('1') => __encoding FMLALT_Z_Z8Z8Z8i__ // fmlalt_z_z8z8z8i_
                when ('011', _, '0x01xxxx', _, '10xx10', _, _, _) =>
                    // sve_fp8_fma_w
                    case (24 +: 8, 23 +: 1, 21 +: 2, 16 +: 5, 14 +: 2, 13 +: 1, 12 +: 1, 10 +: 2, 0 +: 10) of
                        when (_, '0', _, _, _, _, _, _, _) => // sve_fp8_fma_long_long
                            __field Zm 16 +: 5
                            __field TT 12 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (TT) of
                                when ('00') => __encoding FMLALLBB_Z32_Z8Z8Z8__ // fmlallbb_z32_z8z8z8_
                                when ('01') => __encoding FMLALLBT_Z32_Z8Z8Z8__ // fmlallbt_z32_z8z8z8_
                                when ('10') => __encoding FMLALLTB_Z32_Z8Z8Z8__ // fmlalltb_z32_z8z8z8_
                                when ('11') => __encoding FMLALLTT_Z32_Z8Z8Z8__ // fmlalltt_z32_z8z8z8_
                        when (_, '1', _, _, _, '0', _, _, _) => // sve_fp8_fma_long
                            __field Zm 16 +: 5
                            __field T 12 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (T) of
                                when ('0') => __encoding FMLALB_Z_Z8Z8Z8__ // fmlalb_z_z8z8z8_
                                when ('1') => __encoding FMLALT_Z_Z8Z8Z8__ // fmlalt_z_z8z8z8_
                        when (_, '1', _, _, _, '1', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '10xx11', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '10x10x', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '11x1xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x11xxxx', _, '0011xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x11xxxx', _, '01x1xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x11xxxx', _, '1xx1xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x11xxxx', _, '10x01x', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx0xxxx', _, 'x1xxxx', _, _, _) => // sve_fp_3op_p_pd
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field op 15 +: 1
                    __field o2 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field o3 4 +: 1
                    __field Pd 0 +: 4
                    case (op, o2, o3) of
                        when ('0', '0', '0') => __encoding FCMGE_P_P_ZZ__ // fcmge_p_p_zz_
                        when ('0', '0', '1') => __encoding FCMGT_P_P_ZZ__ // fcmgt_p_p_zz_
                        when ('0', '1', '0') => __encoding FCMEQ_P_P_ZZ__ // fcmeq_p_p_zz_
                        when ('0', '1', '1') => __encoding FCMNE_P_P_ZZ__ // fcmne_p_p_zz_
                        when ('1', '0', '0') => __encoding FCMUO_P_P_ZZ__ // fcmuo_p_p_zz_
                        when ('1', '0', '1') => __encoding FACGE_P_P_ZZ__ // facge_p_p_zz_
                        when ('1', '1', '0') => __UNALLOCATED
                        when ('1', '1', '1') => __encoding FACGT_P_P_ZZ__ // facgt_p_p_zz_
                when ('011', _, '1xx0xxxx', _, '000xxx', _, _, _) => // sve_fp_3op_u_zd
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size, opc) of
                        when (_, '011') => __encoding FTSMUL_Z_ZZ__ // ftsmul_z_zz_
                        when (_, '10x') => __UNALLOCATED
                        when (_, '110') => __encoding FRECPS_Z_ZZ__ // frecps_z_zz_
                        when (_, '111') => __encoding FRSQRTS_Z_ZZ__ // frsqrts_z_zz_
                        when (!'00', '000') => __encoding FADD_Z_ZZ__ // fadd_z_zz_
                        when (!'00', '001') => __encoding FSUB_Z_ZZ__ // fsub_z_zz_
                        when (!'00', '010') => __encoding FMUL_Z_ZZ__ // fmul_z_zz_
                        when ('00', '000') => __encoding BFADD_Z_ZZ__ // bfadd_z_zz_
                        when ('00', '001') => __encoding BFSUB_Z_ZZ__ // bfsub_z_zz_
                        when ('00', '010') => __encoding BFMUL_Z_ZZ__ // bfmul_z_zz_
                when ('011', _, '1xx0xxxx', _, '100xxx', _, _, _) =>
                    // sve_fp_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 10 +: 3, 6 +: 4, 0 +: 6) of
                        when (_, _, _, '0x', _, _, _, _, _) => // sve_fp_2op_p_zds
                            __field size 22 +: 2
                            __field opc 16 +: 4
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, opc) of
                                when (_, '0011') => __encoding FSUBR_Z_P_ZZ__ // fsubr_z_p_zz_
                                when (_, '1000') => __encoding FABD_Z_P_ZZ__ // fabd_z_p_zz_
                                when (_, '1001') => __encoding FSCALE_Z_P_ZZ__ // fscale_z_p_zz_
                                when (_, '1010') => __encoding FMULX_Z_P_ZZ__ // fmulx_z_p_zz_
                                when (_, '1011') => __UNALLOCATED
                                when (_, '1100') => __encoding FDIVR_Z_P_ZZ__ // fdivr_z_p_zz_
                                when (_, '1101') => __encoding FDIV_Z_P_ZZ__ // fdiv_z_p_zz_
                                when (_, '1110') => __encoding FAMAX_Z_P_ZZ__ // famax_z_p_zz_
                                when (_, '1111') => __encoding FAMIN_Z_P_ZZ__ // famin_z_p_zz_
                                when (!'00', '0000') => __encoding FADD_Z_P_ZZ__ // fadd_z_p_zz_
                                when (!'00', '0001') => __encoding FSUB_Z_P_ZZ__ // fsub_z_p_zz_
                                when (!'00', '0010') => __encoding FMUL_Z_P_ZZ__ // fmul_z_p_zz_
                                when (!'00', '0100') => __encoding FMAXNM_Z_P_ZZ__ // fmaxnm_z_p_zz_
                                when (!'00', '0101') => __encoding FMINNM_Z_P_ZZ__ // fminnm_z_p_zz_
                                when (!'00', '0110') => __encoding FMAX_Z_P_ZZ__ // fmax_z_p_zz_
                                when (!'00', '0111') => __encoding FMIN_Z_P_ZZ__ // fmin_z_p_zz_
                                when ('00', '0000') => __encoding BFADD_Z_P_ZZ__ // bfadd_z_p_zz_
                                when ('00', '0001') => __encoding BFSUB_Z_P_ZZ__ // bfsub_z_p_zz_
                                when ('00', '0010') => __encoding BFMUL_Z_P_ZZ__ // bfmul_z_p_zz_
                                when ('00', '0100') => __encoding BFMAXNM_Z_P_ZZ__ // bfmaxnm_z_p_zz_
                                when ('00', '0101') => __encoding BFMINNM_Z_P_ZZ__ // bfminnm_z_p_zz_
                                when ('00', '0110') => __encoding BFMAX_Z_P_ZZ__ // bfmax_z_p_zz_
                                when ('00', '0111') => __encoding BFMIN_Z_P_ZZ__ // bfmin_z_p_zz_
                        when (_, _, _, '10', _, _, '000', _, _) => // sve_fp_ftmad
                            __field size 22 +: 2
                            __field imm3 16 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding FTMAD_Z_ZZI__ // ftmad_z_zzi_
                        when (_, _, _, '10', _, _, !'000', _, _) => __UNPREDICTABLE
                        when (_, _, _, '11', _, _, _, '0000', _) => // sve_fp_2op_i_p_zds
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field i1 5 +: 1
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding FADD_Z_P_ZS__ // fadd_z_p_zs_
                                when ('001') => __encoding FSUB_Z_P_ZS__ // fsub_z_p_zs_
                                when ('010') => __encoding FMUL_Z_P_ZS__ // fmul_z_p_zs_
                                when ('011') => __encoding FSUBR_Z_P_ZS__ // fsubr_z_p_zs_
                                when ('100') => __encoding FMAXNM_Z_P_ZS__ // fmaxnm_z_p_zs_
                                when ('101') => __encoding FMINNM_Z_P_ZS__ // fminnm_z_p_zs_
                                when ('110') => __encoding FMAX_Z_P_ZS__ // fmax_z_p_zs_
                                when ('111') => __encoding FMIN_Z_P_ZS__ // fmin_z_p_zs_
                        when (_, _, _, '11', _, _, _, !'0000', _) => __UNPREDICTABLE
                when ('011', _, '1xx0xxxx', _, '101xxx', _, _, _) =>
                    // sve_fp_unary
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '00x', _, _, _) => // sve_fp_2op_p_zd_a
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding FRINTN_Z_P_Z__ // frintn_z_p_z_
                                when ('001') => __encoding FRINTP_Z_P_Z__ // frintp_z_p_z_
                                when ('010') => __encoding FRINTM_Z_P_Z__ // frintm_z_p_z_
                                when ('011') => __encoding FRINTZ_Z_P_Z__ // frintz_z_p_z_
                                when ('100') => __encoding FRINTA_Z_P_Z__ // frinta_z_p_z_
                                when ('101') => __UNALLOCATED
                                when ('110') => __encoding FRINTX_Z_P_Z__ // frintx_z_p_z_
                                when ('111') => __encoding FRINTI_Z_P_Z__ // frinti_z_p_z_
                        when (_, _, _, '010', _, _, _) => // sve_fp_2op_p_zd_b_0
                            __field opc 22 +: 2
                            __field opc2 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('x0', '11') => __UNALLOCATED
                                when ('00', '0x') => __UNALLOCATED
                                when ('00', '10') => __encoding FCVTX_Z_P_Z_D2S // fcvtx_z_p_z_d2s
                                when ('01', _) => __UNALLOCATED
                                when ('10', '00') => __encoding FCVT_Z_P_Z_S2H // fcvt_z_p_z_s2h
                                when ('10', '01') => __encoding FCVT_Z_P_Z_H2S // fcvt_z_p_z_h2s
                                when ('10', '10') => __encoding BFCVT_Z_P_Z_S2BF // bfcvt_z_p_z_s2bf
                                when ('11', '00') => __encoding FCVT_Z_P_Z_D2H // fcvt_z_p_z_d2h
                                when ('11', '01') => __encoding FCVT_Z_P_Z_H2D // fcvt_z_p_z_h2d
                                when ('11', '10') => __encoding FCVT_Z_P_Z_D2S // fcvt_z_p_z_d2s
                                when ('11', '11') => __encoding FCVT_Z_P_Z_S2D // fcvt_z_p_z_s2d
                        when (_, _, _, '011', _, _, _) => // sve_fp_2op_p_zd_b_1
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding FRECPX_Z_P_Z__ // frecpx_z_p_z_
                                when ('01') => __encoding FSQRT_Z_P_Z__ // fsqrt_z_p_z_
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '10x', _, _, _) => // sve_fp_2op_p_zd_c
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2, U) of
                                when ('00', _, _) => __UNALLOCATED
                                when ('01', '00', _) => __UNALLOCATED
                                when ('01', '01', '0') => __encoding SCVTF_Z_P_Z_H2FP16 // scvtf_z_p_z_h2fp16
                                when ('01', '01', '1') => __encoding UCVTF_Z_P_Z_H2FP16 // ucvtf_z_p_z_h2fp16
                                when ('01', '10', '0') => __encoding SCVTF_Z_P_Z_W2FP16 // scvtf_z_p_z_w2fp16
                                when ('01', '10', '1') => __encoding UCVTF_Z_P_Z_W2FP16 // ucvtf_z_p_z_w2fp16
                                when ('01', '11', '0') => __encoding SCVTF_Z_P_Z_X2FP16 // scvtf_z_p_z_x2fp16
                                when ('01', '11', '1') => __encoding UCVTF_Z_P_Z_X2FP16 // ucvtf_z_p_z_x2fp16
                                when ('10', '0x', _) => __UNALLOCATED
                                when ('10', '10', '0') => __encoding SCVTF_Z_P_Z_W2S // scvtf_z_p_z_w2s
                                when ('10', '10', '1') => __encoding UCVTF_Z_P_Z_W2S // ucvtf_z_p_z_w2s
                                when ('10', '11', _) => __UNALLOCATED
                                when ('11', '00', '0') => __encoding SCVTF_Z_P_Z_W2D // scvtf_z_p_z_w2d
                                when ('11', '00', '1') => __encoding UCVTF_Z_P_Z_W2D // ucvtf_z_p_z_w2d
                                when ('11', '01', _) => __UNALLOCATED
                                when ('11', '10', '0') => __encoding SCVTF_Z_P_Z_X2S // scvtf_z_p_z_x2s
                                when ('11', '10', '1') => __encoding UCVTF_Z_P_Z_X2S // ucvtf_z_p_z_x2s
                                when ('11', '11', '0') => __encoding SCVTF_Z_P_Z_X2D // scvtf_z_p_z_x2d
                                when ('11', '11', '1') => __encoding UCVTF_Z_P_Z_X2D // ucvtf_z_p_z_x2d
                        when (_, _, _, '11x', _, _, _) => // sve_fp_2op_p_zd_d
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2, U) of
                                when ('00', _, '0') => __encoding FLOGB_Z_P_Z__ // flogb_z_p_z_
                                when ('00', _, '1') => __UNALLOCATED
                                when ('01', '00', _) => __UNALLOCATED
                                when ('01', '01', '0') => __encoding FCVTZS_Z_P_Z_FP162H // fcvtzs_z_p_z_fp162h
                                when ('01', '01', '1') => __encoding FCVTZU_Z_P_Z_FP162H // fcvtzu_z_p_z_fp162h
                                when ('01', '10', '0') => __encoding FCVTZS_Z_P_Z_FP162W // fcvtzs_z_p_z_fp162w
                                when ('01', '10', '1') => __encoding FCVTZU_Z_P_Z_FP162W // fcvtzu_z_p_z_fp162w
                                when ('01', '11', '0') => __encoding FCVTZS_Z_P_Z_FP162X // fcvtzs_z_p_z_fp162x
                                when ('01', '11', '1') => __encoding FCVTZU_Z_P_Z_FP162X // fcvtzu_z_p_z_fp162x
                                when ('10', '0x', _) => __UNALLOCATED
                                when ('10', '10', '0') => __encoding FCVTZS_Z_P_Z_S2W // fcvtzs_z_p_z_s2w
                                when ('10', '10', '1') => __encoding FCVTZU_Z_P_Z_S2W // fcvtzu_z_p_z_s2w
                                when ('10', '11', _) => __UNALLOCATED
                                when ('11', '00', '0') => __encoding FCVTZS_Z_P_Z_D2W // fcvtzs_z_p_z_d2w
                                when ('11', '00', '1') => __encoding FCVTZU_Z_P_Z_D2W // fcvtzu_z_p_z_d2w
                                when ('11', '01', _) => __UNALLOCATED
                                when ('11', '10', '0') => __encoding FCVTZS_Z_P_Z_S2X // fcvtzs_z_p_z_s2x
                                when ('11', '10', '1') => __encoding FCVTZU_Z_P_Z_S2X // fcvtzu_z_p_z_s2x
                                when ('11', '11', '0') => __encoding FCVTZS_Z_P_Z_D2X // fcvtzs_z_p_z_d2x
                                when ('11', '11', '1') => __encoding FCVTZU_Z_P_Z_D2X // fcvtzu_z_p_z_d2x
                when ('011', _, '1xx000xx', _, '001xxx', _, _, _) => // sve_fp_fast_red
                    __field size 22 +: 2
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Vd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding FADDV_V_P_Z__ // faddv_v_p_z_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding FMAXNMV_V_P_Z__ // fmaxnmv_v_p_z_
                        when ('101') => __encoding FMINNMV_V_P_Z__ // fminnmv_v_p_z_
                        when ('110') => __encoding FMAXV_V_P_Z__ // fmaxv_v_p_z_
                        when ('111') => __encoding FMINV_V_P_Z__ // fminv_v_p_z_
                when ('011', _, '1xx001xx', _, '0010xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx001xx', _, '0011xx', _, _, _) =>
                    // sve_fp_unary_unpred
                    case (24 +: 8, 22 +: 2, 19 +: 3, 16 +: 3, 12 +: 4, 10 +: 2, 6 +: 4, 5 +: 1, 0 +: 5) of
                        when (_, '00', _, '00x', _, _, _, _, _) => // sve_fp8_fcvt_wide
                            __field L 16 +: 1
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (L, opc) of
                                when ('0', '00') => __encoding F1CVT_Z_Z8_B2H // f1cvt_z_z8_b2h
                                when ('0', '01') => __encoding F2CVT_Z_Z8_B2H // f2cvt_z_z8_b2h
                                when ('0', '10') => __encoding BF1CVT_Z_Z8_B2BF // bf1cvt_z_z8_b2bf
                                when ('0', '11') => __encoding BF2CVT_Z_Z8_B2BF // bf2cvt_z_z8_b2bf
                                when ('1', '00') => __encoding F1CVTLT_Z_Z8_B2H // f1cvtlt_z_z8_b2h
                                when ('1', '01') => __encoding F2CVTLT_Z_Z8_B2H // f2cvtlt_z_z8_b2h
                                when ('1', '10') => __encoding BF1CVTLT_Z_Z8_B2BF // bf1cvtlt_z_z8_b2bf
                                when ('1', '11') => __encoding BF2CVTLT_Z_Z8_B2BF // bf2cvtlt_z_z8_b2bf
                        when (_, '00', _, '010', _, _, _, '0', _) => // sve_fp8_fcvt_narrow
                            __field opc 10 +: 2
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding FCVTN_Z8_MZ2_H2B // fcvtn_z8_mz2_h2b
                                when ('01') => __encoding FCVTNB_Z8_MZ2_S2B // fcvtnb_z8_mz2_s2b
                                when ('10') => __encoding BFCVTN_Z8_MZ2_BF2B // bfcvtn_z8_mz2_bf2b
                                when ('11') => __encoding FCVTNT_Z8_MZ2_S2B // fcvtnt_z8_mz2_s2b
                        when (_, '00', _, '010', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '011', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '0xx', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '11x', _, '00', _, _, _) => // sve_fp_2op_u_zd
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding FRECPE_Z_Z__ // frecpe_z_z_
                                when ('1') => __encoding FRSQRTE_Z_Z__ // frsqrte_z_z_
                        when (_, _, _, '11x', _, !'00', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx010xx', _, '001xxx', _, _, _) =>
                    // sve_fp_cmpzero
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '0', _, _, _) => // sve_fp_2op_p_pd
                            __field size 22 +: 2
                            __field eq 17 +: 1
                            __field lt 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (eq, lt, ne) of
                                when ('0', '0', '0') => __encoding FCMGE_P_P_Z0__ // fcmge_p_p_z0_
                                when ('0', '0', '1') => __encoding FCMGT_P_P_Z0__ // fcmgt_p_p_z0_
                                when ('0', '1', '0') => __encoding FCMLT_P_P_Z0__ // fcmlt_p_p_z0_
                                when ('0', '1', '1') => __encoding FCMLE_P_P_Z0__ // fcmle_p_p_z0_
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding FCMEQ_P_P_Z0__ // fcmeq_p_p_z0_
                                when ('1', '1', '0') => __encoding FCMNE_P_P_Z0__ // fcmne_p_p_z0_
                        when (_, _, _, '1', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx011xx', _, '001xxx', _, _, _) =>
                    // sve_fp_slowreduce
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 13 +: 3, 0 +: 13) of
                        when (_, _, _, '0', _, _, _) => // sve_fp_2op_p_vd
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Vdn 0 +: 5
                            case (opc) of
                                when ('00') => __encoding FADDA_V_P_Z__ // fadda_v_p_z_
                                when ('01') => __UNALLOCATED
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '1', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx1xxxx', _, _, _, _, _) =>
                    // sve_fp_fma
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 0 +: 15) of
                        when (_, _, _, _, '0', _) => // sve_fp_3op_p_zds_a
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, opc) of
                                when (_, '10') => __encoding FNMLA_Z_P_ZZZ__ // fnmla_z_p_zzz_
                                when (_, '11') => __encoding FNMLS_Z_P_ZZZ__ // fnmls_z_p_zzz_
                                when (!'00', '00') => __encoding FMLA_Z_P_ZZZ__ // fmla_z_p_zzz_
                                when (!'00', '01') => __encoding FMLS_Z_P_ZZZ__ // fmls_z_p_zzz_
                                when ('00', '00') => __encoding BFMLA_Z_P_ZZZ__ // bfmla_z_p_zzz_
                                when ('00', '01') => __encoding BFMLS_Z_P_ZZZ__ // bfmls_z_p_zzz_
                        when (_, _, _, _, '1', _) => // sve_fp_3op_p_zds_b
                            __field size 22 +: 2
                            __field Za 16 +: 5
                            __field opc 13 +: 2
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('00') => __encoding FMAD_Z_P_ZZZ__ // fmad_z_p_zzz_
                                when ('01') => __encoding FMSB_Z_P_ZZZ__ // fmsb_z_p_zzz_
                                when ('10') => __encoding FNMAD_Z_P_ZZZ__ // fnmad_z_p_zzz_
                                when ('11') => __encoding FNMSB_Z_P_ZZZ__ // fnmsb_z_p_zzz_
                when ('100', _, _, _, _, _, _, _) =>
                    // sve_mem32
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '00', 'x1', _, '0xx', _, '0', _) => // sve_mem_32b_prfm_sv
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BZ_S_x32_scaled // prfb_i_p_bz_s_x32_scaled
                                when ('01') => __encoding PRFH_I_P_BZ_S_x32_scaled // prfh_i_p_bz_s_x32_scaled
                                when ('10') => __encoding PRFW_I_P_BZ_S_x32_scaled // prfw_i_p_bz_s_x32_scaled
                                when ('11') => __encoding PRFD_I_P_BZ_S_x32_scaled // prfd_i_p_bz_s_x32_scaled
                        when (_, '00', 'x1', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, '01', 'x1', _, '0xx', _, _, _) => // sve_mem_32b_gld_sv_a
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (U, ff) of
                                when ('0', '0') => __encoding LD1SH_Z_P_BZ_S_x32_scaled // ld1sh_z_p_bz_s_x32_scaled
                                when ('0', '1') => __encoding LDFF1SH_Z_P_BZ_S_x32_scaled // ldff1sh_z_p_bz_s_x32_scaled
                                when ('1', '0') => __encoding LD1H_Z_P_BZ_S_x32_scaled // ld1h_z_p_bz_s_x32_scaled
                                when ('1', '1') => __encoding LDFF1H_Z_P_BZ_S_x32_scaled // ldff1h_z_p_bz_s_x32_scaled
                        when (_, '10', 'x1', _, '0xx', _, _, _) => // sve_mem_32b_gld_sv_b
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (U, ff) of
                                when ('0', _) => __UNALLOCATED
                                when ('1', '0') => __encoding LD1W_Z_P_BZ_S_x32_scaled // ld1w_z_p_bz_s_x32_scaled
                                when ('1', '1') => __encoding LDFF1W_Z_P_BZ_S_x32_scaled // ldff1w_z_p_bz_s_x32_scaled
                        when (_, '11', '0x', _, '000', _, '0', _) => // sve_mem_32b_pfill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Pt 0 +: 4
                            case () of
                                when () => __encoding LDR_P_BI__ // ldr_p_bi_
                        when (_, '11', '0x', _, '000', _, '1', _) => __UNPREDICTABLE
                        when (_, '11', '0x', _, '010', _, _, _) => // sve_mem_32b_fill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding LDR_Z_BI__ // ldr_z_bi_
                        when (_, '11', '0x', _, '0x1', _, _, _) => __UNPREDICTABLE
                        when (_, '11', '1x', _, '0xx', _, '0', _) => // sve_mem_prfm_si
                            __field imm6 16 +: 6
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BI_S // prfb_i_p_bi_s
                                when ('01') => __encoding PRFH_I_P_BI_S // prfh_i_p_bi_s
                                when ('10') => __encoding PRFW_I_P_BI_S // prfw_i_p_bi_s
                                when ('11') => __encoding PRFD_I_P_BI_S // prfd_i_p_bi_s
                        when (_, '11', '1x', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, !'11', 'x0', _, '0xx', _, _, _) => // sve_mem_32b_gld_vs
                            __field opc 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_BZ_S_x32_unscaled // ld1sb_z_p_bz_s_x32_unscaled
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_BZ_S_x32_unscaled // ldff1sb_z_p_bz_s_x32_unscaled
                                when ('00', '1', '0') => __encoding LD1B_Z_P_BZ_S_x32_unscaled // ld1b_z_p_bz_s_x32_unscaled
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_BZ_S_x32_unscaled // ldff1b_z_p_bz_s_x32_unscaled
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_S_x32_unscaled // ld1sh_z_p_bz_s_x32_unscaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_S_x32_unscaled // ldff1sh_z_p_bz_s_x32_unscaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_S_x32_unscaled // ld1h_z_p_bz_s_x32_unscaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_S_x32_unscaled // ldff1h_z_p_bz_s_x32_unscaled
                                when ('10', '0', _) => __UNALLOCATED
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_S_x32_unscaled // ld1w_z_p_bz_s_x32_unscaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_S_x32_unscaled // ldff1w_z_p_bz_s_x32_unscaled
                        when (_, _, '00', _, '10x', _, _, _) => // sve_mem_32b_gldnt_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field U 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U) of
                                when ('00', '0') => __encoding LDNT1SB_Z_P_AR_S_x32_unscaled // ldnt1sb_z_p_ar_s_x32_unscaled
                                when ('00', '1') => __encoding LDNT1B_Z_P_AR_S_x32_unscaled // ldnt1b_z_p_ar_s_x32_unscaled
                                when ('01', '0') => __encoding LDNT1SH_Z_P_AR_S_x32_unscaled // ldnt1sh_z_p_ar_s_x32_unscaled
                                when ('01', '1') => __encoding LDNT1H_Z_P_AR_S_x32_unscaled // ldnt1h_z_p_ar_s_x32_unscaled
                                when ('10', '0') => __UNALLOCATED
                                when ('10', '1') => __encoding LDNT1W_Z_P_AR_S_x32_unscaled // ldnt1w_z_p_ar_s_x32_unscaled
                                when ('11', _) => __UNALLOCATED
                        when (_, _, '00', _, '110', _, '0', _) => // sve_mem_prfm_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BR_S // prfb_i_p_br_s
                                when ('01') => __encoding PRFH_I_P_BR_S // prfh_i_p_br_s
                                when ('10') => __encoding PRFW_I_P_BR_S // prfw_i_p_br_s
                                when ('11') => __encoding PRFD_I_P_BR_S // prfd_i_p_br_s
                        when (_, _, '00', _, '111', _, '0', _) => // sve_mem_32b_prfm_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_AI_S // prfb_i_p_ai_s
                                when ('01') => __encoding PRFH_I_P_AI_S // prfh_i_p_ai_s
                                when ('10') => __encoding PRFW_I_P_AI_S // prfw_i_p_ai_s
                                when ('11') => __encoding PRFD_I_P_AI_S // prfd_i_p_ai_s
                        when (_, _, '00', _, '11x', _, '1', _) => __UNPREDICTABLE
                        when (_, _, '01', _, '1xx', _, _, _) => // sve_mem_32b_gld_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_AI_S // ld1sb_z_p_ai_s
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_AI_S // ldff1sb_z_p_ai_s
                                when ('00', '1', '0') => __encoding LD1B_Z_P_AI_S // ld1b_z_p_ai_s
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_AI_S // ldff1b_z_p_ai_s
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_AI_S // ld1sh_z_p_ai_s
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_AI_S // ldff1sh_z_p_ai_s
                                when ('01', '1', '0') => __encoding LD1H_Z_P_AI_S // ld1h_z_p_ai_s
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_AI_S // ldff1h_z_p_ai_s
                                when ('10', '0', _) => __UNALLOCATED
                                when ('10', '1', '0') => __encoding LD1W_Z_P_AI_S // ld1w_z_p_ai_s
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_AI_S // ldff1w_z_p_ai_s
                                when ('11', _, _) => __UNALLOCATED
                        when (_, _, '1x', _, '1xx', _, _, _) => // sve_mem_ld_dup
                            __field dtypeh 23 +: 2
                            __field imm6 16 +: 6
                            __field dtypel 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtypeh, dtypel) of
                                when ('00', '00') => __encoding LD1RB_Z_P_BI_U8 // ld1rb_z_p_bi_u8
                                when ('00', '01') => __encoding LD1RB_Z_P_BI_U16 // ld1rb_z_p_bi_u16
                                when ('00', '10') => __encoding LD1RB_Z_P_BI_U32 // ld1rb_z_p_bi_u32
                                when ('00', '11') => __encoding LD1RB_Z_P_BI_U64 // ld1rb_z_p_bi_u64
                                when ('01', '00') => __encoding LD1RSW_Z_P_BI_S64 // ld1rsw_z_p_bi_s64
                                when ('01', '01') => __encoding LD1RH_Z_P_BI_U16 // ld1rh_z_p_bi_u16
                                when ('01', '10') => __encoding LD1RH_Z_P_BI_U32 // ld1rh_z_p_bi_u32
                                when ('01', '11') => __encoding LD1RH_Z_P_BI_U64 // ld1rh_z_p_bi_u64
                                when ('10', '00') => __encoding LD1RSH_Z_P_BI_S64 // ld1rsh_z_p_bi_s64
                                when ('10', '01') => __encoding LD1RSH_Z_P_BI_S32 // ld1rsh_z_p_bi_s32
                                when ('10', '10') => __encoding LD1RW_Z_P_BI_U32 // ld1rw_z_p_bi_u32
                                when ('10', '11') => __encoding LD1RW_Z_P_BI_U64 // ld1rw_z_p_bi_u64
                                when ('11', '00') => __encoding LD1RSB_Z_P_BI_S64 // ld1rsb_z_p_bi_s64
                                when ('11', '01') => __encoding LD1RSB_Z_P_BI_S32 // ld1rsb_z_p_bi_s32
                                when ('11', '10') => __encoding LD1RSB_Z_P_BI_S16 // ld1rsb_z_p_bi_s16
                                when ('11', '11') => __encoding LD1RD_Z_P_BI_U64 // ld1rd_z_p_bi_u64
                when ('101', _, _, _, _, _, _, _) =>
                    // sve_memcld
                    case (25 +: 7, 23 +: 2, 21 +: 2, 20 +: 1, 16 +: 4, 13 +: 3, 0 +: 13) of
                        when (_, _, '00', '0', _, '111', _) => // sve_mem_cldnt_si
                            __field msz 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding LDNT1B_Z_P_BI_Contiguous // ldnt1b_z_p_bi_contiguous
                                when ('01') => __encoding LDNT1H_Z_P_BI_Contiguous // ldnt1h_z_p_bi_contiguous
                                when ('10') => __encoding LDNT1W_Z_P_BI_Contiguous // ldnt1w_z_p_bi_contiguous
                                when ('11') => __encoding LDNT1D_Z_P_BI_Contiguous // ldnt1d_z_p_bi_contiguous
                        when (_, _, '00', '1', _, '001', _) => // sve_mem_cld_si_q
                            __field dtype 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding LD1W_Z_P_BI_U128 // ld1w_z_p_bi_u128
                                when ('11') => __encoding LD1D_Z_P_BI_U128 // ld1d_z_p_bi_u128
                        when (_, _, '00', '1', _, '111', _) => // sve_mem_eldq_si
                            __field num 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding LD2Q_Z_P_BI_Contiguous // ld2q_z_p_bi_contiguous
                                when ('10') => __encoding LD3Q_Z_P_BI_Contiguous // ld3q_z_p_bi_contiguous
                                when ('11') => __encoding LD4Q_Z_P_BI_Contiguous // ld4q_z_p_bi_contiguous
                        when (_, _, '00', _, _, '100', _) => // sve_mem_cld_ss_q
                            __field dtype 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding LD1W_Z_P_BR_U128 // ld1w_z_p_br_u128
                                when ('11') => __encoding LD1D_Z_P_BR_U128 // ld1d_z_p_br_u128
                        when (_, _, '00', _, _, '110', _) => // sve_mem_cldnt_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding LDNT1B_Z_P_BR_Contiguous // ldnt1b_z_p_br_contiguous
                                when ('01') => __encoding LDNT1H_Z_P_BR_Contiguous // ldnt1h_z_p_br_contiguous
                                when ('10') => __encoding LDNT1W_Z_P_BR_Contiguous // ldnt1w_z_p_br_contiguous
                                when ('11') => __encoding LDNT1D_Z_P_BR_Contiguous // ldnt1d_z_p_br_contiguous
                        when (_, _, '01', _, _, '100', _) => // sve_mem_eldq_ss
                            __field num 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding LD2Q_Z_P_BR_Contiguous // ld2q_z_p_br_contiguous
                                when ('10') => __encoding LD3Q_Z_P_BR_Contiguous // ld3q_z_p_br_contiguous
                                when ('11') => __encoding LD4Q_Z_P_BR_Contiguous // ld4q_z_p_br_contiguous
                        when (_, _, '1x', _, _, '100', _) => __UNPREDICTABLE
                        when (_, _, !'00', '0', _, '111', _) => // sve_mem_eld_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding LD2B_Z_P_BI_Contiguous // ld2b_z_p_bi_contiguous
                                when ('00', '10') => __encoding LD3B_Z_P_BI_Contiguous // ld3b_z_p_bi_contiguous
                                when ('00', '11') => __encoding LD4B_Z_P_BI_Contiguous // ld4b_z_p_bi_contiguous
                                when ('01', '01') => __encoding LD2H_Z_P_BI_Contiguous // ld2h_z_p_bi_contiguous
                                when ('01', '10') => __encoding LD3H_Z_P_BI_Contiguous // ld3h_z_p_bi_contiguous
                                when ('01', '11') => __encoding LD4H_Z_P_BI_Contiguous // ld4h_z_p_bi_contiguous
                                when ('10', '01') => __encoding LD2W_Z_P_BI_Contiguous // ld2w_z_p_bi_contiguous
                                when ('10', '10') => __encoding LD3W_Z_P_BI_Contiguous // ld3w_z_p_bi_contiguous
                                when ('10', '11') => __encoding LD4W_Z_P_BI_Contiguous // ld4w_z_p_bi_contiguous
                                when ('11', '01') => __encoding LD2D_Z_P_BI_Contiguous // ld2d_z_p_bi_contiguous
                                when ('11', '10') => __encoding LD3D_Z_P_BI_Contiguous // ld3d_z_p_bi_contiguous
                                when ('11', '11') => __encoding LD4D_Z_P_BI_Contiguous // ld4d_z_p_bi_contiguous
                        when (_, _, !'00', '1', _, '001', _) => __UNPREDICTABLE
                        when (_, _, !'00', '1', _, '111', _) => __UNPREDICTABLE
                        when (_, _, !'00', _, _, '110', _) => // sve_mem_eld_ss
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding LD2B_Z_P_BR_Contiguous // ld2b_z_p_br_contiguous
                                when ('00', '10') => __encoding LD3B_Z_P_BR_Contiguous // ld3b_z_p_br_contiguous
                                when ('00', '11') => __encoding LD4B_Z_P_BR_Contiguous // ld4b_z_p_br_contiguous
                                when ('01', '01') => __encoding LD2H_Z_P_BR_Contiguous // ld2h_z_p_br_contiguous
                                when ('01', '10') => __encoding LD3H_Z_P_BR_Contiguous // ld3h_z_p_br_contiguous
                                when ('01', '11') => __encoding LD4H_Z_P_BR_Contiguous // ld4h_z_p_br_contiguous
                                when ('10', '01') => __encoding LD2W_Z_P_BR_Contiguous // ld2w_z_p_br_contiguous
                                when ('10', '10') => __encoding LD3W_Z_P_BR_Contiguous // ld3w_z_p_br_contiguous
                                when ('10', '11') => __encoding LD4W_Z_P_BR_Contiguous // ld4w_z_p_br_contiguous
                                when ('11', '01') => __encoding LD2D_Z_P_BR_Contiguous // ld2d_z_p_br_contiguous
                                when ('11', '10') => __encoding LD3D_Z_P_BR_Contiguous // ld3d_z_p_br_contiguous
                                when ('11', '11') => __encoding LD4D_Z_P_BR_Contiguous // ld4d_z_p_br_contiguous
                        when (_, _, _, '0', _, '001', _) => // sve_mem_ldqr_si
                            __field msz 23 +: 2
                            __field ssz 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, ssz) of
                                when (_, '1x') => __UNALLOCATED
                                when ('00', '00') => __encoding LD1RQB_Z_P_BI_U8 // ld1rqb_z_p_bi_u8
                                when ('00', '01') => __encoding LD1ROB_Z_P_BI_U8 // ld1rob_z_p_bi_u8
                                when ('01', '00') => __encoding LD1RQH_Z_P_BI_U16 // ld1rqh_z_p_bi_u16
                                when ('01', '01') => __encoding LD1ROH_Z_P_BI_U16 // ld1roh_z_p_bi_u16
                                when ('10', '00') => __encoding LD1RQW_Z_P_BI_U32 // ld1rqw_z_p_bi_u32
                                when ('10', '01') => __encoding LD1ROW_Z_P_BI_U32 // ld1row_z_p_bi_u32
                                when ('11', '00') => __encoding LD1RQD_Z_P_BI_U64 // ld1rqd_z_p_bi_u64
                                when ('11', '01') => __encoding LD1ROD_Z_P_BI_U64 // ld1rod_z_p_bi_u64
                        when (_, _, _, '0', _, '101', _) => // sve_mem_cld_si
                            __field dtype 21 +: 4
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding LD1B_Z_P_BI_U8 // ld1b_z_p_bi_u8
                                when ('0001') => __encoding LD1B_Z_P_BI_U16 // ld1b_z_p_bi_u16
                                when ('0010') => __encoding LD1B_Z_P_BI_U32 // ld1b_z_p_bi_u32
                                when ('0011') => __encoding LD1B_Z_P_BI_U64 // ld1b_z_p_bi_u64
                                when ('0100') => __encoding LD1SW_Z_P_BI_S64 // ld1sw_z_p_bi_s64
                                when ('0101') => __encoding LD1H_Z_P_BI_U16 // ld1h_z_p_bi_u16
                                when ('0110') => __encoding LD1H_Z_P_BI_U32 // ld1h_z_p_bi_u32
                                when ('0111') => __encoding LD1H_Z_P_BI_U64 // ld1h_z_p_bi_u64
                                when ('1000') => __encoding LD1SH_Z_P_BI_S64 // ld1sh_z_p_bi_s64
                                when ('1001') => __encoding LD1SH_Z_P_BI_S32 // ld1sh_z_p_bi_s32
                                when ('1010') => __encoding LD1W_Z_P_BI_U32 // ld1w_z_p_bi_u32
                                when ('1011') => __encoding LD1W_Z_P_BI_U64 // ld1w_z_p_bi_u64
                                when ('1100') => __encoding LD1SB_Z_P_BI_S64 // ld1sb_z_p_bi_s64
                                when ('1101') => __encoding LD1SB_Z_P_BI_S32 // ld1sb_z_p_bi_s32
                                when ('1110') => __encoding LD1SB_Z_P_BI_S16 // ld1sb_z_p_bi_s16
                                when ('1111') => __encoding LD1D_Z_P_BI_U64 // ld1d_z_p_bi_u64
                        when (_, _, _, '1', _, '101', _) => // sve_mem_cldnf_si
                            __field dtype 21 +: 4
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding LDNF1B_Z_P_BI_U8 // ldnf1b_z_p_bi_u8
                                when ('0001') => __encoding LDNF1B_Z_P_BI_U16 // ldnf1b_z_p_bi_u16
                                when ('0010') => __encoding LDNF1B_Z_P_BI_U32 // ldnf1b_z_p_bi_u32
                                when ('0011') => __encoding LDNF1B_Z_P_BI_U64 // ldnf1b_z_p_bi_u64
                                when ('0100') => __encoding LDNF1SW_Z_P_BI_S64 // ldnf1sw_z_p_bi_s64
                                when ('0101') => __encoding LDNF1H_Z_P_BI_U16 // ldnf1h_z_p_bi_u16
                                when ('0110') => __encoding LDNF1H_Z_P_BI_U32 // ldnf1h_z_p_bi_u32
                                when ('0111') => __encoding LDNF1H_Z_P_BI_U64 // ldnf1h_z_p_bi_u64
                                when ('1000') => __encoding LDNF1SH_Z_P_BI_S64 // ldnf1sh_z_p_bi_s64
                                when ('1001') => __encoding LDNF1SH_Z_P_BI_S32 // ldnf1sh_z_p_bi_s32
                                when ('1010') => __encoding LDNF1W_Z_P_BI_U32 // ldnf1w_z_p_bi_u32
                                when ('1011') => __encoding LDNF1W_Z_P_BI_U64 // ldnf1w_z_p_bi_u64
                                when ('1100') => __encoding LDNF1SB_Z_P_BI_S64 // ldnf1sb_z_p_bi_s64
                                when ('1101') => __encoding LDNF1SB_Z_P_BI_S32 // ldnf1sb_z_p_bi_s32
                                when ('1110') => __encoding LDNF1SB_Z_P_BI_S16 // ldnf1sb_z_p_bi_s16
                                when ('1111') => __encoding LDNF1D_Z_P_BI_U64 // ldnf1d_z_p_bi_u64
                        when (_, _, _, _, _, '000', _) => // sve_mem_ldqr_ss
                            __field msz 23 +: 2
                            __field ssz 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, ssz) of
                                when (_, '1x') => __UNALLOCATED
                                when ('00', '00') => __encoding LD1RQB_Z_P_BR_Contiguous // ld1rqb_z_p_br_contiguous
                                when ('00', '01') => __encoding LD1ROB_Z_P_BR_Contiguous // ld1rob_z_p_br_contiguous
                                when ('01', '00') => __encoding LD1RQH_Z_P_BR_Contiguous // ld1rqh_z_p_br_contiguous
                                when ('01', '01') => __encoding LD1ROH_Z_P_BR_Contiguous // ld1roh_z_p_br_contiguous
                                when ('10', '00') => __encoding LD1RQW_Z_P_BR_Contiguous // ld1rqw_z_p_br_contiguous
                                when ('10', '01') => __encoding LD1ROW_Z_P_BR_Contiguous // ld1row_z_p_br_contiguous
                                when ('11', '00') => __encoding LD1RQD_Z_P_BR_Contiguous // ld1rqd_z_p_br_contiguous
                                when ('11', '01') => __encoding LD1ROD_Z_P_BR_Contiguous // ld1rod_z_p_br_contiguous
                        when (_, _, _, _, _, '010', _) => // sve_mem_cld_ss
                            __field dtype 21 +: 4
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding LD1B_Z_P_BR_U8 // ld1b_z_p_br_u8
                                when ('0001') => __encoding LD1B_Z_P_BR_U16 // ld1b_z_p_br_u16
                                when ('0010') => __encoding LD1B_Z_P_BR_U32 // ld1b_z_p_br_u32
                                when ('0011') => __encoding LD1B_Z_P_BR_U64 // ld1b_z_p_br_u64
                                when ('0100') => __encoding LD1SW_Z_P_BR_S64 // ld1sw_z_p_br_s64
                                when ('0101') => __encoding LD1H_Z_P_BR_U16 // ld1h_z_p_br_u16
                                when ('0110') => __encoding LD1H_Z_P_BR_U32 // ld1h_z_p_br_u32
                                when ('0111') => __encoding LD1H_Z_P_BR_U64 // ld1h_z_p_br_u64
                                when ('1000') => __encoding LD1SH_Z_P_BR_S64 // ld1sh_z_p_br_s64
                                when ('1001') => __encoding LD1SH_Z_P_BR_S32 // ld1sh_z_p_br_s32
                                when ('1010') => __encoding LD1W_Z_P_BR_U32 // ld1w_z_p_br_u32
                                when ('1011') => __encoding LD1W_Z_P_BR_U64 // ld1w_z_p_br_u64
                                when ('1100') => __encoding LD1SB_Z_P_BR_S64 // ld1sb_z_p_br_s64
                                when ('1101') => __encoding LD1SB_Z_P_BR_S32 // ld1sb_z_p_br_s32
                                when ('1110') => __encoding LD1SB_Z_P_BR_S16 // ld1sb_z_p_br_s16
                                when ('1111') => __encoding LD1D_Z_P_BR_U64 // ld1d_z_p_br_u64
                        when (_, _, _, _, _, '011', _) => // sve_mem_cldff_ss
                            __field dtype 21 +: 4
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding LDFF1B_Z_P_BR_U8 // ldff1b_z_p_br_u8
                                when ('0001') => __encoding LDFF1B_Z_P_BR_U16 // ldff1b_z_p_br_u16
                                when ('0010') => __encoding LDFF1B_Z_P_BR_U32 // ldff1b_z_p_br_u32
                                when ('0011') => __encoding LDFF1B_Z_P_BR_U64 // ldff1b_z_p_br_u64
                                when ('0100') => __encoding LDFF1SW_Z_P_BR_S64 // ldff1sw_z_p_br_s64
                                when ('0101') => __encoding LDFF1H_Z_P_BR_U16 // ldff1h_z_p_br_u16
                                when ('0110') => __encoding LDFF1H_Z_P_BR_U32 // ldff1h_z_p_br_u32
                                when ('0111') => __encoding LDFF1H_Z_P_BR_U64 // ldff1h_z_p_br_u64
                                when ('1000') => __encoding LDFF1SH_Z_P_BR_S64 // ldff1sh_z_p_br_s64
                                when ('1001') => __encoding LDFF1SH_Z_P_BR_S32 // ldff1sh_z_p_br_s32
                                when ('1010') => __encoding LDFF1W_Z_P_BR_U32 // ldff1w_z_p_br_u32
                                when ('1011') => __encoding LDFF1W_Z_P_BR_U64 // ldff1w_z_p_br_u64
                                when ('1100') => __encoding LDFF1SB_Z_P_BR_S64 // ldff1sb_z_p_br_s64
                                when ('1101') => __encoding LDFF1SB_Z_P_BR_S32 // ldff1sb_z_p_br_s32
                                when ('1110') => __encoding LDFF1SB_Z_P_BR_S16 // ldff1sb_z_p_br_s16
                                when ('1111') => __encoding LDFF1D_Z_P_BR_U64 // ldff1d_z_p_br_u64
                when ('110', _, _, _, _, _, _, _) =>
                    // sve_mem64
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '00', '00', _, '101', _, _, _) => // sve_mem_64b_gldq_vs
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding LD1Q_Z_P_AR_D_64_unscaled // ld1q_z_p_ar_d_64_unscaled
                        when (_, '00', '01', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', '11', _, '1xx', _, '0', _) => // sve_mem_64b_prfm_sv2
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BZ_D_64_scaled // prfb_i_p_bz_d_64_scaled
                                when ('01') => __encoding PRFH_I_P_BZ_D_64_scaled // prfh_i_p_bz_d_64_scaled
                                when ('10') => __encoding PRFW_I_P_BZ_D_64_scaled // prfw_i_p_bz_d_64_scaled
                                when ('11') => __encoding PRFD_I_P_BZ_D_64_scaled // prfd_i_p_bz_d_64_scaled
                        when (_, '00', '11', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, '00', 'x1', _, '0xx', _, '0', _) => // sve_mem_64b_prfm_sv
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_BZ_D_x32_scaled // prfb_i_p_bz_d_x32_scaled
                                when ('01') => __encoding PRFH_I_P_BZ_D_x32_scaled // prfh_i_p_bz_d_x32_scaled
                                when ('10') => __encoding PRFW_I_P_BZ_D_x32_scaled // prfw_i_p_bz_d_x32_scaled
                                when ('11') => __encoding PRFD_I_P_BZ_D_x32_scaled // prfd_i_p_bz_d_x32_scaled
                        when (_, !'00', '00', _, '101', _, _, _) => __UNPREDICTABLE
                        when (_, !'00', '11', _, '1xx', _, _, _) => // sve_mem_64b_gld_sv2
                            __field opc 23 +: 2
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_D_64_scaled // ld1sh_z_p_bz_d_64_scaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_D_64_scaled // ldff1sh_z_p_bz_d_64_scaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_D_64_scaled // ld1h_z_p_bz_d_64_scaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_D_64_scaled // ldff1h_z_p_bz_d_64_scaled
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_BZ_D_64_scaled // ld1sw_z_p_bz_d_64_scaled
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_BZ_D_64_scaled // ldff1sw_z_p_bz_d_64_scaled
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_D_64_scaled // ld1w_z_p_bz_d_64_scaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_D_64_scaled // ldff1w_z_p_bz_d_64_scaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_BZ_D_64_scaled // ld1d_z_p_bz_d_64_scaled
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_BZ_D_64_scaled // ldff1d_z_p_bz_d_64_scaled
                        when (_, !'00', 'x1', _, '0xx', _, _, _) => // sve_mem_64b_gld_sv
                            __field opc 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_D_x32_scaled // ld1sh_z_p_bz_d_x32_scaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_D_x32_scaled // ldff1sh_z_p_bz_d_x32_scaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_D_x32_scaled // ld1h_z_p_bz_d_x32_scaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_D_x32_scaled // ldff1h_z_p_bz_d_x32_scaled
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_BZ_D_x32_scaled // ld1sw_z_p_bz_d_x32_scaled
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_BZ_D_x32_scaled // ldff1sw_z_p_bz_d_x32_scaled
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_D_x32_scaled // ld1w_z_p_bz_d_x32_scaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_D_x32_scaled // ldff1w_z_p_bz_d_x32_scaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_BZ_D_x32_scaled // ld1d_z_p_bz_d_x32_scaled
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_BZ_D_x32_scaled // ldff1d_z_p_bz_d_x32_scaled
                        when (_, _, '00', _, '111', _, '0', _) => // sve_mem_64b_prfm_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding PRFB_I_P_AI_D // prfb_i_p_ai_d
                                when ('01') => __encoding PRFH_I_P_AI_D // prfh_i_p_ai_d
                                when ('10') => __encoding PRFW_I_P_AI_D // prfw_i_p_ai_d
                                when ('11') => __encoding PRFD_I_P_AI_D // prfd_i_p_ai_d
                        when (_, _, '00', _, '111', _, '1', _) => __UNPREDICTABLE
                        when (_, _, '00', _, '1x0', _, _, _) => // sve_mem_64b_gldnt_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field U 14 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U) of
                                when ('00', '0') => __encoding LDNT1SB_Z_P_AR_D_64_unscaled // ldnt1sb_z_p_ar_d_64_unscaled
                                when ('00', '1') => __encoding LDNT1B_Z_P_AR_D_64_unscaled // ldnt1b_z_p_ar_d_64_unscaled
                                when ('01', '0') => __encoding LDNT1SH_Z_P_AR_D_64_unscaled // ldnt1sh_z_p_ar_d_64_unscaled
                                when ('01', '1') => __encoding LDNT1H_Z_P_AR_D_64_unscaled // ldnt1h_z_p_ar_d_64_unscaled
                                when ('10', '0') => __encoding LDNT1SW_Z_P_AR_D_64_unscaled // ldnt1sw_z_p_ar_d_64_unscaled
                                when ('10', '1') => __encoding LDNT1W_Z_P_AR_D_64_unscaled // ldnt1w_z_p_ar_d_64_unscaled
                                when ('11', '0') => __UNALLOCATED
                                when ('11', '1') => __encoding LDNT1D_Z_P_AR_D_64_unscaled // ldnt1d_z_p_ar_d_64_unscaled
                        when (_, _, '01', _, '1xx', _, _, _) => // sve_mem_64b_gld_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_AI_D // ld1sb_z_p_ai_d
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_AI_D // ldff1sb_z_p_ai_d
                                when ('00', '1', '0') => __encoding LD1B_Z_P_AI_D // ld1b_z_p_ai_d
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_AI_D // ldff1b_z_p_ai_d
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_AI_D // ld1sh_z_p_ai_d
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_AI_D // ldff1sh_z_p_ai_d
                                when ('01', '1', '0') => __encoding LD1H_Z_P_AI_D // ld1h_z_p_ai_d
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_AI_D // ldff1h_z_p_ai_d
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_AI_D // ld1sw_z_p_ai_d
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_AI_D // ldff1sw_z_p_ai_d
                                when ('10', '1', '0') => __encoding LD1W_Z_P_AI_D // ld1w_z_p_ai_d
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_AI_D // ldff1w_z_p_ai_d
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_AI_D // ld1d_z_p_ai_d
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_AI_D // ldff1d_z_p_ai_d
                        when (_, _, '10', _, '1xx', _, _, _) => // sve_mem_64b_gld_vs2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_BZ_D_64_unscaled // ld1sb_z_p_bz_d_64_unscaled
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_BZ_D_64_unscaled // ldff1sb_z_p_bz_d_64_unscaled
                                when ('00', '1', '0') => __encoding LD1B_Z_P_BZ_D_64_unscaled // ld1b_z_p_bz_d_64_unscaled
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_BZ_D_64_unscaled // ldff1b_z_p_bz_d_64_unscaled
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_D_64_unscaled // ld1sh_z_p_bz_d_64_unscaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_D_64_unscaled // ldff1sh_z_p_bz_d_64_unscaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_D_64_unscaled // ld1h_z_p_bz_d_64_unscaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_D_64_unscaled // ldff1h_z_p_bz_d_64_unscaled
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_BZ_D_64_unscaled // ld1sw_z_p_bz_d_64_unscaled
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_BZ_D_64_unscaled // ldff1sw_z_p_bz_d_64_unscaled
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_D_64_unscaled // ld1w_z_p_bz_d_64_unscaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_D_64_unscaled // ldff1w_z_p_bz_d_64_unscaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_BZ_D_64_unscaled // ld1d_z_p_bz_d_64_unscaled
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_BZ_D_64_unscaled // ldff1d_z_p_bz_d_64_unscaled
                        when (_, _, 'x0', _, '0xx', _, _, _) => // sve_mem_64b_gld_vs
                            __field msz 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding LD1SB_Z_P_BZ_D_x32_unscaled // ld1sb_z_p_bz_d_x32_unscaled
                                when ('00', '0', '1') => __encoding LDFF1SB_Z_P_BZ_D_x32_unscaled // ldff1sb_z_p_bz_d_x32_unscaled
                                when ('00', '1', '0') => __encoding LD1B_Z_P_BZ_D_x32_unscaled // ld1b_z_p_bz_d_x32_unscaled
                                when ('00', '1', '1') => __encoding LDFF1B_Z_P_BZ_D_x32_unscaled // ldff1b_z_p_bz_d_x32_unscaled
                                when ('01', '0', '0') => __encoding LD1SH_Z_P_BZ_D_x32_unscaled // ld1sh_z_p_bz_d_x32_unscaled
                                when ('01', '0', '1') => __encoding LDFF1SH_Z_P_BZ_D_x32_unscaled // ldff1sh_z_p_bz_d_x32_unscaled
                                when ('01', '1', '0') => __encoding LD1H_Z_P_BZ_D_x32_unscaled // ld1h_z_p_bz_d_x32_unscaled
                                when ('01', '1', '1') => __encoding LDFF1H_Z_P_BZ_D_x32_unscaled // ldff1h_z_p_bz_d_x32_unscaled
                                when ('10', '0', '0') => __encoding LD1SW_Z_P_BZ_D_x32_unscaled // ld1sw_z_p_bz_d_x32_unscaled
                                when ('10', '0', '1') => __encoding LDFF1SW_Z_P_BZ_D_x32_unscaled // ldff1sw_z_p_bz_d_x32_unscaled
                                when ('10', '1', '0') => __encoding LD1W_Z_P_BZ_D_x32_unscaled // ld1w_z_p_bz_d_x32_unscaled
                                when ('10', '1', '1') => __encoding LDFF1W_Z_P_BZ_D_x32_unscaled // ldff1w_z_p_bz_d_x32_unscaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding LD1D_Z_P_BZ_D_x32_unscaled // ld1d_z_p_bz_d_x32_unscaled
                                when ('11', '1', '1') => __encoding LDFF1D_Z_P_BZ_D_x32_unscaled // ldff1d_z_p_bz_d_x32_unscaled
                when ('111', _, _, _, '0x0xxx', _, _, _) =>
                    // sve_memst_cs
                    case (25 +: 7, 22 +: 3, 20 +: 2, 16 +: 4, 15 +: 1, 14 +: 1, 13 +: 1, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '0xx', '00', _, _, '0', _, _, _, _) => // sve_mem_estq_si
                            __field num 22 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST2Q_Z_P_BI_Contiguous // st2q_z_p_bi_contiguous
                                when ('10') => __encoding ST3Q_Z_P_BI_Contiguous // st3q_z_p_bi_contiguous
                                when ('11') => __encoding ST4Q_Z_P_BI_Contiguous // st4q_z_p_bi_contiguous
                        when (_, '0xx', '01', _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, '0xx', '1x', _, _, '0', _, _, _, _) => // sve_mem_estq_ss
                            __field num 22 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST2Q_Z_P_BR_Contiguous // st2q_z_p_br_contiguous
                                when ('10') => __encoding ST3Q_Z_P_BR_Contiguous // st3q_z_p_br_contiguous
                                when ('11') => __encoding ST4Q_Z_P_BR_Contiguous // st4q_z_p_br_contiguous
                        when (_, '10x', _, _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, '110', _, _, _, '0', _, _, '0', _) => // sve_mem_pspill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Pt 0 +: 4
                            case () of
                                when () => __encoding STR_P_BI__ // str_p_bi_
                        when (_, '110', _, _, _, '0', _, _, '1', _) => __UNPREDICTABLE
                        when (_, '110', _, _, _, '1', _, _, _, _) => // sve_mem_spill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding STR_Z_BI__ // str_z_bi_
                        when (_, '111', _, _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, !'110', _, _, _, '1', _, _, _, _) => // sve_mem_cst_ss
                            __field opc 22 +: 3
                            __field o2 21 +: 1
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, o2) of
                                when ('00x', _) => __encoding ST1B_Z_P_BR__ // st1b_z_p_br_
                                when ('01x', _) => __encoding ST1H_Z_P_BR__ // st1h_z_p_br_
                                when ('100', '0') => __encoding ST1W_Z_P_BR_U128 // st1w_z_p_br_u128
                                when ('101', _) => __encoding ST1W_Z_P_BR__ // st1w_z_p_br_
                                when ('111', '0') => __encoding ST1D_Z_P_BR_U128 // st1d_z_p_br_u128
                                when ('111', '1') => __encoding ST1D_Z_P_BR__ // st1d_z_p_br_
                when ('111', _, _, _, '001xxx', _, _, _) =>
                    // sve_memsst_nt
                    case (25 +: 7, 22 +: 3, 21 +: 1, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, '000', '1', _, _, _) => // sve_mem_sstq_64b_vs
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding ST1Q_Z_P_AR_D_64_unscaled // st1q_z_p_ar_d_64_unscaled
                        when (_, !'000', '1', _, _, _) => __UNPREDICTABLE
                        when (_, 'xx0', '0', _, _, _) => // sve_mem_sstnt_64b_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding STNT1B_Z_P_AR_D_64_unscaled // stnt1b_z_p_ar_d_64_unscaled
                                when ('01') => __encoding STNT1H_Z_P_AR_D_64_unscaled // stnt1h_z_p_ar_d_64_unscaled
                                when ('10') => __encoding STNT1W_Z_P_AR_D_64_unscaled // stnt1w_z_p_ar_d_64_unscaled
                                when ('11') => __encoding STNT1D_Z_P_AR_D_64_unscaled // stnt1d_z_p_ar_d_64_unscaled
                        when (_, 'xx1', '0', _, _, _) => // sve_mem_sstnt_32b_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding STNT1B_Z_P_AR_S_x32_unscaled // stnt1b_z_p_ar_s_x32_unscaled
                                when ('01') => __encoding STNT1H_Z_P_AR_S_x32_unscaled // stnt1h_z_p_ar_s_x32_unscaled
                                when ('10') => __encoding STNT1W_Z_P_AR_S_x32_unscaled // stnt1w_z_p_ar_s_x32_unscaled
                                when ('11') => __UNALLOCATED
                when ('111', _, _, _, '011xxx', _, _, _) =>
                    // sve_memcst_nt
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, _, '00', _, _, _) => // sve_mem_cstnt_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding STNT1B_Z_P_BR_Contiguous // stnt1b_z_p_br_contiguous
                                when ('01') => __encoding STNT1H_Z_P_BR_Contiguous // stnt1h_z_p_br_contiguous
                                when ('10') => __encoding STNT1W_Z_P_BR_Contiguous // stnt1w_z_p_br_contiguous
                                when ('11') => __encoding STNT1D_Z_P_BR_Contiguous // stnt1d_z_p_br_contiguous
                        when (_, _, !'00', _, _, _) => // sve_mem_est_ss
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding ST2B_Z_P_BR_Contiguous // st2b_z_p_br_contiguous
                                when ('00', '10') => __encoding ST3B_Z_P_BR_Contiguous // st3b_z_p_br_contiguous
                                when ('00', '11') => __encoding ST4B_Z_P_BR_Contiguous // st4b_z_p_br_contiguous
                                when ('01', '01') => __encoding ST2H_Z_P_BR_Contiguous // st2h_z_p_br_contiguous
                                when ('01', '10') => __encoding ST3H_Z_P_BR_Contiguous // st3h_z_p_br_contiguous
                                when ('01', '11') => __encoding ST4H_Z_P_BR_Contiguous // st4h_z_p_br_contiguous
                                when ('10', '01') => __encoding ST2W_Z_P_BR_Contiguous // st2w_z_p_br_contiguous
                                when ('10', '10') => __encoding ST3W_Z_P_BR_Contiguous // st3w_z_p_br_contiguous
                                when ('10', '11') => __encoding ST4W_Z_P_BR_Contiguous // st4w_z_p_br_contiguous
                                when ('11', '01') => __encoding ST2D_Z_P_BR_Contiguous // st2d_z_p_br_contiguous
                                when ('11', '10') => __encoding ST3D_Z_P_BR_Contiguous // st3d_z_p_br_contiguous
                                when ('11', '11') => __encoding ST4D_Z_P_BR_Contiguous // st4d_z_p_br_contiguous
                when ('111', _, _, _, '1x0xxx', _, _, _) =>
                    // sve_memst_ss
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 15 +: 1, 14 +: 1, 13 +: 1, 0 +: 13) of
                        when (_, _, '00', _, _, _, _, _) => // sve_mem_sst_vs_a
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_BZ_D_x32_unscaled // st1b_z_p_bz_d_x32_unscaled
                                when ('01') => __encoding ST1H_Z_P_BZ_D_x32_unscaled // st1h_z_p_bz_d_x32_unscaled
                                when ('10') => __encoding ST1W_Z_P_BZ_D_x32_unscaled // st1w_z_p_bz_d_x32_unscaled
                                when ('11') => __encoding ST1D_Z_P_BZ_D_x32_unscaled // st1d_z_p_bz_d_x32_unscaled
                        when (_, _, '01', _, _, _, _, _) => // sve_mem_sst_sv_a
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST1H_Z_P_BZ_D_x32_scaled // st1h_z_p_bz_d_x32_scaled
                                when ('10') => __encoding ST1W_Z_P_BZ_D_x32_scaled // st1w_z_p_bz_d_x32_scaled
                                when ('11') => __encoding ST1D_Z_P_BZ_D_x32_scaled // st1d_z_p_bz_d_x32_scaled
                        when (_, _, '10', _, _, _, _, _) => // sve_mem_sst_vs_b
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_BZ_S_x32_unscaled // st1b_z_p_bz_s_x32_unscaled
                                when ('01') => __encoding ST1H_Z_P_BZ_S_x32_unscaled // st1h_z_p_bz_s_x32_unscaled
                                when ('10') => __encoding ST1W_Z_P_BZ_S_x32_unscaled // st1w_z_p_bz_s_x32_unscaled
                                when ('11') => __UNALLOCATED
                        when (_, _, '11', _, _, _, _, _) => // sve_mem_sst_sv_b
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST1H_Z_P_BZ_S_x32_scaled // st1h_z_p_bz_s_x32_scaled
                                when ('10') => __encoding ST1W_Z_P_BZ_S_x32_scaled // st1w_z_p_bz_s_x32_scaled
                                when ('11') => __UNALLOCATED
                when ('111', _, _, _, '101xxx', _, _, _) =>
                    // sve_memst_ss2
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 0 +: 13) of
                        when (_, _, '00', _, _, _) => // sve_mem_sst_vs2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_BZ_D_64_unscaled // st1b_z_p_bz_d_64_unscaled
                                when ('01') => __encoding ST1H_Z_P_BZ_D_64_unscaled // st1h_z_p_bz_d_64_unscaled
                                when ('10') => __encoding ST1W_Z_P_BZ_D_64_unscaled // st1w_z_p_bz_d_64_unscaled
                                when ('11') => __encoding ST1D_Z_P_BZ_D_64_unscaled // st1d_z_p_bz_d_64_unscaled
                        when (_, _, '01', _, _, _) => // sve_mem_sst_sv2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding ST1H_Z_P_BZ_D_64_scaled // st1h_z_p_bz_d_64_scaled
                                when ('10') => __encoding ST1W_Z_P_BZ_D_64_scaled // st1w_z_p_bz_d_64_scaled
                                when ('11') => __encoding ST1D_Z_P_BZ_D_64_scaled // st1d_z_p_bz_d_64_scaled
                        when (_, _, '10', _, _, _) => // sve_mem_sst_vi_a
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_AI_D // st1b_z_p_ai_d
                                when ('01') => __encoding ST1H_Z_P_AI_D // st1h_z_p_ai_d
                                when ('10') => __encoding ST1W_Z_P_AI_D // st1w_z_p_ai_d
                                when ('11') => __encoding ST1D_Z_P_AI_D // st1d_z_p_ai_d
                        when (_, _, '11', _, _, _) => // sve_mem_sst_vi_b
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding ST1B_Z_P_AI_S // st1b_z_p_ai_s
                                when ('01') => __encoding ST1H_Z_P_AI_S // st1h_z_p_ai_s
                                when ('10') => __encoding ST1W_Z_P_AI_S // st1w_z_p_ai_s
                                when ('11') => __UNALLOCATED
                when ('111', _, _, _, '111xxx', _, _, _) =>
                    // sve_memst_si
                    case (25 +: 7, 23 +: 2, 21 +: 2, 20 +: 1, 16 +: 4, 13 +: 3, 0 +: 13) of
                        when (_, _, '00', '1', _, _, _) => // sve_mem_cstnt_si
                            __field msz 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding STNT1B_Z_P_BI_Contiguous // stnt1b_z_p_bi_contiguous
                                when ('01') => __encoding STNT1H_Z_P_BI_Contiguous // stnt1h_z_p_bi_contiguous
                                when ('10') => __encoding STNT1W_Z_P_BI_Contiguous // stnt1w_z_p_bi_contiguous
                                when ('11') => __encoding STNT1D_Z_P_BI_Contiguous // stnt1d_z_p_bi_contiguous
                        when (_, _, !'00', '1', _, _, _) => // sve_mem_est_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding ST2B_Z_P_BI_Contiguous // st2b_z_p_bi_contiguous
                                when ('00', '10') => __encoding ST3B_Z_P_BI_Contiguous // st3b_z_p_bi_contiguous
                                when ('00', '11') => __encoding ST4B_Z_P_BI_Contiguous // st4b_z_p_bi_contiguous
                                when ('01', '01') => __encoding ST2H_Z_P_BI_Contiguous // st2h_z_p_bi_contiguous
                                when ('01', '10') => __encoding ST3H_Z_P_BI_Contiguous // st3h_z_p_bi_contiguous
                                when ('01', '11') => __encoding ST4H_Z_P_BI_Contiguous // st4h_z_p_bi_contiguous
                                when ('10', '01') => __encoding ST2W_Z_P_BI_Contiguous // st2w_z_p_bi_contiguous
                                when ('10', '10') => __encoding ST3W_Z_P_BI_Contiguous // st3w_z_p_bi_contiguous
                                when ('10', '11') => __encoding ST4W_Z_P_BI_Contiguous // st4w_z_p_bi_contiguous
                                when ('11', '01') => __encoding ST2D_Z_P_BI_Contiguous // st2d_z_p_bi_contiguous
                                when ('11', '10') => __encoding ST3D_Z_P_BI_Contiguous // st3d_z_p_bi_contiguous
                                when ('11', '11') => __encoding ST4D_Z_P_BI_Contiguous // st4d_z_p_bi_contiguous
                        when (_, _, _, '0', _, _, _) => // sve_mem_cst_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', _) => __encoding ST1B_Z_P_BI__ // st1b_z_p_bi_
                                when ('01', _) => __encoding ST1H_Z_P_BI__ // st1h_z_p_bi_
                                when ('10', '00') => __encoding ST1W_Z_P_BI_U128 // st1w_z_p_bi_u128
                                when ('10', '01') => __UNALLOCATED
                                when ('10', '1x') => __encoding ST1W_Z_P_BI__ // st1w_z_p_bi_
                                when ('11', '0x') => __UNALLOCATED
                                when ('11', '10') => __encoding ST1D_Z_P_BI_U128 // st1d_z_p_bi_u128
                                when ('11', '11') => __encoding ST1D_Z_P_BI__ // st1d_z_p_bi_
        when (_, _, '0011', _) => __UNPREDICTABLE
        when (_, _, '100x', _) =>
            // dpimm
            case (31 +: 1, 29 +: 2, 26 +: 3, 22 +: 4, 0 +: 22) of
                when (_, '11', _, '111x', _) => // dp_1src_imm
                    __field sf 31 +: 1
                    __field opc 21 +: 2
                    __field imm16 5 +: 16
                    __field Rd 0 +: 5
                    case (sf, opc, Rd) of
                        when ('0', _, _) => __UNALLOCATED
                        when ('1', '0x', '0xxxx') => __UNALLOCATED
                        when ('1', '0x', '10xxx') => __UNALLOCATED
                        when ('1', '0x', '110xx') => __UNALLOCATED
                        when ('1', '0x', '1110x') => __UNALLOCATED
                        when ('1', '0x', '11110') => __UNALLOCATED
                        when ('1', '00', '11111') => __encoding A64_dpimm_dp_1src_imm_AUTIASPPC_only_dp_1src_imm // AUTIASPPC_only_dp_1src_imm
                        when ('1', '01', '11111') => __encoding A64_dpimm_dp_1src_imm_AUTIBSPPC_only_dp_1src_imm // AUTIBSPPC_only_dp_1src_imm
                        when ('1', '1x', _) => __UNALLOCATED
                when (_, _, _, '00xx', _) => // pcreladdr
                    __field op 31 +: 1
                    __field immlo 29 +: 2
                    __field immhi 5 +: 19
                    __field Rd 0 +: 5
                    case (op) of
                        when ('0') => __encoding A64_dpimm_pcreladdr_ADR_only_pcreladdr // ADR_only_pcreladdr
                        when ('1') => __encoding A64_dpimm_pcreladdr_ADRP_only_pcreladdr // ADRP_only_pcreladdr
                when (_, _, _, '010x', _) => // addsub_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field sh 22 +: 1
                    __field imm12 10 +: 12
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', '0', '0') => __encoding A64_dpimm_addsub_imm_ADD_32_addsub_imm // ADD_32_addsub_imm
                        when ('0', '0', '1') => __encoding A64_dpimm_addsub_imm_ADDS_32S_addsub_imm // ADDS_32S_addsub_imm
                        when ('0', '1', '0') => __encoding A64_dpimm_addsub_imm_SUB_32_addsub_imm // SUB_32_addsub_imm
                        when ('0', '1', '1') => __encoding A64_dpimm_addsub_imm_SUBS_32S_addsub_imm // SUBS_32S_addsub_imm
                        when ('1', '0', '0') => __encoding A64_dpimm_addsub_imm_ADD_32_addsub_imm // ADD_64_addsub_imm
                        when ('1', '0', '1') => __encoding A64_dpimm_addsub_imm_ADDS_32S_addsub_imm // ADDS_64S_addsub_imm
                        when ('1', '1', '0') => __encoding A64_dpimm_addsub_imm_SUB_32_addsub_imm // SUB_64_addsub_imm
                        when ('1', '1', '1') => __encoding A64_dpimm_addsub_imm_SUBS_32S_addsub_imm // SUBS_64S_addsub_imm
                when (_, _, _, '0110', _) => // addsub_immtags
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field uimm6 16 +: 6
                    __field op3 14 +: 2
                    __field uimm4 10 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', _, _) => __UNALLOCATED
                        when ('1', _, '1') => __UNALLOCATED
                        when ('1', '0', '0') => __encoding A64_dpimm_addsub_immtags_ADDG_64_addsub_immtags // ADDG_64_addsub_immtags
                        when ('1', '1', '0') => __encoding A64_dpimm_addsub_immtags_SUBG_64_addsub_immtags // SUBG_64_addsub_immtags
                when (_, _, _, '0111', _) => // minmax_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opc 18 +: 4
                    __field imm8 10 +: 8
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, opc) of
                        when (_, '0', '0', '01xx') => __UNALLOCATED
                        when (_, '0', '0', '1xxx') => __UNALLOCATED
                        when (_, '0', '1', _) => __UNALLOCATED
                        when (_, '1', _, _) => __UNALLOCATED
                        when ('0', '0', '0', '0000') => __encoding A64_dpimm_minmax_imm_SMAX_32_minmax_imm // SMAX_32_minmax_imm
                        when ('0', '0', '0', '0001') => __encoding A64_dpimm_minmax_imm_UMAX_32U_minmax_imm // UMAX_32U_minmax_imm
                        when ('0', '0', '0', '0010') => __encoding A64_dpimm_minmax_imm_SMIN_32_minmax_imm // SMIN_32_minmax_imm
                        when ('0', '0', '0', '0011') => __encoding A64_dpimm_minmax_imm_UMIN_32U_minmax_imm // UMIN_32U_minmax_imm
                        when ('1', '0', '0', '0000') => __encoding A64_dpimm_minmax_imm_SMAX_32_minmax_imm // SMAX_64_minmax_imm
                        when ('1', '0', '0', '0001') => __encoding A64_dpimm_minmax_imm_UMAX_32U_minmax_imm // UMAX_64U_minmax_imm
                        when ('1', '0', '0', '0010') => __encoding A64_dpimm_minmax_imm_SMIN_32_minmax_imm // SMIN_64_minmax_imm
                        when ('1', '0', '0', '0011') => __encoding A64_dpimm_minmax_imm_UMIN_32U_minmax_imm // UMIN_64U_minmax_imm
                when (_, _, _, '100x', _) => // log_imm
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field N 22 +: 1
                    __field immr 16 +: 6
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N) of
                        when ('0', _, '1') => __UNALLOCATED
                        when ('0', '00', '0') => __encoding A64_dpimm_log_imm_AND_32_log_imm // AND_32_log_imm
                        when ('0', '01', '0') => __encoding A64_dpimm_log_imm_ORR_32_log_imm // ORR_32_log_imm
                        when ('0', '10', '0') => __encoding A64_dpimm_log_imm_EOR_32_log_imm // EOR_32_log_imm
                        when ('0', '11', '0') => __encoding A64_dpimm_log_imm_ANDS_32S_log_imm // ANDS_32S_log_imm
                        when ('1', '00', _) => __encoding A64_dpimm_log_imm_AND_32_log_imm // AND_64_log_imm
                        when ('1', '01', _) => __encoding A64_dpimm_log_imm_ORR_32_log_imm // ORR_64_log_imm
                        when ('1', '10', _) => __encoding A64_dpimm_log_imm_EOR_32_log_imm // EOR_64_log_imm
                        when ('1', '11', _) => __encoding A64_dpimm_log_imm_ANDS_32S_log_imm // ANDS_64S_log_imm
                when (_, _, _, '101x', _) => // movewide
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field hw 21 +: 2
                    __field imm16 5 +: 16
                    __field Rd 0 +: 5
                    case (sf, opc, hw) of
                        when (_, '01', '0x') => __UNALLOCATED
                        when ('0', _, '1x') => __UNALLOCATED
                        when ('0', '00', '0x') => __encoding A64_dpimm_movewide_MOVN_32_movewide // MOVN_32_movewide
                        when ('0', '10', '0x') => __encoding A64_dpimm_movewide_MOVZ_32_movewide // MOVZ_32_movewide
                        when ('0', '11', '0x') => __encoding A64_dpimm_movewide_MOVK_32_movewide // MOVK_32_movewide
                        when ('1', '00', _) => __encoding A64_dpimm_movewide_MOVN_32_movewide // MOVN_64_movewide
                        when ('1', '01', '1x') => __UNALLOCATED
                        when ('1', '10', _) => __encoding A64_dpimm_movewide_MOVZ_32_movewide // MOVZ_64_movewide
                        when ('1', '11', _) => __encoding A64_dpimm_movewide_MOVK_32_movewide // MOVK_64_movewide
                when (_, _, _, '110x', _) => // bitfield
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field N 22 +: 1
                    __field immr 16 +: 6
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N) of
                        when ('0', _, '1') => __UNALLOCATED
                        when ('0', '00', '0') => __encoding A64_dpimm_bitfield_SBFM_32M_bitfield // SBFM_32M_bitfield
                        when ('0', '01', '0') => __encoding A64_dpimm_bitfield_BFM_32M_bitfield // BFM_32M_bitfield
                        when ('0', '10', '0') => __encoding A64_dpimm_bitfield_UBFM_32M_bitfield // UBFM_32M_bitfield
                        when ('0', '11', '0') => __UNALLOCATED
                        when ('1', _, '0') => __UNALLOCATED
                        when ('1', '00', '1') => __encoding A64_dpimm_bitfield_SBFM_32M_bitfield // SBFM_64M_bitfield
                        when ('1', '01', '1') => __encoding A64_dpimm_bitfield_BFM_32M_bitfield // BFM_64M_bitfield
                        when ('1', '10', '1') => __encoding A64_dpimm_bitfield_UBFM_32M_bitfield // UBFM_64M_bitfield
                        when ('1', '11', '1') => __UNALLOCATED
                when (_, !'11', _, '111x', _) => // extract
                    __field sf 31 +: 1
                    __field op21 29 +: 2
                    __field N 22 +: 1
                    __field o0 21 +: 1
                    __field Rm 16 +: 5
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op21, N, o0, imms) of
                        when (_, '00', _, '1', _) => __UNALLOCATED
                        when (_, '01', _, _, _) => __UNALLOCATED
                        when (_, '1x', _, _, _) => __UNALLOCATED
                        when ('0', '00', '0', '0', '0xxxxx') => __encoding A64_dpimm_extract_EXTR_32_extract // EXTR_32_extract
                        when ('0', '00', '0', '0', '1xxxxx') => __UNALLOCATED
                        when ('0', '00', '1', '0', _) => __UNALLOCATED
                        when ('1', '00', '0', '0', _) => __UNALLOCATED
                        when ('1', '00', '1', '0', _) => __encoding A64_dpimm_extract_EXTR_32_extract // EXTR_64_extract
        when (_, _, '101x', _) =>
            // control
            case (29 +: 3, 26 +: 3, 12 +: 14, 5 +: 7, 0 +: 5) of
                when ('010', _, '00xxxxxxxxxxxx', _, _) => // condbranch
                    __field imm19 5 +: 19
                    __field o0 4 +: 1
                    __field cond 0 +: 4
                    case (o0) of
                        when ('0') => __encoding A64_control_condbranch_B_only_condbranch // B_only_condbranch
                        when ('1') => __encoding A64_control_condbranch_BC_only_condbranch // BC_only_condbranch
                when ('010', _, '01xxxxxxxxxxxx', _, _) => // miscbranch
                    __field opc 21 +: 3
                    __field imm16 5 +: 16
                    __field op2 0 +: 5
                    case (opc, op2) of
                        when ('00x', '0xxxx') => __UNALLOCATED
                        when ('00x', '10xxx') => __UNALLOCATED
                        when ('00x', '110xx') => __UNALLOCATED
                        when ('00x', '1110x') => __UNALLOCATED
                        when ('00x', '11110') => __UNALLOCATED
                        when ('000', '11111') => __encoding A64_control_miscbranch_RETAASPPC_only_miscbranch // RETAASPPC_only_miscbranch
                        when ('001', '11111') => __encoding A64_control_miscbranch_RETAASPPC_only_miscbranch // RETABSPPC_only_miscbranch
                        when ('01x', _) => __UNALLOCATED
                        when ('1xx', _) => __UNALLOCATED
                when ('110', _, '00xxxxxxxxxxxx', _, _) => // exception
                    __field opc 21 +: 3
                    __field imm16 5 +: 16
                    __field op2 2 +: 3
                    __field LL 0 +: 2
                    case (opc, op2, LL) of
                        when (_, '001', _) => __UNALLOCATED
                        when (_, '01x', _) => __UNALLOCATED
                        when (_, '1xx', _) => __UNALLOCATED
                        when ('x11', '000', '01') => __UNALLOCATED
                        when ('x11', '000', '1x') => __UNALLOCATED
                        when ('000', '000', '00') => __UNALLOCATED
                        when ('000', '000', '01') => __encoding A64_control_exception_SVC_EX_exception // SVC_EX_exception
                        when ('000', '000', '10') => __encoding A64_control_exception_HVC_EX_exception // HVC_EX_exception
                        when ('000', '000', '11') => __encoding A64_control_exception_SMC_EX_exception // SMC_EX_exception
                        when ('001', '000', '00') => __encoding A64_control_exception_BRK_EX_exception // BRK_EX_exception
                        when ('001', '000', '01') => __UNALLOCATED
                        when ('001', '000', '1x') => __UNALLOCATED
                        when ('010', '000', '00') => __encoding A64_control_exception_HLT_EX_exception // HLT_EX_exception
                        when ('010', '000', '01') => __UNALLOCATED
                        when ('010', '000', '1x') => __UNALLOCATED
                        when ('011', '000', '00') => __encoding A64_control_exception_TCANCEL_EX_exception // TCANCEL_EX_exception
                        when ('1x0', '000', _) => __UNALLOCATED
                        when ('1x1', '000', '00') => __UNALLOCATED
                        when ('101', '000', '01') => __encoding A64_control_exception_DCPS1_DC_exception // DCPS1_DC_exception
                        when ('101', '000', '10') => __encoding A64_control_exception_DCPS2_DC_exception // DCPS2_DC_exception
                        when ('101', '000', '11') => __encoding A64_control_exception_DCPS3_DC_exception // DCPS3_DC_exception
                when ('110', _, '01000000110001', _, _) => // systeminstrswithreg
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (CRm, op2) of
                        when ('0000', '000') => __encoding A64_control_systeminstrswithreg_WFET_only_systeminstrswithreg // WFET_only_systeminstrswithreg
                        when ('0000', '001') => __encoding A64_control_systeminstrswithreg_WFIT_only_systeminstrswithreg // WFIT_only_systeminstrswithreg
                        when ('0000', '01x') => __UNALLOCATED
                        when ('0000', '1xx') => __UNALLOCATED
                        when ('0001', _) => __UNALLOCATED
                        when ('001x', _) => __UNALLOCATED
                        when ('01xx', _) => __UNALLOCATED
                        when ('1xxx', _) => __UNALLOCATED
                when ('110', _, '01000000110010', _, '11111') => // hints
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    case (CRm, op2) of
                        when (_, _) => __encoding A64_control_hints_HINT_HM_hints // HINT_HM_hints
                        when ('0000', '000') => __encoding A64_control_hints_NOP_HI_hints // NOP_HI_hints
                        when ('0000', '001') => __encoding A64_control_hints_YIELD_HI_hints // YIELD_HI_hints
                        when ('0000', '010') => __encoding A64_control_hints_WFE_HI_hints // WFE_HI_hints
                        when ('0000', '011') => __encoding A64_control_hints_WFI_HI_hints // WFI_HI_hints
                        when ('0000', '100') => __encoding A64_control_hints_SEV_HI_hints // SEV_HI_hints
                        when ('0000', '101') => __encoding A64_control_hints_SEVL_HI_hints // SEVL_HI_hints
                        when ('0000', '110') => __encoding A64_control_hints_DGH_HI_hints // DGH_HI_hints
                        when ('0000', '111') => __encoding A64_control_hints_XPACLRI_HI_hints // XPACLRI_HI_hints
                        when ('0001', '000') => __encoding A64_control_hints_PACIA1716_HI_hints // PACIA1716_HI_hints
                        when ('0001', '010') => __encoding A64_control_hints_PACIB1716_HI_hints // PACIB1716_HI_hints
                        when ('0001', '100') => __encoding A64_control_hints_AUTIA1716_HI_hints // AUTIA1716_HI_hints
                        when ('0001', '110') => __encoding A64_control_hints_AUTIB1716_HI_hints // AUTIB1716_HI_hints
                        when ('0010', '000') => __encoding A64_control_hints_ESB_HI_hints // ESB_HI_hints
                        when ('0010', '001') => __encoding A64_control_hints_PSB_HC_hints // PSB_HC_hints
                        when ('0010', '010') => __encoding A64_control_hints_TSB_HC_hints // TSB_HC_hints
                        when ('0010', '011') => __encoding A64_control_hints_GCSB_HD_hints // GCSB_HD_hints
                        when ('0010', '100') => __encoding A64_control_hints_CSDB_HI_hints // CSDB_HI_hints
                        when ('0010', '110') => __encoding A64_control_hints_CLRBHB_HI_hints // CLRBHB_HI_hints
                        when ('0011', '000') => __encoding A64_control_hints_PACIA1716_HI_hints // PACIAZ_HI_hints
                        when ('0011', '001') => __encoding A64_control_hints_PACIA1716_HI_hints // PACIASP_HI_hints
                        when ('0011', '010') => __encoding A64_control_hints_PACIB1716_HI_hints // PACIBZ_HI_hints
                        when ('0011', '011') => __encoding A64_control_hints_PACIB1716_HI_hints // PACIBSP_HI_hints
                        when ('0011', '100') => __encoding A64_control_hints_AUTIA1716_HI_hints // AUTIAZ_HI_hints
                        when ('0011', '101') => __encoding A64_control_hints_AUTIA1716_HI_hints // AUTIASP_HI_hints
                        when ('0011', '110') => __encoding A64_control_hints_AUTIB1716_HI_hints // AUTIBZ_HI_hints
                        when ('0011', '111') => __encoding A64_control_hints_AUTIB1716_HI_hints // AUTIBSP_HI_hints
                        when ('0100', 'xx0') => __encoding A64_control_hints_BTI_HB_hints // BTI_HB_hints
                        when ('0100', '111') => __encoding A64_control_hints_PACM_HI_hints // PACM_HI_hints
                        when ('0101', '000') => __encoding A64_control_hints_CHKFEAT_HF_hints // CHKFEAT_HF_hints
                when ('110', _, '01000000110010', _, !'11111') => __UNPREDICTABLE
                when ('110', _, '01000000110011', _, _) => // barriers
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (CRm, op2, Rt) of
                        when (_, _, '0xxxx') => __UNALLOCATED
                        when (_, _, '10xxx') => __UNALLOCATED
                        when (_, _, '110xx') => __UNALLOCATED
                        when (_, _, '1110x') => __UNALLOCATED
                        when (_, _, '11110') => __UNALLOCATED
                        when (_, '010', '11111') => __encoding A64_control_barriers_CLREX_BN_barriers // CLREX_BN_barriers
                        when (_, '100', '11111') => __encoding A64_control_barriers_DSB_BO_barriers // DSB_BO_barriers
                        when (_, '101', '11111') => __encoding A64_control_barriers_DMB_BO_barriers // DMB_BO_barriers
                        when (_, '110', '11111') => __encoding A64_control_barriers_ISB_BI_barriers // ISB_BI_barriers
                        when (_, '111', '11111') => __encoding A64_control_barriers_SB_only_barriers // SB_only_barriers
                        when ('xxx1', '011', '11111') => __UNALLOCATED
                        when ('xx0x', '00x', '11111') => __UNALLOCATED
                        when ('xx1x', '000', '11111') => __UNALLOCATED
                        when ('xx10', '001', '11111') => __encoding A64_control_barriers_DSB_BOn_barriers // DSB_BOn_barriers
                        when ('xx10', '011', '11111') => __UNALLOCATED
                        when ('xx11', '001', '11111') => __UNALLOCATED
                        when ('0000', '011', '11111') => __encoding A64_control_barriers_TCOMMIT_only_barriers // TCOMMIT_only_barriers
                        when ('0100', '011', '11111') => __UNALLOCATED
                        when ('1x00', '011', '11111') => __UNALLOCATED
                when ('110', _, '0100000xxx0100', _, _) => // pstate
                    __field op1 16 +: 3
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (op1, op2, Rt) of
                        when (_, _, '0xxxx') => __UNALLOCATED
                        when (_, _, '10xxx') => __UNALLOCATED
                        when (_, _, '110xx') => __UNALLOCATED
                        when (_, _, '1110x') => __UNALLOCATED
                        when (_, _, '11110') => __UNALLOCATED
                        when (_, _, '11111') => __encoding A64_control_pstate_MSR_SI_pstate // MSR_SI_pstate
                        when ('000', '000', '11111') => __encoding A64_control_pstate_CFINV_M_pstate // CFINV_M_pstate
                        when ('000', '001', '11111') => __encoding A64_control_pstate_XAFLAG_M_pstate // XAFLAG_M_pstate
                        when ('000', '010', '11111') => __encoding A64_control_pstate_AXFLAG_M_pstate // AXFLAG_M_pstate
                when ('110', _, '0100100xxxxxxx', _, _) => // systemresult
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (op1, CRn, CRm, op2) of
                        when ('00x', _, _, _) => __UNALLOCATED
                        when ('010', _, _, _) => __UNALLOCATED
                        when ('011', '000x', _, _) => __UNALLOCATED
                        when ('011', '0010', _, _) => __UNALLOCATED
                        when ('011', '0011', '000x', '00x') => __UNALLOCATED
                        when ('011', '0011', '000x', '010') => __UNALLOCATED
                        when ('011', '0011', '000x', '1xx') => __UNALLOCATED
                        when ('011', '0011', '0000', '011') => __encoding A64_control_systemresult_TSTART_BR_systemresult // TSTART_BR_systemresult
                        when ('011', '0011', '0001', '011') => __encoding A64_control_systemresult_TTEST_BR_systemresult // TTEST_BR_systemresult
                        when ('011', '0011', '001x', _) => __UNALLOCATED
                        when ('011', '0011', '01xx', _) => __UNALLOCATED
                        when ('011', '0011', '1xxx', _) => __UNALLOCATED
                        when ('011', '01xx', _, _) => __UNALLOCATED
                        when ('011', '1xxx', _, _) => __UNALLOCATED
                        when ('1xx', _, _, _) => __UNALLOCATED
                when ('110', _, '0100x01xxxxxxx', _, _) => // systeminstrs
                    __field L 21 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding A64_control_systeminstrs_SYS_CR_systeminstrs // SYS_CR_systeminstrs
                        when ('1') => __encoding A64_control_systeminstrs_SYSL_RC_systeminstrs // SYSL_RC_systeminstrs
                when ('110', _, '0100x1xxxxxxxx', _, _) => // systemmove
                    __field L 21 +: 1
                    __field o0 19 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding A64_control_systemmove_MSR_SR_systemmove // MSR_SR_systemmove
                        when ('1') => __encoding A64_control_systemmove_MRS_RS_systemmove // MRS_RS_systemmove
                when ('110', _, '0101x01xxxxxxx', _, _) => // syspairinstrs
                    __field L 21 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding A64_control_syspairinstrs_SYSP_CR_syspairinstrs // SYSP_CR_syspairinstrs
                        when ('1') => __UNALLOCATED
                when ('110', _, '0101x1xxxxxxxx', _, _) => // systemmovepr
                    __field L 21 +: 1
                    __field o0 19 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding A64_control_systemmovepr_MSRR_SR_systemmovepr // MSRR_SR_systemmovepr
                        when ('1') => __encoding A64_control_systemmovepr_MRRS_RS_systemmovepr // MRRS_RS_systemmovepr
                when ('110', _, '1xxxxxxxxxxxxx', _, _) => // branch_reg
                    __field opc 21 +: 4
                    __field op2 16 +: 5
                    __field op3 10 +: 6
                    __field Rn 5 +: 5
                    __field op4 0 +: 5
                    case (opc, op2, op3, Rn, op4) of
                        when (_, !'11111', _, _, _) => __UNALLOCATED
                        when ('0000', '11111', '000000', _, !'00000') => __UNALLOCATED
                        when ('0000', '11111', '000000', _, '00000') => __encoding A64_control_branch_reg_BR_64_branch_reg // BR_64_branch_reg
                        when ('0000', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0000', '11111', '000010', _, !'11111') => __UNALLOCATED
                        when ('0000', '11111', '000010', _, '11111') => __encoding A64_control_branch_reg_BRAAZ_64_branch_reg // BRAAZ_64_branch_reg
                        when ('0000', '11111', '000011', _, !'11111') => __UNALLOCATED
                        when ('0000', '11111', '000011', _, '11111') => __encoding A64_control_branch_reg_BRAAZ_64_branch_reg // BRABZ_64_branch_reg
                        when ('0000', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('0000', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('0000', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('0000', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('0001', '11111', '000000', _, !'00000') => __UNALLOCATED
                        when ('0001', '11111', '000000', _, '00000') => __encoding A64_control_branch_reg_BLR_64_branch_reg // BLR_64_branch_reg
                        when ('0001', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0001', '11111', '000010', _, !'11111') => __UNALLOCATED
                        when ('0001', '11111', '000010', _, '11111') => __encoding A64_control_branch_reg_BLRAAZ_64_branch_reg // BLRAAZ_64_branch_reg
                        when ('0001', '11111', '000011', _, !'11111') => __UNALLOCATED
                        when ('0001', '11111', '000011', _, '11111') => __encoding A64_control_branch_reg_BLRAAZ_64_branch_reg // BLRABZ_64_branch_reg
                        when ('0001', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('0001', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('0001', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('0001', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('0010', '11111', '000000', _, !'00000') => __UNALLOCATED
                        when ('0010', '11111', '000000', _, '00000') => __encoding A64_control_branch_reg_RET_64R_branch_reg // RET_64R_branch_reg
                        when ('0010', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0010', '11111', '000010', !'11111', !'11111') => __UNALLOCATED
                        when ('0010', '11111', '000010', !'11111', '11111') => __UNALLOCATED
                        when ('0010', '11111', '000010', '11111', !'11111') => __UNALLOCATED
                        when ('0010', '11111', '000010', '11111', '11111') => __encoding A64_control_branch_reg_RETAA_64E_branch_reg // RETAA_64E_branch_reg
                        when ('0010', '11111', '000010', '11111', !'11111') => __encoding A64_control_branch_reg_RETAASPPC_64M_branch_reg // RETAASPPC_64M_branch_reg
                        when ('0010', '11111', '000011', !'11111', !'11111') => __UNALLOCATED
                        when ('0010', '11111', '000011', !'11111', '11111') => __UNALLOCATED
                        when ('0010', '11111', '000011', '11111', !'11111') => __UNALLOCATED
                        when ('0010', '11111', '000011', '11111', '11111') => __encoding A64_control_branch_reg_RETAA_64E_branch_reg // RETAB_64E_branch_reg
                        when ('0010', '11111', '000011', '11111', !'11111') => __encoding A64_control_branch_reg_RETAASPPC_64M_branch_reg // RETABSPPC_64M_branch_reg
                        when ('0010', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('0010', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('0010', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('0010', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('0011', '11111', _, _, _) => __UNALLOCATED
                        when ('0100', '11111', '000000', !'11111', _) => __UNALLOCATED
                        when ('0100', '11111', '000000', '11111', !'00000') => __UNALLOCATED
                        when ('0100', '11111', '000000', '11111', '00000') => __encoding A64_control_branch_reg_ERET_64E_branch_reg // ERET_64E_branch_reg
                        when ('0100', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0100', '11111', '000010', !'11111', !'11111') => __UNALLOCATED
                        when ('0100', '11111', '000010', !'11111', '11111') => __UNALLOCATED
                        when ('0100', '11111', '000010', '11111', !'11111') => __UNALLOCATED
                        when ('0100', '11111', '000010', '11111', '11111') => __encoding A64_control_branch_reg_ERETAA_64E_branch_reg // ERETAA_64E_branch_reg
                        when ('0100', '11111', '000011', !'11111', !'11111') => __UNALLOCATED
                        when ('0100', '11111', '000011', !'11111', '11111') => __UNALLOCATED
                        when ('0100', '11111', '000011', '11111', !'11111') => __UNALLOCATED
                        when ('0100', '11111', '000011', '11111', '11111') => __encoding A64_control_branch_reg_ERETAA_64E_branch_reg // ERETAB_64E_branch_reg
                        when ('0100', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('0100', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('0100', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('0100', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('0101', '11111', !'000000', _, _) => __UNALLOCATED
                        when ('0101', '11111', '000000', !'11111', _) => __UNALLOCATED
                        when ('0101', '11111', '000000', '11111', !'00000') => __UNALLOCATED
                        when ('0101', '11111', '000000', '11111', '00000') => __encoding A64_control_branch_reg_DRPS_64E_branch_reg // DRPS_64E_branch_reg
                        when ('011x', '11111', _, _, _) => __UNALLOCATED
                        when ('1000', '11111', '00000x', _, _) => __UNALLOCATED
                        when ('1000', '11111', '000010', _, _) => __encoding A64_control_branch_reg_BRAAZ_64_branch_reg // BRAA_64P_branch_reg
                        when ('1000', '11111', '000011', _, _) => __encoding A64_control_branch_reg_BRAAZ_64_branch_reg // BRAB_64P_branch_reg
                        when ('1000', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('1000', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('1000', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('1000', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('1001', '11111', '00000x', _, _) => __UNALLOCATED
                        when ('1001', '11111', '000010', _, _) => __encoding A64_control_branch_reg_BLRAAZ_64_branch_reg // BLRAA_64P_branch_reg
                        when ('1001', '11111', '000011', _, _) => __encoding A64_control_branch_reg_BLRAAZ_64_branch_reg // BLRAB_64P_branch_reg
                        when ('1001', '11111', '0001xx', _, _) => __UNALLOCATED
                        when ('1001', '11111', '001xxx', _, _) => __UNALLOCATED
                        when ('1001', '11111', '01xxxx', _, _) => __UNALLOCATED
                        when ('1001', '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('101x', '11111', _, _, _) => __UNALLOCATED
                        when ('11xx', '11111', _, _, _) => __UNALLOCATED
                when ('x00', _, _, _, _) => // branch_imm
                    __field op 31 +: 1
                    __field imm26 0 +: 26
                    case (op) of
                        when ('0') => __encoding A64_control_branch_imm_B_only_branch_imm // B_only_branch_imm
                        when ('1') => __encoding A64_control_branch_imm_BL_only_branch_imm // BL_only_branch_imm
                when ('x01', _, '0xxxxxxxxxxxxx', _, _) => // compbranch
                    __field sf 31 +: 1
                    __field op 24 +: 1
                    __field imm19 5 +: 19
                    __field Rt 0 +: 5
                    case (sf, op) of
                        when ('0', '0') => __encoding A64_control_compbranch_CBZ_32_compbranch // CBZ_32_compbranch
                        when ('0', '1') => __encoding A64_control_compbranch_CBNZ_32_compbranch // CBNZ_32_compbranch
                        when ('1', '0') => __encoding A64_control_compbranch_CBZ_32_compbranch // CBZ_64_compbranch
                        when ('1', '1') => __encoding A64_control_compbranch_CBNZ_32_compbranch // CBNZ_64_compbranch
                when ('x01', _, '1xxxxxxxxxxxxx', _, _) => // testbranch
                    __field b5 31 +: 1
                    __field op 24 +: 1
                    __field b40 19 +: 5
                    __field imm14 5 +: 14
                    __field Rt 0 +: 5
                    case (op) of
                        when ('0') => __encoding A64_control_testbranch_TBZ_only_testbranch // TBZ_only_testbranch
                        when ('1') => __encoding A64_control_testbranch_TBNZ_only_testbranch // TBNZ_only_testbranch
                when ('x11', _, _, _, _) => __UNPREDICTABLE
        when (_, _, 'x101', _) =>
            // dpreg
            case (31 +: 1, 30 +: 1, 29 +: 1, 28 +: 1, 25 +: 3, 21 +: 4, 16 +: 5, 10 +: 6, 0 +: 10) of
                when (_, '0', _, '1', _, '0110', _, _, _) => // dp_2src
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field opcode 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, opcode) of
                        when (_, _, '1xxxxx') => __UNALLOCATED
                        when (_, '0', '00011x') => __UNALLOCATED
                        when ('0', '0', '0x11xx') => __UNALLOCATED
                        when ('0', '0', '000x0x') => __UNALLOCATED
                        when ('0', '0', '000010') => __encoding A64_dpreg_dp_2src_UDIV_32_dp_2src // UDIV_32_dp_2src
                        when ('0', '0', '000011') => __encoding A64_dpreg_dp_2src_SDIV_32_dp_2src // SDIV_32_dp_2src
                        when ('0', '0', '001000') => __encoding A64_dpreg_dp_2src_LSLV_32_dp_2src // LSLV_32_dp_2src
                        when ('0', '0', '001001') => __encoding A64_dpreg_dp_2src_LSRV_32_dp_2src // LSRV_32_dp_2src
                        when ('0', '0', '001010') => __encoding A64_dpreg_dp_2src_ASRV_32_dp_2src // ASRV_32_dp_2src
                        when ('0', '0', '001011') => __encoding A64_dpreg_dp_2src_RORV_32_dp_2src // RORV_32_dp_2src
                        when ('0', '0', '010x11') => __UNALLOCATED
                        when ('0', '0', '010000') => __encoding A64_dpreg_dp_2src_CRC32B_32C_dp_2src // CRC32B_32C_dp_2src
                        when ('0', '0', '010001') => __encoding A64_dpreg_dp_2src_CRC32B_32C_dp_2src // CRC32H_32C_dp_2src
                        when ('0', '0', '010010') => __encoding A64_dpreg_dp_2src_CRC32B_32C_dp_2src // CRC32W_32C_dp_2src
                        when ('0', '0', '010100') => __encoding A64_dpreg_dp_2src_CRC32CB_32C_dp_2src // CRC32CB_32C_dp_2src
                        when ('0', '0', '010101') => __encoding A64_dpreg_dp_2src_CRC32CB_32C_dp_2src // CRC32CH_32C_dp_2src
                        when ('0', '0', '010110') => __encoding A64_dpreg_dp_2src_CRC32CB_32C_dp_2src // CRC32CW_32C_dp_2src
                        when ('0', '0', '011000') => __encoding A64_dpreg_dp_2src_SMAX_32_dp_2src // SMAX_32_dp_2src
                        when ('0', '0', '011001') => __encoding A64_dpreg_dp_2src_UMAX_32_dp_2src // UMAX_32_dp_2src
                        when ('0', '0', '011010') => __encoding A64_dpreg_dp_2src_SMIN_32_dp_2src // SMIN_32_dp_2src
                        when ('0', '0', '011011') => __encoding A64_dpreg_dp_2src_UMIN_32_dp_2src // UMIN_32_dp_2src
                        when ('0', '1', '0xxxxx') => __UNALLOCATED
                        when ('1', _, '000001') => __UNALLOCATED
                        when ('1', _, '01000x') => __UNALLOCATED
                        when ('1', '0', '000000') => __encoding A64_dpreg_dp_2src_SUBP_64S_dp_2src // SUBP_64S_dp_2src
                        when ('1', '0', '000010') => __encoding A64_dpreg_dp_2src_UDIV_32_dp_2src // UDIV_64_dp_2src
                        when ('1', '0', '000011') => __encoding A64_dpreg_dp_2src_SDIV_32_dp_2src // SDIV_64_dp_2src
                        when ('1', '0', '000100') => __encoding A64_dpreg_dp_2src_IRG_64I_dp_2src // IRG_64I_dp_2src
                        when ('1', '0', '000101') => __encoding A64_dpreg_dp_2src_GMI_64G_dp_2src // GMI_64G_dp_2src
                        when ('1', '0', '001000') => __encoding A64_dpreg_dp_2src_LSLV_32_dp_2src // LSLV_64_dp_2src
                        when ('1', '0', '001001') => __encoding A64_dpreg_dp_2src_LSRV_32_dp_2src // LSRV_64_dp_2src
                        when ('1', '0', '001010') => __encoding A64_dpreg_dp_2src_ASRV_32_dp_2src // ASRV_64_dp_2src
                        when ('1', '0', '001011') => __encoding A64_dpreg_dp_2src_RORV_32_dp_2src // RORV_64_dp_2src
                        when ('1', '0', '001100') => __encoding A64_dpreg_dp_2src_PACGA_64P_dp_2src // PACGA_64P_dp_2src
                        when ('1', '0', '001101') => __UNALLOCATED
                        when ('1', '0', '00111x') => __UNALLOCATED
                        when ('1', '0', '010x10') => __UNALLOCATED
                        when ('1', '0', '010011') => __encoding A64_dpreg_dp_2src_CRC32B_32C_dp_2src // CRC32X_64C_dp_2src
                        when ('1', '0', '01010x') => __UNALLOCATED
                        when ('1', '0', '010111') => __encoding A64_dpreg_dp_2src_CRC32CB_32C_dp_2src // CRC32CX_64C_dp_2src
                        when ('1', '0', '011000') => __encoding A64_dpreg_dp_2src_SMAX_32_dp_2src // SMAX_64_dp_2src
                        when ('1', '0', '011001') => __encoding A64_dpreg_dp_2src_UMAX_32_dp_2src // UMAX_64_dp_2src
                        when ('1', '0', '011010') => __encoding A64_dpreg_dp_2src_SMIN_32_dp_2src // SMIN_64_dp_2src
                        when ('1', '0', '011011') => __encoding A64_dpreg_dp_2src_UMIN_32_dp_2src // UMIN_64_dp_2src
                        when ('1', '0', '0111xx') => __UNALLOCATED
                        when ('1', '1', '0x001x') => __UNALLOCATED
                        when ('1', '1', '0x01xx') => __UNALLOCATED
                        when ('1', '1', '0x1xxx') => __UNALLOCATED
                        when ('1', '1', '000000') => __encoding A64_dpreg_dp_2src_SUBPS_64S_dp_2src // SUBPS_64S_dp_2src
                when (_, '1', _, '1', _, '0110', _, _, _) => // dp_1src
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field opcode2 16 +: 5
                    __field opcode 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, opcode2, opcode, Rn, Rd) of
                        when (_, '0', '00000', '001001', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '00101x', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '0011xx', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '01xxxx', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '1xxxxx', _, _) => __UNALLOCATED
                        when (_, '0', '0001x', _, _, _) => __UNALLOCATED
                        when (_, '0', '001xx', _, _, _) => __UNALLOCATED
                        when (_, '0', '01xxx', _, _, _) => __UNALLOCATED
                        when (_, '0', '1xxxx', _, _, _) => __UNALLOCATED
                        when (_, '1', _, _, _, _) => __UNALLOCATED
                        when ('0', '0', '00000', '000000', _, _) => __encoding A64_dpreg_dp_1src_RBIT_32_dp_1src // RBIT_32_dp_1src
                        when ('0', '0', '00000', '000001', _, _) => __encoding A64_dpreg_dp_1src_REV16_32_dp_1src // REV16_32_dp_1src
                        when ('0', '0', '00000', '000010', _, _) => __encoding A64_dpreg_dp_1src_REV_32_dp_1src // REV_32_dp_1src
                        when ('0', '0', '00000', '000011', _, _) => __UNALLOCATED
                        when ('0', '0', '00000', '000100', _, _) => __encoding A64_dpreg_dp_1src_CLZ_32_dp_1src // CLZ_32_dp_1src
                        when ('0', '0', '00000', '000101', _, _) => __encoding A64_dpreg_dp_1src_CLS_32_dp_1src // CLS_32_dp_1src
                        when ('0', '0', '00000', '000110', _, _) => __encoding A64_dpreg_dp_1src_CTZ_32_dp_1src // CTZ_32_dp_1src
                        when ('0', '0', '00000', '000111', _, _) => __encoding A64_dpreg_dp_1src_CNT_32_dp_1src // CNT_32_dp_1src
                        when ('0', '0', '00000', '001000', _, _) => __encoding A64_dpreg_dp_1src_ABS_32_dp_1src // ABS_32_dp_1src
                        when ('0', '0', '00001', _, _, _) => __UNALLOCATED
                        when ('1', '0', '00000', '000000', _, _) => __encoding A64_dpreg_dp_1src_RBIT_32_dp_1src // RBIT_64_dp_1src
                        when ('1', '0', '00000', '000001', _, _) => __encoding A64_dpreg_dp_1src_REV16_32_dp_1src // REV16_64_dp_1src
                        when ('1', '0', '00000', '000010', _, _) => __encoding A64_dpreg_dp_1src_REV32_64_dp_1src // REV32_64_dp_1src
                        when ('1', '0', '00000', '000011', _, _) => __encoding A64_dpreg_dp_1src_REV_32_dp_1src // REV_64_dp_1src
                        when ('1', '0', '00000', '000100', _, _) => __encoding A64_dpreg_dp_1src_CLZ_32_dp_1src // CLZ_64_dp_1src
                        when ('1', '0', '00000', '000101', _, _) => __encoding A64_dpreg_dp_1src_CLS_32_dp_1src // CLS_64_dp_1src
                        when ('1', '0', '00000', '000110', _, _) => __encoding A64_dpreg_dp_1src_CTZ_32_dp_1src // CTZ_64_dp_1src
                        when ('1', '0', '00000', '000111', _, _) => __encoding A64_dpreg_dp_1src_CNT_32_dp_1src // CNT_64_dp_1src
                        when ('1', '0', '00000', '001000', _, _) => __encoding A64_dpreg_dp_1src_ABS_32_dp_1src // ABS_64_dp_1src
                        when ('1', '0', '00001', '000000', _, _) => __encoding A64_dpreg_dp_1src_PACIA_64P_dp_1src // PACIA_64P_dp_1src
                        when ('1', '0', '00001', '000001', _, _) => __encoding A64_dpreg_dp_1src_PACIB_64P_dp_1src // PACIB_64P_dp_1src
                        when ('1', '0', '00001', '000010', _, _) => __encoding A64_dpreg_dp_1src_PACDA_64P_dp_1src // PACDA_64P_dp_1src
                        when ('1', '0', '00001', '000011', _, _) => __encoding A64_dpreg_dp_1src_PACDB_64P_dp_1src // PACDB_64P_dp_1src
                        when ('1', '0', '00001', '000100', _, _) => __encoding A64_dpreg_dp_1src_AUTIA_64P_dp_1src // AUTIA_64P_dp_1src
                        when ('1', '0', '00001', '000101', _, _) => __encoding A64_dpreg_dp_1src_AUTIB_64P_dp_1src // AUTIB_64P_dp_1src
                        when ('1', '0', '00001', '000110', _, _) => __encoding A64_dpreg_dp_1src_AUTDA_64P_dp_1src // AUTDA_64P_dp_1src
                        when ('1', '0', '00001', '000111', _, _) => __encoding A64_dpreg_dp_1src_AUTDB_64P_dp_1src // AUTDB_64P_dp_1src
                        when ('1', '0', '00001', '001000', '11111', _) => __encoding A64_dpreg_dp_1src_PACIA_64P_dp_1src // PACIZA_64Z_dp_1src
                        when ('1', '0', '00001', '001001', '11111', _) => __encoding A64_dpreg_dp_1src_PACIB_64P_dp_1src // PACIZB_64Z_dp_1src
                        when ('1', '0', '00001', '001010', '11111', _) => __encoding A64_dpreg_dp_1src_PACDA_64P_dp_1src // PACDZA_64Z_dp_1src
                        when ('1', '0', '00001', '001011', '11111', _) => __encoding A64_dpreg_dp_1src_PACDB_64P_dp_1src // PACDZB_64Z_dp_1src
                        when ('1', '0', '00001', '001100', '11111', _) => __encoding A64_dpreg_dp_1src_AUTIA_64P_dp_1src // AUTIZA_64Z_dp_1src
                        when ('1', '0', '00001', '001101', '11111', _) => __encoding A64_dpreg_dp_1src_AUTIB_64P_dp_1src // AUTIZB_64Z_dp_1src
                        when ('1', '0', '00001', '001110', '11111', _) => __encoding A64_dpreg_dp_1src_AUTDA_64P_dp_1src // AUTDZA_64Z_dp_1src
                        when ('1', '0', '00001', '001111', '11111', _) => __encoding A64_dpreg_dp_1src_AUTDB_64P_dp_1src // AUTDZB_64Z_dp_1src
                        when ('1', '0', '00001', '010000', '11111', _) => __encoding A64_dpreg_dp_1src_XPACD_64Z_dp_1src // XPACI_64Z_dp_1src
                        when ('1', '0', '00001', '010001', '11111', _) => __encoding A64_dpreg_dp_1src_XPACD_64Z_dp_1src // XPACD_64Z_dp_1src
                        when ('1', '0', '00001', '01001x', _, _) => __UNALLOCATED
                        when ('1', '0', '00001', '0101xx', _, _) => __UNALLOCATED
                        when ('1', '0', '00001', '011xxx', _, _) => __UNALLOCATED
                        when ('1', '0', '00001', '100000', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACNBIASPPC_64LR_dp_1src // PACNBIASPPC_64LR_dp_1src
                        when ('1', '0', '00001', '100001', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACNBIBSPPC_64LR_dp_1src // PACNBIBSPPC_64LR_dp_1src
                        when ('1', '0', '00001', '100010', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACIA171615_64LR_dp_1src // PACIA171615_64LR_dp_1src
                        when ('1', '0', '00001', '100011', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACIB171615_64LR_dp_1src // PACIB171615_64LR_dp_1src
                        when ('1', '0', '00001', '100100', _, '11110') => __encoding A64_dpreg_dp_1src_AUTIASPPC_64LRR_dp_1src // AUTIASPPC_64LRR_dp_1src
                        when ('1', '0', '00001', '100101', _, '11110') => __encoding A64_dpreg_dp_1src_AUTIBSPPC_64LRR_dp_1src // AUTIBSPPC_64LRR_dp_1src
                        when ('1', '0', '00001', '101000', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACIASPPC_64LR_dp_1src // PACIASPPC_64LR_dp_1src
                        when ('1', '0', '00001', '101001', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACIBSPPC_64LR_dp_1src // PACIBSPPC_64LR_dp_1src
                        when ('1', '0', '00001', '101110', '11111', '11110') => __encoding A64_dpreg_dp_1src_AUTIA171615_64LR_dp_1src // AUTIA171615_64LR_dp_1src
                        when ('1', '0', '00001', '101111', '11111', '11110') => __encoding A64_dpreg_dp_1src_AUTIB171615_64LR_dp_1src // AUTIB171615_64LR_dp_1src
                when (_, _, _, '0', _, '0xxx', _, _, _) => // log_shift
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field shift 22 +: 2
                    __field N 21 +: 1
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N) of
                        when ('0', '00', '0') => __encoding A64_dpreg_log_shift_AND_32_log_shift // AND_32_log_shift
                        when ('0', '00', '1') => __encoding A64_dpreg_log_shift_BIC_32_log_shift // BIC_32_log_shift
                        when ('0', '01', '0') => __encoding A64_dpreg_log_shift_ORR_32_log_shift // ORR_32_log_shift
                        when ('0', '01', '1') => __encoding A64_dpreg_log_shift_ORN_32_log_shift // ORN_32_log_shift
                        when ('0', '10', '0') => __encoding A64_dpreg_log_shift_EOR_32_log_shift // EOR_32_log_shift
                        when ('0', '10', '1') => __encoding A64_dpreg_log_shift_EON_32_log_shift // EON_32_log_shift
                        when ('0', '11', '0') => __encoding A64_dpreg_log_shift_ANDS_32_log_shift // ANDS_32_log_shift
                        when ('0', '11', '1') => __encoding A64_dpreg_log_shift_BICS_32_log_shift // BICS_32_log_shift
                        when ('1', '00', '0') => __encoding A64_dpreg_log_shift_AND_32_log_shift // AND_64_log_shift
                        when ('1', '00', '1') => __encoding A64_dpreg_log_shift_BIC_32_log_shift // BIC_64_log_shift
                        when ('1', '01', '0') => __encoding A64_dpreg_log_shift_ORR_32_log_shift // ORR_64_log_shift
                        when ('1', '01', '1') => __encoding A64_dpreg_log_shift_ORN_32_log_shift // ORN_64_log_shift
                        when ('1', '10', '0') => __encoding A64_dpreg_log_shift_EOR_32_log_shift // EOR_64_log_shift
                        when ('1', '10', '1') => __encoding A64_dpreg_log_shift_EON_32_log_shift // EON_64_log_shift
                        when ('1', '11', '0') => __encoding A64_dpreg_log_shift_ANDS_32_log_shift // ANDS_64_log_shift
                        when ('1', '11', '1') => __encoding A64_dpreg_log_shift_BICS_32_log_shift // BICS_64_log_shift
                when (_, _, _, '0', _, '1xx0', _, _, _) => // addsub_shift
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field shift 22 +: 2
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', '0', '0') => __encoding A64_dpreg_addsub_shift_ADD_32_addsub_shift // ADD_32_addsub_shift
                        when ('0', '0', '1') => __encoding A64_dpreg_addsub_shift_ADDS_32_addsub_shift // ADDS_32_addsub_shift
                        when ('0', '1', '0') => __encoding A64_dpreg_addsub_shift_SUB_32_addsub_shift // SUB_32_addsub_shift
                        when ('0', '1', '1') => __encoding A64_dpreg_addsub_shift_SUBS_32_addsub_shift // SUBS_32_addsub_shift
                        when ('1', '0', '0') => __encoding A64_dpreg_addsub_shift_ADD_32_addsub_shift // ADD_64_addsub_shift
                        when ('1', '0', '1') => __encoding A64_dpreg_addsub_shift_ADDS_32_addsub_shift // ADDS_64_addsub_shift
                        when ('1', '1', '0') => __encoding A64_dpreg_addsub_shift_SUB_32_addsub_shift // SUB_64_addsub_shift
                        when ('1', '1', '1') => __encoding A64_dpreg_addsub_shift_SUBS_32_addsub_shift // SUBS_64_addsub_shift
                when (_, _, _, '0', _, '1xx1', _, _, _) => // addsub_ext
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opt 22 +: 2
                    __field Rm 16 +: 5
                    __field option 13 +: 3
                    __field imm3 10 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, opt) of
                        when (_, _, _, '01') => __UNALLOCATED
                        when (_, _, _, '1x') => __UNALLOCATED
                        when ('0', '0', '0', '00') => __encoding A64_dpreg_addsub_ext_ADD_32_addsub_ext // ADD_32_addsub_ext
                        when ('0', '0', '1', '00') => __encoding A64_dpreg_addsub_ext_ADDS_32S_addsub_ext // ADDS_32S_addsub_ext
                        when ('0', '1', '0', '00') => __encoding A64_dpreg_addsub_ext_SUB_32_addsub_ext // SUB_32_addsub_ext
                        when ('0', '1', '1', '00') => __encoding A64_dpreg_addsub_ext_SUBS_32S_addsub_ext // SUBS_32S_addsub_ext
                        when ('1', '0', '0', '00') => __encoding A64_dpreg_addsub_ext_ADD_32_addsub_ext // ADD_64_addsub_ext
                        when ('1', '0', '1', '00') => __encoding A64_dpreg_addsub_ext_ADDS_32S_addsub_ext // ADDS_64S_addsub_ext
                        when ('1', '1', '0', '00') => __encoding A64_dpreg_addsub_ext_SUB_32_addsub_ext // SUB_64_addsub_ext
                        when ('1', '1', '1', '00') => __encoding A64_dpreg_addsub_ext_SUBS_32S_addsub_ext // SUBS_64S_addsub_ext
                when (_, _, _, '1', _, '0000', _, '000000', _) => // addsub_carry
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', '0', '0') => __encoding A64_dpreg_addsub_carry_ADC_32_addsub_carry // ADC_32_addsub_carry
                        when ('0', '0', '1') => __encoding A64_dpreg_addsub_carry_ADCS_32_addsub_carry // ADCS_32_addsub_carry
                        when ('0', '1', '0') => __encoding A64_dpreg_addsub_carry_SBC_32_addsub_carry // SBC_32_addsub_carry
                        when ('0', '1', '1') => __encoding A64_dpreg_addsub_carry_SBCS_32_addsub_carry // SBCS_32_addsub_carry
                        when ('1', '0', '0') => __encoding A64_dpreg_addsub_carry_ADC_32_addsub_carry // ADC_64_addsub_carry
                        when ('1', '0', '1') => __encoding A64_dpreg_addsub_carry_ADCS_32_addsub_carry // ADCS_64_addsub_carry
                        when ('1', '1', '0') => __encoding A64_dpreg_addsub_carry_SBC_32_addsub_carry // SBC_64_addsub_carry
                        when ('1', '1', '1') => __encoding A64_dpreg_addsub_carry_SBCS_32_addsub_carry // SBCS_64_addsub_carry
                when (_, _, _, '1', _, '0000', _, '001xxx', _) => // addsub_pt
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field imm3 10 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', _, _) => __UNALLOCATED
                        when ('1', _, '1') => __UNALLOCATED
                        when ('1', '0', '0') => __encoding A64_dpreg_addsub_pt_ADDPT_64_addsub_pt // ADDPT_64_addsub_pt
                        when ('1', '1', '0') => __encoding A64_dpreg_addsub_pt_SUBPT_64_addsub_pt // SUBPT_64_addsub_pt
                when (_, _, _, '1', _, '0000', _, '011xxx', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, '100000', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, '1x1xxx', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, 'x00001', _) => // rmif
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field imm6 15 +: 6
                    __field Rn 5 +: 5
                    __field o2 4 +: 1
                    __field mask 0 +: 4
                    case (sf, op, S, o2) of
                        when ('0', _, _, _) => __UNALLOCATED
                        when ('1', '0', '0', _) => __UNALLOCATED
                        when ('1', '0', '1', '0') => __encoding A64_dpreg_rmif_RMIF_only_rmif // RMIF_only_rmif
                        when ('1', '0', '1', '1') => __UNALLOCATED
                        when ('1', '1', _, _) => __UNALLOCATED
                when (_, _, _, '1', _, '0000', _, 'x0010x', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, 'x10x0x', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, 'xx0010', _) => // setf
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opcode2 15 +: 6
                    __field sz 14 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field mask 0 +: 4
                    case (sf, op, S, opcode2, sz, o3, mask) of
                        when ('0', '0', '0', _, _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '0', '0xxx') => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '0', '10xx') => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '0', '1100') => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '0', '111x') => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '1', _) => __UNALLOCATED
                        when ('0', '0', '1', '000000', '0', '0', '1101') => __encoding A64_dpreg_setf_SETF8_only_setf // SETF8_only_setf
                        when ('0', '0', '1', '000000', '1', '0', '1101') => __encoding A64_dpreg_setf_SETF8_only_setf // SETF16_only_setf
                        when ('0', '0', '1', '000001', _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', '00001x', _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', '0001xx', _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', '001xxx', _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', '01xxxx', _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', '1xxxxx', _, _, _) => __UNALLOCATED
                        when ('0', '1', _, _, _, _, _) => __UNALLOCATED
                        when ('1', _, _, _, _, _, _) => __UNALLOCATED
                when (_, _, _, '1', _, '0000', _, 'xx0011', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, 'xx011x', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0010', _, 'xxxx0x', _) => // condcmp_reg
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field o2 10 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field nzcv 0 +: 4
                    case (sf, op, S, o2, o3) of
                        when (_, _, '0', _, _) => __UNALLOCATED
                        when (_, _, '1', '0', '1') => __UNALLOCATED
                        when (_, _, '1', '1', _) => __UNALLOCATED
                        when ('0', '0', '1', '0', '0') => __encoding A64_dpreg_condcmp_reg_CCMN_32_condcmp_reg // CCMN_32_condcmp_reg
                        when ('0', '1', '1', '0', '0') => __encoding A64_dpreg_condcmp_reg_CCMP_32_condcmp_reg // CCMP_32_condcmp_reg
                        when ('1', '0', '1', '0', '0') => __encoding A64_dpreg_condcmp_reg_CCMN_32_condcmp_reg // CCMN_64_condcmp_reg
                        when ('1', '1', '1', '0', '0') => __encoding A64_dpreg_condcmp_reg_CCMP_32_condcmp_reg // CCMP_64_condcmp_reg
                when (_, _, _, '1', _, '0010', _, 'xxxx1x', _) => // condcmp_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field imm5 16 +: 5
                    __field cond 12 +: 4
                    __field o2 10 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field nzcv 0 +: 4
                    case (sf, op, S, o2, o3) of
                        when (_, _, '0', _, _) => __UNALLOCATED
                        when (_, _, '1', '0', '1') => __UNALLOCATED
                        when (_, _, '1', '1', _) => __UNALLOCATED
                        when ('0', '0', '1', '0', '0') => __encoding A64_dpreg_condcmp_imm_CCMN_32_condcmp_imm // CCMN_32_condcmp_imm
                        when ('0', '1', '1', '0', '0') => __encoding A64_dpreg_condcmp_imm_CCMP_32_condcmp_imm // CCMP_32_condcmp_imm
                        when ('1', '0', '1', '0', '0') => __encoding A64_dpreg_condcmp_imm_CCMN_32_condcmp_imm // CCMN_64_condcmp_imm
                        when ('1', '1', '1', '0', '0') => __encoding A64_dpreg_condcmp_imm_CCMP_32_condcmp_imm // CCMP_64_condcmp_imm
                when (_, _, _, '1', _, '0100', _, _, _) => // condsel
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field op2 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, op2) of
                        when (_, _, '0', '1x') => __UNALLOCATED
                        when (_, _, '1', _) => __UNALLOCATED
                        when ('0', '0', '0', '00') => __encoding A64_dpreg_condsel_CSEL_32_condsel // CSEL_32_condsel
                        when ('0', '0', '0', '01') => __encoding A64_dpreg_condsel_CSINC_32_condsel // CSINC_32_condsel
                        when ('0', '1', '0', '00') => __encoding A64_dpreg_condsel_CSINV_32_condsel // CSINV_32_condsel
                        when ('0', '1', '0', '01') => __encoding A64_dpreg_condsel_CSNEG_32_condsel // CSNEG_32_condsel
                        when ('1', '0', '0', '00') => __encoding A64_dpreg_condsel_CSEL_32_condsel // CSEL_64_condsel
                        when ('1', '0', '0', '01') => __encoding A64_dpreg_condsel_CSINC_32_condsel // CSINC_64_condsel
                        when ('1', '1', '0', '00') => __encoding A64_dpreg_condsel_CSINV_32_condsel // CSINV_64_condsel
                        when ('1', '1', '0', '01') => __encoding A64_dpreg_condsel_CSNEG_32_condsel // CSNEG_64_condsel
                when (_, _, _, '1', _, '0xx1', _, _, _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '1xxx', _, _, _) => // dp_3src
                    __field sf 31 +: 1
                    __field op54 29 +: 2
                    __field op31 21 +: 3
                    __field Rm 16 +: 5
                    __field o0 15 +: 1
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op54, op31, o0) of
                        when (_, '00', '100', _) => __UNALLOCATED
                        when (_, '01', _, _) => __UNALLOCATED
                        when (_, '1x', _, _) => __UNALLOCATED
                        when ('0', '00', 'x01', _) => __UNALLOCATED
                        when ('0', '00', 'x1x', _) => __UNALLOCATED
                        when ('0', '00', '000', '0') => __encoding A64_dpreg_dp_3src_MADD_32A_dp_3src // MADD_32A_dp_3src
                        when ('0', '00', '000', '1') => __encoding A64_dpreg_dp_3src_MSUB_32A_dp_3src // MSUB_32A_dp_3src
                        when ('1', '00', 'x10', '1') => __UNALLOCATED
                        when ('1', '00', '000', '0') => __encoding A64_dpreg_dp_3src_MADD_32A_dp_3src // MADD_64A_dp_3src
                        when ('1', '00', '000', '1') => __encoding A64_dpreg_dp_3src_MSUB_32A_dp_3src // MSUB_64A_dp_3src
                        when ('1', '00', '001', '0') => __encoding A64_dpreg_dp_3src_SMADDL_64WA_dp_3src // SMADDL_64WA_dp_3src
                        when ('1', '00', '001', '1') => __encoding A64_dpreg_dp_3src_SMSUBL_64WA_dp_3src // SMSUBL_64WA_dp_3src
                        when ('1', '00', '010', '0') => __encoding A64_dpreg_dp_3src_SMULH_64_dp_3src // SMULH_64_dp_3src
                        when ('1', '00', '011', '0') => __encoding A64_dpreg_dp_3src_MADDPT_64A_dp_3src // MADDPT_64A_dp_3src
                        when ('1', '00', '011', '1') => __encoding A64_dpreg_dp_3src_MSUBPT_64A_dp_3src // MSUBPT_64A_dp_3src
                        when ('1', '00', '101', '0') => __encoding A64_dpreg_dp_3src_UMADDL_64WA_dp_3src // UMADDL_64WA_dp_3src
                        when ('1', '00', '101', '1') => __encoding A64_dpreg_dp_3src_UMSUBL_64WA_dp_3src // UMSUBL_64WA_dp_3src
                        when ('1', '00', '110', '0') => __encoding A64_dpreg_dp_3src_UMULH_64_dp_3src // UMULH_64_dp_3src
                        when ('1', '00', '111', _) => __UNALLOCATED
        when (_, _, 'x111', _) =>
            // simd_dp
            case (28 +: 4, 25 +: 3, 23 +: 2, 19 +: 4, 10 +: 9, 0 +: 10) of
                when ('0000', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0010', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0100', _, '0x', 'x101', '00xxxxx10', _) => // cryptoaes
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when ('00', '000xx') => __UNALLOCATED
                        when ('00', '00100') => __encoding A64_simd_dp_cryptoaes_AESE_B_cryptoaes // AESE_B_cryptoaes
                        when ('00', '00101') => __encoding A64_simd_dp_cryptoaes_AESD_B_cryptoaes // AESD_B_cryptoaes
                        when ('00', '00110') => __encoding A64_simd_dp_cryptoaes_AESMC_B_cryptoaes // AESMC_B_cryptoaes
                        when ('00', '00111') => __encoding A64_simd_dp_cryptoaes_AESIMC_B_cryptoaes // AESIMC_B_cryptoaes
                        when ('00', '01xxx') => __UNALLOCATED
                        when ('00', '1xxxx') => __UNALLOCATED
                        when ('01', _) => __UNALLOCATED
                        when ('1x', _) => __UNALLOCATED
                when ('0101', _, '0x', 'x0xx', 'xxx0xxx00', _) => // cryptosha3
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when ('00', '000') => __encoding A64_simd_dp_cryptosha3_SHA1C_QSV_cryptosha3 // SHA1C_QSV_cryptosha3
                        when ('00', '001') => __encoding A64_simd_dp_cryptosha3_SHA1P_QSV_cryptosha3 // SHA1P_QSV_cryptosha3
                        when ('00', '010') => __encoding A64_simd_dp_cryptosha3_SHA1M_QSV_cryptosha3 // SHA1M_QSV_cryptosha3
                        when ('00', '011') => __encoding A64_simd_dp_cryptosha3_SHA1SU0_VVV_cryptosha3 // SHA1SU0_VVV_cryptosha3
                        when ('00', '100') => __encoding A64_simd_dp_cryptosha3_SHA256H_QQV_cryptosha3 // SHA256H_QQV_cryptosha3
                        when ('00', '101') => __encoding A64_simd_dp_cryptosha3_SHA256H2_QQV_cryptosha3 // SHA256H2_QQV_cryptosha3
                        when ('00', '110') => __encoding A64_simd_dp_cryptosha3_SHA256SU1_VVV_cryptosha3 // SHA256SU1_VVV_cryptosha3
                        when ('00', '111') => __UNALLOCATED
                        when ('01', _) => __UNALLOCATED
                        when ('1x', _) => __UNALLOCATED
                when ('0101', _, '0x', 'x0xx', 'xxx0xxx10', _) => __UNPREDICTABLE
                when ('0101', _, '0x', 'x101', '00xxxxx10', _) => // cryptosha2
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when ('00', '00000') => __encoding A64_simd_dp_cryptosha2_SHA1H_SS_cryptosha2 // SHA1H_SS_cryptosha2
                        when ('00', '00001') => __encoding A64_simd_dp_cryptosha2_SHA1SU1_VV_cryptosha2 // SHA1SU1_VV_cryptosha2
                        when ('00', '00010') => __encoding A64_simd_dp_cryptosha2_SHA256SU0_VV_cryptosha2 // SHA256SU0_VV_cryptosha2
                        when ('00', '00011') => __UNALLOCATED
                        when ('00', '001xx') => __UNALLOCATED
                        when ('00', '01xxx') => __UNALLOCATED
                        when ('00', '1xxxx') => __UNALLOCATED
                        when ('01', _) => __UNALLOCATED
                        when ('1x', _) => __UNALLOCATED
                when ('0110', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0111', _, '0x', 'x0xx', 'xxx0xxxx0', _) => __UNPREDICTABLE
                when ('0111', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '00', '00xx', 'xxx0xxxx1', _) => // asisdone
                    __field op 29 +: 1
                    __field imm5 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (op, imm4) of
                        when ('0', '0000') => __encoding A64_simd_dp_asisdone_DUP_asisdone_only // DUP_asisdone_only
                        when ('0', '0001') => __UNALLOCATED
                        when ('0', '001x') => __UNALLOCATED
                        when ('0', '01xx') => __UNALLOCATED
                        when ('0', '1xxx') => __UNALLOCATED
                        when ('1', _) => __UNALLOCATED
                when ('01x1', _, '01', '00xx', 'xxx0xxxx1', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '0111', '00xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '10xx', 'xxx00xxx1', _) => // asisdsamefp16
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field Rm 16 +: 5
                    __field opcode 11 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, '00x') => __UNALLOCATED
                        when (_, '1', '011') => __UNALLOCATED
                        when ('0', _, 'x10') => __UNALLOCATED
                        when ('0', '0', '011') => __encoding A64_simd_dp_asisdsamefp16_FMULX_asisdsamefp16_only // FMULX_asisdsamefp16_only
                        when ('0', '0', '100') => __encoding A64_simd_dp_asisdsamefp16_FCMEQ_asisdsamefp16_only // FCMEQ_asisdsamefp16_only
                        when ('0', '0', '101') => __UNALLOCATED
                        when ('0', '0', '111') => __encoding A64_simd_dp_asisdsamefp16_FRECPS_asisdsamefp16_only // FRECPS_asisdsamefp16_only
                        when ('0', '1', '10x') => __UNALLOCATED
                        when ('0', '1', '111') => __encoding A64_simd_dp_asisdsamefp16_FRSQRTS_asisdsamefp16_only // FRSQRTS_asisdsamefp16_only
                        when ('1', _, '11x') => __UNALLOCATED
                        when ('1', '0', '01x') => __UNALLOCATED
                        when ('1', '0', '100') => __encoding A64_simd_dp_asisdsamefp16_FCMGE_asisdsamefp16_only // FCMGE_asisdsamefp16_only
                        when ('1', '0', '101') => __encoding A64_simd_dp_asisdsamefp16_FACGE_asisdsamefp16_only // FACGE_asisdsamefp16_only
                        when ('1', '1', '010') => __encoding A64_simd_dp_asisdsamefp16_FABD_asisdsamefp16_only // FABD_asisdsamefp16_only
                        when ('1', '1', '100') => __encoding A64_simd_dp_asisdsamefp16_FCMGT_asisdsamefp16_only // FCMGT_asisdsamefp16_only
                        when ('1', '1', '101') => __encoding A64_simd_dp_asisdsamefp16_FACGT_asisdsamefp16_only // FACGT_asisdsamefp16_only
                when ('01x1', _, '0x', '10xx', 'xxx01xxx1', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '1111', '00xxxxx10', _) => // asisdmiscfp16
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, 'x0xxx') => __UNALLOCATED
                        when (_, _, '1100x') => __UNALLOCATED
                        when (_, '0', '01xxx') => __UNALLOCATED
                        when (_, '1', '010xx') => __UNALLOCATED
                        when (_, '1', '11100') => __UNALLOCATED
                        when ('0', '0', '11010') => __encoding A64_simd_dp_asisdmiscfp16_FCVTNS_asisdmiscfp16_R // FCVTNS_asisdmiscfp16_R
                        when ('0', '0', '11011') => __encoding A64_simd_dp_asisdmiscfp16_FCVTMS_asisdmiscfp16_R // FCVTMS_asisdmiscfp16_R
                        when ('0', '0', '11100') => __encoding A64_simd_dp_asisdmiscfp16_FCVTAS_asisdmiscfp16_R // FCVTAS_asisdmiscfp16_R
                        when ('0', '0', '11101') => __encoding A64_simd_dp_asisdmiscfp16_SCVTF_asisdmiscfp16_R // SCVTF_asisdmiscfp16_R
                        when ('0', '0', '1111x') => __UNALLOCATED
                        when ('0', '1', '01100') => __encoding A64_simd_dp_asisdmiscfp16_FCMGT_asisdmiscfp16_FZ // FCMGT_asisdmiscfp16_FZ
                        when ('0', '1', '01101') => __encoding A64_simd_dp_asisdmiscfp16_FCMEQ_asisdmiscfp16_FZ // FCMEQ_asisdmiscfp16_FZ
                        when ('0', '1', '01110') => __encoding A64_simd_dp_asisdmiscfp16_FCMLT_asisdmiscfp16_FZ // FCMLT_asisdmiscfp16_FZ
                        when ('0', '1', '01111') => __UNALLOCATED
                        when ('0', '1', '11010') => __encoding A64_simd_dp_asisdmiscfp16_FCVTPS_asisdmiscfp16_R // FCVTPS_asisdmiscfp16_R
                        when ('0', '1', '11011') => __encoding A64_simd_dp_asisdmiscfp16_FCVTZS_asisdmiscfp16_R // FCVTZS_asisdmiscfp16_R
                        when ('0', '1', '11101') => __encoding A64_simd_dp_asisdmiscfp16_FRECPE_asisdmiscfp16_R // FRECPE_asisdmiscfp16_R
                        when ('0', '1', '11110') => __UNALLOCATED
                        when ('0', '1', '11111') => __encoding A64_simd_dp_asisdmiscfp16_FRECPX_asisdmiscfp16_R // FRECPX_asisdmiscfp16_R
                        when ('1', _, '1111x') => __UNALLOCATED
                        when ('1', '0', '11010') => __encoding A64_simd_dp_asisdmiscfp16_FCVTNU_asisdmiscfp16_R // FCVTNU_asisdmiscfp16_R
                        when ('1', '0', '11011') => __encoding A64_simd_dp_asisdmiscfp16_FCVTMU_asisdmiscfp16_R // FCVTMU_asisdmiscfp16_R
                        when ('1', '0', '11100') => __encoding A64_simd_dp_asisdmiscfp16_FCVTAU_asisdmiscfp16_R // FCVTAU_asisdmiscfp16_R
                        when ('1', '0', '11101') => __encoding A64_simd_dp_asisdmiscfp16_UCVTF_asisdmiscfp16_R // UCVTF_asisdmiscfp16_R
                        when ('1', '1', '01100') => __encoding A64_simd_dp_asisdmiscfp16_FCMGE_asisdmiscfp16_FZ // FCMGE_asisdmiscfp16_FZ
                        when ('1', '1', '01101') => __encoding A64_simd_dp_asisdmiscfp16_FCMLE_asisdmiscfp16_FZ // FCMLE_asisdmiscfp16_FZ
                        when ('1', '1', '0111x') => __UNALLOCATED
                        when ('1', '1', '11010') => __encoding A64_simd_dp_asisdmiscfp16_FCVTPU_asisdmiscfp16_R // FCVTPU_asisdmiscfp16_R
                        when ('1', '1', '11011') => __encoding A64_simd_dp_asisdmiscfp16_FCVTZU_asisdmiscfp16_R // FCVTZU_asisdmiscfp16_R
                        when ('1', '1', '11101') => __encoding A64_simd_dp_asisdmiscfp16_FRSQRTE_asisdmiscfp16_R // FRSQRTE_asisdmiscfp16_R
                when ('01x1', _, '0x', 'x0xx', 'xxx1xxxx0', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', 'x0xx', 'xxx1xxxx1', _) => // asisdsame2
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when ('0', _) => __UNALLOCATED
                        when ('1', '0000') => __encoding A64_simd_dp_asisdsame2_SQRDMLAH_asisdsame2_only // SQRDMLAH_asisdsame2_only
                        when ('1', '0001') => __encoding A64_simd_dp_asisdsame2_SQRDMLSH_asisdsame2_only // SQRDMLSH_asisdsame2_only
                        when ('1', '001x') => __UNALLOCATED
                        when ('1', '01xx') => __UNALLOCATED
                        when ('1', '1xxx') => __UNALLOCATED
                when ('01x1', _, '0x', 'x100', '00xxxxx10', _) => // asisdmisc
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '00x0x') => __UNALLOCATED
                        when (_, _, '1x000') => __UNALLOCATED
                        when (_, _, '10xx1') => __UNALLOCATED
                        when (_, _, '11001') => __UNALLOCATED
                        when (_, '0x', '01xxx') => __UNALLOCATED
                        when (_, '0x', '1111x') => __UNALLOCATED
                        when (_, '1x', '01111') => __UNALLOCATED
                        when (_, '1x', '11100') => __UNALLOCATED
                        when (_, '10', '010x1') => __UNALLOCATED
                        when (_, '10', '01000') => __UNALLOCATED
                        when ('0', _, 'x0x10') => __UNALLOCATED
                        when ('0', _, '00011') => __encoding A64_simd_dp_asisdmisc_SUQADD_asisdmisc_R // SUQADD_asisdmisc_R
                        when ('0', _, '00111') => __encoding A64_simd_dp_asisdmisc_SQABS_asisdmisc_R // SQABS_asisdmisc_R
                        when ('0', _, '10100') => __encoding A64_simd_dp_asisdmisc_SQXTN_asisdmisc_N // SQXTN_asisdmisc_N
                        when ('0', '0x', '11010') => __encoding A64_simd_dp_asisdmisc_FCVTNS_asisdmisc_R // FCVTNS_asisdmisc_R
                        when ('0', '0x', '11011') => __encoding A64_simd_dp_asisdmisc_FCVTMS_asisdmisc_R // FCVTMS_asisdmisc_R
                        when ('0', '0x', '11100') => __encoding A64_simd_dp_asisdmisc_FCVTAS_asisdmisc_R // FCVTAS_asisdmisc_R
                        when ('0', '0x', '11101') => __encoding A64_simd_dp_asisdmisc_SCVTF_asisdmisc_R // SCVTF_asisdmisc_R
                        when ('0', '1x', '01100') => __encoding A64_simd_dp_asisdmisc_FCMGT_asisdmisc_FZ // FCMGT_asisdmisc_FZ
                        when ('0', '1x', '01101') => __encoding A64_simd_dp_asisdmisc_FCMEQ_asisdmisc_FZ // FCMEQ_asisdmisc_FZ
                        when ('0', '1x', '01110') => __encoding A64_simd_dp_asisdmisc_FCMLT_asisdmisc_FZ // FCMLT_asisdmisc_FZ
                        when ('0', '1x', '11010') => __encoding A64_simd_dp_asisdmisc_FCVTPS_asisdmisc_R // FCVTPS_asisdmisc_R
                        when ('0', '1x', '11011') => __encoding A64_simd_dp_asisdmisc_FCVTZS_asisdmisc_R // FCVTZS_asisdmisc_R
                        when ('0', '1x', '11101') => __encoding A64_simd_dp_asisdmisc_FRECPE_asisdmisc_R // FRECPE_asisdmisc_R
                        when ('0', '1x', '11110') => __UNALLOCATED
                        when ('0', '1x', '11111') => __encoding A64_simd_dp_asisdmisc_FRECPX_asisdmisc_R // FRECPX_asisdmisc_R
                        when ('0', '10', '01010') => __UNALLOCATED
                        when ('0', '11', '01000') => __encoding A64_simd_dp_asisdmisc_CMGT_asisdmisc_Z // CMGT_asisdmisc_Z
                        when ('0', '11', '01001') => __encoding A64_simd_dp_asisdmisc_CMEQ_asisdmisc_Z // CMEQ_asisdmisc_Z
                        when ('0', '11', '01010') => __encoding A64_simd_dp_asisdmisc_CMLT_asisdmisc_Z // CMLT_asisdmisc_Z
                        when ('0', '11', '01011') => __encoding A64_simd_dp_asisdmisc_ABS_asisdmisc_R // ABS_asisdmisc_R
                        when ('1', _, '00x10') => __UNALLOCATED
                        when ('1', _, '00011') => __encoding A64_simd_dp_asisdmisc_USQADD_asisdmisc_R // USQADD_asisdmisc_R
                        when ('1', _, '00111') => __encoding A64_simd_dp_asisdmisc_SQNEG_asisdmisc_R // SQNEG_asisdmisc_R
                        when ('1', _, '10010') => __encoding A64_simd_dp_asisdmisc_SQXTUN_asisdmisc_N // SQXTUN_asisdmisc_N
                        when ('1', _, '10100') => __encoding A64_simd_dp_asisdmisc_UQXTN_asisdmisc_N // UQXTN_asisdmisc_N
                        when ('1', '0x', '11010') => __encoding A64_simd_dp_asisdmisc_FCVTNU_asisdmisc_R // FCVTNU_asisdmisc_R
                        when ('1', '0x', '11011') => __encoding A64_simd_dp_asisdmisc_FCVTMU_asisdmisc_R // FCVTMU_asisdmisc_R
                        when ('1', '0x', '11100') => __encoding A64_simd_dp_asisdmisc_FCVTAU_asisdmisc_R // FCVTAU_asisdmisc_R
                        when ('1', '0x', '11101') => __encoding A64_simd_dp_asisdmisc_UCVTF_asisdmisc_R // UCVTF_asisdmisc_R
                        when ('1', '00', '10110') => __UNALLOCATED
                        when ('1', '01', '10110') => __encoding A64_simd_dp_asisdmisc_FCVTXN_asisdmisc_N // FCVTXN_asisdmisc_N
                        when ('1', '1x', '01x10') => __UNALLOCATED
                        when ('1', '1x', '01100') => __encoding A64_simd_dp_asisdmisc_FCMGE_asisdmisc_FZ // FCMGE_asisdmisc_FZ
                        when ('1', '1x', '01101') => __encoding A64_simd_dp_asisdmisc_FCMLE_asisdmisc_FZ // FCMLE_asisdmisc_FZ
                        when ('1', '1x', '1x110') => __UNALLOCATED
                        when ('1', '1x', '11010') => __encoding A64_simd_dp_asisdmisc_FCVTPU_asisdmisc_R // FCVTPU_asisdmisc_R
                        when ('1', '1x', '11011') => __encoding A64_simd_dp_asisdmisc_FCVTZU_asisdmisc_R // FCVTZU_asisdmisc_R
                        when ('1', '1x', '11101') => __encoding A64_simd_dp_asisdmisc_FRSQRTE_asisdmisc_R // FRSQRTE_asisdmisc_R
                        when ('1', '1x', '11111') => __UNALLOCATED
                        when ('1', '11', '01000') => __encoding A64_simd_dp_asisdmisc_CMGE_asisdmisc_Z // CMGE_asisdmisc_Z
                        when ('1', '11', '01001') => __encoding A64_simd_dp_asisdmisc_CMLE_asisdmisc_Z // CMLE_asisdmisc_Z
                        when ('1', '11', '01011') => __encoding A64_simd_dp_asisdmisc_NEG_asisdmisc_R // NEG_asisdmisc_R
                when ('01x1', _, '0x', 'x110', '00xxxxx10', _) => // asisdpair
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, 'x0xxx') => __UNALLOCATED
                        when (_, _, '01110') => __UNALLOCATED
                        when (_, _, '111xx') => __UNALLOCATED
                        when (_, '10', '01101') => __UNALLOCATED
                        when ('0', 'x1', '011x1') => __UNALLOCATED
                        when ('0', 'x1', '01100') => __UNALLOCATED
                        when ('0', '0x', 'x10xx') => __UNALLOCATED
                        when ('0', '00', '01100') => __encoding A64_simd_dp_asisdpair_FMAXNMP_asisdpair_only_H // FMAXNMP_asisdpair_only_H
                        when ('0', '00', '01101') => __encoding A64_simd_dp_asisdpair_FADDP_asisdpair_only_H // FADDP_asisdpair_only_H
                        when ('0', '00', '01111') => __encoding A64_simd_dp_asisdpair_FMAXP_asisdpair_only_H // FMAXP_asisdpair_only_H
                        when ('0', '10', 'x10xx') => __UNALLOCATED
                        when ('0', '10', '01100') => __encoding A64_simd_dp_asisdpair_FMINNMP_asisdpair_only_H // FMINNMP_asisdpair_only_H
                        when ('0', '10', '01111') => __encoding A64_simd_dp_asisdpair_FMINP_asisdpair_only_H // FMINP_asisdpair_only_H
                        when ('0', '11', 'x1010') => __UNALLOCATED
                        when ('0', '11', '010x1') => __UNALLOCATED
                        when ('0', '11', '01000') => __UNALLOCATED
                        when ('0', '11', '1100x') => __UNALLOCATED
                        when ('0', '11', '11011') => __encoding A64_simd_dp_asisdpair_ADDP_asisdpair_only // ADDP_asisdpair_only
                        when ('1', _, 'x10xx') => __UNALLOCATED
                        when ('1', '0x', '01100') => __encoding A64_simd_dp_asisdpair_FMAXNMP_asisdpair_only_SD // FMAXNMP_asisdpair_only_SD
                        when ('1', '0x', '01101') => __encoding A64_simd_dp_asisdpair_FADDP_asisdpair_only_SD // FADDP_asisdpair_only_SD
                        when ('1', '0x', '01111') => __encoding A64_simd_dp_asisdpair_FMAXP_asisdpair_only_SD // FMAXP_asisdpair_only_SD
                        when ('1', '1x', '01100') => __encoding A64_simd_dp_asisdpair_FMINNMP_asisdpair_only_SD // FMINNMP_asisdpair_only_SD
                        when ('1', '1x', '01111') => __encoding A64_simd_dp_asisdpair_FMINP_asisdpair_only_SD // FMINP_asisdpair_only_SD
                        when ('1', '11', '01101') => __UNALLOCATED
                when ('01x1', _, '0x', 'x1xx', '01xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', 'x1xx', '1xxxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', 'x1xx', 'xxxxxxx00', _) => // asisddiff
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when ('0', '0xxx') => __UNALLOCATED
                        when ('0', '1xx0') => __UNALLOCATED
                        when ('0', '1001') => __encoding A64_simd_dp_asisddiff_SQDMLAL_asisddiff_only // SQDMLAL_asisddiff_only
                        when ('0', '1011') => __encoding A64_simd_dp_asisddiff_SQDMLSL_asisddiff_only // SQDMLSL_asisddiff_only
                        when ('0', '1101') => __encoding A64_simd_dp_asisddiff_SQDMULL_asisddiff_only // SQDMULL_asisddiff_only
                        when ('0', '1111') => __UNALLOCATED
                        when ('1', _) => __UNALLOCATED
                when ('01x1', _, '0x', 'x1xx', 'xxxxxxxx1', _) => // asisdsame
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, 'x0011') => __UNALLOCATED
                        when (_, _, '011x1') => __UNALLOCATED
                        when (_, _, '1010x') => __UNALLOCATED
                        when (_, _, '11001') => __UNALLOCATED
                        when (_, _, '11110') => __UNALLOCATED
                        when (_, 'x0', '0x1x0') => __UNALLOCATED
                        when (_, 'x1', '00100') => __UNALLOCATED
                        when (_, 'x1', '011x0') => __UNALLOCATED
                        when (_, '0x', 'xx0x0') => __UNALLOCATED
                        when (_, '0x', '00111') => __UNALLOCATED
                        when (_, '0x', '10001') => __UNALLOCATED
                        when (_, '01', '00110') => __UNALLOCATED
                        when (_, '1x', '10010') => __UNALLOCATED
                        when (_, '1x', '11000') => __UNALLOCATED
                        when (_, '10', '0x0x0') => __UNALLOCATED
                        when (_, '10', '00111') => __UNALLOCATED
                        when (_, '10', '1000x') => __UNALLOCATED
                        when (_, '11', '00000') => __UNALLOCATED
                        when (_, '11', '00010') => __UNALLOCATED
                        when ('0', _, '00001') => __encoding A64_simd_dp_asisdsame_SQADD_asisdsame_only // SQADD_asisdsame_only
                        when ('0', _, '00101') => __encoding A64_simd_dp_asisdsame_SQSUB_asisdsame_only // SQSUB_asisdsame_only
                        when ('0', _, '01001') => __encoding A64_simd_dp_asisdsame_SQSHL_asisdsame_only // SQSHL_asisdsame_only
                        when ('0', _, '01011') => __encoding A64_simd_dp_asisdsame_SQRSHL_asisdsame_only // SQRSHL_asisdsame_only
                        when ('0', _, '10110') => __encoding A64_simd_dp_asisdsame_SQDMULH_asisdsame_only // SQDMULH_asisdsame_only
                        when ('0', _, '10111') => __UNALLOCATED
                        when ('0', '0x', '11011') => __encoding A64_simd_dp_asisdsame_FMULX_asisdsame_only // FMULX_asisdsame_only
                        when ('0', '0x', '11100') => __encoding A64_simd_dp_asisdsame_FCMEQ_asisdsame_only // FCMEQ_asisdsame_only
                        when ('0', '0x', '11101') => __UNALLOCATED
                        when ('0', '0x', '11111') => __encoding A64_simd_dp_asisdsame_FRECPS_asisdsame_only // FRECPS_asisdsame_only
                        when ('0', '1x', '1101x') => __UNALLOCATED
                        when ('0', '1x', '1110x') => __UNALLOCATED
                        when ('0', '1x', '11111') => __encoding A64_simd_dp_asisdsame_FRSQRTS_asisdsame_only // FRSQRTS_asisdsame_only
                        when ('0', '11', '00110') => __encoding A64_simd_dp_asisdsame_CMGT_asisdsame_only // CMGT_asisdsame_only
                        when ('0', '11', '00111') => __encoding A64_simd_dp_asisdsame_CMGE_asisdsame_only // CMGE_asisdsame_only
                        when ('0', '11', '01000') => __encoding A64_simd_dp_asisdsame_SSHL_asisdsame_only // SSHL_asisdsame_only
                        when ('0', '11', '01010') => __encoding A64_simd_dp_asisdsame_SRSHL_asisdsame_only // SRSHL_asisdsame_only
                        when ('0', '11', '10000') => __encoding A64_simd_dp_asisdsame_ADD_asisdsame_only // ADD_asisdsame_only
                        when ('0', '11', '10001') => __encoding A64_simd_dp_asisdsame_CMTST_asisdsame_only // CMTST_asisdsame_only
                        when ('1', _, '00001') => __encoding A64_simd_dp_asisdsame_UQADD_asisdsame_only // UQADD_asisdsame_only
                        when ('1', _, '00101') => __encoding A64_simd_dp_asisdsame_UQSUB_asisdsame_only // UQSUB_asisdsame_only
                        when ('1', _, '01001') => __encoding A64_simd_dp_asisdsame_UQSHL_asisdsame_only // UQSHL_asisdsame_only
                        when ('1', _, '01011') => __encoding A64_simd_dp_asisdsame_UQRSHL_asisdsame_only // UQRSHL_asisdsame_only
                        when ('1', _, '1x111') => __UNALLOCATED
                        when ('1', _, '10110') => __encoding A64_simd_dp_asisdsame_SQRDMULH_asisdsame_only // SQRDMULH_asisdsame_only
                        when ('1', _, '11011') => __UNALLOCATED
                        when ('1', '0x', '11100') => __encoding A64_simd_dp_asisdsame_FCMGE_asisdsame_only // FCMGE_asisdsame_only
                        when ('1', '0x', '11101') => __encoding A64_simd_dp_asisdsame_FACGE_asisdsame_only // FACGE_asisdsame_only
                        when ('1', '1x', '11010') => __encoding A64_simd_dp_asisdsame_FABD_asisdsame_only // FABD_asisdsame_only
                        when ('1', '1x', '11100') => __encoding A64_simd_dp_asisdsame_FCMGT_asisdsame_only // FCMGT_asisdsame_only
                        when ('1', '1x', '11101') => __encoding A64_simd_dp_asisdsame_FACGT_asisdsame_only // FACGT_asisdsame_only
                        when ('1', '11', '00110') => __encoding A64_simd_dp_asisdsame_CMHI_asisdsame_only // CMHI_asisdsame_only
                        when ('1', '11', '00111') => __encoding A64_simd_dp_asisdsame_CMHS_asisdsame_only // CMHS_asisdsame_only
                        when ('1', '11', '01000') => __encoding A64_simd_dp_asisdsame_USHL_asisdsame_only // USHL_asisdsame_only
                        when ('1', '11', '01010') => __encoding A64_simd_dp_asisdsame_URSHL_asisdsame_only // URSHL_asisdsame_only
                        when ('1', '11', '10000') => __encoding A64_simd_dp_asisdsame_SUB_asisdsame_only // SUB_asisdsame_only
                        when ('1', '11', '10001') => __encoding A64_simd_dp_asisdsame_CMEQ_asisdsame_only // CMEQ_asisdsame_only
                when ('01x1', _, '10', _, 'xxxxxxxx1', _) => // asisdshf
                    __field U 29 +: 1
                    __field immh 19 +: 4
                    __field immb 16 +: 3
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, immh, opcode) of
                        when (_, _, '0xxx1') => __UNALLOCATED
                        when (_, _, '101xx') => __UNALLOCATED
                        when (_, _, '110xx') => __UNALLOCATED
                        when (_, _, '11101') => __UNALLOCATED
                        when (_, 'xxx1', '11110') => __UNALLOCATED
                        when (_, 'xx10', '11110') => __UNALLOCATED
                        when (_, 'x100', '11110') => __UNALLOCATED
                        when (_, '0xxx', '00xx0') => __UNALLOCATED
                        when (_, '0xxx', '010x0') => __UNALLOCATED
                        when (_, '0000', 'x1110') => __UNALLOCATED
                        when (_, '0000', '1001x') => __UNALLOCATED
                        when (_, '0000', '11100') => __UNALLOCATED
                        when (_, '0000', '11111') => __UNALLOCATED
                        when (_, '1000', '11110') => __UNALLOCATED
                        when ('0', '1xxx', '00000') => __encoding A64_simd_dp_asisdshf_SSHR_asisdshf_R // SSHR_asisdshf_R
                        when ('0', '1xxx', '00010') => __encoding A64_simd_dp_asisdshf_SSRA_asisdshf_R // SSRA_asisdshf_R
                        when ('0', '1xxx', '00100') => __encoding A64_simd_dp_asisdshf_SRSHR_asisdshf_R // SRSHR_asisdshf_R
                        when ('0', '1xxx', '00110') => __encoding A64_simd_dp_asisdshf_SRSRA_asisdshf_R // SRSRA_asisdshf_R
                        when ('0', '1xxx', '01010') => __encoding A64_simd_dp_asisdshf_SHL_asisdshf_R // SHL_asisdshf_R
                        when ('0', _, '01100') => __UNALLOCATED
                        when ('0', !'0000', '01110') => __encoding A64_simd_dp_asisdshf_SQSHL_asisdshf_R // SQSHL_asisdshf_R
                        when ('0', _, '1000x') => __UNALLOCATED
                        when ('0', !'0000', '10010') => __encoding A64_simd_dp_asisdshf_SQSHRN_asisdshf_N // SQSHRN_asisdshf_N
                        when ('0', !'0000', '10011') => __encoding A64_simd_dp_asisdshf_SQRSHRN_asisdshf_N // SQRSHRN_asisdshf_N
                        when ('0', !'0000', '11100') => __encoding A64_simd_dp_asisdshf_SCVTF_asisdshf_C // SCVTF_asisdshf_C
                        when ('0', !'0000', '11111') => __encoding A64_simd_dp_asisdshf_FCVTZS_asisdshf_C // FCVTZS_asisdshf_C
                        when ('0', '1xxx', '01000') => __UNALLOCATED
                        when ('1', '1xxx', '00000') => __encoding A64_simd_dp_asisdshf_USHR_asisdshf_R // USHR_asisdshf_R
                        when ('1', '1xxx', '00010') => __encoding A64_simd_dp_asisdshf_USRA_asisdshf_R // USRA_asisdshf_R
                        when ('1', '1xxx', '00100') => __encoding A64_simd_dp_asisdshf_URSHR_asisdshf_R // URSHR_asisdshf_R
                        when ('1', '1xxx', '00110') => __encoding A64_simd_dp_asisdshf_URSRA_asisdshf_R // URSRA_asisdshf_R
                        when ('1', '1xxx', '01000') => __encoding A64_simd_dp_asisdshf_SRI_asisdshf_R // SRI_asisdshf_R
                        when ('1', '1xxx', '01010') => __encoding A64_simd_dp_asisdshf_SLI_asisdshf_R // SLI_asisdshf_R
                        when ('1', !'0000', '01100') => __encoding A64_simd_dp_asisdshf_SQSHLU_asisdshf_R // SQSHLU_asisdshf_R
                        when ('1', !'0000', '01110') => __encoding A64_simd_dp_asisdshf_UQSHL_asisdshf_R // UQSHL_asisdshf_R
                        when ('1', !'0000', '10000') => __encoding A64_simd_dp_asisdshf_SQSHRUN_asisdshf_N // SQSHRUN_asisdshf_N
                        when ('1', !'0000', '10001') => __encoding A64_simd_dp_asisdshf_SQRSHRUN_asisdshf_N // SQRSHRUN_asisdshf_N
                        when ('1', !'0000', '10010') => __encoding A64_simd_dp_asisdshf_UQSHRN_asisdshf_N // UQSHRN_asisdshf_N
                        when ('1', !'0000', '10011') => __encoding A64_simd_dp_asisdshf_UQRSHRN_asisdshf_N // UQRSHRN_asisdshf_N
                        when ('1', !'0000', '11100') => __encoding A64_simd_dp_asisdshf_UCVTF_asisdshf_C // UCVTF_asisdshf_C
                        when ('1', !'0000', '11111') => __encoding A64_simd_dp_asisdshf_FCVTZU_asisdshf_C // FCVTZU_asisdshf_C
                        when ('1', '0000', '01100') => __UNALLOCATED
                        when ('1', '0000', '1000x') => __UNALLOCATED
                when ('01x1', _, '11', _, 'xxxxxxxx1', _) => __UNPREDICTABLE
                when ('01x1', _, '1x', _, 'xxxxxxxx0', _) => // asisdelem
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field L 21 +: 1
                    __field M 20 +: 1
                    __field Rm 16 +: 4
                    __field opcode 12 +: 4
                    __field H 11 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, '01', '1001') => __UNALLOCATED
                        when ('0', _, '0xx0') => __UNALLOCATED
                        when ('0', _, '0011') => __encoding A64_simd_dp_asisdelem_SQDMLAL_asisdelem_L // SQDMLAL_asisdelem_L
                        when ('0', _, '0111') => __encoding A64_simd_dp_asisdelem_SQDMLSL_asisdelem_L // SQDMLSL_asisdelem_L
                        when ('0', _, '10x0') => __UNALLOCATED
                        when ('0', _, '1011') => __encoding A64_simd_dp_asisdelem_SQDMULL_asisdelem_L // SQDMULL_asisdelem_L
                        when ('0', _, '1100') => __encoding A64_simd_dp_asisdelem_SQDMULH_asisdelem_R // SQDMULH_asisdelem_R
                        when ('0', _, '1101') => __encoding A64_simd_dp_asisdelem_SQRDMULH_asisdelem_R // SQRDMULH_asisdelem_R
                        when ('0', _, '111x') => __UNALLOCATED
                        when ('0', '00', '0001') => __encoding A64_simd_dp_asisdelem_FMLA_asisdelem_RH_H // FMLA_asisdelem_RH_H
                        when ('0', '00', '0101') => __encoding A64_simd_dp_asisdelem_FMLS_asisdelem_RH_H // FMLS_asisdelem_RH_H
                        when ('0', '00', '1001') => __encoding A64_simd_dp_asisdelem_FMUL_asisdelem_RH_H // FMUL_asisdelem_RH_H
                        when ('0', '01', '0x01') => __UNALLOCATED
                        when ('0', '1x', '0001') => __encoding A64_simd_dp_asisdelem_FMLA_asisdelem_R_SD // FMLA_asisdelem_R_SD
                        when ('0', '1x', '0101') => __encoding A64_simd_dp_asisdelem_FMLS_asisdelem_R_SD // FMLS_asisdelem_R_SD
                        when ('0', '1x', '1001') => __encoding A64_simd_dp_asisdelem_FMUL_asisdelem_R_SD // FMUL_asisdelem_R_SD
                        when ('1', _, '0xxx') => __UNALLOCATED
                        when ('1', _, '1xx0') => __UNALLOCATED
                        when ('1', _, '1011') => __UNALLOCATED
                        when ('1', _, '1101') => __encoding A64_simd_dp_asisdelem_SQRDMLAH_asisdelem_R // SQRDMLAH_asisdelem_R
                        when ('1', _, '1111') => __encoding A64_simd_dp_asisdelem_SQRDMLSH_asisdelem_R // SQRDMLSH_asisdelem_R
                        when ('1', '00', '1001') => __encoding A64_simd_dp_asisdelem_FMULX_asisdelem_RH_H // FMULX_asisdelem_RH_H
                        when ('1', '1x', '1001') => __encoding A64_simd_dp_asisdelem_FMULX_asisdelem_R_SD // FMULX_asisdelem_R_SD
                when ('0x00', _, '0x', 'x0xx', 'xxx0xxx00', _) => // asimdtbl
                    __field Q 30 +: 1
                    __field op2 22 +: 2
                    __field Rm 16 +: 5
                    __field len 13 +: 2
                    __field op 12 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, op2, len, op) of
                        when (_, '00', '00', '0') => __encoding A64_simd_dp_asimdtbl_TBL_asimdtbl_L1_1 // TBL_asimdtbl_L1_1
                        when (_, '00', '00', '1') => __encoding A64_simd_dp_asimdtbl_TBX_asimdtbl_L1_1 // TBX_asimdtbl_L1_1
                        when (_, '00', '01', '0') => __encoding A64_simd_dp_asimdtbl_TBL_asimdtbl_L1_1 // TBL_asimdtbl_L2_2
                        when (_, '00', '01', '1') => __encoding A64_simd_dp_asimdtbl_TBX_asimdtbl_L1_1 // TBX_asimdtbl_L2_2
                        when (_, '00', '10', '0') => __encoding A64_simd_dp_asimdtbl_TBL_asimdtbl_L1_1 // TBL_asimdtbl_L3_3
                        when (_, '00', '10', '1') => __encoding A64_simd_dp_asimdtbl_TBX_asimdtbl_L1_1 // TBX_asimdtbl_L3_3
                        when (_, '00', '11', '0') => __encoding A64_simd_dp_asimdtbl_TBL_asimdtbl_L1_1 // TBL_asimdtbl_L4_4
                        when (_, '00', '11', '1') => __encoding A64_simd_dp_asimdtbl_TBX_asimdtbl_L1_1 // TBX_asimdtbl_L4_4
                        when ('0', '01', _, _) => __UNALLOCATED
                        when ('0', '1x', _, _) => __UNALLOCATED
                        when ('1', '01', _, '1') => __encoding A64_simd_dp_asimdtbl_LUTI4_asimdtbl_L5 // LUTI4_asimdtbl_L7
                        when ('1', '01', 'x0', '0') => __UNALLOCATED
                        when ('1', '01', 'x1', '0') => __encoding A64_simd_dp_asimdtbl_LUTI4_asimdtbl_L5 // LUTI4_asimdtbl_L5
                        when ('1', '10', _, '0') => __UNALLOCATED
                        when ('1', '10', _, '1') => __encoding A64_simd_dp_asimdtbl_LUTI2_asimdtbl_L5 // LUTI2_asimdtbl_L5
                        when ('1', '11', _, _) => __encoding A64_simd_dp_asimdtbl_LUTI2_asimdtbl_L5 // LUTI2_asimdtbl_L6
                when ('0x00', _, '0x', 'x0xx', 'xxx0xxx10', _) => // asimdperm
                    __field Q 30 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('x00') => __UNALLOCATED
                        when ('001') => __encoding A64_simd_dp_asimdperm_UZP1_asimdperm_only // UZP1_asimdperm_only
                        when ('010') => __encoding A64_simd_dp_asimdperm_TRN1_asimdperm_only // TRN1_asimdperm_only
                        when ('011') => __encoding A64_simd_dp_asimdperm_ZIP1_asimdperm_only // ZIP1_asimdperm_only
                        when ('101') => __encoding A64_simd_dp_asimdperm_UZP2_asimdperm_only // UZP2_asimdperm_only
                        when ('110') => __encoding A64_simd_dp_asimdperm_TRN2_asimdperm_only // TRN2_asimdperm_only
                        when ('111') => __encoding A64_simd_dp_asimdperm_ZIP2_asimdperm_only // ZIP2_asimdperm_only
                when ('0x10', _, '0x', 'x0xx', 'xxx0xxxx0', _) => // asimdext
                    __field Q 30 +: 1
                    __field op2 22 +: 2
                    __field Rm 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (op2) of
                        when ('00') => __encoding A64_simd_dp_asimdext_EXT_asimdext_only // EXT_asimdext_only
                        when ('01') => __UNALLOCATED
                        when ('1x') => __UNALLOCATED
                when ('0xx0', _, '00', '00xx', 'xxx0xxxx1', _) => // asimdins
                    __field Q 30 +: 1
                    __field op 29 +: 1
                    __field imm5 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, op, imm5, imm4) of
                        when (_, '0', _, '0000') => __encoding A64_simd_dp_asimdins_DUP_asimdins_DV_v // DUP_asimdins_DV_v
                        when (_, '0', _, '0001') => __encoding A64_simd_dp_asimdins_DUP_asimdins_DR_r // DUP_asimdins_DR_r
                        when (_, '0', _, '01x0') => __UNALLOCATED
                        when (_, '0', _, '1xxx') => __UNALLOCATED
                        when ('0', '0', _, '001x') => __UNALLOCATED
                        when ('0', '0', _, '0101') => __encoding A64_simd_dp_asimdins_SMOV_asimdins_W_w // SMOV_asimdins_W_w
                        when ('0', '0', _, '0111') => __encoding A64_simd_dp_asimdins_UMOV_asimdins_W_w // UMOV_asimdins_W_w
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', '0', _, '0010') => __UNALLOCATED
                        when ('1', '0', _, '0011') => __encoding A64_simd_dp_asimdins_INS_asimdins_IR_r // INS_asimdins_IR_r
                        when ('1', '0', _, '0101') => __encoding A64_simd_dp_asimdins_SMOV_asimdins_W_w // SMOV_asimdins_X_x
                        when ('1', '0', 'x0xxx', '0111') => __UNALLOCATED
                        when ('1', '0', 'x1000', '0111') => __encoding A64_simd_dp_asimdins_UMOV_asimdins_W_w // UMOV_asimdins_X_x
                        when ('1', '0', 'x1001', '0111') => __UNALLOCATED
                        when ('1', '0', 'x101x', '0111') => __UNALLOCATED
                        when ('1', '0', 'x11xx', '0111') => __UNALLOCATED
                        when ('1', '1', _, _) => __encoding A64_simd_dp_asimdins_INS_asimdins_IV_v // INS_asimdins_IV_v
                when ('0xx0', _, '01', '00xx', 'xxx0xxxx1', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '0111', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '10xx', 'xxx00xxx1', _) => // asimdsamefp16
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field Rm 16 +: 5
                    __field opcode 11 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when ('0', '0', '000') => __encoding A64_simd_dp_asimdsamefp16_FMAXNM_asimdsamefp16_only // FMAXNM_asimdsamefp16_only
                        when ('0', '0', '001') => __encoding A64_simd_dp_asimdsamefp16_FMLA_asimdsamefp16_only // FMLA_asimdsamefp16_only
                        when ('0', '0', '010') => __encoding A64_simd_dp_asimdsamefp16_FADD_asimdsamefp16_only // FADD_asimdsamefp16_only
                        when ('0', '0', '011') => __encoding A64_simd_dp_asimdsamefp16_FMULX_asimdsamefp16_only // FMULX_asimdsamefp16_only
                        when ('0', '0', '100') => __encoding A64_simd_dp_asimdsamefp16_FCMEQ_asimdsamefp16_only // FCMEQ_asimdsamefp16_only
                        when ('0', '0', '101') => __UNALLOCATED
                        when ('0', '0', '110') => __encoding A64_simd_dp_asimdsamefp16_FMAX_asimdsamefp16_only // FMAX_asimdsamefp16_only
                        when ('0', '0', '111') => __encoding A64_simd_dp_asimdsamefp16_FRECPS_asimdsamefp16_only // FRECPS_asimdsamefp16_only
                        when ('0', '1', '000') => __encoding A64_simd_dp_asimdsamefp16_FMINNM_asimdsamefp16_only // FMINNM_asimdsamefp16_only
                        when ('0', '1', '001') => __encoding A64_simd_dp_asimdsamefp16_FMLS_asimdsamefp16_only // FMLS_asimdsamefp16_only
                        when ('0', '1', '010') => __encoding A64_simd_dp_asimdsamefp16_FSUB_asimdsamefp16_only // FSUB_asimdsamefp16_only
                        when ('0', '1', '011') => __encoding A64_simd_dp_asimdsamefp16_FAMAX_asimdsamefp16_only // FAMAX_asimdsamefp16_only
                        when ('0', '1', '10x') => __UNALLOCATED
                        when ('0', '1', '110') => __encoding A64_simd_dp_asimdsamefp16_FMIN_asimdsamefp16_only // FMIN_asimdsamefp16_only
                        when ('0', '1', '111') => __encoding A64_simd_dp_asimdsamefp16_FRSQRTS_asimdsamefp16_only // FRSQRTS_asimdsamefp16_only
                        when ('1', _, '001') => __UNALLOCATED
                        when ('1', '0', '000') => __encoding A64_simd_dp_asimdsamefp16_FMAXNMP_asimdsamefp16_only // FMAXNMP_asimdsamefp16_only
                        when ('1', '0', '010') => __encoding A64_simd_dp_asimdsamefp16_FADDP_asimdsamefp16_only // FADDP_asimdsamefp16_only
                        when ('1', '0', '011') => __encoding A64_simd_dp_asimdsamefp16_FMUL_asimdsamefp16_only // FMUL_asimdsamefp16_only
                        when ('1', '0', '100') => __encoding A64_simd_dp_asimdsamefp16_FCMGE_asimdsamefp16_only // FCMGE_asimdsamefp16_only
                        when ('1', '0', '101') => __encoding A64_simd_dp_asimdsamefp16_FACGE_asimdsamefp16_only // FACGE_asimdsamefp16_only
                        when ('1', '0', '110') => __encoding A64_simd_dp_asimdsamefp16_FMAXP_asimdsamefp16_only // FMAXP_asimdsamefp16_only
                        when ('1', '0', '111') => __encoding A64_simd_dp_asimdsamefp16_FDIV_asimdsamefp16_only // FDIV_asimdsamefp16_only
                        when ('1', '1', '000') => __encoding A64_simd_dp_asimdsamefp16_FMINNMP_asimdsamefp16_only // FMINNMP_asimdsamefp16_only
                        when ('1', '1', '010') => __encoding A64_simd_dp_asimdsamefp16_FABD_asimdsamefp16_only // FABD_asimdsamefp16_only
                        when ('1', '1', '011') => __encoding A64_simd_dp_asimdsamefp16_FAMIN_asimdsamefp16_only // FAMIN_asimdsamefp16_only
                        when ('1', '1', '100') => __encoding A64_simd_dp_asimdsamefp16_FCMGT_asimdsamefp16_only // FCMGT_asimdsamefp16_only
                        when ('1', '1', '101') => __encoding A64_simd_dp_asimdsamefp16_FACGT_asimdsamefp16_only // FACGT_asimdsamefp16_only
                        when ('1', '1', '110') => __encoding A64_simd_dp_asimdsamefp16_FMINP_asimdsamefp16_only // FMINP_asimdsamefp16_only
                        when ('1', '1', '111') => __encoding A64_simd_dp_asimdsamefp16_FSCALE_asimdsamefp16_only // FSCALE_asimdsamefp16_only
                when ('0xx0', _, '0x', '10xx', 'xxx01xxx1', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '1111', '00xxxxx10', _) => // asimdmiscfp16
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, 'x0xxx') => __UNALLOCATED
                        when (_, '0', '01xxx') => __UNALLOCATED
                        when (_, '0', '1111x') => __UNALLOCATED
                        when (_, '1', '010xx') => __UNALLOCATED
                        when (_, '1', '11100') => __UNALLOCATED
                        when ('0', '0', '11000') => __encoding A64_simd_dp_asimdmiscfp16_FRINTN_asimdmiscfp16_R // FRINTN_asimdmiscfp16_R
                        when ('0', '0', '11001') => __encoding A64_simd_dp_asimdmiscfp16_FRINTM_asimdmiscfp16_R // FRINTM_asimdmiscfp16_R
                        when ('0', '0', '11010') => __encoding A64_simd_dp_asimdmiscfp16_FCVTNS_asimdmiscfp16_R // FCVTNS_asimdmiscfp16_R
                        when ('0', '0', '11011') => __encoding A64_simd_dp_asimdmiscfp16_FCVTMS_asimdmiscfp16_R // FCVTMS_asimdmiscfp16_R
                        when ('0', '0', '11100') => __encoding A64_simd_dp_asimdmiscfp16_FCVTAS_asimdmiscfp16_R // FCVTAS_asimdmiscfp16_R
                        when ('0', '0', '11101') => __encoding A64_simd_dp_asimdmiscfp16_SCVTF_asimdmiscfp16_R // SCVTF_asimdmiscfp16_R
                        when ('0', '1', '01100') => __encoding A64_simd_dp_asimdmiscfp16_FCMGT_asimdmiscfp16_FZ // FCMGT_asimdmiscfp16_FZ
                        when ('0', '1', '01101') => __encoding A64_simd_dp_asimdmiscfp16_FCMEQ_asimdmiscfp16_FZ // FCMEQ_asimdmiscfp16_FZ
                        when ('0', '1', '01110') => __encoding A64_simd_dp_asimdmiscfp16_FCMLT_asimdmiscfp16_FZ // FCMLT_asimdmiscfp16_FZ
                        when ('0', '1', '01111') => __encoding A64_simd_dp_asimdmiscfp16_FABS_asimdmiscfp16_R // FABS_asimdmiscfp16_R
                        when ('0', '1', '11000') => __encoding A64_simd_dp_asimdmiscfp16_FRINTP_asimdmiscfp16_R // FRINTP_asimdmiscfp16_R
                        when ('0', '1', '11001') => __encoding A64_simd_dp_asimdmiscfp16_FRINTZ_asimdmiscfp16_R // FRINTZ_asimdmiscfp16_R
                        when ('0', '1', '11010') => __encoding A64_simd_dp_asimdmiscfp16_FCVTPS_asimdmiscfp16_R // FCVTPS_asimdmiscfp16_R
                        when ('0', '1', '11011') => __encoding A64_simd_dp_asimdmiscfp16_FCVTZS_asimdmiscfp16_R // FCVTZS_asimdmiscfp16_R
                        when ('0', '1', '11101') => __encoding A64_simd_dp_asimdmiscfp16_FRECPE_asimdmiscfp16_R // FRECPE_asimdmiscfp16_R
                        when ('0', '1', '1111x') => __UNALLOCATED
                        when ('1', '0', '11000') => __encoding A64_simd_dp_asimdmiscfp16_FRINTA_asimdmiscfp16_R // FRINTA_asimdmiscfp16_R
                        when ('1', '0', '11001') => __encoding A64_simd_dp_asimdmiscfp16_FRINTX_asimdmiscfp16_R // FRINTX_asimdmiscfp16_R
                        when ('1', '0', '11010') => __encoding A64_simd_dp_asimdmiscfp16_FCVTNU_asimdmiscfp16_R // FCVTNU_asimdmiscfp16_R
                        when ('1', '0', '11011') => __encoding A64_simd_dp_asimdmiscfp16_FCVTMU_asimdmiscfp16_R // FCVTMU_asimdmiscfp16_R
                        when ('1', '0', '11100') => __encoding A64_simd_dp_asimdmiscfp16_FCVTAU_asimdmiscfp16_R // FCVTAU_asimdmiscfp16_R
                        when ('1', '0', '11101') => __encoding A64_simd_dp_asimdmiscfp16_UCVTF_asimdmiscfp16_R // UCVTF_asimdmiscfp16_R
                        when ('1', '1', '01100') => __encoding A64_simd_dp_asimdmiscfp16_FCMGE_asimdmiscfp16_FZ // FCMGE_asimdmiscfp16_FZ
                        when ('1', '1', '01101') => __encoding A64_simd_dp_asimdmiscfp16_FCMLE_asimdmiscfp16_FZ // FCMLE_asimdmiscfp16_FZ
                        when ('1', '1', '01110') => __UNALLOCATED
                        when ('1', '1', '01111') => __encoding A64_simd_dp_asimdmiscfp16_FNEG_asimdmiscfp16_R // FNEG_asimdmiscfp16_R
                        when ('1', '1', '11000') => __UNALLOCATED
                        when ('1', '1', '11001') => __encoding A64_simd_dp_asimdmiscfp16_FRINTI_asimdmiscfp16_R // FRINTI_asimdmiscfp16_R
                        when ('1', '1', '11010') => __encoding A64_simd_dp_asimdmiscfp16_FCVTPU_asimdmiscfp16_R // FCVTPU_asimdmiscfp16_R
                        when ('1', '1', '11011') => __encoding A64_simd_dp_asimdmiscfp16_FCVTZU_asimdmiscfp16_R // FCVTZU_asimdmiscfp16_R
                        when ('1', '1', '11101') => __encoding A64_simd_dp_asimdmiscfp16_FRSQRTE_asimdmiscfp16_R // FRSQRTE_asimdmiscfp16_R
                        when ('1', '1', '11110') => __UNALLOCATED
                        when ('1', '1', '11111') => __encoding A64_simd_dp_asimdmiscfp16_FSQRT_asimdmiscfp16_R // FSQRT_asimdmiscfp16_R
                when ('0xx0', _, '0x', 'x0xx', 'xxx1xxxx0', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x0xx', 'xxx1xxxx1', _) => // asimdsame2
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, U, size, opcode) of
                        when (_, '0', _, '0010') => __encoding A64_simd_dp_asimdsame2_SDOT_asimdsame2_D // SDOT_asimdsame2_D
                        when (_, '0', '0x', 'x011') => __UNALLOCATED
                        when (_, '0', '0x', '000x') => __UNALLOCATED
                        when (_, '0', '0x', '1001') => __UNALLOCATED
                        when (_, '0', '0x', '1010') => __UNALLOCATED
                        when (_, '0', '0x', '1100') => __UNALLOCATED
                        when (_, '0', '00', '1110') => __encoding A64_simd_dp_asimdsame2_FCVTN_asimdsame2_H // FCVTN_asimdsame2_H
                        when (_, '0', '00', '1111') => __encoding A64_simd_dp_asimdsame2_FDOT_asimdsame2_DD // FDOT_asimdsame2_DD
                        when (_, '0', '01', '1110') => __encoding A64_simd_dp_asimdsame2_FCVTN_asimdsame2_D // FCVTN_asimdsame2_D
                        when (_, '0', '01', '1111') => __encoding A64_simd_dp_asimdsame2_FDOT_asimdsame2_D // FDOT_asimdsame2_D
                        when (_, '0', '1x', '000x') => __UNALLOCATED
                        when (_, '0', '10', '0011') => __encoding A64_simd_dp_asimdsame2_USDOT_asimdsame2_D // USDOT_asimdsame2_D
                        when (_, '0', '10', '1xx0') => __UNALLOCATED
                        when (_, '0', '10', '1x11') => __UNALLOCATED
                        when (_, '0', '10', '1001') => __UNALLOCATED
                        when (_, '0', '11', '0011') => __UNALLOCATED
                        when (_, '0', '11', '1xx0') => __UNALLOCATED
                        when (_, '0', '11', '1001') => __UNALLOCATED
                        when (_, '0', '11', '1011') => __UNALLOCATED
                        when (_, '1', _, '0000') => __encoding A64_simd_dp_asimdsame2_SQRDMLAH_asimdsame2_only // SQRDMLAH_asimdsame2_only
                        when (_, '1', _, '0001') => __encoding A64_simd_dp_asimdsame2_SQRDMLSH_asimdsame2_only // SQRDMLSH_asimdsame2_only
                        when (_, '1', _, '0010') => __encoding A64_simd_dp_asimdsame2_UDOT_asimdsame2_D // UDOT_asimdsame2_D
                        when (_, '1', _, '0011') => __UNALLOCATED
                        when (_, '1', _, '10xx') => __encoding A64_simd_dp_asimdsame2_FCMLA_asimdsame2_C // FCMLA_asimdsame2_C
                        when (_, '1', _, '11x0') => __encoding A64_simd_dp_asimdsame2_FCADD_asimdsame2_C // FCADD_asimdsame2_C
                        when (_, '1', 'x0', '1111') => __UNALLOCATED
                        when (_, '1', '01', '1111') => __encoding A64_simd_dp_asimdsame2_BFDOT_asimdsame2_D // BFDOT_asimdsame2_D
                        when (_, '1', '11', '1111') => __encoding A64_simd_dp_asimdsame2_BFMLAL_asimdsame2_F_ // BFMLAL_asimdsame2_F_
                        when ('0', _, _, '01xx') => __UNALLOCATED
                        when ('0', _, _, '1101') => __UNALLOCATED
                        when ('0', '0', '00', '1000') => __encoding A64_simd_dp_asimdsame2_FMLALLBB_asimdsame2_G // FMLALLBB_asimdsame2_G
                        when ('0', '0', '01', '1000') => __encoding A64_simd_dp_asimdsame2_FMLALLBB_asimdsame2_G // FMLALLBT_asimdsame2_G
                        when ('0', '0', '11', '1111') => __encoding A64_simd_dp_asimdsame2_FMLALB_asimdsame2_J // FMLALB_asimdsame2_J
                        when ('1', _, '0x', '01xx') => __UNALLOCATED
                        when ('1', _, '10', '011x') => __UNALLOCATED
                        when ('1', _, '11', '01xx') => __UNALLOCATED
                        when ('1', _, '11', '1101') => __UNALLOCATED
                        when ('1', '0', '0x', '1101') => __UNALLOCATED
                        when ('1', '0', '00', '1000') => __encoding A64_simd_dp_asimdsame2_FMLALLBB_asimdsame2_G // FMLALLTB_asimdsame2_G
                        when ('1', '0', '01', '1000') => __encoding A64_simd_dp_asimdsame2_FMLALLBB_asimdsame2_G // FMLALLTT_asimdsame2_G
                        when ('1', '0', '10', '0100') => __encoding A64_simd_dp_asimdsame2_SMMLA_asimdsame2_G // SMMLA_asimdsame2_G
                        when ('1', '0', '10', '0101') => __encoding A64_simd_dp_asimdsame2_USMMLA_asimdsame2_G // USMMLA_asimdsame2_G
                        when ('1', '0', '10', '1101') => __UNALLOCATED
                        when ('1', '0', '11', '1111') => __encoding A64_simd_dp_asimdsame2_FMLALB_asimdsame2_J // FMLALT_asimdsame2_J
                        when ('1', '1', 'x0', '1101') => __UNALLOCATED
                        when ('1', '1', '01', '1101') => __encoding A64_simd_dp_asimdsame2_BFMMLA_asimdsame2_E // BFMMLA_asimdsame2_E
                        when ('1', '1', '10', '0100') => __encoding A64_simd_dp_asimdsame2_UMMLA_asimdsame2_G // UMMLA_asimdsame2_G
                        when ('1', '1', '10', '0101') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x100', '00xxxxx10', _) => // asimdmisc
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '1000x') => __UNALLOCATED
                        when (_, _, '10101') => __UNALLOCATED
                        when (_, '0x', '011xx') => __UNALLOCATED
                        when ('0', _, '00000') => __encoding A64_simd_dp_asimdmisc_REV64_asimdmisc_R // REV64_asimdmisc_R
                        when ('0', _, '00001') => __encoding A64_simd_dp_asimdmisc_REV16_asimdmisc_R // REV16_asimdmisc_R
                        when ('0', _, '00010') => __encoding A64_simd_dp_asimdmisc_SADDLP_asimdmisc_P // SADDLP_asimdmisc_P
                        when ('0', _, '00011') => __encoding A64_simd_dp_asimdmisc_SUQADD_asimdmisc_R // SUQADD_asimdmisc_R
                        when ('0', _, '00100') => __encoding A64_simd_dp_asimdmisc_CLS_asimdmisc_R // CLS_asimdmisc_R
                        when ('0', _, '00101') => __encoding A64_simd_dp_asimdmisc_CNT_asimdmisc_R // CNT_asimdmisc_R
                        when ('0', _, '00110') => __encoding A64_simd_dp_asimdmisc_SADALP_asimdmisc_P // SADALP_asimdmisc_P
                        when ('0', _, '00111') => __encoding A64_simd_dp_asimdmisc_SQABS_asimdmisc_R // SQABS_asimdmisc_R
                        when ('0', _, '01000') => __encoding A64_simd_dp_asimdmisc_CMGT_asimdmisc_Z // CMGT_asimdmisc_Z
                        when ('0', _, '01001') => __encoding A64_simd_dp_asimdmisc_CMEQ_asimdmisc_Z // CMEQ_asimdmisc_Z
                        when ('0', _, '01010') => __encoding A64_simd_dp_asimdmisc_CMLT_asimdmisc_Z // CMLT_asimdmisc_Z
                        when ('0', _, '01011') => __encoding A64_simd_dp_asimdmisc_ABS_asimdmisc_R // ABS_asimdmisc_R
                        when ('0', _, '10010') => __encoding A64_simd_dp_asimdmisc_XTN_asimdmisc_N // XTN_asimdmisc_N
                        when ('0', _, '10100') => __encoding A64_simd_dp_asimdmisc_SQXTN_asimdmisc_N // SQXTN_asimdmisc_N
                        when ('0', '0x', '10011') => __UNALLOCATED
                        when ('0', '0x', '10110') => __encoding A64_simd_dp_asimdmisc_FCVTN_asimdmisc_N // FCVTN_asimdmisc_N
                        when ('0', '0x', '10111') => __encoding A64_simd_dp_asimdmisc_FCVTL_asimdmisc_L // FCVTL_asimdmisc_L
                        when ('0', '0x', '11000') => __encoding A64_simd_dp_asimdmisc_FRINTN_asimdmisc_R // FRINTN_asimdmisc_R
                        when ('0', '0x', '11001') => __encoding A64_simd_dp_asimdmisc_FRINTM_asimdmisc_R // FRINTM_asimdmisc_R
                        when ('0', '0x', '11010') => __encoding A64_simd_dp_asimdmisc_FCVTNS_asimdmisc_R // FCVTNS_asimdmisc_R
                        when ('0', '0x', '11011') => __encoding A64_simd_dp_asimdmisc_FCVTMS_asimdmisc_R // FCVTMS_asimdmisc_R
                        when ('0', '0x', '11100') => __encoding A64_simd_dp_asimdmisc_FCVTAS_asimdmisc_R // FCVTAS_asimdmisc_R
                        when ('0', '0x', '11101') => __encoding A64_simd_dp_asimdmisc_SCVTF_asimdmisc_R // SCVTF_asimdmisc_R
                        when ('0', '0x', '11110') => __encoding A64_simd_dp_asimdmisc_FRINT32Z_asimdmisc_R // FRINT32Z_asimdmisc_R
                        when ('0', '0x', '11111') => __encoding A64_simd_dp_asimdmisc_FRINT64Z_asimdmisc_R // FRINT64Z_asimdmisc_R
                        when ('0', '1x', '01100') => __encoding A64_simd_dp_asimdmisc_FCMGT_asimdmisc_FZ // FCMGT_asimdmisc_FZ
                        when ('0', '1x', '01101') => __encoding A64_simd_dp_asimdmisc_FCMEQ_asimdmisc_FZ // FCMEQ_asimdmisc_FZ
                        when ('0', '1x', '01110') => __encoding A64_simd_dp_asimdmisc_FCMLT_asimdmisc_FZ // FCMLT_asimdmisc_FZ
                        when ('0', '1x', '01111') => __encoding A64_simd_dp_asimdmisc_FABS_asimdmisc_R // FABS_asimdmisc_R
                        when ('0', '1x', '10x11') => __UNALLOCATED
                        when ('0', '1x', '11000') => __encoding A64_simd_dp_asimdmisc_FRINTP_asimdmisc_R // FRINTP_asimdmisc_R
                        when ('0', '1x', '11001') => __encoding A64_simd_dp_asimdmisc_FRINTZ_asimdmisc_R // FRINTZ_asimdmisc_R
                        when ('0', '1x', '11010') => __encoding A64_simd_dp_asimdmisc_FCVTPS_asimdmisc_R // FCVTPS_asimdmisc_R
                        when ('0', '1x', '11011') => __encoding A64_simd_dp_asimdmisc_FCVTZS_asimdmisc_R // FCVTZS_asimdmisc_R
                        when ('0', '1x', '11100') => __encoding A64_simd_dp_asimdmisc_URECPE_asimdmisc_R // URECPE_asimdmisc_R
                        when ('0', '1x', '11101') => __encoding A64_simd_dp_asimdmisc_FRECPE_asimdmisc_R // FRECPE_asimdmisc_R
                        when ('0', '10', '10110') => __encoding A64_simd_dp_asimdmisc_BFCVTN_asimdmisc_4S // BFCVTN_asimdmisc_4S
                        when ('0', '10', '1111x') => __UNALLOCATED
                        when ('0', '11', '1x110') => __UNALLOCATED
                        when ('0', '11', '11111') => __UNALLOCATED
                        when ('1', _, '00000') => __encoding A64_simd_dp_asimdmisc_REV32_asimdmisc_R // REV32_asimdmisc_R
                        when ('1', _, '00010') => __encoding A64_simd_dp_asimdmisc_UADDLP_asimdmisc_P // UADDLP_asimdmisc_P
                        when ('1', _, '00011') => __encoding A64_simd_dp_asimdmisc_USQADD_asimdmisc_R // USQADD_asimdmisc_R
                        when ('1', _, '00100') => __encoding A64_simd_dp_asimdmisc_CLZ_asimdmisc_R // CLZ_asimdmisc_R
                        when ('1', _, '00110') => __encoding A64_simd_dp_asimdmisc_UADALP_asimdmisc_P // UADALP_asimdmisc_P
                        when ('1', _, '00111') => __encoding A64_simd_dp_asimdmisc_SQNEG_asimdmisc_R // SQNEG_asimdmisc_R
                        when ('1', _, '01000') => __encoding A64_simd_dp_asimdmisc_CMGE_asimdmisc_Z // CMGE_asimdmisc_Z
                        when ('1', _, '01001') => __encoding A64_simd_dp_asimdmisc_CMLE_asimdmisc_Z // CMLE_asimdmisc_Z
                        when ('1', _, '01010') => __UNALLOCATED
                        when ('1', _, '01011') => __encoding A64_simd_dp_asimdmisc_NEG_asimdmisc_R // NEG_asimdmisc_R
                        when ('1', _, '10010') => __encoding A64_simd_dp_asimdmisc_SQXTUN_asimdmisc_N // SQXTUN_asimdmisc_N
                        when ('1', _, '10011') => __encoding A64_simd_dp_asimdmisc_SHLL_asimdmisc_S // SHLL_asimdmisc_S
                        when ('1', _, '10100') => __encoding A64_simd_dp_asimdmisc_UQXTN_asimdmisc_N // UQXTN_asimdmisc_N
                        when ('1', '0x', '00001') => __UNALLOCATED
                        when ('1', '0x', '11000') => __encoding A64_simd_dp_asimdmisc_FRINTA_asimdmisc_R // FRINTA_asimdmisc_R
                        when ('1', '0x', '11001') => __encoding A64_simd_dp_asimdmisc_FRINTX_asimdmisc_R // FRINTX_asimdmisc_R
                        when ('1', '0x', '11010') => __encoding A64_simd_dp_asimdmisc_FCVTNU_asimdmisc_R // FCVTNU_asimdmisc_R
                        when ('1', '0x', '11011') => __encoding A64_simd_dp_asimdmisc_FCVTMU_asimdmisc_R // FCVTMU_asimdmisc_R
                        when ('1', '0x', '11100') => __encoding A64_simd_dp_asimdmisc_FCVTAU_asimdmisc_R // FCVTAU_asimdmisc_R
                        when ('1', '0x', '11101') => __encoding A64_simd_dp_asimdmisc_UCVTF_asimdmisc_R // UCVTF_asimdmisc_R
                        when ('1', '0x', '11110') => __encoding A64_simd_dp_asimdmisc_FRINT32X_asimdmisc_R // FRINT32X_asimdmisc_R
                        when ('1', '0x', '11111') => __encoding A64_simd_dp_asimdmisc_FRINT64X_asimdmisc_R // FRINT64X_asimdmisc_R
                        when ('1', '00', '00101') => __encoding A64_simd_dp_asimdmisc_NOT_asimdmisc_R // NOT_asimdmisc_R
                        when ('1', '00', '10110') => __UNALLOCATED
                        when ('1', '00', '10111') => __encoding A64_simd_dp_asimdmisc_F1CVTL_asimdmisc_V // F1CVTL_asimdmisc_V
                        when ('1', '01', '00101') => __encoding A64_simd_dp_asimdmisc_RBIT_asimdmisc_R // RBIT_asimdmisc_R
                        when ('1', '01', '10110') => __encoding A64_simd_dp_asimdmisc_FCVTXN_asimdmisc_N // FCVTXN_asimdmisc_N
                        when ('1', '01', '10111') => __encoding A64_simd_dp_asimdmisc_F1CVTL_asimdmisc_V // F2CVTL_asimdmisc_V
                        when ('1', '1x', '00x01') => __UNALLOCATED
                        when ('1', '1x', '01100') => __encoding A64_simd_dp_asimdmisc_FCMGE_asimdmisc_FZ // FCMGE_asimdmisc_FZ
                        when ('1', '1x', '01101') => __encoding A64_simd_dp_asimdmisc_FCMLE_asimdmisc_FZ // FCMLE_asimdmisc_FZ
                        when ('1', '1x', '01110') => __UNALLOCATED
                        when ('1', '1x', '01111') => __encoding A64_simd_dp_asimdmisc_FNEG_asimdmisc_R // FNEG_asimdmisc_R
                        when ('1', '1x', '1x110') => __UNALLOCATED
                        when ('1', '1x', '11000') => __UNALLOCATED
                        when ('1', '1x', '11001') => __encoding A64_simd_dp_asimdmisc_FRINTI_asimdmisc_R // FRINTI_asimdmisc_R
                        when ('1', '1x', '11010') => __encoding A64_simd_dp_asimdmisc_FCVTPU_asimdmisc_R // FCVTPU_asimdmisc_R
                        when ('1', '1x', '11011') => __encoding A64_simd_dp_asimdmisc_FCVTZU_asimdmisc_R // FCVTZU_asimdmisc_R
                        when ('1', '1x', '11100') => __encoding A64_simd_dp_asimdmisc_URSQRTE_asimdmisc_R // URSQRTE_asimdmisc_R
                        when ('1', '1x', '11101') => __encoding A64_simd_dp_asimdmisc_FRSQRTE_asimdmisc_R // FRSQRTE_asimdmisc_R
                        when ('1', '1x', '11111') => __encoding A64_simd_dp_asimdmisc_FSQRT_asimdmisc_R // FSQRT_asimdmisc_R
                        when ('1', '10', '10111') => __encoding A64_simd_dp_asimdmisc_BF1CVTL_asimdmisc_V // BF1CVTL_asimdmisc_V
                        when ('1', '11', '10111') => __encoding A64_simd_dp_asimdmisc_BF1CVTL_asimdmisc_V // BF2CVTL_asimdmisc_V
                when ('0xx0', _, '0x', 'x110', '00xxxxx10', _) => // asimdall
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, U, size, opcode) of
                        when (_, _, _, 'x100x') => __UNALLOCATED
                        when (_, _, _, '000x0') => __UNALLOCATED
                        when (_, _, _, '00001') => __UNALLOCATED
                        when (_, _, _, '01011') => __UNALLOCATED
                        when (_, _, _, '100xx') => __UNALLOCATED
                        when (_, _, 'x0', '001xx') => __UNALLOCATED
                        when (_, _, 'x0', '01101') => __UNALLOCATED
                        when (_, _, 'x0', '101xx') => __UNALLOCATED
                        when (_, _, 'x0', '111xx') => __UNALLOCATED
                        when (_, _, 'x1', 'xx1xx') => __UNALLOCATED
                        when (_, '0', _, '00011') => __encoding A64_simd_dp_asimdall_SADDLV_asimdall_only // SADDLV_asimdall_only
                        when (_, '0', _, '01010') => __encoding A64_simd_dp_asimdall_SMAXV_asimdall_only // SMAXV_asimdall_only
                        when (_, '0', _, '11010') => __encoding A64_simd_dp_asimdall_SMINV_asimdall_only // SMINV_asimdall_only
                        when (_, '0', _, '11011') => __encoding A64_simd_dp_asimdall_ADDV_asimdall_only // ADDV_asimdall_only
                        when (_, '0', 'x0', '01110') => __UNALLOCATED
                        when (_, '0', '00', '01100') => __encoding A64_simd_dp_asimdall_FMAXNMV_asimdall_only_H // FMAXNMV_asimdall_only_H
                        when (_, '0', '00', '01111') => __encoding A64_simd_dp_asimdall_FMAXV_asimdall_only_H // FMAXV_asimdall_only_H
                        when (_, '0', '10', '01100') => __encoding A64_simd_dp_asimdall_FMINNMV_asimdall_only_H // FMINNMV_asimdall_only_H
                        when (_, '0', '10', '01111') => __encoding A64_simd_dp_asimdall_FMINV_asimdall_only_H // FMINV_asimdall_only_H
                        when (_, '1', _, '00011') => __encoding A64_simd_dp_asimdall_UADDLV_asimdall_only // UADDLV_asimdall_only
                        when (_, '1', _, '01010') => __encoding A64_simd_dp_asimdall_UMAXV_asimdall_only // UMAXV_asimdall_only
                        when (_, '1', _, '11010') => __encoding A64_simd_dp_asimdall_UMINV_asimdall_only // UMINV_asimdall_only
                        when (_, '1', _, '11011') => __UNALLOCATED
                        when ('1', '1', '00', '01100') => __encoding A64_simd_dp_asimdall_FMAXNMV_asimdall_only_SD // FMAXNMV_asimdall_only_SD
                        when ('1', '1', '00', '01111') => __encoding A64_simd_dp_asimdall_FMAXV_asimdall_only_SD // FMAXV_asimdall_only_SD
                        when ('1', '1', '10', '01100') => __encoding A64_simd_dp_asimdall_FMINNMV_asimdall_only_SD // FMINNMV_asimdall_only_SD
                        when ('1', '1', '10', '01111') => __encoding A64_simd_dp_asimdall_FMINV_asimdall_only_SD // FMINV_asimdall_only_SD
                        when ('0', '1', 'x0', '011x0') => __UNALLOCATED
                        when ('0', '1', 'x0', '01111') => __UNALLOCATED
                        when ('1', '1', 'x0', '01110') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x1xx', '01xxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x1xx', '1xxxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x1xx', 'xxxxxxx00', _) => // asimddiff
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when ('0', '0000') => __encoding A64_simd_dp_asimddiff_SADDL_asimddiff_L // SADDL_asimddiff_L
                        when ('0', '0001') => __encoding A64_simd_dp_asimddiff_SADDW_asimddiff_W // SADDW_asimddiff_W
                        when ('0', '0010') => __encoding A64_simd_dp_asimddiff_SSUBL_asimddiff_L // SSUBL_asimddiff_L
                        when ('0', '0011') => __encoding A64_simd_dp_asimddiff_SSUBW_asimddiff_W // SSUBW_asimddiff_W
                        when ('0', '0100') => __encoding A64_simd_dp_asimddiff_ADDHN_asimddiff_N // ADDHN_asimddiff_N
                        when ('0', '0101') => __encoding A64_simd_dp_asimddiff_SABAL_asimddiff_L // SABAL_asimddiff_L
                        when ('0', '0110') => __encoding A64_simd_dp_asimddiff_SUBHN_asimddiff_N // SUBHN_asimddiff_N
                        when ('0', '0111') => __encoding A64_simd_dp_asimddiff_SABDL_asimddiff_L // SABDL_asimddiff_L
                        when ('0', '1000') => __encoding A64_simd_dp_asimddiff_SMLAL_asimddiff_L // SMLAL_asimddiff_L
                        when ('0', '1001') => __encoding A64_simd_dp_asimddiff_SQDMLAL_asimddiff_L // SQDMLAL_asimddiff_L
                        when ('0', '1010') => __encoding A64_simd_dp_asimddiff_SMLSL_asimddiff_L // SMLSL_asimddiff_L
                        when ('0', '1011') => __encoding A64_simd_dp_asimddiff_SQDMLSL_asimddiff_L // SQDMLSL_asimddiff_L
                        when ('0', '1100') => __encoding A64_simd_dp_asimddiff_SMULL_asimddiff_L // SMULL_asimddiff_L
                        when ('0', '1101') => __encoding A64_simd_dp_asimddiff_SQDMULL_asimddiff_L // SQDMULL_asimddiff_L
                        when ('0', '1110') => __encoding A64_simd_dp_asimddiff_PMULL_asimddiff_L // PMULL_asimddiff_L
                        when ('0', '1111') => __UNALLOCATED
                        when ('1', '0000') => __encoding A64_simd_dp_asimddiff_UADDL_asimddiff_L // UADDL_asimddiff_L
                        when ('1', '0001') => __encoding A64_simd_dp_asimddiff_UADDW_asimddiff_W // UADDW_asimddiff_W
                        when ('1', '0010') => __encoding A64_simd_dp_asimddiff_USUBL_asimddiff_L // USUBL_asimddiff_L
                        when ('1', '0011') => __encoding A64_simd_dp_asimddiff_USUBW_asimddiff_W // USUBW_asimddiff_W
                        when ('1', '0100') => __encoding A64_simd_dp_asimddiff_RADDHN_asimddiff_N // RADDHN_asimddiff_N
                        when ('1', '0101') => __encoding A64_simd_dp_asimddiff_UABAL_asimddiff_L // UABAL_asimddiff_L
                        when ('1', '0110') => __encoding A64_simd_dp_asimddiff_RSUBHN_asimddiff_N // RSUBHN_asimddiff_N
                        when ('1', '0111') => __encoding A64_simd_dp_asimddiff_UABDL_asimddiff_L // UABDL_asimddiff_L
                        when ('1', '1xx1') => __UNALLOCATED
                        when ('1', '1000') => __encoding A64_simd_dp_asimddiff_UMLAL_asimddiff_L // UMLAL_asimddiff_L
                        when ('1', '1010') => __encoding A64_simd_dp_asimddiff_UMLSL_asimddiff_L // UMLSL_asimddiff_L
                        when ('1', '1100') => __encoding A64_simd_dp_asimddiff_UMULL_asimddiff_L // UMULL_asimddiff_L
                        when ('1', '1110') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x1xx', 'xxxxxxxx1', _) => // asimdsame
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when ('0', _, '00000') => __encoding A64_simd_dp_asimdsame_SHADD_asimdsame_only // SHADD_asimdsame_only
                        when ('0', _, '00001') => __encoding A64_simd_dp_asimdsame_SQADD_asimdsame_only // SQADD_asimdsame_only
                        when ('0', _, '00010') => __encoding A64_simd_dp_asimdsame_SRHADD_asimdsame_only // SRHADD_asimdsame_only
                        when ('0', _, '00100') => __encoding A64_simd_dp_asimdsame_SHSUB_asimdsame_only // SHSUB_asimdsame_only
                        when ('0', _, '00101') => __encoding A64_simd_dp_asimdsame_SQSUB_asimdsame_only // SQSUB_asimdsame_only
                        when ('0', _, '00110') => __encoding A64_simd_dp_asimdsame_CMGT_asimdsame_only // CMGT_asimdsame_only
                        when ('0', _, '00111') => __encoding A64_simd_dp_asimdsame_CMGE_asimdsame_only // CMGE_asimdsame_only
                        when ('0', _, '01000') => __encoding A64_simd_dp_asimdsame_SSHL_asimdsame_only // SSHL_asimdsame_only
                        when ('0', _, '01001') => __encoding A64_simd_dp_asimdsame_SQSHL_asimdsame_only // SQSHL_asimdsame_only
                        when ('0', _, '01010') => __encoding A64_simd_dp_asimdsame_SRSHL_asimdsame_only // SRSHL_asimdsame_only
                        when ('0', _, '01011') => __encoding A64_simd_dp_asimdsame_SQRSHL_asimdsame_only // SQRSHL_asimdsame_only
                        when ('0', _, '01100') => __encoding A64_simd_dp_asimdsame_SMAX_asimdsame_only // SMAX_asimdsame_only
                        when ('0', _, '01101') => __encoding A64_simd_dp_asimdsame_SMIN_asimdsame_only // SMIN_asimdsame_only
                        when ('0', _, '01110') => __encoding A64_simd_dp_asimdsame_SABD_asimdsame_only // SABD_asimdsame_only
                        when ('0', _, '01111') => __encoding A64_simd_dp_asimdsame_SABA_asimdsame_only // SABA_asimdsame_only
                        when ('0', _, '10000') => __encoding A64_simd_dp_asimdsame_ADD_asimdsame_only // ADD_asimdsame_only
                        when ('0', _, '10001') => __encoding A64_simd_dp_asimdsame_CMTST_asimdsame_only // CMTST_asimdsame_only
                        when ('0', _, '10010') => __encoding A64_simd_dp_asimdsame_MLA_asimdsame_only // MLA_asimdsame_only
                        when ('0', _, '10011') => __encoding A64_simd_dp_asimdsame_MUL_asimdsame_only // MUL_asimdsame_only
                        when ('0', _, '10100') => __encoding A64_simd_dp_asimdsame_SMAXP_asimdsame_only // SMAXP_asimdsame_only
                        when ('0', _, '10101') => __encoding A64_simd_dp_asimdsame_SMINP_asimdsame_only // SMINP_asimdsame_only
                        when ('0', _, '10110') => __encoding A64_simd_dp_asimdsame_SQDMULH_asimdsame_only // SQDMULH_asimdsame_only
                        when ('0', _, '10111') => __encoding A64_simd_dp_asimdsame_ADDP_asimdsame_only // ADDP_asimdsame_only
                        when ('0', '1x', '11011') => __encoding A64_simd_dp_asimdsame_FAMAX_asimdsame_only // FAMAX_asimdsame_only
                        when ('0', 'x1', '11101') => __UNALLOCATED
                        when ('0', '0x', '11000') => __encoding A64_simd_dp_asimdsame_FMAXNM_asimdsame_only // FMAXNM_asimdsame_only
                        when ('0', '0x', '11001') => __encoding A64_simd_dp_asimdsame_FMLA_asimdsame_only // FMLA_asimdsame_only
                        when ('0', '0x', '11010') => __encoding A64_simd_dp_asimdsame_FADD_asimdsame_only // FADD_asimdsame_only
                        when ('0', '0x', '11011') => __encoding A64_simd_dp_asimdsame_FMULX_asimdsame_only // FMULX_asimdsame_only
                        when ('0', '0x', '11100') => __encoding A64_simd_dp_asimdsame_FCMEQ_asimdsame_only // FCMEQ_asimdsame_only
                        when ('0', '0x', '11110') => __encoding A64_simd_dp_asimdsame_FMAX_asimdsame_only // FMAX_asimdsame_only
                        when ('0', '0x', '11111') => __encoding A64_simd_dp_asimdsame_FRECPS_asimdsame_only // FRECPS_asimdsame_only
                        when ('0', '00', '00011') => __encoding A64_simd_dp_asimdsame_AND_asimdsame_only // AND_asimdsame_only
                        when ('0', '00', '11101') => __encoding A64_simd_dp_asimdsame_FMLAL_asimdsame_F // FMLAL_asimdsame_F
                        when ('0', '01', '00011') => __encoding A64_simd_dp_asimdsame_BIC_asimdsame_only // BIC_asimdsame_only
                        when ('0', '1x', '11000') => __encoding A64_simd_dp_asimdsame_FMINNM_asimdsame_only // FMINNM_asimdsame_only
                        when ('0', '1x', '11001') => __encoding A64_simd_dp_asimdsame_FMLS_asimdsame_only // FMLS_asimdsame_only
                        when ('0', '1x', '11010') => __encoding A64_simd_dp_asimdsame_FSUB_asimdsame_only // FSUB_asimdsame_only
                        when ('0', '1x', '11100') => __UNALLOCATED
                        when ('0', '1x', '11110') => __encoding A64_simd_dp_asimdsame_FMIN_asimdsame_only // FMIN_asimdsame_only
                        when ('0', '1x', '11111') => __encoding A64_simd_dp_asimdsame_FRSQRTS_asimdsame_only // FRSQRTS_asimdsame_only
                        when ('0', '10', '00011') => __encoding A64_simd_dp_asimdsame_ORR_asimdsame_only // ORR_asimdsame_only
                        when ('0', '10', '11101') => __encoding A64_simd_dp_asimdsame_FMLSL_asimdsame_F // FMLSL_asimdsame_F
                        when ('0', '11', '00011') => __encoding A64_simd_dp_asimdsame_ORN_asimdsame_only // ORN_asimdsame_only
                        when ('1', _, '00000') => __encoding A64_simd_dp_asimdsame_UHADD_asimdsame_only // UHADD_asimdsame_only
                        when ('1', _, '00001') => __encoding A64_simd_dp_asimdsame_UQADD_asimdsame_only // UQADD_asimdsame_only
                        when ('1', _, '00010') => __encoding A64_simd_dp_asimdsame_URHADD_asimdsame_only // URHADD_asimdsame_only
                        when ('1', _, '00100') => __encoding A64_simd_dp_asimdsame_UHSUB_asimdsame_only // UHSUB_asimdsame_only
                        when ('1', _, '00101') => __encoding A64_simd_dp_asimdsame_UQSUB_asimdsame_only // UQSUB_asimdsame_only
                        when ('1', _, '00110') => __encoding A64_simd_dp_asimdsame_CMHI_asimdsame_only // CMHI_asimdsame_only
                        when ('1', _, '00111') => __encoding A64_simd_dp_asimdsame_CMHS_asimdsame_only // CMHS_asimdsame_only
                        when ('1', _, '01000') => __encoding A64_simd_dp_asimdsame_USHL_asimdsame_only // USHL_asimdsame_only
                        when ('1', _, '01001') => __encoding A64_simd_dp_asimdsame_UQSHL_asimdsame_only // UQSHL_asimdsame_only
                        when ('1', _, '01010') => __encoding A64_simd_dp_asimdsame_URSHL_asimdsame_only // URSHL_asimdsame_only
                        when ('1', _, '01011') => __encoding A64_simd_dp_asimdsame_UQRSHL_asimdsame_only // UQRSHL_asimdsame_only
                        when ('1', _, '01100') => __encoding A64_simd_dp_asimdsame_UMAX_asimdsame_only // UMAX_asimdsame_only
                        when ('1', _, '01101') => __encoding A64_simd_dp_asimdsame_UMIN_asimdsame_only // UMIN_asimdsame_only
                        when ('1', _, '01110') => __encoding A64_simd_dp_asimdsame_UABD_asimdsame_only // UABD_asimdsame_only
                        when ('1', _, '01111') => __encoding A64_simd_dp_asimdsame_UABA_asimdsame_only // UABA_asimdsame_only
                        when ('1', _, '10000') => __encoding A64_simd_dp_asimdsame_SUB_asimdsame_only // SUB_asimdsame_only
                        when ('1', _, '10001') => __encoding A64_simd_dp_asimdsame_CMEQ_asimdsame_only // CMEQ_asimdsame_only
                        when ('1', _, '10010') => __encoding A64_simd_dp_asimdsame_MLS_asimdsame_only // MLS_asimdsame_only
                        when ('1', _, '10011') => __encoding A64_simd_dp_asimdsame_PMUL_asimdsame_only // PMUL_asimdsame_only
                        when ('1', _, '10100') => __encoding A64_simd_dp_asimdsame_UMAXP_asimdsame_only // UMAXP_asimdsame_only
                        when ('1', _, '10101') => __encoding A64_simd_dp_asimdsame_UMINP_asimdsame_only // UMINP_asimdsame_only
                        when ('1', _, '10110') => __encoding A64_simd_dp_asimdsame_SQRDMULH_asimdsame_only // SQRDMULH_asimdsame_only
                        when ('1', _, '10111') => __UNALLOCATED
                        when ('1', '1x', '11011') => __encoding A64_simd_dp_asimdsame_FAMIN_asimdsame_only // FAMIN_asimdsame_only
                        when ('1', '1x', '11111') => __encoding A64_simd_dp_asimdsame_FSCALE_asimdsame_only // FSCALE_asimdsame_only
                        when ('1', 'x1', '11001') => __UNALLOCATED
                        when ('1', '0x', '11000') => __encoding A64_simd_dp_asimdsame_FMAXNMP_asimdsame_only // FMAXNMP_asimdsame_only
                        when ('1', '0x', '11010') => __encoding A64_simd_dp_asimdsame_FADDP_asimdsame_only // FADDP_asimdsame_only
                        when ('1', '0x', '11011') => __encoding A64_simd_dp_asimdsame_FMUL_asimdsame_only // FMUL_asimdsame_only
                        when ('1', '0x', '11100') => __encoding A64_simd_dp_asimdsame_FCMGE_asimdsame_only // FCMGE_asimdsame_only
                        when ('1', '0x', '11101') => __encoding A64_simd_dp_asimdsame_FACGE_asimdsame_only // FACGE_asimdsame_only
                        when ('1', '0x', '11110') => __encoding A64_simd_dp_asimdsame_FMAXP_asimdsame_only // FMAXP_asimdsame_only
                        when ('1', '0x', '11111') => __encoding A64_simd_dp_asimdsame_FDIV_asimdsame_only // FDIV_asimdsame_only
                        when ('1', '00', '00011') => __encoding A64_simd_dp_asimdsame_EOR_asimdsame_only // EOR_asimdsame_only
                        when ('1', '00', '11001') => __encoding A64_simd_dp_asimdsame_FMLAL2_asimdsame_F // FMLAL2_asimdsame_F
                        when ('1', '01', '00011') => __encoding A64_simd_dp_asimdsame_BSL_asimdsame_only // BSL_asimdsame_only
                        when ('1', '1x', '11000') => __encoding A64_simd_dp_asimdsame_FMINNMP_asimdsame_only // FMINNMP_asimdsame_only
                        when ('1', '1x', '11010') => __encoding A64_simd_dp_asimdsame_FABD_asimdsame_only // FABD_asimdsame_only
                        when ('1', '1x', '11100') => __encoding A64_simd_dp_asimdsame_FCMGT_asimdsame_only // FCMGT_asimdsame_only
                        when ('1', '1x', '11101') => __encoding A64_simd_dp_asimdsame_FACGT_asimdsame_only // FACGT_asimdsame_only
                        when ('1', '1x', '11110') => __encoding A64_simd_dp_asimdsame_FMINP_asimdsame_only // FMINP_asimdsame_only
                        when ('1', '10', '00011') => __encoding A64_simd_dp_asimdsame_BIT_asimdsame_only // BIT_asimdsame_only
                        when ('1', '10', '11001') => __encoding A64_simd_dp_asimdsame_FMLSL2_asimdsame_F // FMLSL2_asimdsame_F
                        when ('1', '11', '00011') => __encoding A64_simd_dp_asimdsame_BIF_asimdsame_only // BIF_asimdsame_only
                when ('0xx0', _, '10', '0000', 'xxxxxxxx1', _) => // asimdimm
                    __field Q 30 +: 1
                    __field op 29 +: 1
                    __field a 18 +: 1
                    __field b 17 +: 1
                    __field c 16 +: 1
                    __field cmode 12 +: 4
                    __field o2 11 +: 1
                    __field d 9 +: 1
                    __field e 8 +: 1
                    __field f 7 +: 1
                    __field g 6 +: 1
                    __field h 5 +: 1
                    __field Rd 0 +: 5
                    case (Q, op, cmode, o2) of
                        when (_, '0', '0xxx', '1') => __UNALLOCATED
                        when (_, '0', '0xx0', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_L_sl
                        when (_, '0', '0xx1', '0') => __encoding A64_simd_dp_asimdimm_ORR_asimdimm_L_hl // ORR_asimdimm_L_sl
                        when (_, '0', '10xx', '1') => __UNALLOCATED
                        when (_, '0', '10x0', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_L_hl
                        when (_, '0', '10x1', '0') => __encoding A64_simd_dp_asimdimm_ORR_asimdimm_L_hl // ORR_asimdimm_L_hl
                        when (_, '0', '110x', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_M_sm
                        when (_, '0', '110x', '1') => __UNALLOCATED
                        when (_, '0', '1110', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_N_b
                        when (_, '0', '1110', '1') => __UNALLOCATED
                        when (_, '0', '1111', '0') => __encoding A64_simd_dp_asimdimm_FMOV_asimdimm_S_s // FMOV_asimdimm_S_s
                        when (_, '0', '1111', '1') => __encoding A64_simd_dp_asimdimm_FMOV_asimdimm_H_h // FMOV_asimdimm_H_h
                        when (_, '1', _, '1') => __UNALLOCATED
                        when (_, '1', '0xx0', '0') => __encoding A64_simd_dp_asimdimm_MVNI_asimdimm_L_hl // MVNI_asimdimm_L_sl
                        when (_, '1', '0xx1', '0') => __encoding A64_simd_dp_asimdimm_BIC_asimdimm_L_hl // BIC_asimdimm_L_sl
                        when (_, '1', '10x0', '0') => __encoding A64_simd_dp_asimdimm_MVNI_asimdimm_L_hl // MVNI_asimdimm_L_hl
                        when (_, '1', '10x1', '0') => __encoding A64_simd_dp_asimdimm_BIC_asimdimm_L_hl // BIC_asimdimm_L_hl
                        when (_, '1', '110x', '0') => __encoding A64_simd_dp_asimdimm_MVNI_asimdimm_L_hl // MVNI_asimdimm_M_sm
                        when ('0', '1', '1110', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_D_ds
                        when ('0', '1', '1111', '0') => __UNALLOCATED
                        when ('1', '1', '1110', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_D2_d
                        when ('1', '1', '1111', '0') => __encoding A64_simd_dp_asimdimm_FMOV_asimdimm_S_s // FMOV_asimdimm_D2_d
                when ('0xx0', _, '10', !'0000', 'xxxxxxxx1', _) => // asimdshf
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field immh 19 +: 4
                    __field immb 16 +: 3
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, immh, opcode) of
                        when (_, _, '0xxx1') => __UNALLOCATED
                        when (_, _, '101x1') => __UNALLOCATED
                        when (_, _, '110xx') => __UNALLOCATED
                        when (_, _, '11101') => __UNALLOCATED
                        when (_, 'xxx1', '1x110') => __UNALLOCATED
                        when (_, 'xx10', '1x110') => __UNALLOCATED
                        when (_, 'x100', '1x110') => __UNALLOCATED
                        when (_, '0000', 'x0xx0') => __UNALLOCATED
                        when (_, '0000', '01x10') => __UNALLOCATED
                        when (_, '0000', '100x1') => __UNALLOCATED
                        when (_, '0000', '111x0') => __UNALLOCATED
                        when (_, '0000', '11111') => __UNALLOCATED
                        when (_, '1000', '1x110') => __UNALLOCATED
                        when ('0', !'0000', '00000') => __encoding A64_simd_dp_asimdshf_SSHR_asimdshf_R // SSHR_asimdshf_R
                        when ('0', !'0000', '00010') => __encoding A64_simd_dp_asimdshf_SSRA_asimdshf_R // SSRA_asimdshf_R
                        when ('0', !'0000', '00100') => __encoding A64_simd_dp_asimdshf_SRSHR_asimdshf_R // SRSHR_asimdshf_R
                        when ('0', !'0000', '00110') => __encoding A64_simd_dp_asimdshf_SRSRA_asimdshf_R // SRSRA_asimdshf_R
                        when ('0', _, '01x00') => __UNALLOCATED
                        when ('0', !'0000', '01010') => __encoding A64_simd_dp_asimdshf_SHL_asimdshf_R // SHL_asimdshf_R
                        when ('0', !'0000', '01110') => __encoding A64_simd_dp_asimdshf_SQSHL_asimdshf_R // SQSHL_asimdshf_R
                        when ('0', !'0000', '10000') => __encoding A64_simd_dp_asimdshf_SHRN_asimdshf_N // SHRN_asimdshf_N
                        when ('0', !'0000', '10001') => __encoding A64_simd_dp_asimdshf_RSHRN_asimdshf_N // RSHRN_asimdshf_N
                        when ('0', !'0000', '10010') => __encoding A64_simd_dp_asimdshf_SQSHRN_asimdshf_N // SQSHRN_asimdshf_N
                        when ('0', !'0000', '10011') => __encoding A64_simd_dp_asimdshf_SQRSHRN_asimdshf_N // SQRSHRN_asimdshf_N
                        when ('0', !'0000', '10100') => __encoding A64_simd_dp_asimdshf_SSHLL_asimdshf_L // SSHLL_asimdshf_L
                        when ('0', !'0000', '11100') => __encoding A64_simd_dp_asimdshf_SCVTF_asimdshf_C // SCVTF_asimdshf_C
                        when ('0', !'0000', '11111') => __encoding A64_simd_dp_asimdshf_FCVTZS_asimdshf_C // FCVTZS_asimdshf_C
                        when ('1', !'0000', '00000') => __encoding A64_simd_dp_asimdshf_USHR_asimdshf_R // USHR_asimdshf_R
                        when ('1', !'0000', '00010') => __encoding A64_simd_dp_asimdshf_USRA_asimdshf_R // USRA_asimdshf_R
                        when ('1', !'0000', '00100') => __encoding A64_simd_dp_asimdshf_URSHR_asimdshf_R // URSHR_asimdshf_R
                        when ('1', !'0000', '00110') => __encoding A64_simd_dp_asimdshf_URSRA_asimdshf_R // URSRA_asimdshf_R
                        when ('1', !'0000', '01000') => __encoding A64_simd_dp_asimdshf_SRI_asimdshf_R // SRI_asimdshf_R
                        when ('1', !'0000', '01010') => __encoding A64_simd_dp_asimdshf_SLI_asimdshf_R // SLI_asimdshf_R
                        when ('1', !'0000', '01100') => __encoding A64_simd_dp_asimdshf_SQSHLU_asimdshf_R // SQSHLU_asimdshf_R
                        when ('1', !'0000', '01110') => __encoding A64_simd_dp_asimdshf_UQSHL_asimdshf_R // UQSHL_asimdshf_R
                        when ('1', !'0000', '10000') => __encoding A64_simd_dp_asimdshf_SQSHRUN_asimdshf_N // SQSHRUN_asimdshf_N
                        when ('1', !'0000', '10001') => __encoding A64_simd_dp_asimdshf_SQRSHRUN_asimdshf_N // SQRSHRUN_asimdshf_N
                        when ('1', !'0000', '10010') => __encoding A64_simd_dp_asimdshf_UQSHRN_asimdshf_N // UQSHRN_asimdshf_N
                        when ('1', !'0000', '10011') => __encoding A64_simd_dp_asimdshf_UQRSHRN_asimdshf_N // UQRSHRN_asimdshf_N
                        when ('1', !'0000', '10100') => __encoding A64_simd_dp_asimdshf_USHLL_asimdshf_L // USHLL_asimdshf_L
                        when ('1', !'0000', '11100') => __encoding A64_simd_dp_asimdshf_UCVTF_asimdshf_C // UCVTF_asimdshf_C
                        when ('1', !'0000', '11111') => __encoding A64_simd_dp_asimdshf_FCVTZU_asimdshf_C // FCVTZU_asimdshf_C
                        when ('1', '0000', '01x00') => __UNALLOCATED
                when ('0xx0', _, '11', _, 'xxxxxxxx1', _) => __UNPREDICTABLE
                when ('0xx0', _, '1x', _, 'xxxxxxxx0', _) => // asimdelem
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field L 21 +: 1
                    __field M 20 +: 1
                    __field Rm 16 +: 4
                    __field opcode 12 +: 4
                    __field H 11 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, U, size, opcode) of
                        when (_, _, '01', '1001') => __UNALLOCATED
                        when (_, '0', _, '0010') => __encoding A64_simd_dp_asimdelem_SMLAL_asimdelem_L // SMLAL_asimdelem_L
                        when (_, '0', _, '0011') => __encoding A64_simd_dp_asimdelem_SQDMLAL_asimdelem_L // SQDMLAL_asimdelem_L
                        when (_, '0', _, '0110') => __encoding A64_simd_dp_asimdelem_SMLSL_asimdelem_L // SMLSL_asimdelem_L
                        when (_, '0', _, '0111') => __encoding A64_simd_dp_asimdelem_SQDMLSL_asimdelem_L // SQDMLSL_asimdelem_L
                        when (_, '0', _, '1000') => __encoding A64_simd_dp_asimdelem_MUL_asimdelem_R // MUL_asimdelem_R
                        when (_, '0', _, '1010') => __encoding A64_simd_dp_asimdelem_SMULL_asimdelem_L // SMULL_asimdelem_L
                        when (_, '0', _, '1011') => __encoding A64_simd_dp_asimdelem_SQDMULL_asimdelem_L // SQDMULL_asimdelem_L
                        when (_, '0', _, '1100') => __encoding A64_simd_dp_asimdelem_SQDMULH_asimdelem_R // SQDMULH_asimdelem_R
                        when (_, '0', _, '1101') => __encoding A64_simd_dp_asimdelem_SQRDMULH_asimdelem_R // SQRDMULH_asimdelem_R
                        when (_, '0', _, '1110') => __encoding A64_simd_dp_asimdelem_SDOT_asimdelem_D // SDOT_asimdelem_D
                        when (_, '0', '0x', '0100') => __UNALLOCATED
                        when (_, '0', '00', '0000') => __encoding A64_simd_dp_asimdelem_FDOT_asimdelem_D // FDOT_asimdelem_D
                        when (_, '0', '00', '0001') => __encoding A64_simd_dp_asimdelem_FMLA_asimdelem_RH_H // FMLA_asimdelem_RH_H
                        when (_, '0', '00', '0101') => __encoding A64_simd_dp_asimdelem_FMLS_asimdelem_RH_H // FMLS_asimdelem_RH_H
                        when (_, '0', '00', '1001') => __encoding A64_simd_dp_asimdelem_FMUL_asimdelem_RH_H // FMUL_asimdelem_RH_H
                        when (_, '0', '00', '1111') => __encoding A64_simd_dp_asimdelem_SUDOT_asimdelem_D // SUDOT_asimdelem_D
                        when (_, '0', '01', '0x01') => __UNALLOCATED
                        when (_, '0', '01', '0000') => __encoding A64_simd_dp_asimdelem_FDOT_asimdelem_G // FDOT_asimdelem_G
                        when (_, '0', '01', '1111') => __encoding A64_simd_dp_asimdelem_BFDOT_asimdelem_E // BFDOT_asimdelem_E
                        when (_, '0', '1x', '0001') => __encoding A64_simd_dp_asimdelem_FMLA_asimdelem_R_SD // FMLA_asimdelem_R_SD
                        when (_, '0', '1x', '0101') => __encoding A64_simd_dp_asimdelem_FMLS_asimdelem_R_SD // FMLS_asimdelem_R_SD
                        when (_, '0', '1x', '1001') => __encoding A64_simd_dp_asimdelem_FMUL_asimdelem_R_SD // FMUL_asimdelem_R_SD
                        when (_, '0', '10', '0000') => __encoding A64_simd_dp_asimdelem_FMLAL_asimdelem_LH // FMLAL_asimdelem_LH
                        when (_, '0', '10', '0100') => __encoding A64_simd_dp_asimdelem_FMLSL_asimdelem_LH // FMLSL_asimdelem_LH
                        when (_, '0', '10', '1111') => __encoding A64_simd_dp_asimdelem_USDOT_asimdelem_D // USDOT_asimdelem_D
                        when (_, '0', '11', '0100') => __UNALLOCATED
                        when (_, '0', '11', '1111') => __encoding A64_simd_dp_asimdelem_BFMLAL_asimdelem_F // BFMLAL_asimdelem_F
                        when (_, '1', _, '0xx1') => __encoding A64_simd_dp_asimdelem_FCMLA_advsimd_elt // FCMLA_advsimd_elt
                        when (_, '1', _, '0000') => __encoding A64_simd_dp_asimdelem_MLA_asimdelem_R // MLA_asimdelem_R
                        when (_, '1', _, '0010') => __encoding A64_simd_dp_asimdelem_UMLAL_asimdelem_L // UMLAL_asimdelem_L
                        when (_, '1', _, '0100') => __encoding A64_simd_dp_asimdelem_MLS_asimdelem_R // MLS_asimdelem_R
                        when (_, '1', _, '0110') => __encoding A64_simd_dp_asimdelem_UMLSL_asimdelem_L // UMLSL_asimdelem_L
                        when (_, '1', _, '1010') => __encoding A64_simd_dp_asimdelem_UMULL_asimdelem_L // UMULL_asimdelem_L
                        when (_, '1', _, '1011') => __UNALLOCATED
                        when (_, '1', _, '1101') => __encoding A64_simd_dp_asimdelem_SQRDMLAH_asimdelem_R // SQRDMLAH_asimdelem_R
                        when (_, '1', _, '1110') => __encoding A64_simd_dp_asimdelem_UDOT_asimdelem_D // UDOT_asimdelem_D
                        when (_, '1', _, '1111') => __encoding A64_simd_dp_asimdelem_SQRDMLSH_asimdelem_R // SQRDMLSH_asimdelem_R
                        when (_, '1', '0x', '1100') => __UNALLOCATED
                        when (_, '1', '00', '1001') => __encoding A64_simd_dp_asimdelem_FMULX_asimdelem_RH_H // FMULX_asimdelem_RH_H
                        when (_, '1', '1x', '1001') => __encoding A64_simd_dp_asimdelem_FMULX_asimdelem_R_SD // FMULX_asimdelem_R_SD
                        when (_, '1', '10', '1000') => __encoding A64_simd_dp_asimdelem_FMLAL2_asimdelem_LH // FMLAL2_asimdelem_LH
                        when (_, '1', '10', '1100') => __encoding A64_simd_dp_asimdelem_FMLSL2_asimdelem_LH // FMLSL2_asimdelem_LH
                        when (_, '1', '11', '1x00') => __UNALLOCATED
                        when ('0', '0', '11', '0000') => __encoding A64_simd_dp_asimdelem_FMLALB_asimdelem_H // FMLALB_asimdelem_H
                        when ('0', '1', '00', '1000') => __encoding A64_simd_dp_asimdelem_FMLALLBB_asimdelem_J // FMLALLBB_asimdelem_J
                        when ('0', '1', '01', '1000') => __encoding A64_simd_dp_asimdelem_FMLALLBB_asimdelem_J // FMLALLBT_asimdelem_J
                        when ('1', '0', '11', '0000') => __encoding A64_simd_dp_asimdelem_FMLALB_asimdelem_H // FMLALT_asimdelem_H
                        when ('1', '1', '00', '1000') => __encoding A64_simd_dp_asimdelem_FMLALLBB_asimdelem_J // FMLALLTB_asimdelem_J
                        when ('1', '1', '01', '1000') => __encoding A64_simd_dp_asimdelem_FMLALLBB_asimdelem_J // FMLALLTT_asimdelem_J
                when ('1100', _, '00', '10xx', 'xxx10xxxx', _) => // crypto3_imm2
                    __field Rm 16 +: 5
                    __field imm2 12 +: 2
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('00') => __encoding A64_simd_dp_crypto3_imm2_SM3TT1A_VVV4_crypto3_imm2 // SM3TT1A_VVV4_crypto3_imm2
                        when ('01') => __encoding A64_simd_dp_crypto3_imm2_SM3TT1B_VVV4_crypto3_imm2 // SM3TT1B_VVV4_crypto3_imm2
                        when ('10') => __encoding A64_simd_dp_crypto3_imm2_SM3TT2A_VVV4_crypto3_imm2 // SM3TT2A_VVV4_crypto3_imm2
                        when ('11') => __encoding A64_simd_dp_crypto3_imm2_SM3TT2B_VVV_crypto3_imm2 // SM3TT2B_VVV_crypto3_imm2
                when ('1100', _, '00', '11xx', 'xxx1x00xx', _) => // cryptosha512_3
                    __field Rm 16 +: 5
                    __field O 14 +: 1
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (O, opcode) of
                        when ('0', '00') => __encoding A64_simd_dp_cryptosha512_3_SHA512H_QQV_cryptosha512_3 // SHA512H_QQV_cryptosha512_3
                        when ('0', '01') => __encoding A64_simd_dp_cryptosha512_3_SHA512H2_QQV_cryptosha512_3 // SHA512H2_QQV_cryptosha512_3
                        when ('0', '10') => __encoding A64_simd_dp_cryptosha512_3_SHA512SU1_VVV2_cryptosha512_3 // SHA512SU1_VVV2_cryptosha512_3
                        when ('0', '11') => __encoding A64_simd_dp_cryptosha512_3_RAX1_VVV2_cryptosha512_3 // RAX1_VVV2_cryptosha512_3
                        when ('1', '00') => __encoding A64_simd_dp_cryptosha512_3_SM3PARTW1_VVV4_cryptosha512_3 // SM3PARTW1_VVV4_cryptosha512_3
                        when ('1', '01') => __encoding A64_simd_dp_cryptosha512_3_SM3PARTW2_VVV4_cryptosha512_3 // SM3PARTW2_VVV4_cryptosha512_3
                        when ('1', '10') => __encoding A64_simd_dp_cryptosha512_3_SM4EKEY_VVV4_cryptosha512_3 // SM4EKEY_VVV4_cryptosha512_3
                        when ('1', '11') => __UNALLOCATED
                when ('1100', _, '00', _, 'xxx0xxxxx', _) => // crypto4
                    __field Op0 21 +: 2
                    __field Rm 16 +: 5
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Op0) of
                        when ('00') => __encoding A64_simd_dp_crypto4_EOR3_VVV16_crypto4 // EOR3_VVV16_crypto4
                        when ('01') => __encoding A64_simd_dp_crypto4_BCAX_VVV16_crypto4 // BCAX_VVV16_crypto4
                        when ('10') => __encoding A64_simd_dp_crypto4_SM3SS1_VVV4_crypto4 // SM3SS1_VVV4_crypto4
                        when ('11') => __UNALLOCATED
                when ('1100', _, '01', '00xx', _, _) => // crypto3_imm6
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case () of
                        when () => __encoding A64_simd_dp_crypto3_imm6_XAR_VVV2_crypto3_imm6 // XAR_VVV2_crypto3_imm6
                when ('1100', _, '01', '1000', '0001000xx', _) => // cryptosha512_2
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('00') => __encoding A64_simd_dp_cryptosha512_2_SHA512SU0_VV2_cryptosha512_2 // SHA512SU0_VV2_cryptosha512_2
                        when ('01') => __encoding A64_simd_dp_cryptosha512_2_SM4E_VV4_cryptosha512_2 // SM4E_VV4_cryptosha512_2
                        when ('1x') => __UNALLOCATED
                when ('1xx0', _, '1x', _, _, _) => __UNPREDICTABLE
                when ('x0x1', _, '0x', 'x0xx', _, _) => // float2fix
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field rmode 19 +: 2
                    __field opcode 16 +: 3
                    __field scale 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, ftype, rmode, opcode) of
                        when (_, '0', _, _, '1xx') => __UNALLOCATED
                        when (_, '0', 'x1', 'x1', '01x') => __UNALLOCATED
                        when (_, '0', 'x1', '0x', '00x') => __UNALLOCATED
                        when (_, '0', 'x1', '10', '0xx') => __UNALLOCATED
                        when (_, '0', '00', 'x1', '01x') => __UNALLOCATED
                        when (_, '0', '00', '0x', '00x') => __UNALLOCATED
                        when (_, '0', '00', '10', '0xx') => __UNALLOCATED
                        when (_, '0', '10', _, '0xx') => __UNALLOCATED
                        when (_, '1', _, _, _) => __UNALLOCATED
                        when ('0', '0', '00', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_S32_float2fix
                        when ('0', '0', '00', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_S32_float2fix
                        when ('0', '0', '00', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_32S_float2fix
                        when ('0', '0', '00', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_32S_float2fix
                        when ('0', '0', '01', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_D32_float2fix
                        when ('0', '0', '01', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_D32_float2fix
                        when ('0', '0', '01', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_32D_float2fix
                        when ('0', '0', '01', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_32D_float2fix
                        when ('0', '0', '11', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_H32_float2fix
                        when ('0', '0', '11', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_H32_float2fix
                        when ('0', '0', '11', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_32H_float2fix
                        when ('0', '0', '11', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_32H_float2fix
                        when ('1', '0', '00', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_S64_float2fix
                        when ('1', '0', '00', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_S64_float2fix
                        when ('1', '0', '00', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_64S_float2fix
                        when ('1', '0', '00', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_64S_float2fix
                        when ('1', '0', '01', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_D64_float2fix
                        when ('1', '0', '01', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_D64_float2fix
                        when ('1', '0', '01', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_64D_float2fix
                        when ('1', '0', '01', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_64D_float2fix
                        when ('1', '0', '11', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_H64_float2fix
                        when ('1', '0', '11', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_H64_float2fix
                        when ('1', '0', '11', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_64H_float2fix
                        when ('1', '0', '11', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_64H_float2fix
                when ('x0x1', _, '0x', 'x1xx', 'xxx000000', _) => // float2int
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field rmode 19 +: 2
                    __field opcode 16 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, ftype, rmode, opcode) of
                        when (_, '0', _, '01', '10x') => __UNALLOCATED
                        when (_, '0', 'x1', 'x1', '01x') => __UNALLOCATED
                        when (_, '0', 'x1', '10', '01x') => __UNALLOCATED
                        when (_, '0', 'x1', '10', '1xx') => __UNALLOCATED
                        when (_, '0', 'x1', '11', '1x1') => __UNALLOCATED
                        when (_, '0', 'x1', '11', '100') => __UNALLOCATED
                        when (_, '0', '00', 'x1', '01x') => __UNALLOCATED
                        when (_, '0', '00', '10', '01x') => __UNALLOCATED
                        when (_, '0', '00', '10', '1xx') => __UNALLOCATED
                        when (_, '0', '00', '11', '1x1') => __UNALLOCATED
                        when (_, '0', '00', '11', '100') => __UNALLOCATED
                        when (_, '0', '10', '00', _) => __UNALLOCATED
                        when (_, '0', '10', '01', '0xx') => __UNALLOCATED
                        when (_, '0', '10', '1x', _) => __UNALLOCATED
                        when (_, '1', _, _, _) => __UNALLOCATED
                        when ('0', '0', '00', 'x1', '110') => __UNALLOCATED
                        when ('0', '0', '00', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_32S_float2int
                        when ('0', '0', '00', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_32S_float2int
                        when ('0', '0', '00', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_S32_float2int
                        when ('0', '0', '00', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_S32_float2int
                        when ('0', '0', '00', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_32S_float2int
                        when ('0', '0', '00', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_32S_float2int
                        when ('0', '0', '00', '00', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_32S_float2int
                        when ('0', '0', '00', '00', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_S32_float2int
                        when ('0', '0', '00', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_32S_float2int
                        when ('0', '0', '00', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_32S_float2int
                        when ('0', '0', '00', '01', '111') => __UNALLOCATED
                        when ('0', '0', '00', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_32S_float2int
                        when ('0', '0', '00', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_32S_float2int
                        when ('0', '0', '00', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_32S_float2int
                        when ('0', '0', '00', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_32S_float2int
                        when ('0', '0', '01', '0x', '11x') => __UNALLOCATED
                        when ('0', '0', '01', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_32D_float2int
                        when ('0', '0', '01', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_32D_float2int
                        when ('0', '0', '01', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_D32_float2int
                        when ('0', '0', '01', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_D32_float2int
                        when ('0', '0', '01', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_32D_float2int
                        when ('0', '0', '01', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_32D_float2int
                        when ('0', '0', '01', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_32D_float2int
                        when ('0', '0', '01', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_32D_float2int
                        when ('0', '0', '01', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_32D_float2int
                        when ('0', '0', '01', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_32D_float2int
                        when ('0', '0', '01', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_32D_float2int
                        when ('0', '0', '01', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_32D_float2int
                        when ('0', '0', '01', '11', '110') => __encoding A64_simd_dp_float2int_FJCVTZS_32D_float2int // FJCVTZS_32D_float2int
                        when ('0', '0', '1x', '01', '11x') => __UNALLOCATED
                        when ('0', '0', '11', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_32H_float2int
                        when ('0', '0', '11', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_32H_float2int
                        when ('0', '0', '11', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_H32_float2int
                        when ('0', '0', '11', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_H32_float2int
                        when ('0', '0', '11', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_32H_float2int
                        when ('0', '0', '11', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_32H_float2int
                        when ('0', '0', '11', '00', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_32H_float2int
                        when ('0', '0', '11', '00', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_H32_float2int
                        when ('0', '0', '11', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_32H_float2int
                        when ('0', '0', '11', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_32H_float2int
                        when ('0', '0', '11', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_32H_float2int
                        when ('0', '0', '11', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_32H_float2int
                        when ('0', '0', '11', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_32H_float2int
                        when ('0', '0', '11', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_32H_float2int
                        when ('0', '0', '11', '11', '110') => __UNALLOCATED
                        when ('1', '0', 'x1', 'x1', '110') => __UNALLOCATED
                        when ('1', '0', 'x1', '01', '111') => __UNALLOCATED
                        when ('1', '0', '00', '0x', '11x') => __UNALLOCATED
                        when ('1', '0', '00', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_64S_float2int
                        when ('1', '0', '00', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_64S_float2int
                        when ('1', '0', '00', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_S64_float2int
                        when ('1', '0', '00', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_S64_float2int
                        when ('1', '0', '00', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_64S_float2int
                        when ('1', '0', '00', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_64S_float2int
                        when ('1', '0', '00', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_64S_float2int
                        when ('1', '0', '00', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_64S_float2int
                        when ('1', '0', '00', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_64S_float2int
                        when ('1', '0', '00', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_64S_float2int
                        when ('1', '0', '00', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_64S_float2int
                        when ('1', '0', '00', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_64S_float2int
                        when ('1', '0', '00', '11', '110') => __UNALLOCATED
                        when ('1', '0', '01', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_64D_float2int
                        when ('1', '0', '01', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_64D_float2int
                        when ('1', '0', '01', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_D64_float2int
                        when ('1', '0', '01', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_D64_float2int
                        when ('1', '0', '01', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_64D_float2int
                        when ('1', '0', '01', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_64D_float2int
                        when ('1', '0', '01', '00', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_64D_float2int
                        when ('1', '0', '01', '00', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_D64_float2int
                        when ('1', '0', '01', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_64D_float2int
                        when ('1', '0', '01', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_64D_float2int
                        when ('1', '0', '01', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_64D_float2int
                        when ('1', '0', '01', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_64D_float2int
                        when ('1', '0', '01', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_64D_float2int
                        when ('1', '0', '01', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_64D_float2int
                        when ('1', '0', '10', '01', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_64VX_float2int
                        when ('1', '0', '10', '01', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_V64I_float2int
                        when ('1', '0', '11', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_64H_float2int
                        when ('1', '0', '11', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_64H_float2int
                        when ('1', '0', '11', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_H64_float2int
                        when ('1', '0', '11', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_H64_float2int
                        when ('1', '0', '11', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_64H_float2int
                        when ('1', '0', '11', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_64H_float2int
                        when ('1', '0', '11', '00', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_64H_float2int
                        when ('1', '0', '11', '00', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_H64_float2int
                        when ('1', '0', '11', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_64H_float2int
                        when ('1', '0', '11', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_64H_float2int
                        when ('1', '0', '11', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_64H_float2int
                        when ('1', '0', '11', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_64H_float2int
                        when ('1', '0', '11', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_64H_float2int
                        when ('1', '0', '11', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_64H_float2int
                when ('x0x1', _, '0x', 'x1xx', 'xxxx10000', _) => // floatdp1
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field opcode 15 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype, opcode) of
                        when ('0', '0', _, '1xxxxx') => __UNALLOCATED
                        when ('0', '0', 'x1', '001101') => __UNALLOCATED
                        when ('0', '0', '0x', '0101xx') => __UNALLOCATED
                        when ('0', '0', '0x', '011xxx') => __UNALLOCATED
                        when ('0', '0', '00', '000000') => __encoding A64_simd_dp_floatdp1_FMOV_H_floatdp1 // FMOV_S_floatdp1
                        when ('0', '0', '00', '000001') => __encoding A64_simd_dp_floatdp1_FABS_H_floatdp1 // FABS_S_floatdp1
                        when ('0', '0', '00', '000010') => __encoding A64_simd_dp_floatdp1_FNEG_H_floatdp1 // FNEG_S_floatdp1
                        when ('0', '0', '00', '000011') => __encoding A64_simd_dp_floatdp1_FSQRT_H_floatdp1 // FSQRT_S_floatdp1
                        when ('0', '0', '00', '0001x0') => __UNALLOCATED
                        when ('0', '0', '00', '000101') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_DS_floatdp1
                        when ('0', '0', '00', '000111') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_HS_floatdp1
                        when ('0', '0', '00', '001000') => __encoding A64_simd_dp_floatdp1_FRINTN_H_floatdp1 // FRINTN_S_floatdp1
                        when ('0', '0', '00', '001001') => __encoding A64_simd_dp_floatdp1_FRINTP_H_floatdp1 // FRINTP_S_floatdp1
                        when ('0', '0', '00', '001010') => __encoding A64_simd_dp_floatdp1_FRINTM_H_floatdp1 // FRINTM_S_floatdp1
                        when ('0', '0', '00', '001011') => __encoding A64_simd_dp_floatdp1_FRINTZ_H_floatdp1 // FRINTZ_S_floatdp1
                        when ('0', '0', '00', '001100') => __encoding A64_simd_dp_floatdp1_FRINTA_H_floatdp1 // FRINTA_S_floatdp1
                        when ('0', '0', '00', '001101') => __UNALLOCATED
                        when ('0', '0', '00', '001110') => __encoding A64_simd_dp_floatdp1_FRINTX_H_floatdp1 // FRINTX_S_floatdp1
                        when ('0', '0', '00', '001111') => __encoding A64_simd_dp_floatdp1_FRINTI_H_floatdp1 // FRINTI_S_floatdp1
                        when ('0', '0', '00', '010000') => __encoding A64_simd_dp_floatdp1_FRINT32Z_S_floatdp1 // FRINT32Z_S_floatdp1
                        when ('0', '0', '00', '010001') => __encoding A64_simd_dp_floatdp1_FRINT32X_S_floatdp1 // FRINT32X_S_floatdp1
                        when ('0', '0', '00', '010010') => __encoding A64_simd_dp_floatdp1_FRINT64Z_S_floatdp1 // FRINT64Z_S_floatdp1
                        when ('0', '0', '00', '010011') => __encoding A64_simd_dp_floatdp1_FRINT64X_S_floatdp1 // FRINT64X_S_floatdp1
                        when ('0', '0', '01', '000000') => __encoding A64_simd_dp_floatdp1_FMOV_H_floatdp1 // FMOV_D_floatdp1
                        when ('0', '0', '01', '000001') => __encoding A64_simd_dp_floatdp1_FABS_H_floatdp1 // FABS_D_floatdp1
                        when ('0', '0', '01', '000010') => __encoding A64_simd_dp_floatdp1_FNEG_H_floatdp1 // FNEG_D_floatdp1
                        when ('0', '0', '01', '000011') => __encoding A64_simd_dp_floatdp1_FSQRT_H_floatdp1 // FSQRT_D_floatdp1
                        when ('0', '0', '01', '000100') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_SD_floatdp1
                        when ('0', '0', '01', '000101') => __UNALLOCATED
                        when ('0', '0', '01', '000110') => __encoding A64_simd_dp_floatdp1_BFCVT_BS_floatdp1 // BFCVT_BS_floatdp1
                        when ('0', '0', '01', '000111') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_HD_floatdp1
                        when ('0', '0', '01', '001000') => __encoding A64_simd_dp_floatdp1_FRINTN_H_floatdp1 // FRINTN_D_floatdp1
                        when ('0', '0', '01', '001001') => __encoding A64_simd_dp_floatdp1_FRINTP_H_floatdp1 // FRINTP_D_floatdp1
                        when ('0', '0', '01', '001010') => __encoding A64_simd_dp_floatdp1_FRINTM_H_floatdp1 // FRINTM_D_floatdp1
                        when ('0', '0', '01', '001011') => __encoding A64_simd_dp_floatdp1_FRINTZ_H_floatdp1 // FRINTZ_D_floatdp1
                        when ('0', '0', '01', '001100') => __encoding A64_simd_dp_floatdp1_FRINTA_H_floatdp1 // FRINTA_D_floatdp1
                        when ('0', '0', '01', '001110') => __encoding A64_simd_dp_floatdp1_FRINTX_H_floatdp1 // FRINTX_D_floatdp1
                        when ('0', '0', '01', '001111') => __encoding A64_simd_dp_floatdp1_FRINTI_H_floatdp1 // FRINTI_D_floatdp1
                        when ('0', '0', '01', '010000') => __encoding A64_simd_dp_floatdp1_FRINT32Z_S_floatdp1 // FRINT32Z_D_floatdp1
                        when ('0', '0', '01', '010001') => __encoding A64_simd_dp_floatdp1_FRINT32X_S_floatdp1 // FRINT32X_D_floatdp1
                        when ('0', '0', '01', '010010') => __encoding A64_simd_dp_floatdp1_FRINT64Z_S_floatdp1 // FRINT64Z_D_floatdp1
                        when ('0', '0', '01', '010011') => __encoding A64_simd_dp_floatdp1_FRINT64X_S_floatdp1 // FRINT64X_D_floatdp1
                        when ('0', '0', '10', '0xxxxx') => __UNALLOCATED
                        when ('0', '0', '11', '000000') => __encoding A64_simd_dp_floatdp1_FMOV_H_floatdp1 // FMOV_H_floatdp1
                        when ('0', '0', '11', '000001') => __encoding A64_simd_dp_floatdp1_FABS_H_floatdp1 // FABS_H_floatdp1
                        when ('0', '0', '11', '000010') => __encoding A64_simd_dp_floatdp1_FNEG_H_floatdp1 // FNEG_H_floatdp1
                        when ('0', '0', '11', '000011') => __encoding A64_simd_dp_floatdp1_FSQRT_H_floatdp1 // FSQRT_H_floatdp1
                        when ('0', '0', '11', '000100') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_SH_floatdp1
                        when ('0', '0', '11', '000101') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_DH_floatdp1
                        when ('0', '0', '11', '00011x') => __UNALLOCATED
                        when ('0', '0', '11', '001000') => __encoding A64_simd_dp_floatdp1_FRINTN_H_floatdp1 // FRINTN_H_floatdp1
                        when ('0', '0', '11', '001001') => __encoding A64_simd_dp_floatdp1_FRINTP_H_floatdp1 // FRINTP_H_floatdp1
                        when ('0', '0', '11', '001010') => __encoding A64_simd_dp_floatdp1_FRINTM_H_floatdp1 // FRINTM_H_floatdp1
                        when ('0', '0', '11', '001011') => __encoding A64_simd_dp_floatdp1_FRINTZ_H_floatdp1 // FRINTZ_H_floatdp1
                        when ('0', '0', '11', '001100') => __encoding A64_simd_dp_floatdp1_FRINTA_H_floatdp1 // FRINTA_H_floatdp1
                        when ('0', '0', '11', '001110') => __encoding A64_simd_dp_floatdp1_FRINTX_H_floatdp1 // FRINTX_H_floatdp1
                        when ('0', '0', '11', '001111') => __encoding A64_simd_dp_floatdp1_FRINTI_H_floatdp1 // FRINTI_H_floatdp1
                        when ('0', '0', '11', '01xxxx') => __UNALLOCATED
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxx1000', _) => // floatcmp
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field Rm 16 +: 5
                    __field op 14 +: 2
                    __field Rn 5 +: 5
                    __field opcode2 0 +: 5
                    case (M, S, ftype, op, opcode2) of
                        when ('0', '0', _, '00', 'xx001') => __UNALLOCATED
                        when ('0', '0', _, '00', 'xx01x') => __UNALLOCATED
                        when ('0', '0', _, '00', 'xx1xx') => __UNALLOCATED
                        when ('0', '0', _, '01', _) => __UNALLOCATED
                        when ('0', '0', _, '1x', _) => __UNALLOCATED
                        when ('0', '0', '00', '00', '00000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_S_floatcmp
                        when ('0', '0', '00', '00', '01000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_SZ_floatcmp
                        when ('0', '0', '00', '00', '10000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_S_floatcmp
                        when ('0', '0', '00', '00', '11000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_SZ_floatcmp
                        when ('0', '0', '01', '00', '00000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_D_floatcmp
                        when ('0', '0', '01', '00', '01000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_DZ_floatcmp
                        when ('0', '0', '01', '00', '10000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_D_floatcmp
                        when ('0', '0', '01', '00', '11000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_DZ_floatcmp
                        when ('0', '0', '10', '00', 'xx000') => __UNALLOCATED
                        when ('0', '0', '11', '00', '00000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_H_floatcmp
                        when ('0', '0', '11', '00', '01000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_HZ_floatcmp
                        when ('0', '0', '11', '00', '10000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_H_floatcmp
                        when ('0', '0', '11', '00', '11000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_HZ_floatcmp
                        when ('0', '1', _, _, _) => __UNALLOCATED
                        when ('1', _, _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxx100', _) => // floatimm
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field imm8 13 +: 8
                    __field imm5 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype, imm5) of
                        when ('0', '0', _, '00001') => __UNALLOCATED
                        when ('0', '0', _, '0001x') => __UNALLOCATED
                        when ('0', '0', _, '001xx') => __UNALLOCATED
                        when ('0', '0', _, '01xxx') => __UNALLOCATED
                        when ('0', '0', _, '1xxxx') => __UNALLOCATED
                        when ('0', '0', '00', '00000') => __encoding A64_simd_dp_floatimm_FMOV_H_floatimm // FMOV_S_floatimm
                        when ('0', '0', '01', '00000') => __encoding A64_simd_dp_floatimm_FMOV_H_floatimm // FMOV_D_floatimm
                        when ('0', '0', '10', '00000') => __UNALLOCATED
                        when ('0', '0', '11', '00000') => __encoding A64_simd_dp_floatimm_FMOV_H_floatimm // FMOV_H_floatimm
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx01', _) => // floatccmp
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field Rn 5 +: 5
                    __field op 4 +: 1
                    __field nzcv 0 +: 4
                    case (M, S, ftype, op) of
                        when ('0', '0', '00', '0') => __encoding A64_simd_dp_floatccmp_FCCMP_H_floatccmp // FCCMP_S_floatccmp
                        when ('0', '0', '00', '1') => __encoding A64_simd_dp_floatccmp_FCCMPE_H_floatccmp // FCCMPE_S_floatccmp
                        when ('0', '0', '01', '0') => __encoding A64_simd_dp_floatccmp_FCCMP_H_floatccmp // FCCMP_D_floatccmp
                        when ('0', '0', '01', '1') => __encoding A64_simd_dp_floatccmp_FCCMPE_H_floatccmp // FCCMPE_D_floatccmp
                        when ('0', '0', '10', _) => __UNALLOCATED
                        when ('0', '0', '11', '0') => __encoding A64_simd_dp_floatccmp_FCCMP_H_floatccmp // FCCMP_H_floatccmp
                        when ('0', '0', '11', '1') => __encoding A64_simd_dp_floatccmp_FCCMPE_H_floatccmp // FCCMPE_H_floatccmp
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx10', _) => // floatdp2
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype, opcode) of
                        when ('0', '0', 'x1', '1001') => __UNALLOCATED
                        when ('0', '0', 'x1', '101x') => __UNALLOCATED
                        when ('0', '0', 'x1', '11xx') => __UNALLOCATED
                        when ('0', '0', '00', '0000') => __encoding A64_simd_dp_floatdp2_FMUL_H_floatdp2 // FMUL_S_floatdp2
                        when ('0', '0', '00', '0001') => __encoding A64_simd_dp_floatdp2_FDIV_H_floatdp2 // FDIV_S_floatdp2
                        when ('0', '0', '00', '0010') => __encoding A64_simd_dp_floatdp2_FADD_H_floatdp2 // FADD_S_floatdp2
                        when ('0', '0', '00', '0011') => __encoding A64_simd_dp_floatdp2_FSUB_H_floatdp2 // FSUB_S_floatdp2
                        when ('0', '0', '00', '0100') => __encoding A64_simd_dp_floatdp2_FMAX_H_floatdp2 // FMAX_S_floatdp2
                        when ('0', '0', '00', '0101') => __encoding A64_simd_dp_floatdp2_FMIN_H_floatdp2 // FMIN_S_floatdp2
                        when ('0', '0', '00', '0110') => __encoding A64_simd_dp_floatdp2_FMAXNM_H_floatdp2 // FMAXNM_S_floatdp2
                        when ('0', '0', '00', '0111') => __encoding A64_simd_dp_floatdp2_FMINNM_H_floatdp2 // FMINNM_S_floatdp2
                        when ('0', '0', '00', '1000') => __encoding A64_simd_dp_floatdp2_FNMUL_H_floatdp2 // FNMUL_S_floatdp2
                        when ('0', '0', '00', '1001') => __UNALLOCATED
                        when ('0', '0', '00', '101x') => __UNALLOCATED
                        when ('0', '0', '00', '11xx') => __UNALLOCATED
                        when ('0', '0', '01', '0000') => __encoding A64_simd_dp_floatdp2_FMUL_H_floatdp2 // FMUL_D_floatdp2
                        when ('0', '0', '01', '0001') => __encoding A64_simd_dp_floatdp2_FDIV_H_floatdp2 // FDIV_D_floatdp2
                        when ('0', '0', '01', '0010') => __encoding A64_simd_dp_floatdp2_FADD_H_floatdp2 // FADD_D_floatdp2
                        when ('0', '0', '01', '0011') => __encoding A64_simd_dp_floatdp2_FSUB_H_floatdp2 // FSUB_D_floatdp2
                        when ('0', '0', '01', '0100') => __encoding A64_simd_dp_floatdp2_FMAX_H_floatdp2 // FMAX_D_floatdp2
                        when ('0', '0', '01', '0101') => __encoding A64_simd_dp_floatdp2_FMIN_H_floatdp2 // FMIN_D_floatdp2
                        when ('0', '0', '01', '0110') => __encoding A64_simd_dp_floatdp2_FMAXNM_H_floatdp2 // FMAXNM_D_floatdp2
                        when ('0', '0', '01', '0111') => __encoding A64_simd_dp_floatdp2_FMINNM_H_floatdp2 // FMINNM_D_floatdp2
                        when ('0', '0', '01', '1000') => __encoding A64_simd_dp_floatdp2_FNMUL_H_floatdp2 // FNMUL_D_floatdp2
                        when ('0', '0', '10', _) => __UNALLOCATED
                        when ('0', '0', '11', '0000') => __encoding A64_simd_dp_floatdp2_FMUL_H_floatdp2 // FMUL_H_floatdp2
                        when ('0', '0', '11', '0001') => __encoding A64_simd_dp_floatdp2_FDIV_H_floatdp2 // FDIV_H_floatdp2
                        when ('0', '0', '11', '0010') => __encoding A64_simd_dp_floatdp2_FADD_H_floatdp2 // FADD_H_floatdp2
                        when ('0', '0', '11', '0011') => __encoding A64_simd_dp_floatdp2_FSUB_H_floatdp2 // FSUB_H_floatdp2
                        when ('0', '0', '11', '0100') => __encoding A64_simd_dp_floatdp2_FMAX_H_floatdp2 // FMAX_H_floatdp2
                        when ('0', '0', '11', '0101') => __encoding A64_simd_dp_floatdp2_FMIN_H_floatdp2 // FMIN_H_floatdp2
                        when ('0', '0', '11', '0110') => __encoding A64_simd_dp_floatdp2_FMAXNM_H_floatdp2 // FMAXNM_H_floatdp2
                        when ('0', '0', '11', '0111') => __encoding A64_simd_dp_floatdp2_FMINNM_H_floatdp2 // FMINNM_H_floatdp2
                        when ('0', '0', '11', '1000') => __encoding A64_simd_dp_floatdp2_FNMUL_H_floatdp2 // FNMUL_H_floatdp2
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx11', _) => // floatsel
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype) of
                        when ('0', '0', '00') => __encoding A64_simd_dp_floatsel_FCSEL_H_floatsel // FCSEL_S_floatsel
                        when ('0', '0', '01') => __encoding A64_simd_dp_floatsel_FCSEL_H_floatsel // FCSEL_D_floatsel
                        when ('0', '0', '10') => __UNALLOCATED
                        when ('0', '0', '11') => __encoding A64_simd_dp_floatsel_FCSEL_H_floatsel // FCSEL_H_floatsel
                        when ('0', '1', _) => __UNALLOCATED
                        when ('1', _, _) => __UNALLOCATED
                when ('x0x1', _, '1x', _, _, _) => // floatdp3
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field o1 21 +: 1
                    __field Rm 16 +: 5
                    __field o0 15 +: 1
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype, o1, o0) of
                        when ('0', '0', '00', '0', '0') => __encoding A64_simd_dp_floatdp3_FMADD_H_floatdp3 // FMADD_S_floatdp3
                        when ('0', '0', '00', '0', '1') => __encoding A64_simd_dp_floatdp3_FMSUB_H_floatdp3 // FMSUB_S_floatdp3
                        when ('0', '0', '00', '1', '0') => __encoding A64_simd_dp_floatdp3_FNMADD_H_floatdp3 // FNMADD_S_floatdp3
                        when ('0', '0', '00', '1', '1') => __encoding A64_simd_dp_floatdp3_FNMSUB_H_floatdp3 // FNMSUB_S_floatdp3
                        when ('0', '0', '01', '0', '0') => __encoding A64_simd_dp_floatdp3_FMADD_H_floatdp3 // FMADD_D_floatdp3
                        when ('0', '0', '01', '0', '1') => __encoding A64_simd_dp_floatdp3_FMSUB_H_floatdp3 // FMSUB_D_floatdp3
                        when ('0', '0', '01', '1', '0') => __encoding A64_simd_dp_floatdp3_FNMADD_H_floatdp3 // FNMADD_D_floatdp3
                        when ('0', '0', '01', '1', '1') => __encoding A64_simd_dp_floatdp3_FNMSUB_H_floatdp3 // FNMSUB_D_floatdp3
                        when ('0', '0', '10', _, _) => __UNALLOCATED
                        when ('0', '0', '11', '0', '0') => __encoding A64_simd_dp_floatdp3_FMADD_H_floatdp3 // FMADD_H_floatdp3
                        when ('0', '0', '11', '0', '1') => __encoding A64_simd_dp_floatdp3_FMSUB_H_floatdp3 // FMSUB_H_floatdp3
                        when ('0', '0', '11', '1', '0') => __encoding A64_simd_dp_floatdp3_FNMADD_H_floatdp3 // FNMADD_H_floatdp3
                        when ('0', '0', '11', '1', '1') => __encoding A64_simd_dp_floatdp3_FNMSUB_H_floatdp3 // FNMSUB_H_floatdp3
                        when ('0', '1', _, _, _) => __UNALLOCATED
                        when ('1', _, _, _, _) => __UNALLOCATED
        when (_, _, 'x1x0', _) =>
            // ldst
            case (28 +: 4, 27 +: 1, 26 +: 1, 25 +: 1, 10 +: 15, 0 +: 10) of
                when ('0x00', _, '0', _, '00x1xxxxxxxxxxx', _) => // comswappr
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0, Rt2) of
                        when (_, _, _, '0xxxx') => __UNALLOCATED
                        when (_, _, _, '10xxx') => __UNALLOCATED
                        when (_, _, _, '110xx') => __UNALLOCATED
                        when (_, _, _, '1110x') => __UNALLOCATED
                        when (_, _, _, '11110') => __UNALLOCATED
                        when ('0', '0', '0', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASP_CP32_comswappr
                        when ('0', '0', '1', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPL_CP32_comswappr
                        when ('0', '1', '0', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPA_CP32_comswappr
                        when ('0', '1', '1', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPAL_CP32_comswappr
                        when ('1', '0', '0', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASP_CP64_comswappr
                        when ('1', '0', '1', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPL_CP64_comswappr
                        when ('1', '1', '0', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPA_CP64_comswappr
                        when ('1', '1', '1', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPAL_CP64_comswappr
                when ('0x00', _, '1', _, '00x000000xxxxxx', _) => // asisdlse
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field opcode 12 +: 4
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, opcode) of
                        when (_, 'x0x1') => __UNALLOCATED
                        when (_, '0101') => __UNALLOCATED
                        when (_, '11xx') => __UNALLOCATED
                        when ('0', '0000') => __encoding A64_ldst_asisdlse_ST4_asisdlse_R4 // ST4_asisdlse_R4
                        when ('0', '0010') => __encoding A64_ldst_asisdlse_ST1_asisdlse_R1_1v // ST1_asisdlse_R4_4v
                        when ('0', '0100') => __encoding A64_ldst_asisdlse_ST3_asisdlse_R3 // ST3_asisdlse_R3
                        when ('0', '0110') => __encoding A64_ldst_asisdlse_ST1_asisdlse_R1_1v // ST1_asisdlse_R3_3v
                        when ('0', '0111') => __encoding A64_ldst_asisdlse_ST1_asisdlse_R1_1v // ST1_asisdlse_R1_1v
                        when ('0', '1000') => __encoding A64_ldst_asisdlse_ST2_asisdlse_R2 // ST2_asisdlse_R2
                        when ('0', '1010') => __encoding A64_ldst_asisdlse_ST1_asisdlse_R1_1v // ST1_asisdlse_R2_2v
                        when ('1', '0000') => __encoding A64_ldst_asisdlse_LD4_asisdlse_R4 // LD4_asisdlse_R4
                        when ('1', '0010') => __encoding A64_ldst_asisdlse_LD1_asisdlse_R1_1v // LD1_asisdlse_R4_4v
                        when ('1', '0100') => __encoding A64_ldst_asisdlse_LD3_asisdlse_R3 // LD3_asisdlse_R3
                        when ('1', '0110') => __encoding A64_ldst_asisdlse_LD1_asisdlse_R1_1v // LD1_asisdlse_R3_3v
                        when ('1', '0111') => __encoding A64_ldst_asisdlse_LD1_asisdlse_R1_1v // LD1_asisdlse_R1_1v
                        when ('1', '1000') => __encoding A64_ldst_asisdlse_LD2_asisdlse_R2 // LD2_asisdlse_R2
                        when ('1', '1010') => __encoding A64_ldst_asisdlse_LD1_asisdlse_R1_1v // LD1_asisdlse_R2_2v
                when ('0x00', _, '1', _, '00x000001xxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '01x0xxxxxxxxxxx', _) => // asisdlsep
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, Rm, opcode) of
                        when (_, _, 'x0x1') => __UNALLOCATED
                        when (_, _, '0101') => __UNALLOCATED
                        when (_, _, '11xx') => __UNALLOCATED
                        when ('0', !'11111', '0000') => __encoding A64_ldst_asisdlsep_ST4_asisdlsep_I4_i // ST4_asisdlsep_R4_r
                        when ('0', !'11111', '0010') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_R4_r4
                        when ('0', !'11111', '0100') => __encoding A64_ldst_asisdlsep_ST3_asisdlsep_I3_i // ST3_asisdlsep_R3_r
                        when ('0', !'11111', '0110') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_R3_r3
                        when ('0', !'11111', '0111') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_R1_r1
                        when ('0', !'11111', '1000') => __encoding A64_ldst_asisdlsep_ST2_asisdlsep_I2_i // ST2_asisdlsep_R2_r
                        when ('0', !'11111', '1010') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_R2_r2
                        when ('0', '11111', '0000') => __encoding A64_ldst_asisdlsep_ST4_asisdlsep_I4_i // ST4_asisdlsep_I4_i
                        when ('0', '11111', '0010') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_I4_i4
                        when ('0', '11111', '0100') => __encoding A64_ldst_asisdlsep_ST3_asisdlsep_I3_i // ST3_asisdlsep_I3_i
                        when ('0', '11111', '0110') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_I3_i3
                        when ('0', '11111', '0111') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_I1_i1
                        when ('0', '11111', '1000') => __encoding A64_ldst_asisdlsep_ST2_asisdlsep_I2_i // ST2_asisdlsep_I2_i
                        when ('0', '11111', '1010') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_I2_i2
                        when ('1', !'11111', '0000') => __encoding A64_ldst_asisdlsep_LD4_asisdlsep_I4_i // LD4_asisdlsep_R4_r
                        when ('1', !'11111', '0010') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_R4_r4
                        when ('1', !'11111', '0100') => __encoding A64_ldst_asisdlsep_LD3_asisdlsep_I3_i // LD3_asisdlsep_R3_r
                        when ('1', !'11111', '0110') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_R3_r3
                        when ('1', !'11111', '0111') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_R1_r1
                        when ('1', !'11111', '1000') => __encoding A64_ldst_asisdlsep_LD2_asisdlsep_I2_i // LD2_asisdlsep_R2_r
                        when ('1', !'11111', '1010') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_R2_r2
                        when ('1', '11111', '0000') => __encoding A64_ldst_asisdlsep_LD4_asisdlsep_I4_i // LD4_asisdlsep_I4_i
                        when ('1', '11111', '0010') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_I4_i4
                        when ('1', '11111', '0100') => __encoding A64_ldst_asisdlsep_LD3_asisdlsep_I3_i // LD3_asisdlsep_I3_i
                        when ('1', '11111', '0110') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_I3_i3
                        when ('1', '11111', '0111') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_I1_i1
                        when ('1', '11111', '1000') => __encoding A64_ldst_asisdlsep_LD2_asisdlsep_I2_i // LD2_asisdlsep_I2_i
                        when ('1', '11111', '1010') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_I2_i2
                when ('0x00', _, '1', _, '0xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10x10001xxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10x1001xxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10x101xxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10x11xxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10xx0000xxxxxxx', _) => // asisdlso
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field R 21 +: 1
                    __field o2 16 +: 1
                    __field opcode 13 +: 3
                    __field S 12 +: 1
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, R, o2, opcode, S, size) of
                        when (_, _, '0', '01x', _, 'x1') => __UNALLOCATED
                        when (_, _, '0', '10x', _, '1x') => __UNALLOCATED
                        when (_, _, '0', '10x', '1', '01') => __UNALLOCATED
                        when (_, '0', '1', '0xx', _, _) => __UNALLOCATED
                        when (_, '0', '1', '100', _, 'x0') => __UNALLOCATED
                        when (_, '0', '1', '100', _, '11') => __UNALLOCATED
                        when (_, '0', '1', '100', '1', '01') => __UNALLOCATED
                        when (_, '0', '1', '101', _, _) => __UNALLOCATED
                        when (_, '0', '1', '11x', _, _) => __UNALLOCATED
                        when (_, '1', '1', _, _, _) => __UNALLOCATED
                        when ('0', _, '0', '11x', _, _) => __UNALLOCATED
                        when ('0', '0', '0', '000', _, _) => __encoding A64_ldst_asisdlso_ST1_asisdlso_B1_1b // ST1_asisdlso_B1_1b
                        when ('0', '0', '0', '001', _, _) => __encoding A64_ldst_asisdlso_ST3_asisdlso_B3_3b // ST3_asisdlso_B3_3b
                        when ('0', '0', '0', '010', _, 'x0') => __encoding A64_ldst_asisdlso_ST1_asisdlso_B1_1b // ST1_asisdlso_H1_1h
                        when ('0', '0', '0', '011', _, 'x0') => __encoding A64_ldst_asisdlso_ST3_asisdlso_B3_3b // ST3_asisdlso_H3_3h
                        when ('0', '0', '0', '100', _, '00') => __encoding A64_ldst_asisdlso_ST1_asisdlso_B1_1b // ST1_asisdlso_S1_1s
                        when ('0', '0', '0', '100', '0', '01') => __encoding A64_ldst_asisdlso_ST1_asisdlso_B1_1b // ST1_asisdlso_D1_1d
                        when ('0', '0', '0', '101', _, '00') => __encoding A64_ldst_asisdlso_ST3_asisdlso_B3_3b // ST3_asisdlso_S3_3s
                        when ('0', '0', '0', '101', '0', '01') => __encoding A64_ldst_asisdlso_ST3_asisdlso_B3_3b // ST3_asisdlso_D3_3d
                        when ('0', '0', '1', '100', '0', '01') => __encoding A64_ldst_asisdlso_STL1_asisdlso_D1 // STL1_asisdlso_D1
                        when ('0', '1', '0', '000', _, _) => __encoding A64_ldst_asisdlso_ST2_asisdlso_B2_2b // ST2_asisdlso_B2_2b
                        when ('0', '1', '0', '001', _, _) => __encoding A64_ldst_asisdlso_ST4_asisdlso_B4_4b // ST4_asisdlso_B4_4b
                        when ('0', '1', '0', '010', _, 'x0') => __encoding A64_ldst_asisdlso_ST2_asisdlso_B2_2b // ST2_asisdlso_H2_2h
                        when ('0', '1', '0', '011', _, 'x0') => __encoding A64_ldst_asisdlso_ST4_asisdlso_B4_4b // ST4_asisdlso_H4_4h
                        when ('0', '1', '0', '100', _, '00') => __encoding A64_ldst_asisdlso_ST2_asisdlso_B2_2b // ST2_asisdlso_S2_2s
                        when ('0', '1', '0', '100', '0', '01') => __encoding A64_ldst_asisdlso_ST2_asisdlso_B2_2b // ST2_asisdlso_D2_2d
                        when ('0', '1', '0', '101', _, '00') => __encoding A64_ldst_asisdlso_ST4_asisdlso_B4_4b // ST4_asisdlso_S4_4s
                        when ('0', '1', '0', '101', '0', '01') => __encoding A64_ldst_asisdlso_ST4_asisdlso_B4_4b // ST4_asisdlso_D4_4d
                        when ('1', _, '0', '11x', '1', _) => __UNALLOCATED
                        when ('1', '0', '0', '000', _, _) => __encoding A64_ldst_asisdlso_LD1_asisdlso_B1_1b // LD1_asisdlso_B1_1b
                        when ('1', '0', '0', '001', _, _) => __encoding A64_ldst_asisdlso_LD3_asisdlso_B3_3b // LD3_asisdlso_B3_3b
                        when ('1', '0', '0', '010', _, 'x0') => __encoding A64_ldst_asisdlso_LD1_asisdlso_B1_1b // LD1_asisdlso_H1_1h
                        when ('1', '0', '0', '011', _, 'x0') => __encoding A64_ldst_asisdlso_LD3_asisdlso_B3_3b // LD3_asisdlso_H3_3h
                        when ('1', '0', '0', '100', _, '00') => __encoding A64_ldst_asisdlso_LD1_asisdlso_B1_1b // LD1_asisdlso_S1_1s
                        when ('1', '0', '0', '100', '0', '01') => __encoding A64_ldst_asisdlso_LD1_asisdlso_B1_1b // LD1_asisdlso_D1_1d
                        when ('1', '0', '0', '101', _, '00') => __encoding A64_ldst_asisdlso_LD3_asisdlso_B3_3b // LD3_asisdlso_S3_3s
                        when ('1', '0', '0', '101', '0', '01') => __encoding A64_ldst_asisdlso_LD3_asisdlso_B3_3b // LD3_asisdlso_D3_3d
                        when ('1', '0', '0', '110', '0', _) => __encoding A64_ldst_asisdlso_LD1R_asisdlso_R1 // LD1R_asisdlso_R1
                        when ('1', '0', '0', '111', '0', _) => __encoding A64_ldst_asisdlso_LD3R_asisdlso_R3 // LD3R_asisdlso_R3
                        when ('1', '0', '1', '100', '0', '01') => __encoding A64_ldst_asisdlso_LDAP1_asisdlso_D1 // LDAP1_asisdlso_D1
                        when ('1', '1', '0', '000', _, _) => __encoding A64_ldst_asisdlso_LD2_asisdlso_B2_2b // LD2_asisdlso_B2_2b
                        when ('1', '1', '0', '001', _, _) => __encoding A64_ldst_asisdlso_LD4_asisdlso_B4_4b // LD4_asisdlso_B4_4b
                        when ('1', '1', '0', '010', _, 'x0') => __encoding A64_ldst_asisdlso_LD2_asisdlso_B2_2b // LD2_asisdlso_H2_2h
                        when ('1', '1', '0', '011', _, 'x0') => __encoding A64_ldst_asisdlso_LD4_asisdlso_B4_4b // LD4_asisdlso_H4_4h
                        when ('1', '1', '0', '100', _, '00') => __encoding A64_ldst_asisdlso_LD2_asisdlso_B2_2b // LD2_asisdlso_S2_2s
                        when ('1', '1', '0', '100', '0', '01') => __encoding A64_ldst_asisdlso_LD2_asisdlso_B2_2b // LD2_asisdlso_D2_2d
                        when ('1', '1', '0', '101', _, '00') => __encoding A64_ldst_asisdlso_LD4_asisdlso_B4_4b // LD4_asisdlso_S4_4s
                        when ('1', '1', '0', '101', '0', '01') => __encoding A64_ldst_asisdlso_LD4_asisdlso_B4_4b // LD4_asisdlso_D4_4d
                        when ('1', '1', '0', '110', '0', _) => __encoding A64_ldst_asisdlso_LD2R_asisdlso_R2 // LD2R_asisdlso_R2
                        when ('1', '1', '0', '111', '0', _) => __encoding A64_ldst_asisdlso_LD4R_asisdlso_R4 // LD4R_asisdlso_R4
                when ('0x00', _, '1', _, '11xxxxxxxxxxxxx', _) => // asisdlsop
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field R 21 +: 1
                    __field Rm 16 +: 5
                    __field opcode 13 +: 3
                    __field S 12 +: 1
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, R, Rm, opcode, S, size) of
                        when (_, _, _, '01x', _, 'x1') => __UNALLOCATED
                        when (_, _, _, '10x', _, '1x') => __UNALLOCATED
                        when (_, _, _, '10x', '1', '01') => __UNALLOCATED
                        when ('0', _, _, '11x', _, _) => __UNALLOCATED
                        when ('0', '0', !'11111', '000', _, _) => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_BX1_r1b
                        when ('0', '0', !'11111', '001', _, _) => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_BX3_r3b
                        when ('0', '0', !'11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_HX1_r1h
                        when ('0', '0', !'11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_HX3_r3h
                        when ('0', '0', !'11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_SX1_r1s
                        when ('0', '0', !'11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_DX1_r1d
                        when ('0', '0', !'11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_SX3_r3s
                        when ('0', '0', !'11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_DX3_r3d
                        when ('0', '0', '11111', '000', _, _) => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_B1_i1b
                        when ('0', '0', '11111', '001', _, _) => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_B3_i3b
                        when ('0', '0', '11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_H1_i1h
                        when ('0', '0', '11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_H3_i3h
                        when ('0', '0', '11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_S1_i1s
                        when ('0', '0', '11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_D1_i1d
                        when ('0', '0', '11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_S3_i3s
                        when ('0', '0', '11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_D3_i3d
                        when ('0', '1', !'11111', '000', _, _) => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_BX2_r2b
                        when ('0', '1', !'11111', '001', _, _) => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_BX4_r4b
                        when ('0', '1', !'11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_HX2_r2h
                        when ('0', '1', !'11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_HX4_r4h
                        when ('0', '1', !'11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_SX2_r2s
                        when ('0', '1', !'11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_DX2_r2d
                        when ('0', '1', !'11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_SX4_r4s
                        when ('0', '1', !'11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_DX4_r4d
                        when ('0', '1', '11111', '000', _, _) => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_B2_i2b
                        when ('0', '1', '11111', '001', _, _) => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_B4_i4b
                        when ('0', '1', '11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_H2_i2h
                        when ('0', '1', '11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_H4_i4h
                        when ('0', '1', '11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_S2_i2s
                        when ('0', '1', '11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_D2_i2d
                        when ('0', '1', '11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_S4_i4s
                        when ('0', '1', '11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_D4_i4d
                        when ('1', _, _, '11x', '1', _) => __UNALLOCATED
                        when ('1', '0', !'11111', '000', _, _) => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_BX1_r1b
                        when ('1', '0', !'11111', '001', _, _) => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_BX3_r3b
                        when ('1', '0', !'11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_HX1_r1h
                        when ('1', '0', !'11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_HX3_r3h
                        when ('1', '0', !'11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_SX1_r1s
                        when ('1', '0', !'11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_DX1_r1d
                        when ('1', '0', !'11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_SX3_r3s
                        when ('1', '0', !'11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_DX3_r3d
                        when ('1', '0', !'11111', '110', '0', _) => __encoding A64_ldst_asisdlsop_LD1R_asisdlsop_R1_i // LD1R_asisdlsop_RX1_r
                        when ('1', '0', !'11111', '111', '0', _) => __encoding A64_ldst_asisdlsop_LD3R_asisdlsop_R3_i // LD3R_asisdlsop_RX3_r
                        when ('1', '0', '11111', '000', _, _) => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_B1_i1b
                        when ('1', '0', '11111', '001', _, _) => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_B3_i3b
                        when ('1', '0', '11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_H1_i1h
                        when ('1', '0', '11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_H3_i3h
                        when ('1', '0', '11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_S1_i1s
                        when ('1', '0', '11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_D1_i1d
                        when ('1', '0', '11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_S3_i3s
                        when ('1', '0', '11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_D3_i3d
                        when ('1', '0', '11111', '110', '0', _) => __encoding A64_ldst_asisdlsop_LD1R_asisdlsop_R1_i // LD1R_asisdlsop_R1_i
                        when ('1', '0', '11111', '111', '0', _) => __encoding A64_ldst_asisdlsop_LD3R_asisdlsop_R3_i // LD3R_asisdlsop_R3_i
                        when ('1', '1', !'11111', '000', _, _) => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_BX2_r2b
                        when ('1', '1', !'11111', '001', _, _) => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_BX4_r4b
                        when ('1', '1', !'11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_HX2_r2h
                        when ('1', '1', !'11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_HX4_r4h
                        when ('1', '1', !'11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_SX2_r2s
                        when ('1', '1', !'11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_DX2_r2d
                        when ('1', '1', !'11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_SX4_r4s
                        when ('1', '1', !'11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_DX4_r4d
                        when ('1', '1', !'11111', '110', '0', _) => __encoding A64_ldst_asisdlsop_LD2R_asisdlsop_R2_i // LD2R_asisdlsop_RX2_r
                        when ('1', '1', !'11111', '111', '0', _) => __encoding A64_ldst_asisdlsop_LD4R_asisdlsop_R4_i // LD4R_asisdlsop_RX4_r
                        when ('1', '1', '11111', '000', _, _) => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_B2_i2b
                        when ('1', '1', '11111', '001', _, _) => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_B4_i4b
                        when ('1', '1', '11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_H2_i2h
                        when ('1', '1', '11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_H4_i4h
                        when ('1', '1', '11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_S2_i2s
                        when ('1', '1', '11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_D2_i2d
                        when ('1', '1', '11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_S4_i4s
                        when ('1', '1', '11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_D4_i4d
                        when ('1', '1', '11111', '110', '0', _) => __encoding A64_ldst_asisdlsop_LD2R_asisdlsop_R2_i // LD2R_asisdlsop_R2_i
                        when ('1', '1', '11111', '111', '0', _) => __encoding A64_ldst_asisdlsop_LD4R_asisdlsop_R4_i // LD4R_asisdlsop_R4_i
                when ('0x00', _, '1', _, 'x0x00001xxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0x0001xxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0x001xxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0x01xxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x01', _, '0', _, '1xx1xxxxx000010', _) => // rcwcomswap
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R) of
                        when ('0', '0', '0') => __encoding A64_ldst_rcwcomswap_RCWCAS_C64_rcwcomswap // RCWCAS_C64_rcwcomswap
                        when ('0', '0', '1') => __encoding A64_ldst_rcwcomswap_RCWCAS_C64_rcwcomswap // RCWCASL_C64_rcwcomswap
                        when ('0', '1', '0') => __encoding A64_ldst_rcwcomswap_RCWCAS_C64_rcwcomswap // RCWCASA_C64_rcwcomswap
                        when ('0', '1', '1') => __encoding A64_ldst_rcwcomswap_RCWCAS_C64_rcwcomswap // RCWCASAL_C64_rcwcomswap
                        when ('1', '0', '0') => __encoding A64_ldst_rcwcomswap_RCWSCAS_C64_rcwcomswap // RCWSCAS_C64_rcwcomswap
                        when ('1', '0', '1') => __encoding A64_ldst_rcwcomswap_RCWSCAS_C64_rcwcomswap // RCWSCASL_C64_rcwcomswap
                        when ('1', '1', '0') => __encoding A64_ldst_rcwcomswap_RCWSCAS_C64_rcwcomswap // RCWSCASA_C64_rcwcomswap
                        when ('1', '1', '1') => __encoding A64_ldst_rcwcomswap_RCWSCAS_C64_rcwcomswap // RCWSCASAL_C64_rcwcomswap
                when ('0x01', _, '0', _, '1xx1xxxxx000011', _) => // rcwcomswappr
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R) of
                        when ('0', '0', '0') => __encoding A64_ldst_rcwcomswappr_RCWCASP_C64_rcwcomswappr // RCWCASP_C64_rcwcomswappr
                        when ('0', '0', '1') => __encoding A64_ldst_rcwcomswappr_RCWCASP_C64_rcwcomswappr // RCWCASPL_C64_rcwcomswappr
                        when ('0', '1', '0') => __encoding A64_ldst_rcwcomswappr_RCWCASP_C64_rcwcomswappr // RCWCASPA_C64_rcwcomswappr
                        when ('0', '1', '1') => __encoding A64_ldst_rcwcomswappr_RCWCASP_C64_rcwcomswappr // RCWCASPAL_C64_rcwcomswappr
                        when ('1', '0', '0') => __encoding A64_ldst_rcwcomswappr_RCWSCASP_C64_rcwcomswappr // RCWSCASP_C64_rcwcomswappr
                        when ('1', '0', '1') => __encoding A64_ldst_rcwcomswappr_RCWSCASP_C64_rcwcomswappr // RCWSCASPL_C64_rcwcomswappr
                        when ('1', '1', '0') => __encoding A64_ldst_rcwcomswappr_RCWSCASP_C64_rcwcomswappr // RCWSCASPA_C64_rcwcomswappr
                        when ('1', '1', '1') => __encoding A64_ldst_rcwcomswappr_RCWSCASP_C64_rcwcomswappr // RCWSCASPAL_C64_rcwcomswappr
                when ('0x01', _, '0', _, '1xx1xxxxxxxxx00', _) => // memop_128
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rt2 16 +: 5
                    __field o3 15 +: 1
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R, o3, opc) of
                        when (_, _, _, _, '1xx') => __UNALLOCATED
                        when ('0', _, _, '0', '0x0') => __UNALLOCATED
                        when ('0', '0', '0', '0', '001') => __encoding A64_ldst_memop_128_LDCLRP_128_memop_128 // LDCLRP_128_memop_128
                        when ('0', '0', '0', '0', '011') => __encoding A64_ldst_memop_128_LDSETP_128_memop_128 // LDSETP_128_memop_128
                        when ('0', '0', '0', '1', '000') => __encoding A64_ldst_memop_128_SWPP_128_memop_128 // SWPP_128_memop_128
                        when ('0', '0', '0', '1', '001') => __encoding A64_ldst_memop_128_RCWCLRP_128_memop_128 // RCWCLRP_128_memop_128
                        when ('0', '0', '0', '1', '010') => __encoding A64_ldst_memop_128_RCWSWPP_128_memop_128 // RCWSWPP_128_memop_128
                        when ('0', '0', '0', '1', '011') => __encoding A64_ldst_memop_128_RCWSETP_128_memop_128 // RCWSETP_128_memop_128
                        when ('0', '0', '1', '0', '001') => __encoding A64_ldst_memop_128_LDCLRP_128_memop_128 // LDCLRPL_128_memop_128
                        when ('0', '0', '1', '0', '011') => __encoding A64_ldst_memop_128_LDSETP_128_memop_128 // LDSETPL_128_memop_128
                        when ('0', '0', '1', '1', '000') => __encoding A64_ldst_memop_128_SWPP_128_memop_128 // SWPPL_128_memop_128
                        when ('0', '0', '1', '1', '001') => __encoding A64_ldst_memop_128_RCWCLRP_128_memop_128 // RCWCLRPL_128_memop_128
                        when ('0', '0', '1', '1', '010') => __encoding A64_ldst_memop_128_RCWSWPP_128_memop_128 // RCWSWPPL_128_memop_128
                        when ('0', '0', '1', '1', '011') => __encoding A64_ldst_memop_128_RCWSETP_128_memop_128 // RCWSETPL_128_memop_128
                        when ('0', '1', '0', '0', '001') => __encoding A64_ldst_memop_128_LDCLRP_128_memop_128 // LDCLRPA_128_memop_128
                        when ('0', '1', '0', '0', '011') => __encoding A64_ldst_memop_128_LDSETP_128_memop_128 // LDSETPA_128_memop_128
                        when ('0', '1', '0', '1', '000') => __encoding A64_ldst_memop_128_SWPP_128_memop_128 // SWPPA_128_memop_128
                        when ('0', '1', '0', '1', '001') => __encoding A64_ldst_memop_128_RCWCLRP_128_memop_128 // RCWCLRPA_128_memop_128
                        when ('0', '1', '0', '1', '010') => __encoding A64_ldst_memop_128_RCWSWPP_128_memop_128 // RCWSWPPA_128_memop_128
                        when ('0', '1', '0', '1', '011') => __encoding A64_ldst_memop_128_RCWSETP_128_memop_128 // RCWSETPA_128_memop_128
                        when ('0', '1', '1', '0', '001') => __encoding A64_ldst_memop_128_LDCLRP_128_memop_128 // LDCLRPAL_128_memop_128
                        when ('0', '1', '1', '0', '011') => __encoding A64_ldst_memop_128_LDSETP_128_memop_128 // LDSETPAL_128_memop_128
                        when ('0', '1', '1', '1', '000') => __encoding A64_ldst_memop_128_SWPP_128_memop_128 // SWPPAL_128_memop_128
                        when ('0', '1', '1', '1', '001') => __encoding A64_ldst_memop_128_RCWCLRP_128_memop_128 // RCWCLRPAL_128_memop_128
                        when ('0', '1', '1', '1', '010') => __encoding A64_ldst_memop_128_RCWSWPP_128_memop_128 // RCWSWPPAL_128_memop_128
                        when ('0', '1', '1', '1', '011') => __encoding A64_ldst_memop_128_RCWSETP_128_memop_128 // RCWSETPAL_128_memop_128
                        when ('1', _, _, '0', '0xx') => __UNALLOCATED
                        when ('1', _, _, '1', '000') => __UNALLOCATED
                        when ('1', '0', '0', '1', '001') => __encoding A64_ldst_memop_128_RCWSCLRP_128_memop_128 // RCWSCLRP_128_memop_128
                        when ('1', '0', '0', '1', '010') => __encoding A64_ldst_memop_128_RCWSSWPP_128_memop_128 // RCWSSWPP_128_memop_128
                        when ('1', '0', '0', '1', '011') => __encoding A64_ldst_memop_128_RCWSSETP_128_memop_128 // RCWSSETP_128_memop_128
                        when ('1', '0', '1', '1', '001') => __encoding A64_ldst_memop_128_RCWSCLRP_128_memop_128 // RCWSCLRPL_128_memop_128
                        when ('1', '0', '1', '1', '010') => __encoding A64_ldst_memop_128_RCWSSWPP_128_memop_128 // RCWSSWPPL_128_memop_128
                        when ('1', '0', '1', '1', '011') => __encoding A64_ldst_memop_128_RCWSSETP_128_memop_128 // RCWSSETPL_128_memop_128
                        when ('1', '1', '0', '1', '001') => __encoding A64_ldst_memop_128_RCWSCLRP_128_memop_128 // RCWSCLRPA_128_memop_128
                        when ('1', '1', '0', '1', '010') => __encoding A64_ldst_memop_128_RCWSSWPP_128_memop_128 // RCWSSWPPA_128_memop_128
                        when ('1', '1', '0', '1', '011') => __encoding A64_ldst_memop_128_RCWSSETP_128_memop_128 // RCWSSETPA_128_memop_128
                        when ('1', '1', '1', '1', '001') => __encoding A64_ldst_memop_128_RCWSCLRP_128_memop_128 // RCWSCLRPAL_128_memop_128
                        when ('1', '1', '1', '1', '010') => __encoding A64_ldst_memop_128_RCWSSWPP_128_memop_128 // RCWSSWPPAL_128_memop_128
                        when ('1', '1', '1', '1', '011') => __encoding A64_ldst_memop_128_RCWSSETP_128_memop_128 // RCWSSETPAL_128_memop_128
                when ('1101', _, '0', _, '1000111110xxx11', _) => // ldst_gcs
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc) of
                        when ('000') => __encoding A64_ldst_ldst_gcs_GCSSTR_64_ldst_gcs // GCSSTR_64_ldst_gcs
                        when ('001') => __encoding A64_ldst_ldst_gcs_GCSSTTR_64_ldst_gcs // GCSSTTR_64_ldst_gcs
                        when ('01x') => __UNALLOCATED
                        when ('1xx') => __UNALLOCATED
                when ('1101', _, '0', _, '1xx1xxxxxxxxxxx', _) => // ldsttags
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field op2 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, imm9, op2) of
                        when ('00', _, '01') => __encoding A64_ldst_ldsttags_STG_64Spost_ldsttags // STG_64Spost_ldsttags
                        when ('00', _, '10') => __encoding A64_ldst_ldsttags_STG_64Soffset_ldsttags // STG_64Soffset_ldsttags
                        when ('00', _, '11') => __encoding A64_ldst_ldsttags_STG_64Spre_ldsttags // STG_64Spre_ldsttags
                        when ('00', '000000000', '00') => __encoding A64_ldst_ldsttags_STZGM_64bulk_ldsttags // STZGM_64bulk_ldsttags
                        when ('00', '000000001', '00') => __UNALLOCATED
                        when ('00', '00000001x', '00') => __UNALLOCATED
                        when ('00', '0000001xx', '00') => __UNALLOCATED
                        when ('00', '000001xxx', '00') => __UNALLOCATED
                        when ('00', '00001xxxx', '00') => __UNALLOCATED
                        when ('00', '0001xxxxx', '00') => __UNALLOCATED
                        when ('00', '001xxxxxx', '00') => __UNALLOCATED
                        when ('00', '01xxxxxxx', '00') => __UNALLOCATED
                        when ('00', '1xxxxxxxx', '00') => __UNALLOCATED
                        when ('01', _, '00') => __encoding A64_ldst_ldsttags_LDG_64Loffset_ldsttags // LDG_64Loffset_ldsttags
                        when ('01', _, '01') => __encoding A64_ldst_ldsttags_STZG_64Spost_ldsttags // STZG_64Spost_ldsttags
                        when ('01', _, '10') => __encoding A64_ldst_ldsttags_STZG_64Soffset_ldsttags // STZG_64Soffset_ldsttags
                        when ('01', _, '11') => __encoding A64_ldst_ldsttags_STZG_64Spre_ldsttags // STZG_64Spre_ldsttags
                        when ('1x', '000000001', '00') => __UNALLOCATED
                        when ('1x', '00000001x', '00') => __UNALLOCATED
                        when ('1x', '0000001xx', '00') => __UNALLOCATED
                        when ('1x', '000001xxx', '00') => __UNALLOCATED
                        when ('1x', '00001xxxx', '00') => __UNALLOCATED
                        when ('1x', '0001xxxxx', '00') => __UNALLOCATED
                        when ('1x', '001xxxxxx', '00') => __UNALLOCATED
                        when ('1x', '01xxxxxxx', '00') => __UNALLOCATED
                        when ('1x', '1xxxxxxxx', '00') => __UNALLOCATED
                        when ('10', _, '01') => __encoding A64_ldst_ldsttags_ST2G_64Spost_ldsttags // ST2G_64Spost_ldsttags
                        when ('10', _, '10') => __encoding A64_ldst_ldsttags_ST2G_64Soffset_ldsttags // ST2G_64Soffset_ldsttags
                        when ('10', _, '11') => __encoding A64_ldst_ldsttags_ST2G_64Spre_ldsttags // ST2G_64Spre_ldsttags
                        when ('10', '000000000', '00') => __encoding A64_ldst_ldsttags_STGM_64bulk_ldsttags // STGM_64bulk_ldsttags
                        when ('11', _, '01') => __encoding A64_ldst_ldsttags_STZ2G_64Spost_ldsttags // STZ2G_64Spost_ldsttags
                        when ('11', _, '10') => __encoding A64_ldst_ldsttags_STZ2G_64Soffset_ldsttags // STZ2G_64Soffset_ldsttags
                        when ('11', _, '11') => __encoding A64_ldst_ldsttags_STZ2G_64Spre_ldsttags // STZ2G_64Spre_ldsttags
                        when ('11', '000000000', '00') => __encoding A64_ldst_ldsttags_LDGM_64bulk_ldsttags // LDGM_64bulk_ldsttags
                when ('1x00', _, '0', _, '00x1xxxxxxxxxxx', _) => // ldstexclp
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0) of
                        when ('0', '0', '0') => __encoding A64_ldst_ldstexclp_STXP_SP32_ldstexclp // STXP_SP32_ldstexclp
                        when ('0', '0', '1') => __encoding A64_ldst_ldstexclp_STLXP_SP32_ldstexclp // STLXP_SP32_ldstexclp
                        when ('0', '1', '0') => __encoding A64_ldst_ldstexclp_LDXP_LP32_ldstexclp // LDXP_LP32_ldstexclp
                        when ('0', '1', '1') => __encoding A64_ldst_ldstexclp_LDAXP_LP32_ldstexclp // LDAXP_LP32_ldstexclp
                        when ('1', '0', '0') => __encoding A64_ldst_ldstexclp_STXP_SP32_ldstexclp // STXP_SP64_ldstexclp
                        when ('1', '0', '1') => __encoding A64_ldst_ldstexclp_STLXP_SP32_ldstexclp // STLXP_SP64_ldstexclp
                        when ('1', '1', '0') => __encoding A64_ldst_ldstexclp_LDXP_LP32_ldstexclp // LDXP_LP64_ldstexclp
                        when ('1', '1', '1') => __encoding A64_ldst_ldstexclp_LDAXP_LP32_ldstexclp // LDAXP_LP64_ldstexclp
                when ('1x00', _, '1', _, _, _) => __UNPREDICTABLE
                when ('xx00', _, '0', _, '00x0xxxxxxxxxxx', _) => // ldstexclr
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstexclr_STXRB_SR32_ldstexclr // STXRB_SR32_ldstexclr
                        when ('00', '0', '1') => __encoding A64_ldst_ldstexclr_STLXRB_SR32_ldstexclr // STLXRB_SR32_ldstexclr
                        when ('00', '1', '0') => __encoding A64_ldst_ldstexclr_LDXRB_LR32_ldstexclr // LDXRB_LR32_ldstexclr
                        when ('00', '1', '1') => __encoding A64_ldst_ldstexclr_LDAXRB_LR32_ldstexclr // LDAXRB_LR32_ldstexclr
                        when ('01', '0', '0') => __encoding A64_ldst_ldstexclr_STXRH_SR32_ldstexclr // STXRH_SR32_ldstexclr
                        when ('01', '0', '1') => __encoding A64_ldst_ldstexclr_STLXRH_SR32_ldstexclr // STLXRH_SR32_ldstexclr
                        when ('01', '1', '0') => __encoding A64_ldst_ldstexclr_LDXRH_LR32_ldstexclr // LDXRH_LR32_ldstexclr
                        when ('01', '1', '1') => __encoding A64_ldst_ldstexclr_LDAXRH_LR32_ldstexclr // LDAXRH_LR32_ldstexclr
                        when ('10', '0', '0') => __encoding A64_ldst_ldstexclr_STXR_SR32_ldstexclr // STXR_SR32_ldstexclr
                        when ('10', '0', '1') => __encoding A64_ldst_ldstexclr_STLXR_SR32_ldstexclr // STLXR_SR32_ldstexclr
                        when ('10', '1', '0') => __encoding A64_ldst_ldstexclr_LDXR_LR32_ldstexclr // LDXR_LR32_ldstexclr
                        when ('10', '1', '1') => __encoding A64_ldst_ldstexclr_LDAXR_LR32_ldstexclr // LDAXR_LR32_ldstexclr
                        when ('11', '0', '0') => __encoding A64_ldst_ldstexclr_STXR_SR32_ldstexclr // STXR_SR64_ldstexclr
                        when ('11', '0', '1') => __encoding A64_ldst_ldstexclr_STLXR_SR32_ldstexclr // STLXR_SR64_ldstexclr
                        when ('11', '1', '0') => __encoding A64_ldst_ldstexclr_LDXR_LR32_ldstexclr // LDXR_LR64_ldstexclr
                        when ('11', '1', '1') => __encoding A64_ldst_ldstexclr_LDAXR_LR32_ldstexclr // LDAXR_LR64_ldstexclr
                when ('xx00', _, '0', _, '01x0xxxxxxxxxxx', _) => // ldstord
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstord_STLLRB_SL32_ldstord // STLLRB_SL32_ldstord
                        when ('00', '0', '1') => __encoding A64_ldst_ldstord_STLRB_SL32_ldstord // STLRB_SL32_ldstord
                        when ('00', '1', '0') => __encoding A64_ldst_ldstord_LDLARB_LR32_ldstord // LDLARB_LR32_ldstord
                        when ('00', '1', '1') => __encoding A64_ldst_ldstord_LDARB_LR32_ldstord // LDARB_LR32_ldstord
                        when ('01', '0', '0') => __encoding A64_ldst_ldstord_STLLRH_SL32_ldstord // STLLRH_SL32_ldstord
                        when ('01', '0', '1') => __encoding A64_ldst_ldstord_STLRH_SL32_ldstord // STLRH_SL32_ldstord
                        when ('01', '1', '0') => __encoding A64_ldst_ldstord_LDLARH_LR32_ldstord // LDLARH_LR32_ldstord
                        when ('01', '1', '1') => __encoding A64_ldst_ldstord_LDARH_LR32_ldstord // LDARH_LR32_ldstord
                        when ('10', '0', '0') => __encoding A64_ldst_ldstord_STLLR_SL32_ldstord // STLLR_SL32_ldstord
                        when ('10', '0', '1') => __encoding A64_ldst_ldstord_STLR_SL32_ldstord // STLR_SL32_ldstord
                        when ('10', '1', '0') => __encoding A64_ldst_ldstord_LDLAR_LR32_ldstord // LDLAR_LR32_ldstord
                        when ('10', '1', '1') => __encoding A64_ldst_ldstord_LDAR_LR32_ldstord // LDAR_LR32_ldstord
                        when ('11', '0', '0') => __encoding A64_ldst_ldstord_STLLR_SL32_ldstord // STLLR_SL64_ldstord
                        when ('11', '0', '1') => __encoding A64_ldst_ldstord_STLR_SL32_ldstord // STLR_SL64_ldstord
                        when ('11', '1', '0') => __encoding A64_ldst_ldstord_LDLAR_LR32_ldstord // LDLAR_LR64_ldstord
                        when ('11', '1', '1') => __encoding A64_ldst_ldstord_LDAR_LR32_ldstord // LDAR_LR64_ldstord
                when ('xx00', _, '0', _, '01x1xxxxxxxxxxx', _) => // comswap
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0, Rt2) of
                        when (_, _, _, '0xxxx') => __UNALLOCATED
                        when (_, _, _, '10xxx') => __UNALLOCATED
                        when (_, _, _, '110xx') => __UNALLOCATED
                        when (_, _, _, '1110x') => __UNALLOCATED
                        when (_, _, _, '11110') => __UNALLOCATED
                        when ('00', '0', '0', '11111') => __encoding A64_ldst_comswap_CASAB_C32_comswap // CASB_C32_comswap
                        when ('00', '0', '1', '11111') => __encoding A64_ldst_comswap_CASAB_C32_comswap // CASLB_C32_comswap
                        when ('00', '1', '0', '11111') => __encoding A64_ldst_comswap_CASAB_C32_comswap // CASAB_C32_comswap
                        when ('00', '1', '1', '11111') => __encoding A64_ldst_comswap_CASAB_C32_comswap // CASALB_C32_comswap
                        when ('01', '0', '0', '11111') => __encoding A64_ldst_comswap_CASAH_C32_comswap // CASH_C32_comswap
                        when ('01', '0', '1', '11111') => __encoding A64_ldst_comswap_CASAH_C32_comswap // CASLH_C32_comswap
                        when ('01', '1', '0', '11111') => __encoding A64_ldst_comswap_CASAH_C32_comswap // CASAH_C32_comswap
                        when ('01', '1', '1', '11111') => __encoding A64_ldst_comswap_CASAH_C32_comswap // CASALH_C32_comswap
                        when ('10', '0', '0', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CAS_C32_comswap
                        when ('10', '0', '1', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASL_C32_comswap
                        when ('10', '1', '0', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASA_C32_comswap
                        when ('10', '1', '1', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASAL_C32_comswap
                        when ('11', '0', '0', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CAS_C64_comswap
                        when ('11', '0', '1', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASL_C64_comswap
                        when ('11', '1', '0', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASA_C64_comswap
                        when ('11', '1', '1', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASAL_C64_comswap
                when ('xx01', _, '0', _, '10x0xxxxxxxxx10', _) => // ldiappstilp
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rt2 16 +: 5
                    __field opc2 12 +: 4
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, opc2) of
                        when ('0x', _, _) => __UNALLOCATED
                        when ('1x', _, '001x') => __UNALLOCATED
                        when ('1x', _, '01xx') => __UNALLOCATED
                        when ('1x', _, '1xxx') => __UNALLOCATED
                        when ('10', '0', '0000') => __encoding A64_ldst_ldiappstilp_STILP_32SE_ldiappstilp // STILP_32SE_ldiappstilp
                        when ('10', '0', '0001') => __encoding A64_ldst_ldiappstilp_STILP_32SE_ldiappstilp // STILP_32S_ldiappstilp
                        when ('10', '1', '0000') => __encoding A64_ldst_ldiappstilp_LDIAPP_32LE_ldiappstilp // LDIAPP_32LE_ldiappstilp
                        when ('10', '1', '0001') => __encoding A64_ldst_ldiappstilp_LDIAPP_32LE_ldiappstilp // LDIAPP_32L_ldiappstilp
                        when ('11', '0', '0000') => __encoding A64_ldst_ldiappstilp_STILP_32SE_ldiappstilp // STILP_64SS_ldiappstilp
                        when ('11', '0', '0001') => __encoding A64_ldst_ldiappstilp_STILP_32SE_ldiappstilp // STILP_64S_ldiappstilp
                        when ('11', '1', '0000') => __encoding A64_ldst_ldiappstilp_LDIAPP_32LE_ldiappstilp // LDIAPP_64LS_ldiappstilp
                        when ('11', '1', '0001') => __encoding A64_ldst_ldiappstilp_LDIAPP_32LE_ldiappstilp // LDIAPP_64L_ldiappstilp
                when ('xx01', _, '0', _, '11x000000000010', _) => // ldapstl_writeback
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L) of
                        when ('0x', _) => __UNALLOCATED
                        when ('10', '0') => __encoding A64_ldst_ldapstl_writeback_STLR_32S_ldapstl_writeback // STLR_32S_ldapstl_writeback
                        when ('10', '1') => __encoding A64_ldst_ldapstl_writeback_LDAPR_32L_ldapstl_writeback // LDAPR_32L_ldapstl_writeback
                        when ('11', '0') => __encoding A64_ldst_ldapstl_writeback_STLR_32S_ldapstl_writeback // STLR_64S_ldapstl_writeback
                        when ('11', '1') => __encoding A64_ldst_ldapstl_writeback_LDAPR_32L_ldapstl_writeback // LDAPR_64L_ldapstl_writeback
                when ('xx01', _, '0', _, '1xx0xxxxxxxxx00', _) => // ldapstl_unscaled
                    __field size 30 +: 2
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, opc) of
                        when ('00', '00') => __encoding A64_ldst_ldapstl_unscaled_STLURB_32_ldapstl_unscaled // STLURB_32_ldapstl_unscaled
                        when ('00', '01') => __encoding A64_ldst_ldapstl_unscaled_LDAPURB_32_ldapstl_unscaled // LDAPURB_32_ldapstl_unscaled
                        when ('00', '10') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSB_32_ldapstl_unscaled // LDAPURSB_64_ldapstl_unscaled
                        when ('00', '11') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSB_32_ldapstl_unscaled // LDAPURSB_32_ldapstl_unscaled
                        when ('01', '00') => __encoding A64_ldst_ldapstl_unscaled_STLURH_32_ldapstl_unscaled // STLURH_32_ldapstl_unscaled
                        when ('01', '01') => __encoding A64_ldst_ldapstl_unscaled_LDAPURH_32_ldapstl_unscaled // LDAPURH_32_ldapstl_unscaled
                        when ('01', '10') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSH_32_ldapstl_unscaled // LDAPURSH_64_ldapstl_unscaled
                        when ('01', '11') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSH_32_ldapstl_unscaled // LDAPURSH_32_ldapstl_unscaled
                        when ('10', '00') => __encoding A64_ldst_ldapstl_unscaled_STLUR_32_ldapstl_unscaled // STLUR_32_ldapstl_unscaled
                        when ('10', '01') => __encoding A64_ldst_ldapstl_unscaled_LDAPUR_32_ldapstl_unscaled // LDAPUR_32_ldapstl_unscaled
                        when ('10', '10') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSW_64_ldapstl_unscaled // LDAPURSW_64_ldapstl_unscaled
                        when ('10', '11') => __UNALLOCATED
                        when ('11', '00') => __encoding A64_ldst_ldapstl_unscaled_STLUR_32_ldapstl_unscaled // STLUR_64_ldapstl_unscaled
                        when ('11', '01') => __encoding A64_ldst_ldapstl_unscaled_LDAPUR_32_ldapstl_unscaled // LDAPUR_64_ldapstl_unscaled
                        when ('11', '1x') => __UNALLOCATED
                when ('xx01', _, '1', _, '1xx0xxxxxxxxx10', _) => // ldapstl_simd
                    __field size 30 +: 2
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, opc) of
                        when ('00', '00') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_B_ldapstl_simd
                        when ('00', '01') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_B_ldapstl_simd
                        when ('00', '10') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_Q_ldapstl_simd
                        when ('00', '11') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_Q_ldapstl_simd
                        when ('01', '00') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_H_ldapstl_simd
                        when ('01', '01') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_H_ldapstl_simd
                        when ('01', '1x') => __UNALLOCATED
                        when ('1x', '1x') => __UNALLOCATED
                        when ('10', '00') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_S_ldapstl_simd
                        when ('10', '01') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_S_ldapstl_simd
                        when ('11', '00') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_D_ldapstl_simd
                        when ('11', '01') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_D_ldapstl_simd
                when ('xx01', _, _, _, '0xxxxxxxxxxxxxx', _) => // loadlit
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field imm19 5 +: 19
                    __field Rt 0 +: 5
                    case (opc, VR) of
                        when ('00', '0') => __encoding A64_ldst_loadlit_LDR_32_loadlit // LDR_32_loadlit
                        when ('00', '1') => __encoding A64_ldst_loadlit_LDR_S_loadlit // LDR_S_loadlit
                        when ('01', '0') => __encoding A64_ldst_loadlit_LDR_32_loadlit // LDR_64_loadlit
                        when ('01', '1') => __encoding A64_ldst_loadlit_LDR_S_loadlit // LDR_D_loadlit
                        when ('10', '0') => __encoding A64_ldst_loadlit_LDRSW_64_loadlit // LDRSW_64_loadlit
                        when ('10', '1') => __encoding A64_ldst_loadlit_LDR_S_loadlit // LDR_Q_loadlit
                        when ('11', '0') => __encoding A64_ldst_loadlit_PRFM_P_loadlit // PRFM_P_loadlit
                        when ('11', '1') => __UNALLOCATED
                when ('xx01', _, _, _, '1xx0xxxxxxxxx01', _) => // memcms
                    __field size 30 +: 2
                    __field o0 26 +: 1
                    __field op1 22 +: 2
                    __field Rs 16 +: 5
                    __field op2 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (o0, op1, op2) of
                        when (_, '11', '11xx') => __UNALLOCATED
                        when ('0', '00', '0000') => __encoding A64_ldst_memcms_CPYFP_CPY_memcms // CPYFP_CPY_memcms
                        when ('0', '00', '0001') => __encoding A64_ldst_memcms_CPYFPWT_CPY_memcms // CPYFPWT_CPY_memcms
                        when ('0', '00', '0010') => __encoding A64_ldst_memcms_CPYFPRT_CPY_memcms // CPYFPRT_CPY_memcms
                        when ('0', '00', '0011') => __encoding A64_ldst_memcms_CPYFPT_CPY_memcms // CPYFPT_CPY_memcms
                        when ('0', '00', '0100') => __encoding A64_ldst_memcms_CPYFPWN_CPY_memcms // CPYFPWN_CPY_memcms
                        when ('0', '00', '0101') => __encoding A64_ldst_memcms_CPYFPWTWN_CPY_memcms // CPYFPWTWN_CPY_memcms
                        when ('0', '00', '0110') => __encoding A64_ldst_memcms_CPYFPRTWN_CPY_memcms // CPYFPRTWN_CPY_memcms
                        when ('0', '00', '0111') => __encoding A64_ldst_memcms_CPYFPTWN_CPY_memcms // CPYFPTWN_CPY_memcms
                        when ('0', '00', '1000') => __encoding A64_ldst_memcms_CPYFPRN_CPY_memcms // CPYFPRN_CPY_memcms
                        when ('0', '00', '1001') => __encoding A64_ldst_memcms_CPYFPWTRN_CPY_memcms // CPYFPWTRN_CPY_memcms
                        when ('0', '00', '1010') => __encoding A64_ldst_memcms_CPYFPRTRN_CPY_memcms // CPYFPRTRN_CPY_memcms
                        when ('0', '00', '1011') => __encoding A64_ldst_memcms_CPYFPTRN_CPY_memcms // CPYFPTRN_CPY_memcms
                        when ('0', '00', '1100') => __encoding A64_ldst_memcms_CPYFPN_CPY_memcms // CPYFPN_CPY_memcms
                        when ('0', '00', '1101') => __encoding A64_ldst_memcms_CPYFPWTN_CPY_memcms // CPYFPWTN_CPY_memcms
                        when ('0', '00', '1110') => __encoding A64_ldst_memcms_CPYFPRTN_CPY_memcms // CPYFPRTN_CPY_memcms
                        when ('0', '00', '1111') => __encoding A64_ldst_memcms_CPYFPTN_CPY_memcms // CPYFPTN_CPY_memcms
                        when ('0', '01', '0000') => __encoding A64_ldst_memcms_CPYFP_CPY_memcms // CPYFM_CPY_memcms
                        when ('0', '01', '0001') => __encoding A64_ldst_memcms_CPYFPWT_CPY_memcms // CPYFMWT_CPY_memcms
                        when ('0', '01', '0010') => __encoding A64_ldst_memcms_CPYFPRT_CPY_memcms // CPYFMRT_CPY_memcms
                        when ('0', '01', '0011') => __encoding A64_ldst_memcms_CPYFPT_CPY_memcms // CPYFMT_CPY_memcms
                        when ('0', '01', '0100') => __encoding A64_ldst_memcms_CPYFPWN_CPY_memcms // CPYFMWN_CPY_memcms
                        when ('0', '01', '0101') => __encoding A64_ldst_memcms_CPYFPWTWN_CPY_memcms // CPYFMWTWN_CPY_memcms
                        when ('0', '01', '0110') => __encoding A64_ldst_memcms_CPYFPRTWN_CPY_memcms // CPYFMRTWN_CPY_memcms
                        when ('0', '01', '0111') => __encoding A64_ldst_memcms_CPYFPTWN_CPY_memcms // CPYFMTWN_CPY_memcms
                        when ('0', '01', '1000') => __encoding A64_ldst_memcms_CPYFPRN_CPY_memcms // CPYFMRN_CPY_memcms
                        when ('0', '01', '1001') => __encoding A64_ldst_memcms_CPYFPWTRN_CPY_memcms // CPYFMWTRN_CPY_memcms
                        when ('0', '01', '1010') => __encoding A64_ldst_memcms_CPYFPRTRN_CPY_memcms // CPYFMRTRN_CPY_memcms
                        when ('0', '01', '1011') => __encoding A64_ldst_memcms_CPYFPTRN_CPY_memcms // CPYFMTRN_CPY_memcms
                        when ('0', '01', '1100') => __encoding A64_ldst_memcms_CPYFPN_CPY_memcms // CPYFMN_CPY_memcms
                        when ('0', '01', '1101') => __encoding A64_ldst_memcms_CPYFPWTN_CPY_memcms // CPYFMWTN_CPY_memcms
                        when ('0', '01', '1110') => __encoding A64_ldst_memcms_CPYFPRTN_CPY_memcms // CPYFMRTN_CPY_memcms
                        when ('0', '01', '1111') => __encoding A64_ldst_memcms_CPYFPTN_CPY_memcms // CPYFMTN_CPY_memcms
                        when ('0', '10', '0000') => __encoding A64_ldst_memcms_CPYFP_CPY_memcms // CPYFE_CPY_memcms
                        when ('0', '10', '0001') => __encoding A64_ldst_memcms_CPYFPWT_CPY_memcms // CPYFEWT_CPY_memcms
                        when ('0', '10', '0010') => __encoding A64_ldst_memcms_CPYFPRT_CPY_memcms // CPYFERT_CPY_memcms
                        when ('0', '10', '0011') => __encoding A64_ldst_memcms_CPYFPT_CPY_memcms // CPYFET_CPY_memcms
                        when ('0', '10', '0100') => __encoding A64_ldst_memcms_CPYFPWN_CPY_memcms // CPYFEWN_CPY_memcms
                        when ('0', '10', '0101') => __encoding A64_ldst_memcms_CPYFPWTWN_CPY_memcms // CPYFEWTWN_CPY_memcms
                        when ('0', '10', '0110') => __encoding A64_ldst_memcms_CPYFPRTWN_CPY_memcms // CPYFERTWN_CPY_memcms
                        when ('0', '10', '0111') => __encoding A64_ldst_memcms_CPYFPTWN_CPY_memcms // CPYFETWN_CPY_memcms
                        when ('0', '10', '1000') => __encoding A64_ldst_memcms_CPYFPRN_CPY_memcms // CPYFERN_CPY_memcms
                        when ('0', '10', '1001') => __encoding A64_ldst_memcms_CPYFPWTRN_CPY_memcms // CPYFEWTRN_CPY_memcms
                        when ('0', '10', '1010') => __encoding A64_ldst_memcms_CPYFPRTRN_CPY_memcms // CPYFERTRN_CPY_memcms
                        when ('0', '10', '1011') => __encoding A64_ldst_memcms_CPYFPTRN_CPY_memcms // CPYFETRN_CPY_memcms
                        when ('0', '10', '1100') => __encoding A64_ldst_memcms_CPYFPN_CPY_memcms // CPYFEN_CPY_memcms
                        when ('0', '10', '1101') => __encoding A64_ldst_memcms_CPYFPWTN_CPY_memcms // CPYFEWTN_CPY_memcms
                        when ('0', '10', '1110') => __encoding A64_ldst_memcms_CPYFPRTN_CPY_memcms // CPYFERTN_CPY_memcms
                        when ('0', '10', '1111') => __encoding A64_ldst_memcms_CPYFPTN_CPY_memcms // CPYFETN_CPY_memcms
                        when ('0', '11', '0000') => __encoding A64_ldst_memcms_SETP_SET_memcms // SETP_SET_memcms
                        when ('0', '11', '0001') => __encoding A64_ldst_memcms_SETPT_SET_memcms // SETPT_SET_memcms
                        when ('0', '11', '0010') => __encoding A64_ldst_memcms_SETPN_SET_memcms // SETPN_SET_memcms
                        when ('0', '11', '0011') => __encoding A64_ldst_memcms_SETPTN_SET_memcms // SETPTN_SET_memcms
                        when ('0', '11', '0100') => __encoding A64_ldst_memcms_SETP_SET_memcms // SETM_SET_memcms
                        when ('0', '11', '0101') => __encoding A64_ldst_memcms_SETPT_SET_memcms // SETMT_SET_memcms
                        when ('0', '11', '0110') => __encoding A64_ldst_memcms_SETPN_SET_memcms // SETMN_SET_memcms
                        when ('0', '11', '0111') => __encoding A64_ldst_memcms_SETPTN_SET_memcms // SETMTN_SET_memcms
                        when ('0', '11', '1000') => __encoding A64_ldst_memcms_SETP_SET_memcms // SETE_SET_memcms
                        when ('0', '11', '1001') => __encoding A64_ldst_memcms_SETPT_SET_memcms // SETET_SET_memcms
                        when ('0', '11', '1010') => __encoding A64_ldst_memcms_SETPN_SET_memcms // SETEN_SET_memcms
                        when ('0', '11', '1011') => __encoding A64_ldst_memcms_SETPTN_SET_memcms // SETETN_SET_memcms
                        when ('1', '00', '0000') => __encoding A64_ldst_memcms_CPYP_CPY_memcms // CPYP_CPY_memcms
                        when ('1', '00', '0001') => __encoding A64_ldst_memcms_CPYPWT_CPY_memcms // CPYPWT_CPY_memcms
                        when ('1', '00', '0010') => __encoding A64_ldst_memcms_CPYPRT_CPY_memcms // CPYPRT_CPY_memcms
                        when ('1', '00', '0011') => __encoding A64_ldst_memcms_CPYPT_CPY_memcms // CPYPT_CPY_memcms
                        when ('1', '00', '0100') => __encoding A64_ldst_memcms_CPYPWN_CPY_memcms // CPYPWN_CPY_memcms
                        when ('1', '00', '0101') => __encoding A64_ldst_memcms_CPYPWTWN_CPY_memcms // CPYPWTWN_CPY_memcms
                        when ('1', '00', '0110') => __encoding A64_ldst_memcms_CPYPRTWN_CPY_memcms // CPYPRTWN_CPY_memcms
                        when ('1', '00', '0111') => __encoding A64_ldst_memcms_CPYPTWN_CPY_memcms // CPYPTWN_CPY_memcms
                        when ('1', '00', '1000') => __encoding A64_ldst_memcms_CPYPRN_CPY_memcms // CPYPRN_CPY_memcms
                        when ('1', '00', '1001') => __encoding A64_ldst_memcms_CPYPWTRN_CPY_memcms // CPYPWTRN_CPY_memcms
                        when ('1', '00', '1010') => __encoding A64_ldst_memcms_CPYPRTRN_CPY_memcms // CPYPRTRN_CPY_memcms
                        when ('1', '00', '1011') => __encoding A64_ldst_memcms_CPYPTRN_CPY_memcms // CPYPTRN_CPY_memcms
                        when ('1', '00', '1100') => __encoding A64_ldst_memcms_CPYPN_CPY_memcms // CPYPN_CPY_memcms
                        when ('1', '00', '1101') => __encoding A64_ldst_memcms_CPYPWTN_CPY_memcms // CPYPWTN_CPY_memcms
                        when ('1', '00', '1110') => __encoding A64_ldst_memcms_CPYPRTN_CPY_memcms // CPYPRTN_CPY_memcms
                        when ('1', '00', '1111') => __encoding A64_ldst_memcms_CPYPTN_CPY_memcms // CPYPTN_CPY_memcms
                        when ('1', '01', '0000') => __encoding A64_ldst_memcms_CPYP_CPY_memcms // CPYM_CPY_memcms
                        when ('1', '01', '0001') => __encoding A64_ldst_memcms_CPYPWT_CPY_memcms // CPYMWT_CPY_memcms
                        when ('1', '01', '0010') => __encoding A64_ldst_memcms_CPYPRT_CPY_memcms // CPYMRT_CPY_memcms
                        when ('1', '01', '0011') => __encoding A64_ldst_memcms_CPYPT_CPY_memcms // CPYMT_CPY_memcms
                        when ('1', '01', '0100') => __encoding A64_ldst_memcms_CPYPWN_CPY_memcms // CPYMWN_CPY_memcms
                        when ('1', '01', '0101') => __encoding A64_ldst_memcms_CPYPWTWN_CPY_memcms // CPYMWTWN_CPY_memcms
                        when ('1', '01', '0110') => __encoding A64_ldst_memcms_CPYPRTWN_CPY_memcms // CPYMRTWN_CPY_memcms
                        when ('1', '01', '0111') => __encoding A64_ldst_memcms_CPYPTWN_CPY_memcms // CPYMTWN_CPY_memcms
                        when ('1', '01', '1000') => __encoding A64_ldst_memcms_CPYPRN_CPY_memcms // CPYMRN_CPY_memcms
                        when ('1', '01', '1001') => __encoding A64_ldst_memcms_CPYPWTRN_CPY_memcms // CPYMWTRN_CPY_memcms
                        when ('1', '01', '1010') => __encoding A64_ldst_memcms_CPYPRTRN_CPY_memcms // CPYMRTRN_CPY_memcms
                        when ('1', '01', '1011') => __encoding A64_ldst_memcms_CPYPTRN_CPY_memcms // CPYMTRN_CPY_memcms
                        when ('1', '01', '1100') => __encoding A64_ldst_memcms_CPYPN_CPY_memcms // CPYMN_CPY_memcms
                        when ('1', '01', '1101') => __encoding A64_ldst_memcms_CPYPWTN_CPY_memcms // CPYMWTN_CPY_memcms
                        when ('1', '01', '1110') => __encoding A64_ldst_memcms_CPYPRTN_CPY_memcms // CPYMRTN_CPY_memcms
                        when ('1', '01', '1111') => __encoding A64_ldst_memcms_CPYPTN_CPY_memcms // CPYMTN_CPY_memcms
                        when ('1', '10', '0000') => __encoding A64_ldst_memcms_CPYP_CPY_memcms // CPYE_CPY_memcms
                        when ('1', '10', '0001') => __encoding A64_ldst_memcms_CPYPWT_CPY_memcms // CPYEWT_CPY_memcms
                        when ('1', '10', '0010') => __encoding A64_ldst_memcms_CPYPRT_CPY_memcms // CPYERT_CPY_memcms
                        when ('1', '10', '0011') => __encoding A64_ldst_memcms_CPYPT_CPY_memcms // CPYET_CPY_memcms
                        when ('1', '10', '0100') => __encoding A64_ldst_memcms_CPYPWN_CPY_memcms // CPYEWN_CPY_memcms
                        when ('1', '10', '0101') => __encoding A64_ldst_memcms_CPYPWTWN_CPY_memcms // CPYEWTWN_CPY_memcms
                        when ('1', '10', '0110') => __encoding A64_ldst_memcms_CPYPRTWN_CPY_memcms // CPYERTWN_CPY_memcms
                        when ('1', '10', '0111') => __encoding A64_ldst_memcms_CPYPTWN_CPY_memcms // CPYETWN_CPY_memcms
                        when ('1', '10', '1000') => __encoding A64_ldst_memcms_CPYPRN_CPY_memcms // CPYERN_CPY_memcms
                        when ('1', '10', '1001') => __encoding A64_ldst_memcms_CPYPWTRN_CPY_memcms // CPYEWTRN_CPY_memcms
                        when ('1', '10', '1010') => __encoding A64_ldst_memcms_CPYPRTRN_CPY_memcms // CPYERTRN_CPY_memcms
                        when ('1', '10', '1011') => __encoding A64_ldst_memcms_CPYPTRN_CPY_memcms // CPYETRN_CPY_memcms
                        when ('1', '10', '1100') => __encoding A64_ldst_memcms_CPYPN_CPY_memcms // CPYEN_CPY_memcms
                        when ('1', '10', '1101') => __encoding A64_ldst_memcms_CPYPWTN_CPY_memcms // CPYEWTN_CPY_memcms
                        when ('1', '10', '1110') => __encoding A64_ldst_memcms_CPYPRTN_CPY_memcms // CPYERTN_CPY_memcms
                        when ('1', '10', '1111') => __encoding A64_ldst_memcms_CPYPTN_CPY_memcms // CPYETN_CPY_memcms
                        when ('1', '11', '0000') => __encoding A64_ldst_memcms_SETGP_SET_memcms // SETGP_SET_memcms
                        when ('1', '11', '0001') => __encoding A64_ldst_memcms_SETGPT_SET_memcms // SETGPT_SET_memcms
                        when ('1', '11', '0010') => __encoding A64_ldst_memcms_SETGPN_SET_memcms // SETGPN_SET_memcms
                        when ('1', '11', '0011') => __encoding A64_ldst_memcms_SETGPTN_SET_memcms // SETGPTN_SET_memcms
                        when ('1', '11', '0100') => __encoding A64_ldst_memcms_SETGP_SET_memcms // SETGM_SET_memcms
                        when ('1', '11', '0101') => __encoding A64_ldst_memcms_SETGPT_SET_memcms // SETGMT_SET_memcms
                        when ('1', '11', '0110') => __encoding A64_ldst_memcms_SETGPN_SET_memcms // SETGMN_SET_memcms
                        when ('1', '11', '0111') => __encoding A64_ldst_memcms_SETGPTN_SET_memcms // SETGMTN_SET_memcms
                        when ('1', '11', '1000') => __encoding A64_ldst_memcms_SETGP_SET_memcms // SETGE_SET_memcms
                        when ('1', '11', '1001') => __encoding A64_ldst_memcms_SETGPT_SET_memcms // SETGET_SET_memcms
                        when ('1', '11', '1010') => __encoding A64_ldst_memcms_SETGPN_SET_memcms // SETGEN_SET_memcms
                        when ('1', '11', '1011') => __encoding A64_ldst_memcms_SETGPTN_SET_memcms // SETGETN_SET_memcms
                when ('xx10', _, _, _, '00xxxxxxxxxxxxx', _) => // ldstnapair_offs
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, VR, L) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_32_ldstnapair_offs // STNP_32_ldstnapair_offs
                        when ('00', '0', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_32_ldstnapair_offs // LDNP_32_ldstnapair_offs
                        when ('00', '1', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_S_ldstnapair_offs // STNP_S_ldstnapair_offs
                        when ('00', '1', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_S_ldstnapair_offs // LDNP_S_ldstnapair_offs
                        when ('01', '0', _) => __UNALLOCATED
                        when ('01', '1', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_S_ldstnapair_offs // STNP_D_ldstnapair_offs
                        when ('01', '1', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_S_ldstnapair_offs // LDNP_D_ldstnapair_offs
                        when ('10', '0', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_32_ldstnapair_offs // STNP_64_ldstnapair_offs
                        when ('10', '0', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_32_ldstnapair_offs // LDNP_64_ldstnapair_offs
                        when ('10', '1', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_S_ldstnapair_offs // STNP_Q_ldstnapair_offs
                        when ('10', '1', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_S_ldstnapair_offs // LDNP_Q_ldstnapair_offs
                        when ('11', _, _) => __UNALLOCATED
                when ('xx10', _, _, _, '01xxxxxxxxxxxxx', _) => // ldstpair_post
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, VR, L) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstpair_post_STP_32_ldstpair_post // STP_32_ldstpair_post
                        when ('00', '0', '1') => __encoding A64_ldst_ldstpair_post_LDP_32_ldstpair_post // LDP_32_ldstpair_post
                        when ('00', '1', '0') => __encoding A64_ldst_ldstpair_post_STP_S_ldstpair_post // STP_S_ldstpair_post
                        when ('00', '1', '1') => __encoding A64_ldst_ldstpair_post_LDP_S_ldstpair_post // LDP_S_ldstpair_post
                        when ('01', '0', '0') => __encoding A64_ldst_ldstpair_post_STGP_64_ldstpair_post // STGP_64_ldstpair_post
                        when ('01', '0', '1') => __encoding A64_ldst_ldstpair_post_LDPSW_64_ldstpair_post // LDPSW_64_ldstpair_post
                        when ('01', '1', '0') => __encoding A64_ldst_ldstpair_post_STP_S_ldstpair_post // STP_D_ldstpair_post
                        when ('01', '1', '1') => __encoding A64_ldst_ldstpair_post_LDP_S_ldstpair_post // LDP_D_ldstpair_post
                        when ('10', '0', '0') => __encoding A64_ldst_ldstpair_post_STP_32_ldstpair_post // STP_64_ldstpair_post
                        when ('10', '0', '1') => __encoding A64_ldst_ldstpair_post_LDP_32_ldstpair_post // LDP_64_ldstpair_post
                        when ('10', '1', '0') => __encoding A64_ldst_ldstpair_post_STP_S_ldstpair_post // STP_Q_ldstpair_post
                        when ('10', '1', '1') => __encoding A64_ldst_ldstpair_post_LDP_S_ldstpair_post // LDP_Q_ldstpair_post
                        when ('11', _, _) => __UNALLOCATED
                when ('xx10', _, _, _, '10xxxxxxxxxxxxx', _) => // ldstpair_off
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, VR, L) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstpair_off_STP_32_ldstpair_off // STP_32_ldstpair_off
                        when ('00', '0', '1') => __encoding A64_ldst_ldstpair_off_LDP_32_ldstpair_off // LDP_32_ldstpair_off
                        when ('00', '1', '0') => __encoding A64_ldst_ldstpair_off_STP_S_ldstpair_off // STP_S_ldstpair_off
                        when ('00', '1', '1') => __encoding A64_ldst_ldstpair_off_LDP_S_ldstpair_off // LDP_S_ldstpair_off
                        when ('01', '0', '0') => __encoding A64_ldst_ldstpair_off_STGP_64_ldstpair_off // STGP_64_ldstpair_off
                        when ('01', '0', '1') => __encoding A64_ldst_ldstpair_off_LDPSW_64_ldstpair_off // LDPSW_64_ldstpair_off
                        when ('01', '1', '0') => __encoding A64_ldst_ldstpair_off_STP_S_ldstpair_off // STP_D_ldstpair_off
                        when ('01', '1', '1') => __encoding A64_ldst_ldstpair_off_LDP_S_ldstpair_off // LDP_D_ldstpair_off
                        when ('10', '0', '0') => __encoding A64_ldst_ldstpair_off_STP_32_ldstpair_off // STP_64_ldstpair_off
                        when ('10', '0', '1') => __encoding A64_ldst_ldstpair_off_LDP_32_ldstpair_off // LDP_64_ldstpair_off
                        when ('10', '1', '0') => __encoding A64_ldst_ldstpair_off_STP_S_ldstpair_off // STP_Q_ldstpair_off
                        when ('10', '1', '1') => __encoding A64_ldst_ldstpair_off_LDP_S_ldstpair_off // LDP_Q_ldstpair_off
                        when ('11', _, _) => __UNALLOCATED
                when ('xx10', _, _, _, '11xxxxxxxxxxxxx', _) => // ldstpair_pre
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, VR, L) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstpair_pre_STP_32_ldstpair_pre // STP_32_ldstpair_pre
                        when ('00', '0', '1') => __encoding A64_ldst_ldstpair_pre_LDP_32_ldstpair_pre // LDP_32_ldstpair_pre
                        when ('00', '1', '0') => __encoding A64_ldst_ldstpair_pre_STP_S_ldstpair_pre // STP_S_ldstpair_pre
                        when ('00', '1', '1') => __encoding A64_ldst_ldstpair_pre_LDP_S_ldstpair_pre // LDP_S_ldstpair_pre
                        when ('01', '0', '0') => __encoding A64_ldst_ldstpair_pre_STGP_64_ldstpair_pre // STGP_64_ldstpair_pre
                        when ('01', '0', '1') => __encoding A64_ldst_ldstpair_pre_LDPSW_64_ldstpair_pre // LDPSW_64_ldstpair_pre
                        when ('01', '1', '0') => __encoding A64_ldst_ldstpair_pre_STP_S_ldstpair_pre // STP_D_ldstpair_pre
                        when ('01', '1', '1') => __encoding A64_ldst_ldstpair_pre_LDP_S_ldstpair_pre // LDP_D_ldstpair_pre
                        when ('10', '0', '0') => __encoding A64_ldst_ldstpair_pre_STP_32_ldstpair_pre // STP_64_ldstpair_pre
                        when ('10', '0', '1') => __encoding A64_ldst_ldstpair_pre_LDP_32_ldstpair_pre // LDP_64_ldstpair_pre
                        when ('10', '1', '0') => __encoding A64_ldst_ldstpair_pre_STP_S_ldstpair_pre // STP_Q_ldstpair_pre
                        when ('10', '1', '1') => __encoding A64_ldst_ldstpair_pre_LDP_S_ldstpair_pre // LDP_Q_ldstpair_pre
                        when ('11', _, _) => __UNALLOCATED
                when ('xx11', _, _, _, '0xx0xxxxxxxxx00', _) => // ldst_unscaled
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_unscaled_STURB_32_ldst_unscaled // STURB_32_ldst_unscaled
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_unscaled_LDURB_32_ldst_unscaled // LDURB_32_ldst_unscaled
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_unscaled_LDURSB_32_ldst_unscaled // LDURSB_64_ldst_unscaled
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_unscaled_LDURSB_32_ldst_unscaled // LDURSB_32_ldst_unscaled
                        when ('00', '1', '00') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_B_ldst_unscaled
                        when ('00', '1', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_B_ldst_unscaled
                        when ('00', '1', '10') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_Q_ldst_unscaled
                        when ('00', '1', '11') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_Q_ldst_unscaled
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_unscaled_STURH_32_ldst_unscaled // STURH_32_ldst_unscaled
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_unscaled_LDURH_32_ldst_unscaled // LDURH_32_ldst_unscaled
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_unscaled_LDURSH_32_ldst_unscaled // LDURSH_64_ldst_unscaled
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_unscaled_LDURSH_32_ldst_unscaled // LDURSH_32_ldst_unscaled
                        when ('01', '1', '00') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_H_ldst_unscaled
                        when ('01', '1', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_H_ldst_unscaled
                        when ('01', '1', '1x') => __UNALLOCATED
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('1x', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_unscaled_STUR_32_ldst_unscaled // STUR_32_ldst_unscaled
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_32_ldst_unscaled // LDUR_32_ldst_unscaled
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_unscaled_LDURSW_64_ldst_unscaled // LDURSW_64_ldst_unscaled
                        when ('10', '1', '00') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_S_ldst_unscaled
                        when ('10', '1', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_S_ldst_unscaled
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_unscaled_STUR_32_ldst_unscaled // STUR_64_ldst_unscaled
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_32_ldst_unscaled // LDUR_64_ldst_unscaled
                        when ('11', '0', '10') => __encoding A64_ldst_ldst_unscaled_PRFUM_P_ldst_unscaled // PRFUM_P_ldst_unscaled
                        when ('11', '1', '00') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_D_ldst_unscaled
                        when ('11', '1', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_D_ldst_unscaled
                when ('xx11', _, _, _, '0xx0xxxxxxxxx01', _) => // ldst_immpost
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_immpost_STRB_32_ldst_immpost // STRB_32_ldst_immpost
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_immpost_LDRB_32_ldst_immpost // LDRB_32_ldst_immpost
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_immpost_LDRSB_32_ldst_immpost // LDRSB_64_ldst_immpost
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_immpost_LDRSB_32_ldst_immpost // LDRSB_32_ldst_immpost
                        when ('00', '1', '00') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_B_ldst_immpost
                        when ('00', '1', '01') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_B_ldst_immpost
                        when ('00', '1', '10') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_Q_ldst_immpost
                        when ('00', '1', '11') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_Q_ldst_immpost
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_immpost_STRH_32_ldst_immpost // STRH_32_ldst_immpost
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_immpost_LDRH_32_ldst_immpost // LDRH_32_ldst_immpost
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_immpost_LDRSH_32_ldst_immpost // LDRSH_64_ldst_immpost
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_immpost_LDRSH_32_ldst_immpost // LDRSH_32_ldst_immpost
                        when ('01', '1', '00') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_H_ldst_immpost
                        when ('01', '1', '01') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_H_ldst_immpost
                        when ('01', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_immpost_STR_32_ldst_immpost // STR_32_ldst_immpost
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_immpost_LDR_32_ldst_immpost // LDR_32_ldst_immpost
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_immpost_LDRSW_64_ldst_immpost // LDRSW_64_ldst_immpost
                        when ('10', '0', '11') => __UNALLOCATED
                        when ('10', '1', '00') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_S_ldst_immpost
                        when ('10', '1', '01') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_S_ldst_immpost
                        when ('10', '1', '1x') => __UNALLOCATED
                        when ('11', _, '1x') => __UNALLOCATED
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_immpost_STR_32_ldst_immpost // STR_64_ldst_immpost
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_immpost_LDR_32_ldst_immpost // LDR_64_ldst_immpost
                        when ('11', '1', '00') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_D_ldst_immpost
                        when ('11', '1', '01') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_D_ldst_immpost
                when ('xx11', _, _, _, '0xx0xxxxxxxxx10', _) => // ldst_unpriv
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when (_, '1', _) => __UNALLOCATED
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_unpriv_STTRB_32_ldst_unpriv // STTRB_32_ldst_unpriv
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_unpriv_LDTRB_32_ldst_unpriv // LDTRB_32_ldst_unpriv
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_unpriv_LDTRSB_32_ldst_unpriv // LDTRSB_64_ldst_unpriv
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_unpriv_LDTRSB_32_ldst_unpriv // LDTRSB_32_ldst_unpriv
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_unpriv_STTRH_32_ldst_unpriv // STTRH_32_ldst_unpriv
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_unpriv_LDTRH_32_ldst_unpriv // LDTRH_32_ldst_unpriv
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_unpriv_LDTRSH_32_ldst_unpriv // LDTRSH_64_ldst_unpriv
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_unpriv_LDTRSH_32_ldst_unpriv // LDTRSH_32_ldst_unpriv
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_unpriv_STTR_32_ldst_unpriv // STTR_32_ldst_unpriv
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_unpriv_LDTR_32_ldst_unpriv // LDTR_32_ldst_unpriv
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_unpriv_LDTRSW_64_ldst_unpriv // LDTRSW_64_ldst_unpriv
                        when ('10', '0', '11') => __UNALLOCATED
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_unpriv_STTR_32_ldst_unpriv // STTR_64_ldst_unpriv
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_unpriv_LDTR_32_ldst_unpriv // LDTR_64_ldst_unpriv
                        when ('11', '0', '1x') => __UNALLOCATED
                when ('xx11', _, _, _, '0xx0xxxxxxxxx11', _) => // ldst_immpre
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_immpre_STRB_32_ldst_immpre // STRB_32_ldst_immpre
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_immpre_LDRB_32_ldst_immpre // LDRB_32_ldst_immpre
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_immpre_LDRSB_32_ldst_immpre // LDRSB_64_ldst_immpre
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_immpre_LDRSB_32_ldst_immpre // LDRSB_32_ldst_immpre
                        when ('00', '1', '00') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_B_ldst_immpre
                        when ('00', '1', '01') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_B_ldst_immpre
                        when ('00', '1', '10') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_Q_ldst_immpre
                        when ('00', '1', '11') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_Q_ldst_immpre
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_immpre_STRH_32_ldst_immpre // STRH_32_ldst_immpre
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_immpre_LDRH_32_ldst_immpre // LDRH_32_ldst_immpre
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_immpre_LDRSH_32_ldst_immpre // LDRSH_64_ldst_immpre
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_immpre_LDRSH_32_ldst_immpre // LDRSH_32_ldst_immpre
                        when ('01', '1', '00') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_H_ldst_immpre
                        when ('01', '1', '01') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_H_ldst_immpre
                        when ('01', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_immpre_STR_32_ldst_immpre // STR_32_ldst_immpre
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_immpre_LDR_32_ldst_immpre // LDR_32_ldst_immpre
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_immpre_LDRSW_64_ldst_immpre // LDRSW_64_ldst_immpre
                        when ('10', '0', '11') => __UNALLOCATED
                        when ('10', '1', '00') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_S_ldst_immpre
                        when ('10', '1', '01') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_S_ldst_immpre
                        when ('10', '1', '1x') => __UNALLOCATED
                        when ('11', _, '1x') => __UNALLOCATED
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_immpre_STR_32_ldst_immpre // STR_64_ldst_immpre
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_immpre_LDR_32_ldst_immpre // LDR_64_ldst_immpre
                        when ('11', '1', '00') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_D_ldst_immpre
                        when ('11', '1', '01') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_D_ldst_immpre
                when ('xx11', _, _, _, '0xx1xxxxxxxxx00', _) => // memop
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field o3 15 +: 1
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, A, R, Rs, o3, opc) of
                        when (_, '0', _, '0', _, '1', '11x') => __UNALLOCATED
                        when (_, '0', _, '1', _, '1', '1xx') => __UNALLOCATED
                        when (_, '0', '0', '0', _, '1', '100') => __UNALLOCATED
                        when (_, '1', _, _, _, _, _) => __UNALLOCATED
                        when ('0x', '0', _, '0', _, '1', '101') => __UNALLOCATED
                        when ('00', '0', '0', '0', _, '0', '000') => __encoding A64_ldst_memop_LDADDAB_32_memop // LDADDB_32_memop
                        when ('00', '0', '0', '0', _, '0', '001') => __encoding A64_ldst_memop_LDCLRAB_32_memop // LDCLRB_32_memop
                        when ('00', '0', '0', '0', _, '0', '010') => __encoding A64_ldst_memop_LDEORAB_32_memop // LDEORB_32_memop
                        when ('00', '0', '0', '0', _, '0', '011') => __encoding A64_ldst_memop_LDSETAB_32_memop // LDSETB_32_memop
                        when ('00', '0', '0', '0', _, '0', '100') => __encoding A64_ldst_memop_LDSMAXAB_32_memop // LDSMAXB_32_memop
                        when ('00', '0', '0', '0', _, '0', '101') => __encoding A64_ldst_memop_LDSMINAB_32_memop // LDSMINB_32_memop
                        when ('00', '0', '0', '0', _, '0', '110') => __encoding A64_ldst_memop_LDUMAXAB_32_memop // LDUMAXB_32_memop
                        when ('00', '0', '0', '0', _, '0', '111') => __encoding A64_ldst_memop_LDUMINAB_32_memop // LDUMINB_32_memop
                        when ('00', '0', '0', '0', _, '1', '000') => __encoding A64_ldst_memop_SWPAB_32_memop // SWPB_32_memop
                        when ('00', '0', '0', '0', _, '1', '001') => __encoding A64_ldst_memop_RCWCLR_64_memop // RCWCLR_64_memop
                        when ('00', '0', '0', '0', _, '1', '010') => __encoding A64_ldst_memop_RCWSWP_64_memop // RCWSWP_64_memop
                        when ('00', '0', '0', '0', _, '1', '011') => __encoding A64_ldst_memop_RCWSET_64_memop // RCWSET_64_memop
                        when ('00', '0', '0', '1', _, '0', '000') => __encoding A64_ldst_memop_LDADDAB_32_memop // LDADDLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '001') => __encoding A64_ldst_memop_LDCLRAB_32_memop // LDCLRLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '010') => __encoding A64_ldst_memop_LDEORAB_32_memop // LDEORLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '011') => __encoding A64_ldst_memop_LDSETAB_32_memop // LDSETLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '100') => __encoding A64_ldst_memop_LDSMAXAB_32_memop // LDSMAXLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '101') => __encoding A64_ldst_memop_LDSMINAB_32_memop // LDSMINLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '110') => __encoding A64_ldst_memop_LDUMAXAB_32_memop // LDUMAXLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '111') => __encoding A64_ldst_memop_LDUMINAB_32_memop // LDUMINLB_32_memop
                        when ('00', '0', '0', '1', _, '1', '000') => __encoding A64_ldst_memop_SWPAB_32_memop // SWPLB_32_memop
                        when ('00', '0', '0', '1', _, '1', '001') => __encoding A64_ldst_memop_RCWCLR_64_memop // RCWCLRL_64_memop
                        when ('00', '0', '0', '1', _, '1', '010') => __encoding A64_ldst_memop_RCWSWP_64_memop // RCWSWPL_64_memop
                        when ('00', '0', '0', '1', _, '1', '011') => __encoding A64_ldst_memop_RCWSET_64_memop // RCWSETL_64_memop
                        when ('00', '0', '1', '0', _, '0', '000') => __encoding A64_ldst_memop_LDADDAB_32_memop // LDADDAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '001') => __encoding A64_ldst_memop_LDCLRAB_32_memop // LDCLRAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '010') => __encoding A64_ldst_memop_LDEORAB_32_memop // LDEORAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '011') => __encoding A64_ldst_memop_LDSETAB_32_memop // LDSETAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '100') => __encoding A64_ldst_memop_LDSMAXAB_32_memop // LDSMAXAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '101') => __encoding A64_ldst_memop_LDSMINAB_32_memop // LDSMINAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '110') => __encoding A64_ldst_memop_LDUMAXAB_32_memop // LDUMAXAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '111') => __encoding A64_ldst_memop_LDUMINAB_32_memop // LDUMINAB_32_memop
                        when ('00', '0', '1', '0', _, '1', '000') => __encoding A64_ldst_memop_SWPAB_32_memop // SWPAB_32_memop
                        when ('00', '0', '1', '0', _, '1', '001') => __encoding A64_ldst_memop_RCWCLR_64_memop // RCWCLRA_64_memop
                        when ('00', '0', '1', '0', _, '1', '010') => __encoding A64_ldst_memop_RCWSWP_64_memop // RCWSWPA_64_memop
                        when ('00', '0', '1', '0', _, '1', '011') => __encoding A64_ldst_memop_RCWSET_64_memop // RCWSETA_64_memop
                        when ('00', '0', '1', '0', _, '1', '100') => __encoding A64_ldst_memop_LDAPRB_32L_memop // LDAPRB_32L_memop
                        when ('00', '0', '1', '1', _, '0', '000') => __encoding A64_ldst_memop_LDADDAB_32_memop // LDADDALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '001') => __encoding A64_ldst_memop_LDCLRAB_32_memop // LDCLRALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '010') => __encoding A64_ldst_memop_LDEORAB_32_memop // LDEORALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '011') => __encoding A64_ldst_memop_LDSETAB_32_memop // LDSETALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '100') => __encoding A64_ldst_memop_LDSMAXAB_32_memop // LDSMAXALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '101') => __encoding A64_ldst_memop_LDSMINAB_32_memop // LDSMINALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '110') => __encoding A64_ldst_memop_LDUMAXAB_32_memop // LDUMAXALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '111') => __encoding A64_ldst_memop_LDUMINAB_32_memop // LDUMINALB_32_memop
                        when ('00', '0', '1', '1', _, '1', '000') => __encoding A64_ldst_memop_SWPAB_32_memop // SWPALB_32_memop
                        when ('00', '0', '1', '1', _, '1', '001') => __encoding A64_ldst_memop_RCWCLR_64_memop // RCWCLRAL_64_memop
                        when ('00', '0', '1', '1', _, '1', '010') => __encoding A64_ldst_memop_RCWSWP_64_memop // RCWSWPAL_64_memop
                        when ('00', '0', '1', '1', _, '1', '011') => __encoding A64_ldst_memop_RCWSET_64_memop // RCWSETAL_64_memop
                        when ('01', '0', '0', '0', _, '0', '000') => __encoding A64_ldst_memop_LDADDAH_32_memop // LDADDH_32_memop
                        when ('01', '0', '0', '0', _, '0', '001') => __encoding A64_ldst_memop_LDCLRAH_32_memop // LDCLRH_32_memop
                        when ('01', '0', '0', '0', _, '0', '010') => __encoding A64_ldst_memop_LDEORAH_32_memop // LDEORH_32_memop
                        when ('01', '0', '0', '0', _, '0', '011') => __encoding A64_ldst_memop_LDSETAH_32_memop // LDSETH_32_memop
                        when ('01', '0', '0', '0', _, '0', '100') => __encoding A64_ldst_memop_LDSMAXAH_32_memop // LDSMAXH_32_memop
                        when ('01', '0', '0', '0', _, '0', '101') => __encoding A64_ldst_memop_LDSMINAH_32_memop // LDSMINH_32_memop
                        when ('01', '0', '0', '0', _, '0', '110') => __encoding A64_ldst_memop_LDUMAXAH_32_memop // LDUMAXH_32_memop
                        when ('01', '0', '0', '0', _, '0', '111') => __encoding A64_ldst_memop_LDUMINAH_32_memop // LDUMINH_32_memop
                        when ('01', '0', '0', '0', _, '1', '000') => __encoding A64_ldst_memop_SWPAH_32_memop // SWPH_32_memop
                        when ('01', '0', '0', '0', _, '1', '001') => __encoding A64_ldst_memop_RCWSCLR_64_memop // RCWSCLR_64_memop
                        when ('01', '0', '0', '0', _, '1', '010') => __encoding A64_ldst_memop_RCWSSWP_64_memop // RCWSSWP_64_memop
                        when ('01', '0', '0', '0', _, '1', '011') => __encoding A64_ldst_memop_RCWSSET_64_memop // RCWSSET_64_memop
                        when ('01', '0', '0', '1', _, '0', '000') => __encoding A64_ldst_memop_LDADDAH_32_memop // LDADDLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '001') => __encoding A64_ldst_memop_LDCLRAH_32_memop // LDCLRLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '010') => __encoding A64_ldst_memop_LDEORAH_32_memop // LDEORLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '011') => __encoding A64_ldst_memop_LDSETAH_32_memop // LDSETLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '100') => __encoding A64_ldst_memop_LDSMAXAH_32_memop // LDSMAXLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '101') => __encoding A64_ldst_memop_LDSMINAH_32_memop // LDSMINLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '110') => __encoding A64_ldst_memop_LDUMAXAH_32_memop // LDUMAXLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '111') => __encoding A64_ldst_memop_LDUMINAH_32_memop // LDUMINLH_32_memop
                        when ('01', '0', '0', '1', _, '1', '000') => __encoding A64_ldst_memop_SWPAH_32_memop // SWPLH_32_memop
                        when ('01', '0', '0', '1', _, '1', '001') => __encoding A64_ldst_memop_RCWSCLR_64_memop // RCWSCLRL_64_memop
                        when ('01', '0', '0', '1', _, '1', '010') => __encoding A64_ldst_memop_RCWSSWP_64_memop // RCWSSWPL_64_memop
                        when ('01', '0', '0', '1', _, '1', '011') => __encoding A64_ldst_memop_RCWSSET_64_memop // RCWSSETL_64_memop
                        when ('01', '0', '1', '0', _, '0', '000') => __encoding A64_ldst_memop_LDADDAH_32_memop // LDADDAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '001') => __encoding A64_ldst_memop_LDCLRAH_32_memop // LDCLRAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '010') => __encoding A64_ldst_memop_LDEORAH_32_memop // LDEORAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '011') => __encoding A64_ldst_memop_LDSETAH_32_memop // LDSETAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '100') => __encoding A64_ldst_memop_LDSMAXAH_32_memop // LDSMAXAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '101') => __encoding A64_ldst_memop_LDSMINAH_32_memop // LDSMINAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '110') => __encoding A64_ldst_memop_LDUMAXAH_32_memop // LDUMAXAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '111') => __encoding A64_ldst_memop_LDUMINAH_32_memop // LDUMINAH_32_memop
                        when ('01', '0', '1', '0', _, '1', '000') => __encoding A64_ldst_memop_SWPAH_32_memop // SWPAH_32_memop
                        when ('01', '0', '1', '0', _, '1', '001') => __encoding A64_ldst_memop_RCWSCLR_64_memop // RCWSCLRA_64_memop
                        when ('01', '0', '1', '0', _, '1', '010') => __encoding A64_ldst_memop_RCWSSWP_64_memop // RCWSSWPA_64_memop
                        when ('01', '0', '1', '0', _, '1', '011') => __encoding A64_ldst_memop_RCWSSET_64_memop // RCWSSETA_64_memop
                        when ('01', '0', '1', '0', _, '1', '100') => __encoding A64_ldst_memop_LDAPRH_32L_memop // LDAPRH_32L_memop
                        when ('01', '0', '1', '1', _, '0', '000') => __encoding A64_ldst_memop_LDADDAH_32_memop // LDADDALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '001') => __encoding A64_ldst_memop_LDCLRAH_32_memop // LDCLRALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '010') => __encoding A64_ldst_memop_LDEORAH_32_memop // LDEORALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '011') => __encoding A64_ldst_memop_LDSETAH_32_memop // LDSETALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '100') => __encoding A64_ldst_memop_LDSMAXAH_32_memop // LDSMAXALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '101') => __encoding A64_ldst_memop_LDSMINAH_32_memop // LDSMINALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '110') => __encoding A64_ldst_memop_LDUMAXAH_32_memop // LDUMAXALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '111') => __encoding A64_ldst_memop_LDUMINAH_32_memop // LDUMINALH_32_memop
                        when ('01', '0', '1', '1', _, '1', '000') => __encoding A64_ldst_memop_SWPAH_32_memop // SWPALH_32_memop
                        when ('01', '0', '1', '1', _, '1', '001') => __encoding A64_ldst_memop_RCWSCLR_64_memop // RCWSCLRAL_64_memop
                        when ('01', '0', '1', '1', _, '1', '010') => __encoding A64_ldst_memop_RCWSSWP_64_memop // RCWSSWPAL_64_memop
                        when ('01', '0', '1', '1', _, '1', '011') => __encoding A64_ldst_memop_RCWSSET_64_memop // RCWSSETAL_64_memop
                        when ('10', '0', _, _, _, '1', '001') => __UNALLOCATED
                        when ('10', '0', _, _, _, '1', '01x') => __UNALLOCATED
                        when ('10', '0', _, '0', _, '1', '101') => __UNALLOCATED
                        when ('10', '0', '0', '0', _, '0', '000') => __encoding A64_ldst_memop_LDADD_32_memop // LDADD_32_memop
                        when ('10', '0', '0', '0', _, '0', '001') => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLR_32_memop
                        when ('10', '0', '0', '0', _, '0', '010') => __encoding A64_ldst_memop_LDEOR_32_memop // LDEOR_32_memop
                        when ('10', '0', '0', '0', _, '0', '011') => __encoding A64_ldst_memop_LDSET_32_memop // LDSET_32_memop
                        when ('10', '0', '0', '0', _, '0', '100') => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAX_32_memop
                        when ('10', '0', '0', '0', _, '0', '101') => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMIN_32_memop
                        when ('10', '0', '0', '0', _, '0', '110') => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAX_32_memop
                        when ('10', '0', '0', '0', _, '0', '111') => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMIN_32_memop
                        when ('10', '0', '0', '0', _, '1', '000') => __encoding A64_ldst_memop_SWP_32_memop // SWP_32_memop
                        when ('10', '0', '0', '1', _, '0', '000') => __encoding A64_ldst_memop_LDADD_32_memop // LDADDL_32_memop
                        when ('10', '0', '0', '1', _, '0', '001') => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRL_32_memop
                        when ('10', '0', '0', '1', _, '0', '010') => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORL_32_memop
                        when ('10', '0', '0', '1', _, '0', '011') => __encoding A64_ldst_memop_LDSET_32_memop // LDSETL_32_memop
                        when ('10', '0', '0', '1', _, '0', '100') => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXL_32_memop
                        when ('10', '0', '0', '1', _, '0', '101') => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINL_32_memop
                        when ('10', '0', '0', '1', _, '0', '110') => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXL_32_memop
                        when ('10', '0', '0', '1', _, '0', '111') => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINL_32_memop
                        when ('10', '0', '0', '1', _, '1', '000') => __encoding A64_ldst_memop_SWP_32_memop // SWPL_32_memop
                        when ('10', '0', '1', '0', _, '0', '000') => __encoding A64_ldst_memop_LDADD_32_memop // LDADDA_32_memop
                        when ('10', '0', '1', '0', _, '0', '001') => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRA_32_memop
                        when ('10', '0', '1', '0', _, '0', '010') => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORA_32_memop
                        when ('10', '0', '1', '0', _, '0', '011') => __encoding A64_ldst_memop_LDSET_32_memop // LDSETA_32_memop
                        when ('10', '0', '1', '0', _, '0', '100') => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXA_32_memop
                        when ('10', '0', '1', '0', _, '0', '101') => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINA_32_memop
                        when ('10', '0', '1', '0', _, '0', '110') => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXA_32_memop
                        when ('10', '0', '1', '0', _, '0', '111') => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINA_32_memop
                        when ('10', '0', '1', '0', _, '1', '000') => __encoding A64_ldst_memop_SWP_32_memop // SWPA_32_memop
                        when ('10', '0', '1', '0', _, '1', '100') => __encoding A64_ldst_memop_LDAPR_32L_memop // LDAPR_32L_memop
                        when ('10', '0', '1', '1', _, '0', '000') => __encoding A64_ldst_memop_LDADD_32_memop // LDADDAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '001') => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '010') => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '011') => __encoding A64_ldst_memop_LDSET_32_memop // LDSETAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '100') => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '101') => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '110') => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '111') => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINAL_32_memop
                        when ('10', '0', '1', '1', _, '1', '000') => __encoding A64_ldst_memop_SWP_32_memop // SWPAL_32_memop
                        when ('11', '0', '0', '0', _, '0', '000') => __encoding A64_ldst_memop_LDADD_32_memop // LDADD_64_memop
                        when ('11', '0', '0', '0', _, '0', '001') => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLR_64_memop
                        when ('11', '0', '0', '0', _, '0', '010') => __encoding A64_ldst_memop_LDEOR_32_memop // LDEOR_64_memop
                        when ('11', '0', '0', '0', _, '0', '011') => __encoding A64_ldst_memop_LDSET_32_memop // LDSET_64_memop
                        when ('11', '0', '0', '0', _, '0', '100') => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAX_64_memop
                        when ('11', '0', '0', '0', _, '0', '101') => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMIN_64_memop
                        when ('11', '0', '0', '0', _, '0', '110') => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAX_64_memop
                        when ('11', '0', '0', '0', _, '0', '111') => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMIN_64_memop
                        when ('11', '0', '0', '0', _, '1', '000') => __encoding A64_ldst_memop_SWP_32_memop // SWP_64_memop
                        when ('11', '0', '0', '0', _, '1', '010') => __encoding A64_ldst_memop_ST64BV0_64_memop // ST64BV0_64_memop
                        when ('11', '0', '0', '0', _, '1', '011') => __encoding A64_ldst_memop_ST64BV_64_memop // ST64BV_64_memop
                        when ('11', '0', '0', '0', '0xxxx', '1', 'x01') => __UNALLOCATED
                        when ('11', '0', '0', '0', '10xxx', '1', 'x01') => __UNALLOCATED
                        when ('11', '0', '0', '0', '110xx', '1', 'x01') => __UNALLOCATED
                        when ('11', '0', '0', '0', '1110x', '1', 'x01') => __UNALLOCATED
                        when ('11', '0', '0', '0', '11110', '1', 'x01') => __UNALLOCATED
                        when ('11', '0', '0', '0', '11111', '1', '001') => __encoding A64_ldst_memop_ST64B_64L_memop // ST64B_64L_memop
                        when ('11', '0', '0', '0', '11111', '1', '101') => __encoding A64_ldst_memop_LD64B_64L_memop // LD64B_64L_memop
                        when ('11', '0', '0', '1', _, '0', '000') => __encoding A64_ldst_memop_LDADD_32_memop // LDADDL_64_memop
                        when ('11', '0', '0', '1', _, '0', '001') => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRL_64_memop
                        when ('11', '0', '0', '1', _, '0', '010') => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORL_64_memop
                        when ('11', '0', '0', '1', _, '0', '011') => __encoding A64_ldst_memop_LDSET_32_memop // LDSETL_64_memop
                        when ('11', '0', '0', '1', _, '0', '100') => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXL_64_memop
                        when ('11', '0', '0', '1', _, '0', '101') => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINL_64_memop
                        when ('11', '0', '0', '1', _, '0', '110') => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXL_64_memop
                        when ('11', '0', '0', '1', _, '0', '111') => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINL_64_memop
                        when ('11', '0', '0', '1', _, '1', '000') => __encoding A64_ldst_memop_SWP_32_memop // SWPL_64_memop
                        when ('11', '0', '0', '1', _, '1', '001') => __UNALLOCATED
                        when ('11', '0', '0', '1', _, '1', '01x') => __UNALLOCATED
                        when ('11', '0', '1', _, _, '1', '001') => __UNALLOCATED
                        when ('11', '0', '1', _, _, '1', '01x') => __UNALLOCATED
                        when ('11', '0', '1', '0', _, '0', '000') => __encoding A64_ldst_memop_LDADD_32_memop // LDADDA_64_memop
                        when ('11', '0', '1', '0', _, '0', '001') => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRA_64_memop
                        when ('11', '0', '1', '0', _, '0', '010') => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORA_64_memop
                        when ('11', '0', '1', '0', _, '0', '011') => __encoding A64_ldst_memop_LDSET_32_memop // LDSETA_64_memop
                        when ('11', '0', '1', '0', _, '0', '100') => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXA_64_memop
                        when ('11', '0', '1', '0', _, '0', '101') => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINA_64_memop
                        when ('11', '0', '1', '0', _, '0', '110') => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXA_64_memop
                        when ('11', '0', '1', '0', _, '0', '111') => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINA_64_memop
                        when ('11', '0', '1', '0', _, '1', '000') => __encoding A64_ldst_memop_SWP_32_memop // SWPA_64_memop
                        when ('11', '0', '1', '0', _, '1', '100') => __encoding A64_ldst_memop_LDAPR_32L_memop // LDAPR_64L_memop
                        when ('11', '0', '1', '0', _, '1', '101') => __UNALLOCATED
                        when ('11', '0', '1', '1', _, '0', '000') => __encoding A64_ldst_memop_LDADD_32_memop // LDADDAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '001') => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '010') => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '011') => __encoding A64_ldst_memop_LDSET_32_memop // LDSETAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '100') => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '101') => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '110') => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '111') => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINAL_64_memop
                        when ('11', '0', '1', '1', _, '1', '000') => __encoding A64_ldst_memop_SWP_32_memop // SWPAL_64_memop
                when ('xx11', _, _, _, '0xx1xxxxxxxxx10', _) => // ldst_regoff
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field Rm 16 +: 5
                    __field option 13 +: 3
                    __field S 12 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc, option, Rt) of
                        when ('00', '0', '00', !'011', _) => __encoding A64_ldst_ldst_regoff_STRB_32B_ldst_regoff // STRB_32B_ldst_regoff
                        when ('00', '0', '00', '011', _) => __encoding A64_ldst_ldst_regoff_STRB_32B_ldst_regoff // STRB_32BL_ldst_regoff
                        when ('00', '0', '01', !'011', _) => __encoding A64_ldst_ldst_regoff_LDRB_32B_ldst_regoff // LDRB_32B_ldst_regoff
                        when ('00', '0', '01', '011', _) => __encoding A64_ldst_ldst_regoff_LDRB_32B_ldst_regoff // LDRB_32BL_ldst_regoff
                        when ('00', '0', '10', !'011', _) => __encoding A64_ldst_ldst_regoff_LDRSB_32B_ldst_regoff // LDRSB_64B_ldst_regoff
                        when ('00', '0', '10', '011', _) => __encoding A64_ldst_ldst_regoff_LDRSB_32B_ldst_regoff // LDRSB_64BL_ldst_regoff
                        when ('00', '0', '11', !'011', _) => __encoding A64_ldst_ldst_regoff_LDRSB_32B_ldst_regoff // LDRSB_32B_ldst_regoff
                        when ('00', '0', '11', '011', _) => __encoding A64_ldst_ldst_regoff_LDRSB_32B_ldst_regoff // LDRSB_32BL_ldst_regoff
                        when ('00', '1', '00', !'011', _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_B_ldst_regoff
                        when ('00', '1', '00', '011', _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_BL_ldst_regoff
                        when ('00', '1', '01', !'011', _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_B_ldst_regoff
                        when ('00', '1', '01', '011', _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_BL_ldst_regoff
                        when ('00', '1', '10', _, _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_Q_ldst_regoff
                        when ('00', '1', '11', _, _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_Q_ldst_regoff
                        when ('01', '0', '00', _, _) => __encoding A64_ldst_ldst_regoff_STRH_32_ldst_regoff // STRH_32_ldst_regoff
                        when ('01', '0', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDRH_32_ldst_regoff // LDRH_32_ldst_regoff
                        when ('01', '0', '10', _, _) => __encoding A64_ldst_ldst_regoff_LDRSH_32_ldst_regoff // LDRSH_64_ldst_regoff
                        when ('01', '0', '11', _, _) => __encoding A64_ldst_ldst_regoff_LDRSH_32_ldst_regoff // LDRSH_32_ldst_regoff
                        when ('01', '1', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_H_ldst_regoff
                        when ('01', '1', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_H_ldst_regoff
                        when ('01', '1', '1x', _, _) => __UNALLOCATED
                        when ('1x', '0', '11', _, _) => __UNALLOCATED
                        when ('1x', '1', '1x', _, _) => __UNALLOCATED
                        when ('10', '0', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_32_ldst_regoff // STR_32_ldst_regoff
                        when ('10', '0', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_32_ldst_regoff // LDR_32_ldst_regoff
                        when ('10', '0', '10', _, _) => __encoding A64_ldst_ldst_regoff_LDRSW_64_ldst_regoff // LDRSW_64_ldst_regoff
                        when ('10', '1', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_S_ldst_regoff
                        when ('10', '1', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_S_ldst_regoff
                        when ('11', '0', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_32_ldst_regoff // STR_64_ldst_regoff
                        when ('11', '0', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_32_ldst_regoff // LDR_64_ldst_regoff
                        when ('11', '0', '10', 'x1x', !'11xxx') => __encoding A64_ldst_ldst_regoff_PRFM_P_ldst_regoff // PRFM_P_ldst_regoff
                        when ('11', '0', '10', 'x1x', '11xxx') => __encoding A64_ldst_ldst_regoff_RPRFM_R_ldst_regoff // RPRFM_R_ldst_regoff
                        when ('11', '0', '10', 'x0x', _) => __UNALLOCATED
                        when ('11', '1', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_D_ldst_regoff
                        when ('11', '1', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_D_ldst_regoff
                when ('xx11', _, _, _, '0xx1xxxxxxxxxx1', _) => // ldst_pac
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field M 23 +: 1
                    __field S 22 +: 1
                    __field imm9 12 +: 9
                    __field W 11 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, M, W) of
                        when ('0x', _, _, _) => __UNALLOCATED
                        when ('10', _, _, _) => __UNALLOCATED
                        when ('11', '0', '0', '0') => __encoding A64_ldst_ldst_pac_LDRAA_64_ldst_pac // LDRAA_64_ldst_pac
                        when ('11', '0', '0', '1') => __encoding A64_ldst_ldst_pac_LDRAA_64_ldst_pac // LDRAA_64W_ldst_pac
                        when ('11', '0', '1', '0') => __encoding A64_ldst_ldst_pac_LDRAA_64_ldst_pac // LDRAB_64_ldst_pac
                        when ('11', '0', '1', '1') => __encoding A64_ldst_ldst_pac_LDRAA_64_ldst_pac // LDRAB_64W_ldst_pac
                        when ('11', '1', _, _) => __UNALLOCATED
                when ('xx11', _, _, _, '1xxxxxxxxxxxxxx', _) => // ldst_pos
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm12 10 +: 12
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_pos_STRB_32_ldst_pos // STRB_32_ldst_pos
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_pos_LDRB_32_ldst_pos // LDRB_32_ldst_pos
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_pos_LDRSB_32_ldst_pos // LDRSB_64_ldst_pos
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_pos_LDRSB_32_ldst_pos // LDRSB_32_ldst_pos
                        when ('00', '1', '00') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_B_ldst_pos
                        when ('00', '1', '01') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_B_ldst_pos
                        when ('00', '1', '10') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_Q_ldst_pos
                        when ('00', '1', '11') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_Q_ldst_pos
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_pos_STRH_32_ldst_pos // STRH_32_ldst_pos
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_pos_LDRH_32_ldst_pos // LDRH_32_ldst_pos
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_pos_LDRSH_32_ldst_pos // LDRSH_64_ldst_pos
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_pos_LDRSH_32_ldst_pos // LDRSH_32_ldst_pos
                        when ('01', '1', '00') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_H_ldst_pos
                        when ('01', '1', '01') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_H_ldst_pos
                        when ('01', '1', '1x') => __UNALLOCATED
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('1x', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_pos_STR_32_ldst_pos // STR_32_ldst_pos
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_pos_LDR_32_ldst_pos // LDR_32_ldst_pos
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_pos_LDRSW_64_ldst_pos // LDRSW_64_ldst_pos
                        when ('10', '1', '00') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_S_ldst_pos
                        when ('10', '1', '01') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_S_ldst_pos
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_pos_STR_32_ldst_pos // STR_64_ldst_pos
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_pos_LDR_32_ldst_pos // LDR_64_ldst_pos
                        when ('11', '0', '10') => __encoding A64_ldst_ldst_pos_PRFM_P_ldst_pos // PRFM_P_ldst_pos
                        when ('11', '1', '00') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_D_ldst_pos
                        when ('11', '1', '01') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_D_ldst_pos

__decode A64
    // A64
    case (31 +: 1, 29 +: 2, 25 +: 4, 0 +: 25) of
        when ('0', _, '0000', _) =>
            // reserved
            case (31 +: 1, 29 +: 2, 25 +: 4, 16 +: 9, 0 +: 16) of
                when (_, '00', _, '000000000', _) => // perm_undef
                    __field imm16 0 +: 16
                    case () of
                        when () => __encoding A64_reserved_perm_undef_UDF_only_perm_undef // UDF_only_perm_undef
                when (_, '00', _, !'000000000', _) => __UNPREDICTABLE
                when (_, !'00', _, _, _) => __UNPREDICTABLE
        when ('1', _, '0000', _) =>
            // sme
            case (31 +: 1, 29 +: 2, 25 +: 4, 10 +: 15, 6 +: 4, 0 +: 6) of
                when (_, '00', _, 'x00xxxxx0x00000', _, '0xx0xx') =>
                    // mortlach2_prod4
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 17 +: 4, 16 +: 1, 15 +: 1, 10 +: 5, 6 +: 4, 5 +: 1, 3 +: 2, 2 +: 1, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, '0', _, _, '0', _, _, _, 'x0', _, _, _) => // mortlach_f32f32_prod4
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (M, N, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f32f32_prod4_fmop4a_za_zz_s1x1 // fmop4a_za_zz_s1x1
                                when ('0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f32f32_prod4_fmop4s_za_zz_s1x1 // fmop4s_za_zz_s1x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f32f32_prod4_fmop4a_za_zz_s2x1 // fmop4a_za_zz_s2x1
                                when ('0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f32f32_prod4_fmop4s_za_zz_s2x1 // fmop4s_za_zz_s2x1
                                when ('1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f32f32_prod4_fmop4a_za_zz_s1x2 // fmop4a_za_zz_s1x2
                                when ('1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f32f32_prod4_fmop4s_za_zz_s1x2 // fmop4s_za_zz_s1x2
                                when ('1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f32f32_prod4_fmop4a_za_zz_s2x2 // fmop4a_za_zz_s2x2
                                when ('1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f32f32_prod4_fmop4s_za_zz_s2x2 // fmop4s_za_zz_s2x2
                        when (_, '0', _, '0', _, _, '0', _, _, _, 'x1', _, '0', _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, _, '0', _, _, _, '00', _, _, _) => // mortlach_f8f32_prod4
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field ZAda 0 +: 2
                            case (M, N) of
                                when ('0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f8f32_prod4_fmop4a_za32_z8z8_b1x1 // fmop4a_za32_z8z8_b1x1
                                when ('0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f8f32_prod4_fmop4a_za32_z8z8_b2x1 // fmop4a_za32_z8z8_b2x1
                                when ('1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f8f32_prod4_fmop4a_za32_z8z8_b1x2 // fmop4a_za32_z8z8_b1x2
                                when ('1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f8f32_prod4_fmop4a_za32_z8z8_b2x2 // fmop4a_za32_z8z8_b2x2
                        when (_, '0', _, '1', _, _, '0', _, _, _, '01', _, '0', _) => // mortlach_f8f16_prod4
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field ZA 0 +: 1
                            case (M, N) of
                                when ('0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f8f16_prod4_fmop4a_za16_z8z8_b1x1 // fmop4a_za16_z8z8_b1x1
                                when ('0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f8f16_prod4_fmop4a_za16_z8z8_b2x1 // fmop4a_za16_z8z8_b2x1
                                when ('1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f8f16_prod4_fmop4a_za16_z8z8_b1x2 // fmop4a_za16_z8z8_b1x2
                                when ('1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f8f16_prod4_fmop4a_za16_z8z8_b2x2 // fmop4a_za16_z8z8_b2x2
                        when (_, '0', _, '1', _, _, '0', _, _, _, '10', _, '1', _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, _, '0', _, _, _, '1x', _, '0', _) => __UNPREDICTABLE
                        when (_, '1', _, '0', _, _, '0', _, _, _, 'x0', _, _, _) => // mortlach_b16f32_prod4
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (M, N, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_b16f32_prod4_bfmop4a_za32_zz_h1x1 // bfmop4a_za32_zz_h1x1
                                when ('0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_b16f32_prod4_bfmop4s_za32_zz_h1x1 // bfmop4s_za32_zz_h1x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_b16f32_prod4_bfmop4a_za32_zz_h2x1 // bfmop4a_za32_zz_h2x1
                                when ('0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_b16f32_prod4_bfmop4s_za32_zz_h2x1 // bfmop4s_za32_zz_h2x1
                                when ('1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_b16f32_prod4_bfmop4a_za32_zz_h1x2 // bfmop4a_za32_zz_h1x2
                                when ('1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_b16f32_prod4_bfmop4s_za32_zz_h1x2 // bfmop4s_za32_zz_h1x2
                                when ('1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_b16f32_prod4_bfmop4a_za32_zz_h2x2 // bfmop4a_za32_zz_h2x2
                                when ('1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_b16f32_prod4_bfmop4s_za32_zz_h2x2 // bfmop4s_za32_zz_h2x2
                        when (_, '1', _, '0', _, _, '0', _, _, _, 'x1', _, '0', _) => // mortlach_f16f16_prod4
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZA 0 +: 1
                            case (M, N, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f16_prod4_fmop4a_za_zz_h1x1 // fmop4a_za_zz_h1x1
                                when ('0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f16_prod4_fmop4s_za_zz_h1x1 // fmop4s_za_zz_h1x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f16_prod4_fmop4a_za_zz_h2x1 // fmop4a_za_zz_h2x1
                                when ('0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f16_prod4_fmop4s_za_zz_h2x1 // fmop4s_za_zz_h2x1
                                when ('1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f16_prod4_fmop4a_za_zz_h1x2 // fmop4a_za_zz_h1x2
                                when ('1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f16_prod4_fmop4s_za_zz_h1x2 // fmop4s_za_zz_h1x2
                                when ('1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f16_prod4_fmop4a_za_zz_h2x2 // fmop4a_za_zz_h2x2
                                when ('1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f16_prod4_fmop4s_za_zz_h2x2 // fmop4s_za_zz_h2x2
                        when (_, '1', _, '1', _, _, '0', _, _, _, 'x0', _, _, _) => // mortlach_f16f32_prod4
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (M, N, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f32_prod4_fmop4a_za32_zz_h1x1 // fmop4a_za32_zz_h1x1
                                when ('0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f32_prod4_fmop4s_za32_zz_h1x1 // fmop4s_za32_zz_h1x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f32_prod4_fmop4a_za32_zz_h2x1 // fmop4a_za32_zz_h2x1
                                when ('0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f32_prod4_fmop4s_za32_zz_h2x1 // fmop4s_za32_zz_h2x1
                                when ('1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f32_prod4_fmop4a_za32_zz_h1x2 // fmop4a_za32_zz_h1x2
                                when ('1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f32_prod4_fmop4s_za32_zz_h1x2 // fmop4s_za32_zz_h1x2
                                when ('1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f32_prod4_fmop4a_za32_zz_h2x2 // fmop4a_za32_zz_h2x2
                                when ('1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_f16f32_prod4_fmop4s_za32_zz_h2x2 // fmop4s_za32_zz_h2x2
                        when (_, '1', _, '1', _, _, '0', _, _, _, 'x1', _, '0', _) => // mortlach_b16b16_prod4
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZA 0 +: 1
                            case (M, N, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_b16b16_prod4_bfmop4a_za_zz_h1x1 // bfmop4a_za_zz_h1x1
                                when ('0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_b16b16_prod4_bfmop4s_za_zz_h1x1 // bfmop4s_za_zz_h1x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_b16b16_prod4_bfmop4a_za_zz_h2x1 // bfmop4a_za_zz_h2x1
                                when ('0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_b16b16_prod4_bfmop4s_za_zz_h2x1 // bfmop4s_za_zz_h2x1
                                when ('1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_b16b16_prod4_bfmop4a_za_zz_h1x2 // bfmop4a_za_zz_h1x2
                                when ('1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_b16b16_prod4_bfmop4s_za_zz_h1x2 // bfmop4s_za_zz_h1x2
                                when ('1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_b16b16_prod4_bfmop4a_za_zz_h2x2 // bfmop4a_za_zz_h2x2
                                when ('1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_b16b16_prod4_bfmop4s_za_zz_h2x2 // bfmop4s_za_zz_h2x2
                        when (_, _, _, '0', _, _, '1', _, _, _, 'x1', _, _, _) => // mortlach_i16i32_prod4
                            __field u0 24 +: 1
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (u0, M, N, S) of
                                when ('0', '0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_smop4a_za32_zz_h1x1 // smop4a_za32_zz_h1x1
                                when ('0', '0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_smop4s_za32_zz_h1x1 // smop4s_za32_zz_h1x1
                                when ('0', '0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_smop4a_za32_zz_h2x1 // smop4a_za32_zz_h2x1
                                when ('0', '0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_smop4s_za32_zz_h2x1 // smop4s_za32_zz_h2x1
                                when ('0', '1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_smop4a_za32_zz_h1x2 // smop4a_za32_zz_h1x2
                                when ('0', '1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_smop4s_za32_zz_h1x2 // smop4s_za32_zz_h1x2
                                when ('0', '1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_smop4a_za32_zz_h2x2 // smop4a_za32_zz_h2x2
                                when ('0', '1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_smop4s_za32_zz_h2x2 // smop4s_za32_zz_h2x2
                                when ('1', '0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_umop4a_za32_zz_h1x1 // umop4a_za32_zz_h1x1
                                when ('1', '0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_umop4s_za32_zz_h1x1 // umop4s_za32_zz_h1x1
                                when ('1', '0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_umop4a_za32_zz_h2x1 // umop4a_za32_zz_h2x1
                                when ('1', '0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_umop4s_za32_zz_h2x1 // umop4s_za32_zz_h2x1
                                when ('1', '1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_umop4a_za32_zz_h1x2 // umop4a_za32_zz_h1x2
                                when ('1', '1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_umop4s_za32_zz_h1x2 // umop4s_za32_zz_h1x2
                                when ('1', '1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_umop4a_za32_zz_h2x2 // umop4a_za32_zz_h2x2
                                when ('1', '1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i16i32_prod4_umop4s_za32_zz_h2x2 // umop4s_za32_zz_h2x2
                        when (_, _, _, '1', _, _, '1', _, _, _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '0', _, _, _, 'x1', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '1', _, _, _, 'x0', _, _, _) => // mortlach_i8i32_prod4
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (u0, u1, M, N, S) of
                                when ('0', '0', '0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_smop4a_za_zz_b1x1 // smop4a_za_zz_b1x1
                                when ('0', '0', '0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_smop4s_za_zz_b1x1 // smop4s_za_zz_b1x1
                                when ('0', '0', '0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_smop4a_za_zz_b2x1 // smop4a_za_zz_b2x1
                                when ('0', '0', '0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_smop4s_za_zz_b2x1 // smop4s_za_zz_b2x1
                                when ('0', '0', '1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_smop4a_za_zz_b1x2 // smop4a_za_zz_b1x2
                                when ('0', '0', '1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_smop4s_za_zz_b1x2 // smop4s_za_zz_b1x2
                                when ('0', '0', '1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_smop4a_za_zz_b2x2 // smop4a_za_zz_b2x2
                                when ('0', '0', '1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_smop4s_za_zz_b2x2 // smop4s_za_zz_b2x2
                                when ('0', '1', '0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_sumop4a_za_zz_b1x1 // sumop4a_za_zz_b1x1
                                when ('0', '1', '0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_sumop4s_za_zz_b1x1 // sumop4s_za_zz_b1x1
                                when ('0', '1', '0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_sumop4a_za_zz_b2x1 // sumop4a_za_zz_b2x1
                                when ('0', '1', '0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_sumop4s_za_zz_b2x1 // sumop4s_za_zz_b2x1
                                when ('0', '1', '1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_sumop4a_za_zz_b1x2 // sumop4a_za_zz_b1x2
                                when ('0', '1', '1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_sumop4s_za_zz_b1x2 // sumop4s_za_zz_b1x2
                                when ('0', '1', '1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_sumop4a_za_zz_b2x2 // sumop4a_za_zz_b2x2
                                when ('0', '1', '1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_sumop4s_za_zz_b2x2 // sumop4s_za_zz_b2x2
                                when ('1', '0', '0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_usmop4a_za_zz_b1x1 // usmop4a_za_zz_b1x1
                                when ('1', '0', '0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_usmop4s_za_zz_b1x1 // usmop4s_za_zz_b1x1
                                when ('1', '0', '0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_usmop4a_za_zz_b2x1 // usmop4a_za_zz_b2x1
                                when ('1', '0', '0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_usmop4s_za_zz_b2x1 // usmop4s_za_zz_b2x1
                                when ('1', '0', '1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_usmop4a_za_zz_b1x2 // usmop4a_za_zz_b1x2
                                when ('1', '0', '1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_usmop4s_za_zz_b1x2 // usmop4s_za_zz_b1x2
                                when ('1', '0', '1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_usmop4a_za_zz_b2x2 // usmop4a_za_zz_b2x2
                                when ('1', '0', '1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_usmop4s_za_zz_b2x2 // usmop4s_za_zz_b2x2
                                when ('1', '1', '0', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_umop4a_za_zz_b1x1 // umop4a_za_zz_b1x1
                                when ('1', '1', '0', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_umop4s_za_zz_b1x1 // umop4s_za_zz_b1x1
                                when ('1', '1', '0', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_umop4a_za_zz_b2x1 // umop4a_za_zz_b2x1
                                when ('1', '1', '0', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_umop4s_za_zz_b2x1 // umop4s_za_zz_b2x1
                                when ('1', '1', '1', '0', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_umop4a_za_zz_b1x2 // umop4a_za_zz_b1x2
                                when ('1', '1', '1', '0', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_umop4s_za_zz_b1x2 // umop4s_za_zz_b1x2
                                when ('1', '1', '1', '1', '0') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_umop4a_za_zz_b2x2 // umop4a_za_zz_b2x2
                                when ('1', '1', '1', '1', '1') => __encoding A64_sme_mortlach2_prod4_mortlach_i8i32_prod4_umop4s_za_zz_b2x2 // umop4s_za_zz_b2x2
                when (_, '00', _, 'x00xxxxx0x00000', _, '1xx0xx') => __UNPREDICTABLE
                when (_, '00', _, 'x00xxxxx0x00001', _, 'xxx0xx') => __UNPREDICTABLE
                when (_, '00', _, 'x00xxxxx0x0001x', _, 'xxx0xx') => __UNPREDICTABLE
                when (_, '00', _, 'x00xxxxx0x001xx', _, 'xxx0xx') => __UNPREDICTABLE
                when (_, '00', _, 'x00xxxxx0x01xxx', _, 'xxx0xx') => __UNPREDICTABLE
                when (_, '00', _, 'x00xxxxx1x0xxxx', _, 'xxx0xx') => __UNPREDICTABLE
                when (_, '00', _, 'x01xxxxxxx0xxxx', _, 'xxx0xx') =>
                    // mortlach2_ss_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 14 +: 1, 13 +: 1, 4 +: 9, 3 +: 1, 2 +: 1, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, '0', _, '0', _, '0', _, '0', _, _, _) => // mortlach_f32f32_1in2ss_prod
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZAda 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach2_ss_prod_mortlach_f32f32_1in2ss_prod_ftmopa_za_zzzi_s2x1 // ftmopa_za_zzzi_s2x1
                        when (_, '0', _, '0', _, '0', _, '0', _, '1', _, '0', _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, '0', _, '0', _, '0', _, _, _) => // mortlach_f8f32_2in4ss_prod
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZAda 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach2_ss_prod_mortlach_f8f32_2in4ss_prod_ftmopa_za32_z8z8zi_b2x1 // ftmopa_za32_z8z8zi_b2x1
                        when (_, '0', _, '1', _, '0', _, '0', _, '1', _, '0', _) => // mortlach_f8f16_2in4ss_prod
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZA 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach2_ss_prod_mortlach_f8f16_2in4ss_prod_ftmopa_za16_z8z8zi_b2x1 // ftmopa_za16_z8z8zi_b2x1
                        when (_, '1', _, '0', _, '0', _, '0', _, '0', _, _, _) => // mortlach_b16f32_2in4ss_prod
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZAda 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach2_ss_prod_mortlach_b16f32_2in4ss_prod_bftmopa_za32_zzzi_h2x1 // bftmopa_za32_zzzi_h2x1
                        when (_, '1', _, '0', _, '0', _, '0', _, '1', _, '0', _) => // mortlach_f16f16_1in2ss_prod
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZA 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach2_ss_prod_mortlach_f16f16_1in2ss_prod_ftmopa_za_zzzi_h2x1 // ftmopa_za_zzzi_h2x1
                        when (_, '1', _, '1', _, '0', _, '0', _, '0', _, _, _) => // mortlach_f16f32_2in4ss_prod
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZAda 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach2_ss_prod_mortlach_f16f32_2in4ss_prod_ftmopa_za32_zzzi_h2x1 // ftmopa_za32_zzzi_h2x1
                        when (_, '1', _, '1', _, '0', _, '0', _, '1', _, '0', _) => // mortlach_b16b16_1in2ss_prod
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZA 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach2_ss_prod_mortlach_b16b16_1in2ss_prod_bftmopa_za_zzzi_h2x1 // bftmopa_za_zzzi_h2x1
                        when (_, _, _, '0', _, '1', _, '0', _, '1', _, _, _) => // mortlach_i16i32_2in4ss_prod
                            __field u0 24 +: 1
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZAda 0 +: 2
                            case (u0) of
                                when ('0') => __encoding A64_sme_mortlach2_ss_prod_mortlach_i16i32_2in4ss_prod_stmopa_za32_zzzi_h2x1 // stmopa_za32_zzzi_h2x1
                                when ('1') => __encoding A64_sme_mortlach2_ss_prod_mortlach_i16i32_2in4ss_prod_utmopa_za32_zzzi_h2x1 // utmopa_za32_zzzi_h2x1
                        when (_, _, _, '1', _, '1', _, '0', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', _, '0', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', _, '0', _, '0', _, _, _) => // mortlach_i8i32_2in4ss_prod
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field Zm 16 +: 5
                            __field K 12 +: 1
                            __field Zk 10 +: 2
                            __field Zn 6 +: 4
                            __field i2 4 +: 2
                            __field ZAda 0 +: 2
                            case (u0, u1) of
                                when ('0', '0') => __encoding A64_sme_mortlach2_ss_prod_mortlach_i8i32_2in4ss_prod_stmopa_za_zzzi_b2x1 // stmopa_za_zzzi_b2x1
                                when ('0', '1') => __encoding A64_sme_mortlach2_ss_prod_mortlach_i8i32_2in4ss_prod_sutmopa_za_zzzi_b2x1 // sutmopa_za_zzzi_b2x1
                                when ('1', '0') => __encoding A64_sme_mortlach2_ss_prod_mortlach_i8i32_2in4ss_prod_ustmopa_za_zzzi_b2x1 // ustmopa_za_zzzi_b2x1
                                when ('1', '1') => __encoding A64_sme_mortlach2_ss_prod_mortlach_i8i32_2in4ss_prod_utmopa_za_zzzi_b2x1 // utmopa_za_zzzi_b2x1
                        when (_, _, _, _, _, _, _, '1', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '00', _, 'x0xxxxxxxx0xxxx', _, 'xxx1xx') => __UNPREDICTABLE
                when (_, '00', _, 'x0xxxxxxxx1xxxx', _, _) => __UNPREDICTABLE
                when (_, '00', _, 'x10xxxxxxxxxxxx', _, 'xx00xx') =>
                    // mortlach_32bit_fp_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 5 +: 16, 4 +: 1, 2 +: 2, 0 +: 2) of
                        when (_, '0', _, '0', _, _, _, _) => // mortlach_f32f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_32bit_fp_prod_mortlach_f32f32_prod_fmopa_za_pp_zz_32 // fmopa_za_pp_zz_32
                                when ('1') => __encoding A64_sme_mortlach_32bit_fp_prod_mortlach_f32f32_prod_fmops_za_pp_zz_32 // fmops_za_pp_zz_32
                        when (_, '0', _, '1', _, '0', _, _) => // mortlach_f8f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field ZAda 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach_32bit_fp_prod_mortlach_f8f32_prod_fmopa_za32_pp_z8z8_8 // fmopa_za32_pp_z8z8_8
                        when (_, '0', _, '1', _, '1', _, _) => __UNPREDICTABLE
                        when (_, '1', _, '0', _, _, _, _) => // mortlach_b16f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_32bit_fp_prod_mortlach_b16f32_prod_bfmopa_za32_pp_zz_ // bfmopa_za32_pp_zz_
                                when ('1') => __encoding A64_sme_mortlach_32bit_fp_prod_mortlach_b16f32_prod_bfmops_za32_pp_zz_ // bfmops_za32_pp_zz_
                        when (_, '1', _, '1', _, _, _, _) => // mortlach_f16f32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_32bit_fp_prod_mortlach_f16f32_prod_fmopa_za32_pp_zz_16 // fmopa_za32_pp_zz_16
                                when ('1') => __encoding A64_sme_mortlach_32bit_fp_prod_mortlach_f16f32_prod_fmops_za32_pp_zz_16 // fmops_za32_pp_zz_16
                when (_, '00', _, 'x10xxxxxxxxxxxx', _, 'xx10xx') =>
                    // mortlach2_misc_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 5 +: 16, 4 +: 1, 2 +: 2, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, '0', _, _, _, _, _) => // mortlach_bini32_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach2_misc_prod_mortlach_bini32_prod_bmopa_za_pp_zz_32 // bmopa_za_pp_zz_32
                                when ('1') => __encoding A64_sme_mortlach2_misc_prod_mortlach_bini32_prod_bmops_za_pp_zz_32 // bmops_za_pp_zz_32
                        when (_, '0', _, '1', _, '0', _, '0', _) => // mortlach_f8f16_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field ZAda 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach2_misc_prod_mortlach_f8f16_prod_fmopa_za16_pp_z8z8_8 // fmopa_za16_pp_z8z8_8
                        when (_, '0', _, '1', _, '1', _, '0', _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, '0', _, _, _, '0', _) => // mortlach_f16f16_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 1
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach2_misc_prod_mortlach_f16f16_prod_fmopa_za_pp_zz_16 // fmopa_za_pp_zz_16
                                when ('1') => __encoding A64_sme_mortlach2_misc_prod_mortlach_f16f16_prod_fmops_za_pp_zz_16 // fmops_za_pp_zz_16
                        when (_, '1', _, '1', _, _, _, '0', _) => // mortlach_b16b16_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 1
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach2_misc_prod_mortlach_b16b16_prod_bfmopa_za_pp_zz_16 // bfmopa_za_pp_zz_16
                                when ('1') => __encoding A64_sme_mortlach2_misc_prod_mortlach_b16b16_prod_bfmops_za_pp_zz_16 // bfmops_za_pp_zz_16
                        when (_, '1', _, _, _, _, _, '1', _) => __UNPREDICTABLE
                when (_, '01', _, '00xxxxxxxxxxxxx', _, _) =>
                    // mortlach_multi_mem_ctg
                    case (23 +: 9, 20 +: 3, 16 +: 4, 15 +: 1, 2 +: 13, 1 +: 1, 0 +: 1) of
                        when (_, '00x', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_ss_ctg_ld1b_mz_p_br_2 // ld1b_mz_p_br_2
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_ss_ctg_ldnt1b_mz_p_br_2 // ldnt1b_mz_p_br_2
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_ss_ctg_ld1h_mz_p_br_2 // ld1h_mz_p_br_2
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_ss_ctg_ldnt1h_mz_p_br_2 // ldnt1h_mz_p_br_2
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_ss_ctg_ld1w_mz_p_br_2 // ld1w_mz_p_br_2
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_ss_ctg_ldnt1w_mz_p_br_2 // ldnt1w_mz_p_br_2
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_ss_ctg_ld1d_mz_p_br_2 // ld1d_mz_p_br_2
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_ss_ctg_ldnt1d_mz_p_br_2 // ldnt1d_mz_p_br_2
                        when (_, '00x', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_ss_ctg_ld1b_mz_p_br_4 // ld1b_mz_p_br_4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_ss_ctg_ldnt1b_mz_p_br_4 // ldnt1b_mz_p_br_4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_ss_ctg_ld1h_mz_p_br_4 // ld1h_mz_p_br_4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_ss_ctg_ldnt1h_mz_p_br_4 // ldnt1h_mz_p_br_4
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_ss_ctg_ld1w_mz_p_br_4 // ld1w_mz_p_br_4
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_ss_ctg_ldnt1w_mz_p_br_4 // ldnt1w_mz_p_br_4
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_ss_ctg_ld1d_mz_p_br_4 // ld1d_mz_p_br_4
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_ss_ctg_ldnt1d_mz_p_br_4 // ldnt1d_mz_p_br_4
                        when (_, '01x', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_ss_ctg_st1b_mz_p_br_2 // st1b_mz_p_br_2
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_ss_ctg_stnt1b_mz_p_br_2 // stnt1b_mz_p_br_2
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_ss_ctg_st1h_mz_p_br_2 // st1h_mz_p_br_2
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_ss_ctg_stnt1h_mz_p_br_2 // stnt1h_mz_p_br_2
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_ss_ctg_st1w_mz_p_br_2 // st1w_mz_p_br_2
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_ss_ctg_stnt1w_mz_p_br_2 // stnt1w_mz_p_br_2
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_ss_ctg_st1d_mz_p_br_2 // st1d_mz_p_br_2
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_ss_ctg_stnt1d_mz_p_br_2 // stnt1d_mz_p_br_2
                        when (_, '01x', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_ss_ctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_ss_ctg_st1b_mz_p_br_4 // st1b_mz_p_br_4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_ss_ctg_stnt1b_mz_p_br_4 // stnt1b_mz_p_br_4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_ss_ctg_st1h_mz_p_br_4 // st1h_mz_p_br_4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_ss_ctg_stnt1h_mz_p_br_4 // stnt1h_mz_p_br_4
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_ss_ctg_st1w_mz_p_br_4 // st1w_mz_p_br_4
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_ss_ctg_stnt1w_mz_p_br_4 // stnt1w_mz_p_br_4
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_ss_ctg_st1d_mz_p_br_4 // st1d_mz_p_br_4
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_ss_ctg_stnt1d_mz_p_br_4 // stnt1d_mz_p_br_4
                        when (_, '0x1', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '100', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_si_ctg_ld1b_mz_p_bi_2 // ld1b_mz_p_bi_2
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_si_ctg_ldnt1b_mz_p_bi_2 // ldnt1b_mz_p_bi_2
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_si_ctg_ld1h_mz_p_bi_2 // ld1h_mz_p_bi_2
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_si_ctg_ldnt1h_mz_p_bi_2 // ldnt1h_mz_p_bi_2
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_si_ctg_ld1w_mz_p_bi_2 // ld1w_mz_p_bi_2
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_si_ctg_ldnt1w_mz_p_bi_2 // ldnt1w_mz_p_bi_2
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_si_ctg_ld1d_mz_p_bi_2 // ld1d_mz_p_bi_2
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cld_cldnt_si_ctg_ldnt1d_mz_p_bi_2 // ldnt1d_mz_p_bi_2
                        when (_, '100', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_si_ctg_ld1b_mz_p_bi_4 // ld1b_mz_p_bi_4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_si_ctg_ldnt1b_mz_p_bi_4 // ldnt1b_mz_p_bi_4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_si_ctg_ld1h_mz_p_bi_4 // ld1h_mz_p_bi_4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_si_ctg_ldnt1h_mz_p_bi_4 // ldnt1h_mz_p_bi_4
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_si_ctg_ld1w_mz_p_bi_4 // ld1w_mz_p_bi_4
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_si_ctg_ldnt1w_mz_p_bi_4 // ldnt1w_mz_p_bi_4
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_si_ctg_ld1d_mz_p_bi_4 // ld1d_mz_p_bi_4
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cld_cldnt_si_ctg_ldnt1d_mz_p_bi_4 // ldnt1d_mz_p_bi_4
                        when (_, '110', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 1 +: 4
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_si_ctg_st1b_mz_p_bi_2 // st1b_mz_p_bi_2
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_si_ctg_stnt1b_mz_p_bi_2 // stnt1b_mz_p_bi_2
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_si_ctg_st1h_mz_p_bi_2 // st1h_mz_p_bi_2
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_si_ctg_stnt1h_mz_p_bi_2 // stnt1h_mz_p_bi_2
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_si_ctg_st1w_mz_p_bi_2 // st1w_mz_p_bi_2
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_si_ctg_stnt1w_mz_p_bi_2 // stnt1w_mz_p_bi_2
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_si_ctg_st1d_mz_p_bi_2 // st1d_mz_p_bi_2
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi2_cst_cstnt_si_ctg_stnt1d_mz_p_bi_2 // stnt1d_mz_p_bi_2
                        when (_, '110', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_si_ctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 2 +: 3
                            __field N 0 +: 1
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_si_ctg_st1b_mz_p_bi_4 // st1b_mz_p_bi_4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_si_ctg_stnt1b_mz_p_bi_4 // stnt1b_mz_p_bi_4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_si_ctg_st1h_mz_p_bi_4 // st1h_mz_p_bi_4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_si_ctg_stnt1h_mz_p_bi_4 // stnt1h_mz_p_bi_4
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_si_ctg_st1w_mz_p_bi_4 // st1w_mz_p_bi_4
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_si_ctg_stnt1w_mz_p_bi_4 // stnt1w_mz_p_bi_4
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_si_ctg_st1d_mz_p_bi_4 // st1d_mz_p_bi_4
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_ctg_mortlach_multi4_cst_cstnt_si_ctg_stnt1d_mz_p_bi_4 // stnt1d_mz_p_bi_4
                        when (_, '1x1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, 'xx0', _, '1', _, '1', _) => __UNPREDICTABLE
                when (_, '01', _, '10xxxxxxxxxxxxx', _, _) =>
                    // mortlach_multi_mem_nctg
                    case (23 +: 9, 20 +: 3, 16 +: 4, 15 +: 1, 3 +: 12, 2 +: 1, 0 +: 2) of
                        when (_, '00x', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field T 4 +: 1
                            __field N 3 +: 1
                            __field Zt 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_ss_nctg_ld1b_mzx_p_br_2x8 // ld1b_mzx_p_br_2x8
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_ss_nctg_ldnt1b_mzx_p_br_2x8 // ldnt1b_mzx_p_br_2x8
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_ss_nctg_ld1h_mzx_p_br_2x8 // ld1h_mzx_p_br_2x8
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_ss_nctg_ldnt1h_mzx_p_br_2x8 // ldnt1h_mzx_p_br_2x8
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_ss_nctg_ld1w_mzx_p_br_2x8 // ld1w_mzx_p_br_2x8
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_ss_nctg_ldnt1w_mzx_p_br_2x8 // ldnt1w_mzx_p_br_2x8
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_ss_nctg_ld1d_mzx_p_br_2x8 // ld1d_mzx_p_br_2x8
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_ss_nctg_ldnt1d_mzx_p_br_2x8 // ldnt1d_mzx_p_br_2x8
                        when (_, '00x', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field T 4 +: 1
                            __field N 3 +: 1
                            __field Zt 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_ss_nctg_ld1b_mzx_p_br_4x4 // ld1b_mzx_p_br_4x4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_ss_nctg_ldnt1b_mzx_p_br_4x4 // ldnt1b_mzx_p_br_4x4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_ss_nctg_ld1h_mzx_p_br_4x4 // ld1h_mzx_p_br_4x4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_ss_nctg_ldnt1h_mzx_p_br_4x4 // ldnt1h_mzx_p_br_4x4
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_ss_nctg_ld1w_mzx_p_br_4x4 // ld1w_mzx_p_br_4x4
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_ss_nctg_ldnt1w_mzx_p_br_4x4 // ldnt1w_mzx_p_br_4x4
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_ss_nctg_ld1d_mzx_p_br_4x4 // ld1d_mzx_p_br_4x4
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_ss_nctg_ldnt1d_mzx_p_br_4x4 // ldnt1d_mzx_p_br_4x4
                        when (_, '01x', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field T 4 +: 1
                            __field N 3 +: 1
                            __field Zt 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_ss_nctg_st1b_mzx_p_br_2x8 // st1b_mzx_p_br_2x8
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_ss_nctg_stnt1b_mzx_p_br_2x8 // stnt1b_mzx_p_br_2x8
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_ss_nctg_st1h_mzx_p_br_2x8 // st1h_mzx_p_br_2x8
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_ss_nctg_stnt1h_mzx_p_br_2x8 // stnt1h_mzx_p_br_2x8
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_ss_nctg_st1w_mzx_p_br_2x8 // st1w_mzx_p_br_2x8
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_ss_nctg_stnt1w_mzx_p_br_2x8 // stnt1w_mzx_p_br_2x8
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_ss_nctg_st1d_mzx_p_br_2x8 // st1d_mzx_p_br_2x8
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_ss_nctg_stnt1d_mzx_p_br_2x8 // stnt1d_mzx_p_br_2x8
                        when (_, '01x', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_ss_nctg
                            __field Rm 16 +: 5
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field T 4 +: 1
                            __field N 3 +: 1
                            __field Zt 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_ss_nctg_st1b_mzx_p_br_4x4 // st1b_mzx_p_br_4x4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_ss_nctg_stnt1b_mzx_p_br_4x4 // stnt1b_mzx_p_br_4x4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_ss_nctg_st1h_mzx_p_br_4x4 // st1h_mzx_p_br_4x4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_ss_nctg_stnt1h_mzx_p_br_4x4 // stnt1h_mzx_p_br_4x4
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_ss_nctg_st1w_mzx_p_br_4x4 // st1w_mzx_p_br_4x4
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_ss_nctg_stnt1w_mzx_p_br_4x4 // stnt1w_mzx_p_br_4x4
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_ss_nctg_st1d_mzx_p_br_4x4 // st1d_mzx_p_br_4x4
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_ss_nctg_stnt1d_mzx_p_br_4x4 // stnt1d_mzx_p_br_4x4
                        when (_, '0x1', _, '1', _, '1', _) => __UNPREDICTABLE
                        when (_, '100', _, '0', _, _, _) => // mortlach_multi2_cld_cldnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field T 4 +: 1
                            __field N 3 +: 1
                            __field Zt 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_si_nctg_ld1b_mzx_p_bi_2x8 // ld1b_mzx_p_bi_2x8
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_si_nctg_ldnt1b_mzx_p_bi_2x8 // ldnt1b_mzx_p_bi_2x8
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_si_nctg_ld1h_mzx_p_bi_2x8 // ld1h_mzx_p_bi_2x8
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_si_nctg_ldnt1h_mzx_p_bi_2x8 // ldnt1h_mzx_p_bi_2x8
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_si_nctg_ld1w_mzx_p_bi_2x8 // ld1w_mzx_p_bi_2x8
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_si_nctg_ldnt1w_mzx_p_bi_2x8 // ldnt1w_mzx_p_bi_2x8
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_si_nctg_ld1d_mzx_p_bi_2x8 // ld1d_mzx_p_bi_2x8
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cld_cldnt_si_nctg_ldnt1d_mzx_p_bi_2x8 // ldnt1d_mzx_p_bi_2x8
                        when (_, '100', _, '1', _, '0', _) => // mortlach_multi4_cld_cldnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field T 4 +: 1
                            __field N 3 +: 1
                            __field Zt 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_si_nctg_ld1b_mzx_p_bi_4x4 // ld1b_mzx_p_bi_4x4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_si_nctg_ldnt1b_mzx_p_bi_4x4 // ldnt1b_mzx_p_bi_4x4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_si_nctg_ld1h_mzx_p_bi_4x4 // ld1h_mzx_p_bi_4x4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_si_nctg_ldnt1h_mzx_p_bi_4x4 // ldnt1h_mzx_p_bi_4x4
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_si_nctg_ld1w_mzx_p_bi_4x4 // ld1w_mzx_p_bi_4x4
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_si_nctg_ldnt1w_mzx_p_bi_4x4 // ldnt1w_mzx_p_bi_4x4
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_si_nctg_ld1d_mzx_p_bi_4x4 // ld1d_mzx_p_bi_4x4
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cld_cldnt_si_nctg_ldnt1d_mzx_p_bi_4x4 // ldnt1d_mzx_p_bi_4x4
                        when (_, '110', _, '0', _, _, _) => // mortlach_multi2_cst_cstnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field T 4 +: 1
                            __field N 3 +: 1
                            __field Zt 0 +: 3
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_si_nctg_st1b_mzx_p_bi_2x8 // st1b_mzx_p_bi_2x8
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_si_nctg_stnt1b_mzx_p_bi_2x8 // stnt1b_mzx_p_bi_2x8
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_si_nctg_st1h_mzx_p_bi_2x8 // st1h_mzx_p_bi_2x8
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_si_nctg_stnt1h_mzx_p_bi_2x8 // stnt1h_mzx_p_bi_2x8
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_si_nctg_st1w_mzx_p_bi_2x8 // st1w_mzx_p_bi_2x8
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_si_nctg_stnt1w_mzx_p_bi_2x8 // stnt1w_mzx_p_bi_2x8
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_si_nctg_st1d_mzx_p_bi_2x8 // st1d_mzx_p_bi_2x8
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi2_cst_cstnt_si_nctg_stnt1d_mzx_p_bi_2x8 // stnt1d_mzx_p_bi_2x8
                        when (_, '110', _, '1', _, '0', _) => // mortlach_multi4_cst_cstnt_si_nctg
                            __field imm4 16 +: 4
                            __field msz 13 +: 2
                            __field PNg 10 +: 3
                            __field Rn 5 +: 5
                            __field T 4 +: 1
                            __field N 3 +: 1
                            __field Zt 0 +: 2
                            case (msz, N) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_si_nctg_st1b_mzx_p_bi_4x4 // st1b_mzx_p_bi_4x4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_si_nctg_stnt1b_mzx_p_bi_4x4 // stnt1b_mzx_p_bi_4x4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_si_nctg_st1h_mzx_p_bi_4x4 // st1h_mzx_p_bi_4x4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_si_nctg_stnt1h_mzx_p_bi_4x4 // stnt1h_mzx_p_bi_4x4
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_si_nctg_st1w_mzx_p_bi_4x4 // st1w_mzx_p_bi_4x4
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_si_nctg_stnt1w_mzx_p_bi_4x4 // stnt1w_mzx_p_bi_4x4
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_si_nctg_st1d_mzx_p_bi_4x4 // st1d_mzx_p_bi_4x4
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_mem_nctg_mortlach_multi4_cst_cstnt_si_nctg_stnt1d_mzx_p_bi_4x4 // stnt1d_mzx_p_bi_4x4
                        when (_, '1x1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, 'xx0', _, '1', _, '1', _) => __UNPREDICTABLE
                when (_, '01', _, 'x10xxxxxxxxxxxx', _, 'xxx0xx') =>
                    // mortlach_32bit_int_prod
                    case (25 +: 7, 24 +: 1, 22 +: 2, 21 +: 1, 4 +: 17, 3 +: 1, 2 +: 1, 0 +: 2) of
                        when (_, _, _, '0', _, '1', _, _) => // mortlach_i16i32_prod
                            __field u0 24 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (u0, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i16i32_prod_smopa_za32_pp_zz_16 // smopa_za32_pp_zz_16
                                when ('0', '1') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i16i32_prod_smops_za32_pp_zz_16 // smops_za32_pp_zz_16
                                when ('1', '0') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i16i32_prod_umopa_za32_pp_zz_16 // umopa_za32_pp_zz_16
                                when ('1', '1') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i16i32_prod_umops_za32_pp_zz_16 // umops_za32_pp_zz_16
                        when (_, _, _, '1', _, '1', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', _, _) => // mortlach_i8i32_prod
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 2
                            case (u0, u1, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i8i32_prod_smopa_za_pp_zz_32 // smopa_za_pp_zz_32
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i8i32_prod_smops_za_pp_zz_32 // smops_za_pp_zz_32
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i8i32_prod_sumopa_za_pp_zz_32 // sumopa_za_pp_zz_32
                                when ('0', '1', '1') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i8i32_prod_sumops_za_pp_zz_32 // sumops_za_pp_zz_32
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i8i32_prod_usmopa_za_pp_zz_32 // usmopa_za_pp_zz_32
                                when ('1', '0', '1') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i8i32_prod_usmops_za_pp_zz_32 // usmops_za_pp_zz_32
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i8i32_prod_umopa_za_pp_zz_32 // umopa_za_pp_zz_32
                                when ('1', '1', '1') => __encoding A64_sme_mortlach_32bit_int_prod_mortlach_i8i32_prod_umops_za_pp_zz_32 // umops_za_pp_zz_32
                when (_, '0x', _, 'x10xxxxxxxxxxxx', _, 'xxx1xx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxx0000000', _, '0x1xxx') =>
                    // mortlach2_64bit_prod4
                    case (30 +: 2, 29 +: 1, 25 +: 4, 24 +: 1, 22 +: 2, 21 +: 1, 17 +: 4, 10 +: 7, 6 +: 4, 5 +: 1, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, '0', _, '0', _, '0', _, _, _, _, _, _, _) => // mortlach_f64f64_prod4
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZAda 0 +: 3
                            case (M, N, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_f64f64_prod4_fmop4a_za_zz_d1x1 // fmop4a_za_zz_d1x1
                                when ('0', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_f64f64_prod4_fmop4s_za_zz_d1x1 // fmop4s_za_zz_d1x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_f64f64_prod4_fmop4a_za_zz_d2x1 // fmop4a_za_zz_d2x1
                                when ('0', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_f64f64_prod4_fmop4s_za_zz_d2x1 // fmop4s_za_zz_d2x1
                                when ('1', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_f64f64_prod4_fmop4a_za_zz_d1x2 // fmop4a_za_zz_d1x2
                                when ('1', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_f64f64_prod4_fmop4s_za_zz_d1x2 // fmop4s_za_zz_d1x2
                                when ('1', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_f64f64_prod4_fmop4a_za_zz_d2x2 // fmop4a_za_zz_d2x2
                                when ('1', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_f64f64_prod4_fmop4s_za_zz_d2x2 // fmop4s_za_zz_d2x2
                        when (_, '0', _, '0', _, '1', _, _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, _, _, _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _, _, _, _, _) => // mortlach_i16i64_prod4
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field M 20 +: 1
                            __field Zm 17 +: 3
                            __field N 9 +: 1
                            __field Zn 6 +: 3
                            __field S 4 +: 1
                            __field ZAda 0 +: 3
                            case (u0, u1, M, N, S) of
                                when ('0', '0', '0', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_smop4a_za_zz_h1x1 // smop4a_za_zz_h1x1
                                when ('0', '0', '0', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_smop4s_za_zz_h1x1 // smop4s_za_zz_h1x1
                                when ('0', '0', '0', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_smop4a_za_zz_h2x1 // smop4a_za_zz_h2x1
                                when ('0', '0', '0', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_smop4s_za_zz_h2x1 // smop4s_za_zz_h2x1
                                when ('0', '0', '1', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_smop4a_za_zz_h1x2 // smop4a_za_zz_h1x2
                                when ('0', '0', '1', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_smop4s_za_zz_h1x2 // smop4s_za_zz_h1x2
                                when ('0', '0', '1', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_smop4a_za_zz_h2x2 // smop4a_za_zz_h2x2
                                when ('0', '0', '1', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_smop4s_za_zz_h2x2 // smop4s_za_zz_h2x2
                                when ('0', '1', '0', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_sumop4a_za_zz_h1x1 // sumop4a_za_zz_h1x1
                                when ('0', '1', '0', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_sumop4s_za_zz_h1x1 // sumop4s_za_zz_h1x1
                                when ('0', '1', '0', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_sumop4a_za_zz_h2x1 // sumop4a_za_zz_h2x1
                                when ('0', '1', '0', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_sumop4s_za_zz_h2x1 // sumop4s_za_zz_h2x1
                                when ('0', '1', '1', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_sumop4a_za_zz_h1x2 // sumop4a_za_zz_h1x2
                                when ('0', '1', '1', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_sumop4s_za_zz_h1x2 // sumop4s_za_zz_h1x2
                                when ('0', '1', '1', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_sumop4a_za_zz_h2x2 // sumop4a_za_zz_h2x2
                                when ('0', '1', '1', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_sumop4s_za_zz_h2x2 // sumop4s_za_zz_h2x2
                                when ('1', '0', '0', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_usmop4a_za_zz_h1x1 // usmop4a_za_zz_h1x1
                                when ('1', '0', '0', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_usmop4s_za_zz_h1x1 // usmop4s_za_zz_h1x1
                                when ('1', '0', '0', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_usmop4a_za_zz_h2x1 // usmop4a_za_zz_h2x1
                                when ('1', '0', '0', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_usmop4s_za_zz_h2x1 // usmop4s_za_zz_h2x1
                                when ('1', '0', '1', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_usmop4a_za_zz_h1x2 // usmop4a_za_zz_h1x2
                                when ('1', '0', '1', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_usmop4s_za_zz_h1x2 // usmop4s_za_zz_h1x2
                                when ('1', '0', '1', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_usmop4a_za_zz_h2x2 // usmop4a_za_zz_h2x2
                                when ('1', '0', '1', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_usmop4s_za_zz_h2x2 // usmop4s_za_zz_h2x2
                                when ('1', '1', '0', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_umop4a_za_zz_h1x1 // umop4a_za_zz_h1x1
                                when ('1', '1', '0', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_umop4s_za_zz_h1x1 // umop4s_za_zz_h1x1
                                when ('1', '1', '0', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_umop4a_za_zz_h2x1 // umop4a_za_zz_h2x1
                                when ('1', '1', '0', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_umop4s_za_zz_h2x1 // umop4s_za_zz_h2x1
                                when ('1', '1', '1', '0', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_umop4a_za_zz_h1x2 // umop4a_za_zz_h1x2
                                when ('1', '1', '1', '0', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_umop4s_za_zz_h1x2 // umop4s_za_zz_h1x2
                                when ('1', '1', '1', '1', '0') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_umop4a_za_zz_h2x2 // umop4a_za_zz_h2x2
                                when ('1', '1', '1', '1', '1') => __encoding A64_sme_mortlach2_64bit_prod4_mortlach_i16i64_prod4_umop4s_za_zz_h2x2 // umop4s_za_zz_h2x2
                when (_, '0x', _, 'x11xxxxx0000000', _, '1x1xxx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxx0000001', _, 'xx1xxx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxx000001x', _, 'xx1xxx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxx00001xx', _, 'xx1xxx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxx0001xxx', _, 'xx1xxx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxx001xxxx', _, 'xx1xxx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxx01xxxxx', _, 'xx1xxx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxx1xxxxxx', _, 'xx1xxx') => __UNPREDICTABLE
                when (_, '0x', _, 'x11xxxxxxxxxxxx', _, 'xx0xxx') =>
                    // mortlach_64bit_prod
                    case (30 +: 2, 29 +: 1, 25 +: 4, 24 +: 1, 22 +: 2, 21 +: 1, 4 +: 17, 3 +: 1, 0 +: 3) of
                        when (_, '0', _, '0', _, '0', _, _, _) => // mortlach_f64f64_prod
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_64bit_prod_mortlach_f64f64_prod_fmopa_za_pp_zz_64 // fmopa_za_pp_zz_64
                                when ('1') => __encoding A64_sme_mortlach_64bit_prod_mortlach_f64f64_prod_fmops_za_pp_zz_64 // fmops_za_pp_zz_64
                        when (_, '0', _, '0', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, '1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _) => // mortlach_i16i64_prod
                            __field u0 24 +: 1
                            __field u1 21 +: 1
                            __field Zm 16 +: 5
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field S 4 +: 1
                            __field ZAda 0 +: 3
                            case (u0, u1, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_64bit_prod_mortlach_i16i64_prod_smopa_za_pp_zz_64 // smopa_za_pp_zz_64
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_64bit_prod_mortlach_i16i64_prod_smops_za_pp_zz_64 // smops_za_pp_zz_64
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_64bit_prod_mortlach_i16i64_prod_sumopa_za_pp_zz_64 // sumopa_za_pp_zz_64
                                when ('0', '1', '1') => __encoding A64_sme_mortlach_64bit_prod_mortlach_i16i64_prod_sumops_za_pp_zz_64 // sumops_za_pp_zz_64
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_64bit_prod_mortlach_i16i64_prod_usmopa_za_pp_zz_64 // usmopa_za_pp_zz_64
                                when ('1', '0', '1') => __encoding A64_sme_mortlach_64bit_prod_mortlach_i16i64_prod_usmops_za_pp_zz_64 // usmops_za_pp_zz_64
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_64bit_prod_mortlach_i16i64_prod_umopa_za_pp_zz_64 // umopa_za_pp_zz_64
                                when ('1', '1', '1') => __encoding A64_sme_mortlach_64bit_prod_mortlach_i16i64_prod_umops_za_pp_zz_64 // umops_za_pp_zz_64
                when (_, '10', _, '0000010xxxxxxxx', _, _) =>
                    // mortlach_zero
                    case (18 +: 14, 8 +: 10, 6 +: 2, 0 +: 6) of
                        when (_, '0000000000', _, _) => // mortlach_zero
                            __field imm8 0 +: 8
                            case () of
                                when () => __encoding A64_sme_mortlach_zero_mortlach_zero_zero_za_i_ // zero_za_i_
                        when (_, !'0000000000', _, _) => __UNPREDICTABLE
                when (_, '10', _, '0000011xxxxxxxx', _, _) =>
                    // mortlach_multizero
                    case (18 +: 14, 13 +: 5, 3 +: 10, 0 +: 3) of
                        when (_, _, '0000000000', _) => // mortlach_multi_zero
                            __field opc 15 +: 3
                            __field Rv 13 +: 2
                            __field opc2 0 +: 3
                            case (opc, opc2) of
                                when ('x1x', '1xx') => __UNALLOCATED
                                when ('000', _) => __encoding A64_sme_mortlach_multizero_mortlach_multi_zero_zero_za1_ri_2 // zero_za1_ri_2
                                when ('001', _) => __encoding A64_sme_mortlach_multizero_mortlach_multi_zero_zero_za2_ri_1 // zero_za2_ri_1
                                when ('010', '0xx') => __encoding A64_sme_mortlach_multizero_mortlach_multi_zero_zero_za2_ri_2 // zero_za2_ri_2
                                when ('011', '0xx') => __encoding A64_sme_mortlach_multizero_mortlach_multi_zero_zero_za2_ri_4 // zero_za2_ri_4
                                when ('100', _) => __encoding A64_sme_mortlach_multizero_mortlach_multi_zero_zero_za1_ri_4 // zero_za1_ri_4
                                when ('101', '0xx') => __encoding A64_sme_mortlach_multizero_mortlach_multi_zero_zero_za4_ri_1 // zero_za4_ri_1
                                when ('101', '1xx') => __UNALLOCATED
                                when ('11x', '01x') => __UNALLOCATED
                                when ('110', '00x') => __encoding A64_sme_mortlach_multizero_mortlach_multi_zero_zero_za4_ri_2 // zero_za4_ri_2
                                when ('111', '00x') => __encoding A64_sme_mortlach_multizero_mortlach_multi_zero_zero_za4_ri_4 // zero_za4_ri_4
                        when (_, _, !'0000000000', _) => __UNPREDICTABLE
                when (_, '10', _, '0010010xxxxxxxx', _, _) =>
                    // mortlach_zero_zt
                    case (18 +: 14, 4 +: 14, 0 +: 4) of
                        when (_, '00000000000000', _) => // mortlach_zero_zt
                            __field opc 0 +: 4
                            case (opc) of
                                when (!'0001') => __UNALLOCATED
                                when ('0001') => __encoding A64_sme_mortlach_zero_zt_mortlach_zero_zt_zero_zt_i_ // zero_zt_i_
                        when (_, !'00000000000000', _) => __UNPREDICTABLE
                when (_, '10', _, '0010011xxxxxxxx', _, _) =>
                    // mortlach_mov_zt
                    case (18 +: 14, 17 +: 1, 15 +: 2, 14 +: 1, 0 +: 14) of
                        when (_, '0', '00', _, _) => // mortlach_extract_zt
                            __field imm3 12 +: 3
                            __field opc 5 +: 7
                            __field Rt 0 +: 5
                            case (opc) of
                                when (!'0011111') => __UNALLOCATED
                                when ('0011111') => __encoding A64_sme_mortlach_mov_zt_mortlach_extract_zt_movt_r_zt_ // movt_r_zt_
                        when (_, '0', '10', _, _) => __UNPREDICTABLE
                        when (_, '1', '00', _, _) => // mortlach_insert_zt
                            __field imm3 12 +: 3
                            __field opc 5 +: 7
                            __field Rt 0 +: 5
                            case (opc) of
                                when (!'0011111') => __UNALLOCATED
                                when ('0011111') => __encoding A64_sme_mortlach_mov_zt_mortlach_insert_zt_movt_zt_r_ // movt_zt_r_
                        when (_, '1', '10', '0', _) => // mortlach_move_to_zt
                            __field off2 12 +: 2
                            __field opc 5 +: 7
                            __field Zt 0 +: 5
                            case (opc) of
                                when (!'0011111') => __UNALLOCATED
                                when ('0011111') => __encoding A64_sme_mortlach_mov_zt_mortlach_move_to_zt_movt_zt_z_ // movt_zt_z_
                        when (_, '1', '10', '1', _) => __UNPREDICTABLE
                        when (_, _, 'x1', _, _) => __UNPREDICTABLE
                when (_, '10', _, '00x011xxxxxxxxx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '010011xxxxxxxxx', _, _) =>
                    // mortlach_zt_expand_nctg
                    case (19 +: 13, 16 +: 3, 14 +: 2, 6 +: 8, 5 +: 1, 4 +: 1, 2 +: 2, 0 +: 2) of
                        when (_, '011', '00', _, '0', _, '00', _) => // mortlach_expand_4dst2src_nctg
                            __field size 12 +: 2
                            __field opc 10 +: 2
                            __field Zn 6 +: 4
                            __field D 4 +: 1
                            __field Zd 0 +: 2
                            case (opc) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sme_mortlach_zt_expand_nctg_mortlach_expand_4dst2src_nctg_luti4_mz4_ztmz2_4 // luti4_mz4_ztmz2_4
                        when (_, '011', '00', _, '1', _, '00', _) => __UNPREDICTABLE
                        when (_, !'011', '00', _, _, _, '00', _) => __UNPREDICTABLE
                        when (_, _, '10', _, _, _, '00', _) => // mortlach_expand_4dst_nctg
                            __field opc 16 +: 3
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field D 4 +: 1
                            __field Zd 0 +: 2
                            case (opc, opc2) of
                                when (_, !'00') => __UNALLOCATED
                                when ('00x', '00') => __UNALLOCATED
                                when ('01x', '00') => __encoding A64_sme_mortlach_zt_expand_nctg_mortlach_expand_4dst_nctg_luti4_mz4_ztz_4 // luti4_mz4_ztz_4
                                when ('1xx', '00') => __encoding A64_sme_mortlach_zt_expand_nctg_mortlach_expand_4dst_nctg_luti2_mz4_ztz_4 // luti2_mz4_ztz_4
                        when (_, _, 'x0', _, _, _, '01', _) => __UNPREDICTABLE
                        when (_, _, 'x1', _, _, _, '0x', _) => // mortlach_expand_2dst_nctg
                            __field opc 15 +: 4
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field D 4 +: 1
                            __field Zd 0 +: 3
                            case (opc, opc2) of
                                when (_, !'00') => __UNALLOCATED
                                when ('00xx', '00') => __UNALLOCATED
                                when ('01xx', '00') => __encoding A64_sme_mortlach_zt_expand_nctg_mortlach_expand_2dst_nctg_luti4_mz2_ztz_8 // luti4_mz2_ztz_8
                                when ('1xxx', '00') => __encoding A64_sme_mortlach_zt_expand_nctg_mortlach_expand_2dst_nctg_luti2_mz2_ztz_8 // luti2_mz2_ztz_8
                        when (_, _, _, _, _, _, '1x', _) => __UNPREDICTABLE
                when (_, '10', _, '011011xxxxxxxxx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '01x001xxxxxxxxx', _, _) =>
                    // mortlach_zt_expand_ctg
                    case (23 +: 9, 22 +: 1, 19 +: 3, 14 +: 5, 6 +: 8, 5 +: 1, 2 +: 3, 0 +: 2) of
                        when (_, '0', _, '00x00', _, _, _, '00') => __UNPREDICTABLE
                        when (_, '0', _, '01000', _, _, _, '00') => __UNPREDICTABLE
                        when (_, '0', _, '01100', _, '0', _, '00') => // mortlach_expand_4dst2src_ctg
                            __field size 12 +: 2
                            __field opc 10 +: 2
                            __field Zn 6 +: 4
                            __field Zd 2 +: 3
                            case (opc) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sme_mortlach_zt_expand_ctg_mortlach_expand_4dst2src_ctg_luti4_mz4_ztmz2_1 // luti4_mz4_ztmz2_1
                        when (_, '0', _, '01100', _, '1', _, '00') => __UNPREDICTABLE
                        when (_, '0', _, '1xx00', _, _, _, '00') => __UNPREDICTABLE
                        when (_, '0', _, 'xxx10', _, _, _, '00') => // mortlach_expand_4dst_ctg
                            __field opc 16 +: 3
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            case (opc, opc2) of
                                when (_, !'00') => __UNALLOCATED
                                when ('00x', '00') => __UNALLOCATED
                                when ('01x', '00') => __encoding A64_sme_mortlach_zt_expand_ctg_mortlach_expand_4dst_ctg_luti4_mz4_ztz_1 // luti4_mz4_ztz_1
                                when ('1xx', '00') => __encoding A64_sme_mortlach_zt_expand_ctg_mortlach_expand_4dst_ctg_luti2_mz4_ztz_1 // luti2_mz4_ztz_1
                        when (_, '0', _, 'xxxx0', _, _, _, '10') => __UNPREDICTABLE
                        when (_, '0', _, 'xxxx1', _, _, _, 'x0') => // mortlach_expand_2dst_ctg
                            __field opc 15 +: 4
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            case (opc, opc2) of
                                when (_, !'00') => __UNALLOCATED
                                when ('00xx', '00') => __UNALLOCATED
                                when ('01xx', '00') => __encoding A64_sme_mortlach_zt_expand_ctg_mortlach_expand_2dst_ctg_luti4_mz2_ztz_1 // luti4_mz2_ztz_1
                                when ('1xxx', '00') => __encoding A64_sme_mortlach_zt_expand_ctg_mortlach_expand_2dst_ctg_luti2_mz2_ztz_1 // luti2_mz2_ztz_1
                        when (_, '0', _, _, _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _) => // mortlach_expand_1dst
                            __field opc 14 +: 5
                            __field size 12 +: 2
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when (_, !'00') => __UNALLOCATED
                                when ('00xxx', '00') => __UNALLOCATED
                                when ('01xxx', '00') => __encoding A64_sme_mortlach_zt_expand_ctg_mortlach_expand_1dst_luti4_z_ztz_ // luti4_z_ztz_
                                when ('1xxxx', '00') => __encoding A64_sme_mortlach_zt_expand_ctg_mortlach_expand_1dst_luti2_z_ztz_ // luti2_z_ztz_
                when (_, '10', _, '0xx000x0xxxxxxx', _, 'x0xxxx') =>
                    // mortlach_ins
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 17 +: 1, 15 +: 2, 13 +: 2, 10 +: 3, 7 +: 3, 5 +: 2, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, '00', _, '1', _, '00', _, '010', _, 'x0', _, '0', _) => // mortlach_multi2_za_insert_ctg
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_ins_mortlach_multi2_za_insert_ctg_mova_za_mz2_1 // mova_za_mz2_1
                        when (_, '00', _, '1', _, '00', _, '011', _, '00', _, '0', _) => // mortlach_multi4_za_insert_ctg
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_ins_mortlach_multi4_za_insert_ctg_mova_za_mz4_1 // mova_za_mz4_1
                        when (_, '00', _, '1', _, '00', _, '011', _, '10', _, '0', _) => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '01x', _, 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0', _, _, _, _, _, _, _, _, _) => // mortlach_insert_pred
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field opc 0 +: 4
                            case (size, Q) of
                                when (!'11', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sme_mortlach_ins_mortlach_insert_pred_mova_za_p_rz_b // mova_za_p_rz_b
                                when ('01', '0') => __encoding A64_sme_mortlach_ins_mortlach_insert_pred_mova_za_p_rz_h // mova_za_p_rz_h
                                when ('10', '0') => __encoding A64_sme_mortlach_ins_mortlach_insert_pred_mova_za_p_rz_w // mova_za_p_rz_w
                                when ('11', '0') => __encoding A64_sme_mortlach_ins_mortlach_insert_pred_mova_za_p_rz_d // mova_za_p_rz_d
                                when ('11', '1') => __encoding A64_sme_mortlach_ins_mortlach_insert_pred_mova_za_p_rz_q // mova_za_p_rz_q
                        when (_, _, _, '1', _, '0x', _, '000', _, 'x0', _, '0', _) => // mortlach_multi2_insert_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Zn 6 +: 4
                            __field opc 0 +: 3
                            case (size) of
                                when ('00') => __encoding A64_sme_mortlach_ins_mortlach_multi2_insert_ctg_mova_za2_z_b1 // mova_za2_z_b1
                                when ('01') => __encoding A64_sme_mortlach_ins_mortlach_multi2_insert_ctg_mova_za2_z_h1 // mova_za2_z_h1
                                when ('10') => __encoding A64_sme_mortlach_ins_mortlach_multi2_insert_ctg_mova_za2_z_w1 // mova_za2_z_w1
                                when ('11') => __encoding A64_sme_mortlach_ins_mortlach_multi2_insert_ctg_mova_za2_z_d1 // mova_za2_z_d1
                        when (_, _, _, '1', _, '0x', _, '001', _, '00', _, '0', _) => // mortlach_multi4_insert_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Zn 7 +: 3
                            __field opc 0 +: 3
                            case (size, opc) of
                                when (!'11', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding A64_sme_mortlach_ins_mortlach_multi4_insert_ctg_mova_za4_z_b1 // mova_za4_z_b1
                                when ('01', '0xx') => __encoding A64_sme_mortlach_ins_mortlach_multi4_insert_ctg_mova_za4_z_h1 // mova_za4_z_h1
                                when ('10', '0xx') => __encoding A64_sme_mortlach_ins_mortlach_multi4_insert_ctg_mova_za4_z_w1 // mova_za4_z_w1
                                when ('11', _) => __encoding A64_sme_mortlach_ins_mortlach_multi4_insert_ctg_mova_za4_z_d1 // mova_za4_z_d1
                        when (_, _, _, '1', _, '0x', _, '001', _, '10', _, '0', _) => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '01x', _, 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '0x', _, '0xx', _, 'x0', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '0x', _, '0xx', _, 'x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '0x', _, '1xx', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '1x', _, _, _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx000x0xxxxxxx', _, 'x1xxxx') => __UNPREDICTABLE
                when (_, '10', _, '0xx000x1xxxxxxx', _, _) =>
                    // mortlach_ext
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 17 +: 1, 15 +: 2, 13 +: 2, 10 +: 3, 8 +: 2, 2 +: 6, 0 +: 2) of
                        when (_, '00', _, '1', _, '00', _, '010', '00', _, 'x0') => // mortlach_multi2_za_extract_ctg
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding A64_sme_mortlach_ext_mortlach_multi2_za_extract_ctg_mova_mz_za2_1 // mova_mz_za2_1
                        when (_, '00', _, '1', _, '00', _, '010', '10', _, 'x0') => // mortlach_multi2_za_extract_zero
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding A64_sme_mortlach_ext_mortlach_multi2_za_extract_zero_movaz_mz_za2_1 // movaz_mz_za2_1
                        when (_, '00', _, '1', _, '00', _, '011', '00', _, '00') => // mortlach_multi4_za_extract_ctg
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_ext_mortlach_multi4_za_extract_ctg_mova_mz_za4_1 // mova_mz_za4_1
                        when (_, '00', _, '1', _, '00', _, '011', '10', _, '00') => // mortlach_multi4_za_extract_zero
                            __field Rv 13 +: 2
                            __field off3 5 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_ext_mortlach_multi4_za_extract_zero_movaz_mz_za4_1 // movaz_mz_za4_1
                        when (_, '00', _, '1', _, '00', _, '011', 'x0', _, '10') => __UNPREDICTABLE
                        when (_, '00', _, '1', _, '01', _, '01x', 'x0', _, 'x0') => __UNPREDICTABLE
                        when (_, _, _, '0', _, _, _, '000', '1x', _, _) => // mortlach_extract_zero
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 4
                            __field Zd 0 +: 5
                            case (size, Q) of
                                when (!'11', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sme_mortlach_ext_mortlach_extract_zero_movaz_z_rza_b // movaz_z_rza_b
                                when ('01', '0') => __encoding A64_sme_mortlach_ext_mortlach_extract_zero_movaz_z_rza_h // movaz_z_rza_h
                                when ('10', '0') => __encoding A64_sme_mortlach_ext_mortlach_extract_zero_movaz_z_rza_w // movaz_z_rza_w
                                when ('11', '0') => __encoding A64_sme_mortlach_ext_mortlach_extract_zero_movaz_z_rza_d // movaz_z_rza_d
                                when ('11', '1') => __encoding A64_sme_mortlach_ext_mortlach_extract_zero_movaz_z_rza_q // movaz_z_rza_q
                        when (_, _, _, '0', _, _, _, _, '0x', _, _) => // mortlach_extract_pred
                            __field size 22 +: 2
                            __field Q 16 +: 1
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field opc 5 +: 4
                            __field Zd 0 +: 5
                            case (size, Q) of
                                when (!'11', '1') => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sme_mortlach_ext_mortlach_extract_pred_mova_z_p_rza_b // mova_z_p_rza_b
                                when ('01', '0') => __encoding A64_sme_mortlach_ext_mortlach_extract_pred_mova_z_p_rza_h // mova_z_p_rza_h
                                when ('10', '0') => __encoding A64_sme_mortlach_ext_mortlach_extract_pred_mova_z_p_rza_w // mova_z_p_rza_w
                                when ('11', '0') => __encoding A64_sme_mortlach_ext_mortlach_extract_pred_mova_z_p_rza_d // mova_z_p_rza_d
                                when ('11', '1') => __encoding A64_sme_mortlach_ext_mortlach_extract_pred_mova_z_p_rza_q // mova_z_p_rza_q
                        when (_, _, _, '0', _, _, _, !'000', '1x', _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '0x', _, '000', '00', _, 'x0') => // mortlach_multi2_extract_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 1 +: 4
                            case (size) of
                                when ('00') => __encoding A64_sme_mortlach_ext_mortlach_multi2_extract_ctg_mova_mz2_za_b1 // mova_mz2_za_b1
                                when ('01') => __encoding A64_sme_mortlach_ext_mortlach_multi2_extract_ctg_mova_mz2_za_h1 // mova_mz2_za_h1
                                when ('10') => __encoding A64_sme_mortlach_ext_mortlach_multi2_extract_ctg_mova_mz2_za_w1 // mova_mz2_za_w1
                                when ('11') => __encoding A64_sme_mortlach_ext_mortlach_multi2_extract_ctg_mova_mz2_za_d1 // mova_mz2_za_d1
                        when (_, _, _, '1', _, '0x', _, '000', '10', _, 'x0') => // mortlach_multi2_extract_zero
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 1 +: 4
                            case (size) of
                                when ('00') => __encoding A64_sme_mortlach_ext_mortlach_multi2_extract_zero_movaz_mz2_za_b1 // movaz_mz2_za_b1
                                when ('01') => __encoding A64_sme_mortlach_ext_mortlach_multi2_extract_zero_movaz_mz2_za_h1 // movaz_mz2_za_h1
                                when ('10') => __encoding A64_sme_mortlach_ext_mortlach_multi2_extract_zero_movaz_mz2_za_w1 // movaz_mz2_za_w1
                                when ('11') => __encoding A64_sme_mortlach_ext_mortlach_multi2_extract_zero_movaz_mz2_za_d1 // movaz_mz2_za_d1
                        when (_, _, _, '1', _, '0x', _, '001', '00', _, '00') => // mortlach_multi4_extract_ctg
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when (!'11', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding A64_sme_mortlach_ext_mortlach_multi4_extract_ctg_mova_mz4_za_b1 // mova_mz4_za_b1
                                when ('01', '0xx') => __encoding A64_sme_mortlach_ext_mortlach_multi4_extract_ctg_mova_mz4_za_h1 // mova_mz4_za_h1
                                when ('10', '0xx') => __encoding A64_sme_mortlach_ext_mortlach_multi4_extract_ctg_mova_mz4_za_w1 // mova_mz4_za_w1
                                when ('11', _) => __encoding A64_sme_mortlach_ext_mortlach_multi4_extract_ctg_mova_mz4_za_d1 // mova_mz4_za_d1
                        when (_, _, _, '1', _, '0x', _, '001', '10', _, '00') => // mortlach_multi4_extract_zero
                            __field size 22 +: 2
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field opc 5 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when (!'11', '1xx') => __UNALLOCATED
                                when ('00', '0xx') => __encoding A64_sme_mortlach_ext_mortlach_multi4_extract_zero_movaz_mz4_za_b1 // movaz_mz4_za_b1
                                when ('01', '0xx') => __encoding A64_sme_mortlach_ext_mortlach_multi4_extract_zero_movaz_mz4_za_h1 // movaz_mz4_za_h1
                                when ('10', '0xx') => __encoding A64_sme_mortlach_ext_mortlach_multi4_extract_zero_movaz_mz4_za_w1 // movaz_mz4_za_w1
                                when ('11', _) => __encoding A64_sme_mortlach_ext_mortlach_multi4_extract_zero_movaz_mz4_za_d1 // movaz_mz4_za_d1
                        when (_, _, _, '1', _, '0x', _, '001', 'x0', _, '10') => __UNPREDICTABLE
                        when (_, !'00', _, '1', _, '0x', _, '01x', 'x0', _, 'x0') => __UNPREDICTABLE
                        when (_, _, _, '1', _, '0x', _, '0xx', 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, '1', _, '0x', _, '0xx', 'x1', _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '0x', _, '1xx', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '1x', _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx010xxxxxxxxx', _, 'xx0xxx') =>
                    // mortlach_hvadd
                    case (24 +: 8, 23 +: 1, 22 +: 1, 19 +: 3, 17 +: 2, 5 +: 12, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, '0', _, _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, '00', _, '0', _, _) => // mortlach_addhv
                            __field op 22 +: 1
                            __field V 16 +: 1
                            __field Pm 13 +: 3
                            __field Pn 10 +: 3
                            __field Zn 5 +: 5
                            __field opc2 0 +: 3
                            case (op, V, opc2) of
                                when ('0', _, '1xx') => __UNALLOCATED
                                when ('0', '0', '0xx') => __encoding A64_sme_mortlach_hvadd_mortlach_addhv_addha_za_pp_z_32 // addha_za_pp_z_32
                                when ('0', '1', '0xx') => __encoding A64_sme_mortlach_hvadd_mortlach_addhv_addva_za_pp_z_32 // addva_za_pp_z_32
                                when ('1', '0', _) => __encoding A64_sme_mortlach_hvadd_mortlach_addhv_addha_za_pp_z_64 // addha_za_pp_z_64
                                when ('1', '1', _) => __encoding A64_sme_mortlach_hvadd_mortlach_addhv_addva_za_pp_z_64 // addva_za_pp_z_64
                        when (_, '1', _, _, '00', _, '1', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, !'00', _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '0xx010xxxxxxxxx', _, 'xx1xxx') => __UNPREDICTABLE
                when (_, '10', _, '0xx1xxxxxxxxxxx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '10x10xxxx0xxxxx', _, _) =>
                    // mortlach_multi_array_1a
                    case (23 +: 9, 22 +: 1, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 10 +: 3, 5 +: 5, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, _, _, _, '000', _, '000', '1', _) => // mortlach_multi2_zz_za_fp8_fma_long_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_fp8_fma_long_long_sm_fmlall_za32_z8z8v_2x1 // fmlall_za32_z8z8v_2x1
                        when (_, '0', _, _, _, _, '000', _, !'000', '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '010', _, _, _, _) => // mortlach_multi2_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field o2 2 +: 1
                            __field off2 0 +: 2
                            case (op, S, o2) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_fma_long_sm_fmlal_za_zzv_2x1 // fmlal_za_zzv_2x1
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_fma_long_sm_fmlal_za_z8z8v_2x1 // fmlal_za_z8z8v_2x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_fma_long_sm_fmlsl_za_zzv_2x1 // fmlsl_za_zzv_2x1
                                when ('0', '1', '1') => __UNALLOCATED
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_fma_long_sm_bfmlal_za_zzv_2x1 // bfmlal_za_zzv_2x1
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_fma_long_sm_bfmlsl_za_zzv_2x1 // bfmlsl_za_zzv_2x1
                        when (_, '0', _, _, _, _, '011', _, _, _, _) => // mortlach_multi1_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_fma_long_sm_fmlal_za_zzv_1 // fmlal_za_zzv_1
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_fma_long_sm_fmlsl_za_zzv_1 // fmlsl_za_zzv_1
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_fma_long_sm_bfmlal_za_zzv_1 // bfmlal_za_zzv_1
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_fma_long_sm_bfmlsl_za_zzv_1 // bfmlsl_za_zzv_1
                        when (_, '0', _, _, _, _, '100', _, _, _, _) => // mortlach_multi2_z_za_fpdot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field opc 3 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_fpdot_sm_fdot_za_zzv_2x1 // fdot_za_zzv_2x1
                                when ('01') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_fpdot_sm_fdot_za_z8z8v_2x1 // fdot_za_z8z8v_2x1
                                when ('10') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_fpdot_sm_bfdot_za_zzv_2x1 // bfdot_za_zzv_2x1
                                when ('11') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_fpdot_sm_fdot_za32_z8z8v_2x1 // fdot_za32_z8z8v_2x1
                        when (_, '0', _, _, _, _, '101', _, 'x1x', _, _) => // mortlach_multi2_z_za_mixed_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_mixed_dot_sm_usdot_za_zzv_s2x1 // usdot_za_zzv_s2x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_mixed_dot_sm_sudot_za_zzv_s2x1 // sudot_za_zzv_s2x1
                        when (_, '1', _, _, _, _, '000', _, _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '010', _, _, _, _) => // mortlach_multi2_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (U, S, op) of
                                when (_, _, '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_sm_smlal_za_zzv_2x1 // smlal_za_zzv_2x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_sm_smlsl_za_zzv_2x1 // smlsl_za_zzv_2x1
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_sm_umlal_za_zzv_2x1 // umlal_za_zzv_2x1
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_sm_umlsl_za_zzv_2x1 // umlsl_za_zzv_2x1
                        when (_, '1', _, _, _, _, '011', _, _, _, _) => // mortlach_multi1_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_sm_smlal_za_zzv_1 // smlal_za_zzv_1
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_sm_smlsl_za_zzv_1 // smlsl_za_zzv_1
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_sm_umlal_za_zzv_1 // umlal_za_zzv_1
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_sm_umlsl_za_zzv_1 // umlsl_za_zzv_1
                        when (_, '1', _, _, _, _, '100', _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '101', _, 'x1x', _, _) => // mortlach_multi2_z_za_2way_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_2way_dot_sm_sdot_za32_zzv_2x1 // sdot_za32_zzv_2x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_2way_dot_sm_udot_za32_zzv_2x1 // udot_za32_zzv_2x1
                        when (_, _, _, _, _, _, '000', _, _, '0', _) => // mortlach_multi2_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_long_sm_smlall_za_zzv_2x1 // smlall_za_zzv_2x1
                                when (_, '0', '1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_long_sm_smlsll_za_zzv_2x1 // smlsll_za_zzv_2x1
                                when (_, '1', '0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_long_sm_umlall_za_zzv_2x1 // umlall_za_zzv_2x1
                                when (_, '1', '1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_long_sm_umlsll_za_zzv_2x1 // umlsll_za_zzv_2x1
                                when ('0', _, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_long_sm_usmlall_za_zzv_s2x1 // usmlall_za_zzv_s2x1
                                when ('0', '1', '0', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_mla_long_long_sm_sumlall_za_zzv_s2x1 // sumlall_za_zzv_s2x1
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, '001', _, _, _, _) => // mortlach_multi1_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_long_sm_smlall_za_zzv_1 // smlall_za_zzv_1
                                when (_, '0', '1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_long_sm_smlsll_za_zzv_1 // smlsll_za_zzv_1
                                when (_, '1', '0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_long_sm_umlall_za_zzv_1 // umlall_za_zzv_1
                                when (_, '1', '1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_long_sm_umlsll_za_zzv_1 // umlsll_za_zzv_1
                                when ('0', '0', '0', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi1_zz_za_mla_long_long_sm_usmlall_za_zzv_s // usmlall_za_zzv_s
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, '101', _, 'x0x', _, _) => // mortlach_multi2_z_za_4way_dot_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_4way_dot_sm_sdot_za_zzv_2x1 // sdot_za_zzv_2x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_z_za_4way_dot_sm_udot_za_zzv_2x1 // udot_za_zzv_2x1
                        when (_, _, _, _, _, _, '110', _, '0xx', _, _) => // mortlach_multi2_zz_za_float_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_float_sm_fmla_za_zzv_2x1 // fmla_za_zzv_2x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_float_sm_fmls_za_zzv_2x1 // fmls_za_zzv_2x1
                        when (_, _, _, _, _, _, '110', _, '1xx', _, _) => // mortlach_multi2_zz_za_int_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_int_sm_add_za_zzv_2x1 // add_za_zzv_2x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_int_sm_sub_za_zzv_2x1 // sub_za_zzv_2x1
                        when (_, _, _, _, _, _, '111', _, '0xx', _, _) => // mortlach_multi2_zz_za_f16_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_f16_sm_fmla_za_zzv_2x1_16 // fmla_za_zzv_2x1_16
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_f16_sm_fmls_za_zzv_2x1_16 // fmls_za_zzv_2x1_16
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_f16_sm_bfmla_za_zzv_2x1_16 // bfmla_za_zzv_2x1_16
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_1a_mortlach_multi2_zz_za_f16_sm_bfmls_za_zzv_2x1_16 // bfmls_za_zzv_2x1_16
                        when (_, _, _, _, _, _, '111', _, '1xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '10x11xxxx0xxxxx', _, _) =>
                    // mortlach_multi_array_1b
                    case (23 +: 9, 22 +: 1, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 10 +: 3, 5 +: 5, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, _, _, _, '000', _, '000', '1', _) => // mortlach_multi4_zz_za_fp8_fma_long_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_fp8_fma_long_long_sm_fmlall_za32_z8z8v_4x1 // fmlall_za32_z8z8v_4x1
                        when (_, '0', _, _, _, _, '000', _, !'000', '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '001', _, '000', _, _) => // mortlach_multi1_zz_za_fp8_fma_long_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi1_zz_za_fp8_fma_long_long_sm_fmlall_za32_z8z8v_1 // fmlall_za32_z8z8v_1
                        when (_, '0', _, _, _, _, '001', _, '001', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '010', _, _, _, _) => // mortlach_multi4_zz_za_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field o2 2 +: 1
                            __field off2 0 +: 2
                            case (op, S, o2) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_fma_long_sm_fmlal_za_zzv_4x1 // fmlal_za_zzv_4x1
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_fma_long_sm_fmlal_za_z8z8v_4x1 // fmlal_za_z8z8v_4x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_fma_long_sm_fmlsl_za_zzv_4x1 // fmlsl_za_zzv_4x1
                                when ('0', '1', '1') => __UNALLOCATED
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_fma_long_sm_bfmlal_za_zzv_4x1 // bfmlal_za_zzv_4x1
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_fma_long_sm_bfmlsl_za_zzv_4x1 // bfmlsl_za_zzv_4x1
                        when (_, '0', _, _, _, _, '011', _, '00x', _, _) => // mortlach_multi1_zz_za_fp8_fma_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi1_zz_za_fp8_fma_long_sm_fmlal_za_z8z8v_1 // fmlal_za_z8z8v_1
                        when (_, '0', _, _, _, _, '0x1', _, '01x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '0x1', _, '1xx', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, '100', _, _, _, _) => // mortlach_multi4_z_za_fpdot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field opc 3 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_fpdot_sm_fdot_za_zzv_4x1 // fdot_za_zzv_4x1
                                when ('01') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_fpdot_sm_fdot_za_z8z8v_4x1 // fdot_za_z8z8v_4x1
                                when ('10') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_fpdot_sm_bfdot_za_zzv_4x1 // bfdot_za_zzv_4x1
                                when ('11') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_fpdot_sm_fdot_za32_z8z8v_4x1 // fdot_za32_z8z8v_4x1
                        when (_, '0', _, _, _, _, '101', _, 'x1x', _, _) => // mortlach_multi4_z_za_mixed_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_mixed_dot_sm_usdot_za_zzv_s4x1 // usdot_za_zzv_s4x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_mixed_dot_sm_sudot_za_zzv_s4x1 // sudot_za_zzv_s4x1
                        when (_, '1', _, _, _, _, '000', _, _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '010', _, _, _, _) => // mortlach_multi4_zz_za_mla_long_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (U, S, op) of
                                when (_, _, '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_sm_smlal_za_zzv_4x1 // smlal_za_zzv_4x1
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_sm_smlsl_za_zzv_4x1 // smlsl_za_zzv_4x1
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_sm_umlal_za_zzv_4x1 // umlal_za_zzv_4x1
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_sm_umlsl_za_zzv_4x1 // umlsl_za_zzv_4x1
                        when (_, '1', _, _, _, _, '0x1', _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '100', _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, '101', _, 'x1x', _, _) => // mortlach_multi4_z_za_2way_dot_sm
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_2way_dot_sm_sdot_za32_zzv_4x1 // sdot_za32_zzv_4x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_2way_dot_sm_udot_za32_zzv_4x1 // udot_za32_zzv_4x1
                        when (_, _, _, _, _, _, '000', _, _, '0', _) => // mortlach_multi4_zz_za_mla_long_long_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_long_sm_smlall_za_zzv_4x1 // smlall_za_zzv_4x1
                                when (_, '0', '1', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_long_sm_smlsll_za_zzv_4x1 // smlsll_za_zzv_4x1
                                when (_, '1', '0', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_long_sm_umlall_za_zzv_4x1 // umlall_za_zzv_4x1
                                when (_, '1', '1', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_long_sm_umlsll_za_zzv_4x1 // umlsll_za_zzv_4x1
                                when ('0', _, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0', '1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_long_sm_usmlall_za_zzv_s4x1 // usmlall_za_zzv_s4x1
                                when ('0', '1', '0', '1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_mla_long_long_sm_sumlall_za_zzv_s4x1 // sumlall_za_zzv_s4x1
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, '101', _, 'x0x', _, _) => // mortlach_multi4_z_za_4way_dot_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_4way_dot_sm_sdot_za_zzv_4x1 // sdot_za_zzv_4x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_z_za_4way_dot_sm_udot_za_zzv_4x1 // udot_za_zzv_4x1
                        when (_, _, _, _, _, _, '110', _, '0xx', _, _) => // mortlach_multi4_zz_za_float_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_float_sm_fmla_za_zzv_4x1 // fmla_za_zzv_4x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_float_sm_fmls_za_zzv_4x1 // fmls_za_zzv_4x1
                        when (_, _, _, _, _, _, '110', _, '1xx', _, _) => // mortlach_multi4_zz_za_int_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_int_sm_add_za_zzv_4x1 // add_za_zzv_4x1
                                when ('1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_int_sm_sub_za_zzv_4x1 // sub_za_zzv_4x1
                        when (_, _, _, _, _, _, '111', _, '0xx', _, _) => // mortlach_multi4_zz_za_f16_sm
                            __field sz 22 +: 1
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field Zn 5 +: 5
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_f16_sm_fmla_za_zzv_4x1_16 // fmla_za_zzv_4x1_16
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_f16_sm_fmls_za_zzv_4x1_16 // fmls_za_zzv_4x1_16
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_f16_sm_bfmla_za_zzv_4x1_16 // bfmla_za_zzv_4x1_16
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_1b_mortlach_multi4_zz_za_f16_sm_bfmls_za_zzv_4x1_16 // bfmls_za_zzv_4x1_16
                        when (_, _, _, _, _, _, '111', _, '1xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '11x1xxxx00xxxxx', _, _) =>
                    // mortlach_multi_array_2a
                    case (23 +: 9, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 15 +: 2, 13 +: 2, 10 +: 3, 6 +: 4, 5 +: 1, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, _, _, _, _, '000', _, '1', '000', '0', _) => // mortlach_multi2_zz_za_fp8_fma_long_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_fp8_fma_long_long_mm_fmlall_za32_z8z8w_2x2 // fmlall_za32_z8z8w_2x2
                        when (_, '0', _, _, _, _, _, '000', _, '1', '001', '0', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '000', _, '1', '10x', '0', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '000', _, '1', 'x0x', '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '010', _, '0', 'xx0', _, _) => // mortlach_multi2_zz_za_fma_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_fma_long_mm_fmlal_za_zzw_2x2 // fmlal_za_zzw_2x2
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_fma_long_mm_fmlsl_za_zzw_2x2 // fmlsl_za_zzw_2x2
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_fma_long_mm_bfmlal_za_zzw_2x2 // bfmlal_za_zzw_2x2
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_fma_long_mm_bfmlsl_za_zzw_2x2 // bfmlsl_za_zzw_2x2
                        when (_, '0', _, _, _, _, _, '010', _, '1', '000', _, _) => // mortlach_multi2_zz_za_fp8_fma_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_fp8_fma_long_mm_fmlal_za_z8z8w_2x2 // fmlal_za_z8z8w_2x2
                        when (_, '0', _, _, _, _, _, '010', _, '1', '100', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '010', _, '1', 'x01', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '0x1', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '100', _, _, 'x0x', _, _) => // mortlach_multi2_z_za_fpdot_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field opc 4 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_fpdot_mm_fdot_za_zzw_2x2 // fdot_za_zzw_2x2
                                when ('01') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_fpdot_mm_bfdot_za_zzw_2x2 // bfdot_za_zzw_2x2
                                when ('10') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_fpdot_mm_fdot_za_z8z8w_2x2 // fdot_za_z8z8w_2x2
                                when ('11') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_fpdot_mm_fdot_za32_z8z8w_2x2 // fdot_za32_z8z8w_2x2
                        when (_, '0', _, _, _, _, _, '101', _, '0', '01x', _, _) => // mortlach_multi2_z_za_mixed_dot_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_mixed_dot_mm_usdot_za_zzw_s2x2 // usdot_za_zzw_s2x2
                        when (_, '0', _, _, _, _, _, '101', _, '0', '11x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '110', _, '1', 'x0x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, '1x1', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, 'xx0', _, '1', 'x1x', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, '010', _, '0', 'xx0', _, _) => // mortlach_multi2_zz_za_mla_long_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_mm_smlal_za_zzw_2x2 // smlal_za_zzw_2x2
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_mm_smlsl_za_zzw_2x2 // smlsl_za_zzw_2x2
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_mm_umlal_za_zzw_2x2 // umlal_za_zzw_2x2
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_mm_umlsl_za_zzw_2x2 // umlsl_za_zzw_2x2
                        when (_, '1', _, _, _, _, _, '100', _, '0', 'x0x', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, '101', _, '0', 'x1x', _, _) => // mortlach_multi2_z_za_2way_dot_mm
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_2way_dot_mm_sdot_za32_zzw_2x2 // sdot_za32_zzw_2x2
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_2way_dot_mm_udot_za32_zzw_2x2 // udot_za32_zzw_2x2
                        when (_, '1', _, _, _, _, _, _, _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', '00', _, _, '111', _, '0', '0xx', _, _) => // mortlach_multi2_z_za_float_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_float_mm_fadd_za_zw_2x2 // fadd_za_zw_2x2
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_float_mm_fsub_za_zw_2x2 // fsub_za_zw_2x2
                        when (_, _, _, '00', '00', _, _, '111', _, '0', '1xx', _, _) => // mortlach_multi2_z_za_int_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_int_mm_add_za_zw_2x2 // add_za_zw_2x2
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_int_mm_sub_za_zw_2x2 // sub_za_zw_2x2
                        when (_, _, _, '00', '10', _, _, '111', _, '0', '0xx', _, _) => // mortlach_multi2_z_za_f16_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_f16_mm_fadd_za_zw_2x2_16 // fadd_za_zw_2x2_16
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_f16_mm_fsub_za_zw_2x2_16 // fsub_za_zw_2x2_16
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_f16_mm_bfadd_za_zw_2x2_16 // bfadd_za_zw_2x2_16
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_f16_mm_bfsub_za_zw_2x2_16 // bfsub_za_zw_2x2_16
                        when (_, _, _, '00', '10', _, _, '111', _, '0', '1xx', _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x1', _, _, '111', _, '0', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '000', _, '0', _, '0', _) => // mortlach_multi2_zz_za_mla_long_long_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_long_mm_smlall_za_zzw_2x2 // smlall_za_zzw_2x2
                                when (_, '0', '1', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_long_mm_smlsll_za_zzw_2x2 // smlsll_za_zzw_2x2
                                when (_, '1', '0', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_long_mm_umlall_za_zzw_2x2 // umlall_za_zzw_2x2
                                when (_, '1', '1', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_long_mm_umlsll_za_zzw_2x2 // umlsll_za_zzw_2x2
                                when ('0', '0', '0', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_mla_long_long_mm_usmlall_za_zzw_s2x2 // usmlall_za_zzw_s2x2
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, _, _, _, '000', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '010', _, '0', 'xx1', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '0x1', _, '0', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, '100', _, '0', 'x1x', _, _) => // mortlach_multi2_zz_za_f16_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 4 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_f16_mm_fmla_za_zzw_2x2_16 // fmla_za_zzw_2x2_16
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_f16_mm_fmls_za_zzw_2x2_16 // fmls_za_zzw_2x2_16
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_f16_mm_bfmla_za_zzw_2x2_16 // bfmla_za_zzw_2x2_16
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_f16_mm_bfmls_za_zzw_2x2_16 // bfmls_za_zzw_2x2_16
                        when (_, _, _, _, _, _, _, '101', _, '0', 'x0x', _, _) => // mortlach_multi2_z_za_4way_dot_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_4way_dot_mm_sdot_za_zzw_2x2 // sdot_za_zzw_2x2
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_z_za_4way_dot_mm_udot_za_zzw_2x2 // udot_za_zzw_2x2
                        when (_, _, _, _, _, _, _, '110', _, '0', '0xx', _, _) => // mortlach_multi2_zz_za_float_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_float_mm_fmla_za_zzw_2x2 // fmla_za_zzw_2x2
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_float_mm_fmls_za_zzw_2x2 // fmls_za_zzw_2x2
                        when (_, _, _, _, _, _, _, '110', _, '0', '1xx', _, _) => // mortlach_multi2_zz_za_int_mm
                            __field sz 22 +: 1
                            __field Zm 17 +: 4
                            __field Rv 13 +: 2
                            __field Zn 6 +: 4
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_int_mm_add_za_zzw_2x2 // add_za_zzw_2x2
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2a_mortlach_multi2_zz_za_int_mm_sub_za_zzw_2x2 // sub_za_zzw_2x2
                        when (_, _, _, !'00', _, _, _, '111', _, '0', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '11x1xxxx10xxxxx', _, _) =>
                    // mortlach_multi_array_2b
                    case (23 +: 9, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 15 +: 2, 13 +: 2, 10 +: 3, 7 +: 3, 5 +: 2, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, '0', _, _, 'x0', _, _, '000', _, '01', '000', '0', _) => // mortlach_multi4_zz_za_fp8_fma_long_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_fp8_fma_long_long_mm_fmlall_za32_z8z8w_4x4 // fmlall_za32_z8z8w_4x4
                        when (_, '0', _, _, 'x0', _, _, '000', _, '01', '001', '0', _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '000', _, '01', '10x', '0', _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '000', _, '01', 'x0x', '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '010', _, '00', 'xx0', _, _) => // mortlach_multi4_zz_za_fma_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_fma_long_mm_fmlal_za_zzw_4x4 // fmlal_za_zzw_4x4
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_fma_long_mm_fmlsl_za_zzw_4x4 // fmlsl_za_zzw_4x4
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_fma_long_mm_bfmlal_za_zzw_4x4 // bfmlal_za_zzw_4x4
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_fma_long_mm_bfmlsl_za_zzw_4x4 // bfmlsl_za_zzw_4x4
                        when (_, '0', _, _, 'x0', _, _, '010', _, '01', '000', _, _) => // mortlach_multi4_zz_za_fp8_fma_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_fp8_fma_long_mm_fmlal_za_z8z8w_4x4 // fmlal_za_z8z8w_4x4
                        when (_, '0', _, _, 'x0', _, _, '010', _, '01', '100', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '010', _, '01', 'x01', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '0x1', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '100', _, '0x', 'x0x', _, _) => // mortlach_multi4_z_za_fpdot_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field opc 4 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_fpdot_mm_fdot_za_zzw_4x4 // fdot_za_zzw_4x4
                                when ('01') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_fpdot_mm_bfdot_za_zzw_4x4 // bfdot_za_zzw_4x4
                                when ('10') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_fpdot_mm_fdot_za_z8z8w_4x4 // fdot_za_z8z8w_4x4
                                when ('11') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_fpdot_mm_fdot_za32_z8z8w_4x4 // fdot_za32_z8z8w_4x4
                        when (_, '0', _, _, 'x0', _, _, '101', _, '00', '01x', _, _) => // mortlach_multi4_z_za_mixed_dot_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_mixed_dot_mm_usdot_za_zzw_s4x4 // usdot_za_zzw_s4x4
                        when (_, '0', _, _, 'x0', _, _, '101', _, '00', '11x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '110', _, '01', 'x0x', _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, '1x1', _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, 'x0', _, _, 'xx0', _, '01', 'x1x', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, 'x0', _, _, '010', _, '00', 'xx0', _, _) => // mortlach_multi4_zz_za_mla_long_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_mm_smlal_za_zzw_4x4 // smlal_za_zzw_4x4
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_mm_smlsl_za_zzw_4x4 // smlsl_za_zzw_4x4
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_mm_umlal_za_zzw_4x4 // umlal_za_zzw_4x4
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_mm_umlsl_za_zzw_4x4 // umlsl_za_zzw_4x4
                        when (_, '1', _, _, 'x0', _, _, '100', _, '00', 'x0x', _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, 'x0', _, _, '101', _, '00', 'x1x', _, _) => // mortlach_multi4_z_za_2way_dot_mm
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_2way_dot_mm_sdot_za32_zzw_4x4 // sdot_za32_zzw_4x4
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_2way_dot_mm_udot_za32_zzw_4x4 // udot_za32_zzw_4x4
                        when (_, '1', _, _, 'x0', _, _, _, _, '01', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', '00', _, _, '111', _, '00', '0xx', _, _) => // mortlach_multi4_z_za_float_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_float_mm_fadd_za_zw_4x4 // fadd_za_zw_4x4
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_float_mm_fsub_za_zw_4x4 // fsub_za_zw_4x4
                        when (_, _, _, '00', '00', _, _, '111', _, '00', '1xx', _, _) => // mortlach_multi4_z_za_int_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_int_mm_add_za_zw_4x4 // add_za_zw_4x4
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_int_mm_sub_za_zw_4x4 // sub_za_zw_4x4
                        when (_, _, _, '00', '10', _, _, '111', _, '00', '0xx', _, _) => // mortlach_multi4_z_za_f16_mm
                            __field sz 22 +: 1
                            __field Rv 13 +: 2
                            __field Zm 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_f16_mm_fadd_za_zw_4x4_16 // fadd_za_zw_4x4_16
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_f16_mm_fsub_za_zw_4x4_16 // fsub_za_zw_4x4_16
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_f16_mm_bfadd_za_zw_4x4_16 // bfadd_za_zw_4x4_16
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_f16_mm_bfsub_za_zw_4x4_16 // bfsub_za_zw_4x4_16
                        when (_, _, _, '00', '10', _, _, '111', _, '00', '1xx', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '000', _, '00', _, '0', _) => // mortlach_multi4_zz_za_mla_long_long_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field o1 0 +: 1
                            case (sz, U, S, op) of
                                when (_, '0', '0', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_long_mm_smlall_za_zzw_4x4 // smlall_za_zzw_4x4
                                when (_, '0', '1', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_long_mm_smlsll_za_zzw_4x4 // smlsll_za_zzw_4x4
                                when (_, '1', '0', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_long_mm_umlall_za_zzw_4x4 // umlall_za_zzw_4x4
                                when (_, '1', '1', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_long_mm_umlsll_za_zzw_4x4 // umlsll_za_zzw_4x4
                                when ('0', '0', '0', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_mla_long_long_mm_usmlall_za_zzw_s4x4 // usmlall_za_zzw_s4x4
                                when ('0', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', _, '1') => __UNALLOCATED
                                when ('1', _, _, '1') => __UNALLOCATED
                        when (_, _, _, _, 'x0', _, _, '000', _, '00', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '010', _, '00', 'xx1', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '0x1', _, '00', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, '100', _, '00', 'x1x', _, _) => // mortlach_multi4_zz_za_f16_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 4 +: 1
                            __field off3 0 +: 3
                            case (sz, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_f16_mm_fmla_za_zzw_4x4_16 // fmla_za_zzw_4x4_16
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_f16_mm_fmls_za_zzw_4x4_16 // fmls_za_zzw_4x4_16
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_f16_mm_bfmla_za_zzw_4x4_16 // bfmla_za_zzw_4x4_16
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_f16_mm_bfmls_za_zzw_4x4_16 // bfmls_za_zzw_4x4_16
                        when (_, _, _, _, 'x0', _, _, '101', _, '00', 'x0x', _, _) => // mortlach_multi4_z_za_4way_dot_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field off3 0 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_4way_dot_mm_sdot_za_zzw_4x4 // sdot_za_zzw_4x4
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_z_za_4way_dot_mm_udot_za_zzw_4x4 // udot_za_zzw_4x4
                        when (_, _, _, _, 'x0', _, _, '110', _, '00', '0xx', _, _) => // mortlach_multi4_zz_za_float_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_float_mm_fmla_za_zzw_4x4 // fmla_za_zzw_4x4
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_float_mm_fmls_za_zzw_4x4 // fmls_za_zzw_4x4
                        when (_, _, _, _, 'x0', _, _, '110', _, '00', '1xx', _, _) => // mortlach_multi4_zz_za_int_mm
                            __field sz 22 +: 1
                            __field Zm 18 +: 3
                            __field Rv 13 +: 2
                            __field Zn 7 +: 3
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (S) of
                                when ('0') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_int_mm_add_za_zzw_4x4 // add_za_zzw_4x4
                                when ('1') => __encoding A64_sme_mortlach_multi_array_2b_mortlach_multi4_zz_za_int_mm_sub_za_zzw_4x4 // sub_za_zzw_4x4
                        when (_, _, _, !'00', 'x0', _, _, '111', _, '00', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, _, _, '1x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x1', _, _, _, _, _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx00xxxxxxxxxx', _, _) =>
                    // mortlach_multi_indexed_1
                    case (24 +: 8, 22 +: 2, 20 +: 2, 13 +: 7, 12 +: 1, 5 +: 7, 2 +: 3, 0 +: 2) of
                        when (_, '00', _, _, _, _, _, _) => // mortlach_multi1_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field i4h 15 +: 1
                            __field Rv 13 +: 2
                            __field i4l 10 +: 3
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field op 2 +: 1
                            __field off2 0 +: 2
                            case (U, S, op) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_s_smlall_za_zzi_s // smlall_za_zzi_s
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_s_usmlall_za_zzi_s // usmlall_za_zzi_s
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_s_smlsll_za_zzi_s // smlsll_za_zzi_s
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_s_umlall_za_zzi_s // umlall_za_zzi_s
                                when ('1', '0', '1') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_s_sumlall_za_zzi_s // sumlall_za_zzi_s
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_s_umlsll_za_zzi_s // umlsll_za_zzi_s
                        when (_, '01', _, _, _, _, '000', _) => // mortlach_multi1_fp8_fma_long_long_idx
                            __field Zm 16 +: 4
                            __field i4h 15 +: 1
                            __field Rv 13 +: 2
                            __field i4l 10 +: 3
                            __field Zn 5 +: 5
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_fp8_fma_long_long_idx_fmlall_za32_z8z8i_1 // fmlall_za32_z8z8i_1
                        when (_, '01', _, _, _, _, !'000', _) => __UNPREDICTABLE
                        when (_, '10', _, _, '0', _, 'xx0', _) => // mortlach_multi1_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_d_smlall_za_zzi_d // smlall_za_zzi_d
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_d_smlsll_za_zzi_d // smlsll_za_zzi_d
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_d_umlall_za_zzi_d // umlall_za_zzi_d
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_long_idx_d_umlsll_za_zzi_d // umlsll_za_zzi_d
                        when (_, '10', _, _, '0', _, 'xx1', _) => __UNPREDICTABLE
                        when (_, '10', _, _, '1', _, _, _) => // mortlach_multi1_fma_long_idx
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_fma_long_idx_fmlal_za_zzi_1 // fmlal_za_zzi_1
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_fma_long_idx_fmlsl_za_zzi_1 // fmlsl_za_zzi_1
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_fma_long_idx_bfmlal_za_zzi_1 // bfmlal_za_zzi_1
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_fma_long_idx_bfmlsl_za_zzi_1 // bfmlsl_za_zzi_1
                        when (_, '11', _, _, '0', _, '0xx', _) => // mortlach_multi1_fp8_fma_long_idx
                            __field Zm 16 +: 4
                            __field i4A 15 +: 1
                            __field Rv 13 +: 2
                            __field i4B 10 +: 2
                            __field Zn 5 +: 5
                            __field i4C 3 +: 1
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_fp8_fma_long_idx_fmlal_za_z8z8i_1 // fmlal_za_z8z8i_1
                        when (_, '11', _, _, '0', _, '1xx', _) => __UNPREDICTABLE
                        when (_, '11', _, _, '1', _, _, _) => // mortlach_multi1_mla_long_idx
                            __field Zm 16 +: 4
                            __field i3h 15 +: 1
                            __field Rv 13 +: 2
                            __field i3l 10 +: 2
                            __field Zn 5 +: 5
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field off3 0 +: 3
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_idx_smlal_za_zzi_1 // smlal_za_zzi_1
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_idx_smlsl_za_zzi_1 // smlsl_za_zzi_1
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_idx_umlal_za_zzi_1 // umlal_za_zzi_1
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_1_mortlach_multi1_mla_long_idx_umlsl_za_zzi_1 // umlsl_za_zzi_1
                when (_, '10', _, '1xx01xxxx0xxxxx', _, _) =>
                    // mortlach_multi_indexed_2
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 11 +: 2, 6 +: 5, 5 +: 1, 3 +: 2, 0 +: 3) of
                        when (_, '00', _, _, _, _, '0x', _, _, _, _) => // mortlach_multi2_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 5 +: 1
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case (op, U, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_s_smlall_za_zzi_s2xi // smlall_za_zzi_s2xi
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_s_smlsll_za_zzi_s2xi // smlsll_za_zzi_s2xi
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_s_umlall_za_zzi_s2xi // umlall_za_zzi_s2xi
                                when ('0', '1', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_s_umlsll_za_zzi_s2xi // umlsll_za_zzi_s2xi
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_s_usmlall_za_zzi_s2xi // usmlall_za_zzi_s2xi
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_s_sumlall_za_zzi_s2xi // sumlall_za_zzi_s2xi
                        when (_, '00', _, _, _, _, '1x', _, _, _, _) => // mortlach_multi2_zza_idx_h
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 5 +: 1
                            __field S 4 +: 1
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_h_fmla_za_zzi_h2xi // fmla_za_zzi_h2xi
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_h_fmls_za_zzi_h2xi // fmls_za_zzi_h2xi
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_h_bfmla_za_zzi_h2xi // bfmla_za_zzi_h2xi
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_h_bfmls_za_zzi_h2xi // bfmls_za_zzi_h2xi
                        when (_, '01', _, _, _, _, _, _, _, _, _) => // mortlach_multi2_zza_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 12 +: 1
                            __field i2 10 +: 2
                            __field Zn 6 +: 4
                            __field opc2 3 +: 3
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '000') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_fmla_za_zzi_s2xi // fmla_za_zzi_s2xi
                                when ('0', '001') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_fvdot_za_zzi_2xi // fvdot_za_zzi_2xi
                                when ('0', '010') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_fmls_za_zzi_s2xi // fmls_za_zzi_s2xi
                                when ('0', '011') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_bfvdot_za_zzi_2xi // bfvdot_za_zzi_2xi
                                when ('0', '100') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_svdot_za32_zzi_2xi // svdot_za32_zzi_2xi
                                when ('0', '101') => __UNALLOCATED
                                when ('0', '110') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_uvdot_za32_zzi_2xi // uvdot_za32_zzi_2xi
                                when ('0', '111') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_fdot_za32_z8z8i_2xi // fdot_za32_z8z8i_2xi
                                when ('1', '000') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_sdot_za32_zzi_2xi // sdot_za32_zzi_2xi
                                when ('1', '001') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_fdot_za_zzi_2xi // fdot_za_zzi_2xi
                                when ('1', '010') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_udot_za32_zzi_2xi // udot_za32_zzi_2xi
                                when ('1', '011') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_bfdot_za_zzi_2xi // bfdot_za_zzi_2xi
                                when ('1', '100') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_sdot_za_zzi_s2xi // sdot_za_zzi_s2xi
                                when ('1', '101') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_usdot_za_zzi_s2xi // usdot_za_zzi_s2xi
                                when ('1', '110') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_udot_za_zzi_s2xi // udot_za_zzi_s2xi
                                when ('1', '111') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_s_sudot_za_zzi_s2xi // sudot_za_zzi_s2xi
                        when (_, '10', _, _, _, _, '00', _, '0', _, _) => // mortlach_multi2_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 1
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 1 +: 2
                            __field o1 0 +: 1
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_d_smlall_za_zzi_d2xi // smlall_za_zzi_d2xi
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_d_smlsll_za_zzi_d2xi // smlsll_za_zzi_d2xi
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_d_umlall_za_zzi_d2xi // umlall_za_zzi_d2xi
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_long_idx_d_umlsll_za_zzi_d2xi // umlsll_za_zzi_d2xi
                        when (_, '10', _, _, _, _, '01', _, '0', _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '0x', _, '1', '00', _) => // mortlach_multi2_fp8_fma_long_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 6 +: 4
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fp8_fma_long_long_idx_fmlall_za32_z8z8i_2xi // fmlall_za32_z8z8i_2xi
                        when (_, '10', _, _, _, _, '0x', _, '1', !'00', _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '0', _, _) => // mortlach_multi2_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fma_long_idx_fmlal_za_zzi_2xi // fmlal_za_zzi_2xi
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fma_long_idx_fmlsl_za_zzi_2xi // fmlsl_za_zzi_2xi
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fma_long_idx_bfmlal_za_zzi_2xi // bfmlal_za_zzi_2xi
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fma_long_idx_bfmlsl_za_zzi_2xi // bfmlsl_za_zzi_2xi
                        when (_, '10', _, _, _, _, '1x', _, '1', '0x', _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '1', '1x', _) => // mortlach_multi2_fp8_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 6 +: 4
                            __field i4l 2 +: 2
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fp8_fma_long_idx_fmlal_za_z8z8i_2xi // fmlal_za_z8z8i_2xi
                        when (_, '11', _, _, _, _, '00', _, '0', _, _) => // mortlach_multi2_zza_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i1 10 +: 1
                            __field Zn 6 +: 4
                            __field opc 3 +: 2
                            __field off3 0 +: 3
                            case (opc) of
                                when ('00') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_d_fmla_za_zzi_d2xi // fmla_za_zzi_d2xi
                                when ('01') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_d_sdot_za_zzi_d2xi // sdot_za_zzi_d2xi
                                when ('10') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_d_fmls_za_zzi_d2xi // fmls_za_zzi_d2xi
                                when ('11') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_zza_idx_d_udot_za_zzi_d2xi // udot_za_zzi_d2xi
                        when (_, '11', _, _, _, _, '01', _, '0', _, _) => // mortlach_multi2_fp8_fvdot_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i2h 10 +: 1
                            __field Zn 6 +: 4
                            __field T 4 +: 1
                            __field i2l 3 +: 1
                            __field off3 0 +: 3
                            case (T) of
                                when ('0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fp8_fvdot_idx_s_fvdotb_za32_z8z8i_2xi // fvdotb_za32_z8z8i_2xi
                                when ('1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fp8_fvdot_idx_s_fvdott_za32_z8z8i_2xi // fvdott_za32_z8z8i_2xi
                        when (_, '11', _, _, _, _, '1x', _, '0', _, _) => // mortlach_multi2_mla_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_idx_smlal_za_zzi_2xi // smlal_za_zzi_2xi
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_idx_smlsl_za_zzi_2xi // smlsl_za_zzi_2xi
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_idx_umlal_za_zzi_2xi // umlal_za_zzi_2xi
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_mla_long_idx_umlsl_za_zzi_2xi // umlsl_za_zzi_2xi
                        when (_, '11', _, _, _, _, _, _, '1', '0x', _) => // mortlach_multi2_fp8_fdot_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 12 +: 1
                            __field i3h 10 +: 2
                            __field Zn 6 +: 4
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fp8_fdot_idx_fdot_za_z8z8i_2xi // fdot_za_z8z8i_2xi
                                when ('1') => __encoding A64_sme_mortlach_multi_indexed_2_mortlach_multi2_fp8_fdot_idx_fvdot_za_z8z8i_2xi // fvdot_za_z8z8i_2xi
                        when (_, '11', _, _, _, _, _, _, '1', '1x', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx01xxxx1xxxxx', _, _) =>
                    // mortlach_multi_indexed_3
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 15 +: 1, 13 +: 2, 11 +: 2, 7 +: 4, 4 +: 3, 3 +: 1, 0 +: 3) of
                        when (_, '00', _, _, _, _, '0x', _, '0xx', _, _) => // mortlach_multi4_mla_long_long_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 5 +: 1
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case (op, U, S) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_s_smlall_za_zzi_s4xi // smlall_za_zzi_s4xi
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_s_smlsll_za_zzi_s4xi // smlsll_za_zzi_s4xi
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_s_umlall_za_zzi_s4xi // umlall_za_zzi_s4xi
                                when ('0', '1', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_s_umlsll_za_zzi_s4xi // umlsll_za_zzi_s4xi
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_s_usmlall_za_zzi_s4xi // usmlall_za_zzi_s4xi
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_s_sumlall_za_zzi_s4xi // sumlall_za_zzi_s4xi
                        when (_, '00', _, _, _, _, '0x', _, '100', '0', _) => // mortlach_multi4_fp8_fma_long_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 7 +: 3
                            __field i4l 1 +: 2
                            __field o1 0 +: 1
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_fp8_fma_long_long_idx_fmlall_za32_z8z8i_4xi // fmlall_za32_z8z8i_4xi
                        when (_, '00', _, _, _, _, '0x', _, '100', '1', _) => __UNPREDICTABLE
                        when (_, '00', _, _, _, _, '1x', _, '0xx', _, _) => // mortlach_multi4_zza_idx_h
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 5 +: 1
                            __field S 4 +: 1
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_h_fmla_za_zzi_h4xi // fmla_za_zzi_h4xi
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_h_fmls_za_zzi_h4xi // fmls_za_zzi_h4xi
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_h_bfmla_za_zzi_h4xi // bfmla_za_zzi_h4xi
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_h_bfmls_za_zzi_h4xi // bfmls_za_zzi_h4xi
                        when (_, '00', _, _, _, _, '1x', _, '100', _, _) => // mortlach_multi4_fp8_fdot_idx_h
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field i3l 3 +: 1
                            __field off3 0 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_fp8_fdot_idx_h_fdot_za_z8z8i_4xi // fdot_za_z8z8i_4xi
                        when (_, '00', _, _, _, _, _, _, '101', _, _) => __UNPREDICTABLE
                        when (_, '00', _, _, _, _, _, _, '11x', _, _) => __UNPREDICTABLE
                        when (_, '01', _, _, _, _, _, _, '0xx', _, _) => // mortlach_multi4_zza_idx_s
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 12 +: 1
                            __field i2 10 +: 2
                            __field Zn 7 +: 3
                            __field opc2 3 +: 3
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '000') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_fmla_za_zzi_s4xi // fmla_za_zzi_s4xi
                                when ('0', '001') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_fdot_za32_z8z8i_4xi // fdot_za32_z8z8i_4xi
                                when ('0', '010') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_fmls_za_zzi_s4xi // fmls_za_zzi_s4xi
                                when ('0', '011') => __UNALLOCATED
                                when ('0', '100') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_svdot_za_zzi_s4xi // svdot_za_zzi_s4xi
                                when ('0', '101') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_usvdot_za_zzi_s4xi // usvdot_za_zzi_s4xi
                                when ('0', '110') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_uvdot_za_zzi_s4xi // uvdot_za_zzi_s4xi
                                when ('0', '111') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_suvdot_za_zzi_s4xi // suvdot_za_zzi_s4xi
                                when ('1', '000') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_sdot_za32_zzi_4xi // sdot_za32_zzi_4xi
                                when ('1', '001') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_fdot_za_zzi_4xi // fdot_za_zzi_4xi
                                when ('1', '010') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_udot_za32_zzi_4xi // udot_za32_zzi_4xi
                                when ('1', '011') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_bfdot_za_zzi_4xi // bfdot_za_zzi_4xi
                                when ('1', '100') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_sdot_za_zzi_s4xi // sdot_za_zzi_s4xi
                                when ('1', '101') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_usdot_za_zzi_s4xi // usdot_za_zzi_s4xi
                                when ('1', '110') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_udot_za_zzi_s4xi // udot_za_zzi_s4xi
                                when ('1', '111') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_s_sudot_za_zzi_s4xi // sudot_za_zzi_s4xi
                        when (_, '10', _, _, _, _, '00', _, '00x', _, _) => // mortlach_multi4_mla_long_long_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 1
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 1 +: 2
                            __field o1 0 +: 1
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_d_smlall_za_zzi_d4xi // smlall_za_zzi_d4xi
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_d_smlsll_za_zzi_d4xi // smlsll_za_zzi_d4xi
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_d_umlall_za_zzi_d4xi // umlall_za_zzi_d4xi
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_long_idx_d_umlsll_za_zzi_d4xi // umlsll_za_zzi_d4xi
                        when (_, '10', _, _, _, _, '01', _, '00x', _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '0x', _, '01x', _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, _, '1x', _, '00x', _, _) => // mortlach_multi4_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field op 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_fma_long_idx_fmlal_za_zzi_4xi // fmlal_za_zzi_4xi
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_fma_long_idx_fmlsl_za_zzi_4xi // fmlsl_za_zzi_4xi
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_fma_long_idx_bfmlal_za_zzi_4xi // bfmlal_za_zzi_4xi
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_fma_long_idx_bfmlsl_za_zzi_4xi // bfmlsl_za_zzi_4xi
                        when (_, '10', _, _, _, _, '1x', _, '010', _, _) => // mortlach_multi4_fp8_fma_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i4h 10 +: 2
                            __field Zn 7 +: 3
                            __field i4l 2 +: 2
                            __field off2 0 +: 2
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_fp8_fma_long_idx_fmlal_za_z8z8i_4xi // fmlal_za_z8z8i_4xi
                        when (_, '10', _, _, _, _, '1x', _, '011', _, _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, _, '0x', _, '00x', _, _) => // mortlach_multi4_zza_idx_d
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field op 11 +: 1
                            __field i1 10 +: 1
                            __field Zn 7 +: 3
                            __field opc2 3 +: 2
                            __field off3 0 +: 3
                            case (op, opc2) of
                                when ('0', '00') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_d_fmla_za_zzi_d4xi // fmla_za_zzi_d4xi
                                when ('0', '01') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_d_sdot_za_zzi_d4xi // sdot_za_zzi_d4xi
                                when ('0', '10') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_d_fmls_za_zzi_d4xi // fmls_za_zzi_d4xi
                                when ('0', '11') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_d_udot_za_zzi_d4xi // udot_za_zzi_d4xi
                                when ('1', 'x0') => __UNALLOCATED
                                when ('1', '01') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_d_svdot_za_zzi_d4xi // svdot_za_zzi_d4xi
                                when ('1', '11') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_zza_idx_d_uvdot_za_zzi_d4xi // uvdot_za_zzi_d4xi
                        when (_, '11', _, _, _, _, '1x', _, '00x', _, _) => // mortlach_multi4_mla_long_idx
                            __field Zm 16 +: 4
                            __field Rv 13 +: 2
                            __field i3h 10 +: 2
                            __field Zn 7 +: 3
                            __field U 4 +: 1
                            __field S 3 +: 1
                            __field i3l 2 +: 1
                            __field off2 0 +: 2
                            case (U, S) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_idx_smlal_za_zzi_4xi // smlal_za_zzi_4xi
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_idx_smlsl_za_zzi_4xi // smlsl_za_zzi_4xi
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_idx_umlal_za_zzi_4xi // umlal_za_zzi_4xi
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_indexed_3_mortlach_multi4_mla_long_idx_umlsl_za_zzi_4xi // umlsl_za_zzi_4xi
                        when (_, '11', _, _, _, _, _, _, '01x', _, _) => __UNPREDICTABLE
                        when (_, !'00', _, _, _, _, _, _, '1xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxxx10100x', _, _) =>
                    // mortlach_multi_sve_2a
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 11 +: 5, 10 +: 1, 8 +: 2, 5 +: 3, 0 +: 5) of
                        when (_, _, _, _, _, '0', '00', '00x', _) => // mortlach_multi2_z_z_minmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (op, U) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_minmax_sm_smax_mz_zzv_2x1 // smax_mz_zzv_2x1
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_minmax_sm_umax_mz_zzv_2x1 // umax_mz_zzv_2x1
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_minmax_sm_smin_mz_zzv_2x1 // smin_mz_zzv_2x1
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_minmax_sm_umin_mz_zzv_2x1 // umin_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '00', '101', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '01', '00x', _) => // mortlach_multi2_z_z_fminmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 1 +: 4
                            __field o2 0 +: 1
                            case (size, op, o2) of
                                when ('00', '0', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fminmax_sm_bfmax_mz_zzv_2x1 // bfmax_mz_zzv_2x1
                                when ('00', '0', '1') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fminmax_sm_bfmin_mz_zzv_2x1 // bfmin_mz_zzv_2x1
                                when ('00', '1', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fminmax_sm_bfmaxnm_mz_zzv_2x1 // bfmaxnm_mz_zzv_2x1
                                when ('00', '1', '1') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fminmax_sm_bfminnm_mz_zzv_2x1 // bfminnm_mz_zzv_2x1
                                when (!'00', '0', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fminmax_sm_fmax_mz_zzv_2x1 // fmax_mz_zzv_2x1
                                when (!'00', '0', '1') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fminmax_sm_fmin_mz_zzv_2x1 // fmin_mz_zzv_2x1
                                when (!'00', '1', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fminmax_sm_fmaxnm_mz_zzv_2x1 // fmaxnm_mz_zzv_2x1
                                when (!'00', '1', '1') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fminmax_sm_fminnm_mz_zzv_2x1 // fminnm_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '01', '100', _) => // mortlach_multi2_z_z_fscale_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 1 +: 4
                            __field op 0 +: 1
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fscale_sm_bfscale_mz_zzv_2x1 // bfscale_mz_zzv_2x1
                                when (!'00', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_fscale_sm_fscale_mz_zzv_2x1 // fscale_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '01', '101', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '0x', 'x1x', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '10', _, _) => // mortlach_multi2_z_z_shift_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field opc 5 +: 3
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (opc, U) of
                                when (!'001', _) => __UNALLOCATED
                                when ('001', '0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_shift_sm_srshl_mz_zzv_2x1 // srshl_mz_zzv_2x1
                                when ('001', '1') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_shift_sm_urshl_mz_zzv_2x1 // urshl_mz_zzv_2x1
                        when (_, _, _, _, _, '0', '11', '000', _) => // mortlach_multi2_z_z_add_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_add_sm_add_mz_zzv_2x1 // add_mz_zzv_2x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '0', '11', !'000', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00', '000', _) => // mortlach_multi2_z_z_sqdmulh_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_2a_mortlach_multi2_z_z_sqdmulh_sm_sqdmulh_mz_zzv_2x1 // sqdmulh_mz_zzv_2x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '1', '00', 'x10', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00', 'xx1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', !'00', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00', '100', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxxx10101x', _, 'xxxx0x') =>
                    // mortlach_multi_sve_2b
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 11 +: 5, 10 +: 1, 8 +: 2, 5 +: 3, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, _, _, _, _, '0', '00', '00x', _, _, _) => // mortlach_multi4_z_z_minmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (op, U) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_minmax_sm_smax_mz_zzv_4x1 // smax_mz_zzv_4x1
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_minmax_sm_umax_mz_zzv_4x1 // umax_mz_zzv_4x1
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_minmax_sm_smin_mz_zzv_4x1 // smin_mz_zzv_4x1
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_minmax_sm_umin_mz_zzv_4x1 // umin_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '00', '101', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '01', '00x', _, _, _) => // mortlach_multi4_z_z_fminmax_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field op 5 +: 1
                            __field Zdn 2 +: 3
                            __field o2 0 +: 1
                            case (size, op, o2) of
                                when ('00', '0', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fminmax_sm_bfmax_mz_zzv_4x1 // bfmax_mz_zzv_4x1
                                when ('00', '0', '1') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fminmax_sm_bfmin_mz_zzv_4x1 // bfmin_mz_zzv_4x1
                                when ('00', '1', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fminmax_sm_bfmaxnm_mz_zzv_4x1 // bfmaxnm_mz_zzv_4x1
                                when ('00', '1', '1') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fminmax_sm_bfminnm_mz_zzv_4x1 // bfminnm_mz_zzv_4x1
                                when (!'00', '0', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fminmax_sm_fmax_mz_zzv_4x1 // fmax_mz_zzv_4x1
                                when (!'00', '0', '1') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fminmax_sm_fmin_mz_zzv_4x1 // fmin_mz_zzv_4x1
                                when (!'00', '1', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fminmax_sm_fmaxnm_mz_zzv_4x1 // fmaxnm_mz_zzv_4x1
                                when (!'00', '1', '1') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fminmax_sm_fminnm_mz_zzv_4x1 // fminnm_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '01', '100', _, _, _) => // mortlach_multi4_z_z_fscale_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 2 +: 3
                            __field op 0 +: 1
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fscale_sm_bfscale_mz_zzv_4x1 // bfscale_mz_zzv_4x1
                                when (!'00', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_fscale_sm_fscale_mz_zzv_4x1 // fscale_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '01', '101', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '0x', 'x1x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '0', '10', _, _, _, _) => // mortlach_multi4_z_z_shift_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field opc 5 +: 3
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (opc, U) of
                                when (!'001', _) => __UNALLOCATED
                                when ('001', '0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_shift_sm_srshl_mz_zzv_4x1 // srshl_mz_zzv_4x1
                                when ('001', '1') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_shift_sm_urshl_mz_zzv_4x1 // urshl_mz_zzv_4x1
                        when (_, _, _, _, _, '0', '11', '000', _, _, _) => // mortlach_multi4_z_z_add_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 2 +: 3
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_add_sm_add_mz_zzv_4x1 // add_mz_zzv_4x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '0', '11', !'000', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00', '000', _, _, _) => // mortlach_multi4_z_z_sqdmulh_sm
                            __field size 22 +: 2
                            __field Zm 16 +: 4
                            __field Zdn 2 +: 3
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_2b_mortlach_multi4_z_z_sqdmulh_sm_sqdmulh_mz_zzv_4x1 // sqdmulh_mz_zzv_4x1
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '1', '00', 'x10', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', '00', 'xx1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '1', !'00', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00', '100', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx10xxxx10101x', _, 'xxxx1x') => __UNPREDICTABLE
                when (_, '10', _, '1xx11xxxx1010xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxx00101110', _, 'xxxx0x') =>
                    // mortlach_multi_sve_2d0
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 10 +: 8, 7 +: 3, 2 +: 5, 1 +: 1, 0 +: 1) of
                        when (_, _, _, _, _, '000', _, _, _) => // mortlach_multi4_z_z_minmax_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 2
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_minmax_mm_smax_mz_zzw_4x4 // smax_mz_zzw_4x4
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_minmax_mm_umax_mz_zzw_4x4 // umax_mz_zzw_4x4
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_minmax_mm_smin_mz_zzw_4x4 // smin_mz_zzw_4x4
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_minmax_mm_umin_mz_zzw_4x4 // umin_mz_zzw_4x4
                                when ('1x', _) => __UNALLOCATED
                        when (_, _, _, _, _, '001', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '010', _, _, _) => // mortlach_multi4_z_z_fminmax_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 2
                            __field Zdn 2 +: 3
                            __field o2 0 +: 1
                            case (size, opc, o2) of
                                when (_, '10', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_famax_mz_zzw_4x4 // famax_mz_zzw_4x4
                                when (_, '10', '1') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_famin_mz_zzw_4x4 // famin_mz_zzw_4x4
                                when (_, '11', _) => __UNALLOCATED
                                when ('00', '00', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_bfmax_mz_zzw_4x4 // bfmax_mz_zzw_4x4
                                when ('00', '00', '1') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_bfmin_mz_zzw_4x4 // bfmin_mz_zzw_4x4
                                when ('00', '01', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_bfmaxnm_mz_zzw_4x4 // bfmaxnm_mz_zzw_4x4
                                when ('00', '01', '1') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_bfminnm_mz_zzw_4x4 // bfminnm_mz_zzw_4x4
                                when (!'00', '00', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_fmax_mz_zzw_4x4 // fmax_mz_zzw_4x4
                                when (!'00', '00', '1') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_fmin_mz_zzw_4x4 // fmin_mz_zzw_4x4
                                when (!'00', '01', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_fmaxnm_mz_zzw_4x4 // fmaxnm_mz_zzw_4x4
                                when (!'00', '01', '1') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fminmax_mm_fminnm_mz_zzw_4x4 // fminnm_mz_zzw_4x4
                        when (_, _, _, _, _, '011', _, _, _) => // mortlach_multi4_z_z_fscale_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 2
                            __field Zdn 2 +: 3
                            __field o2 0 +: 1
                            case (size, opc, o2) of
                                when (_, !'00', _) => __UNALLOCATED
                                when (_, '00', '1') => __UNALLOCATED
                                when ('00', '00', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fscale_mm_bfscale_mz_zzw_4x4 // bfscale_mz_zzw_4x4
                                when (!'00', '00', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_fscale_mm_fscale_mz_zzw_4x4 // fscale_mz_zzw_4x4
                        when (_, _, _, _, _, '10x', _, _, _) => // mortlach_multi4_z_z_shift_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field opc 5 +: 3
                            __field Zdn 2 +: 3
                            __field U 0 +: 1
                            case (opc, U) of
                                when (!'001', _) => __UNALLOCATED
                                when ('001', '0') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_shift_mm_srshl_mz_zzw_4x4 // srshl_mz_zzw_4x4
                                when ('001', '1') => __encoding A64_sme_mortlach_multi_sve_2d0_mortlach_multi4_z_z_shift_mm_urshl_mz_zzw_4x4 // urshl_mz_zzw_4x4
                        when (_, _, _, _, _, '11x', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxx00101111', _, 'xxxx0x') =>
                    // mortlach_multi_sve_2d1
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 10 +: 8, 5 +: 5, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, _, _, _, _, '00000', _, _, _) => // mortlach_multi4_z_z_sqdmulh_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field Zdn 2 +: 3
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_2d1_mortlach_multi4_z_z_sqdmulh_mm_sqdmulh_mz_zzw_4x4 // sqdmulh_mz_zzw_4x4
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, !'00000', _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxx0010111x', _, 'xxxx1x') => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxx1010111x', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxx0101100', _, _) =>
                    // mortlach_multi_sve_2c0
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 10 +: 7, 7 +: 3, 6 +: 1, 0 +: 6) of
                        when (_, _, _, _, _, '000', _, _) => // mortlach_multi2_z_z_minmax_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 2
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (opc, U) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_minmax_mm_smax_mz_zzw_2x2 // smax_mz_zzw_2x2
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_minmax_mm_umax_mz_zzw_2x2 // umax_mz_zzw_2x2
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_minmax_mm_smin_mz_zzw_2x2 // smin_mz_zzw_2x2
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_minmax_mm_umin_mz_zzw_2x2 // umin_mz_zzw_2x2
                                when ('1x', _) => __UNALLOCATED
                        when (_, _, _, _, _, '001', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '010', _, _) => // mortlach_multi2_z_z_fminmax_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 2
                            __field Zdn 1 +: 4
                            __field o2 0 +: 1
                            case (size, opc, o2) of
                                when (_, '10', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_famax_mz_zzw_2x2 // famax_mz_zzw_2x2
                                when (_, '10', '1') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_famin_mz_zzw_2x2 // famin_mz_zzw_2x2
                                when (_, '11', _) => __UNALLOCATED
                                when ('00', '00', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_bfmax_mz_zzw_2x2 // bfmax_mz_zzw_2x2
                                when ('00', '00', '1') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_bfmin_mz_zzw_2x2 // bfmin_mz_zzw_2x2
                                when ('00', '01', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_bfmaxnm_mz_zzw_2x2 // bfmaxnm_mz_zzw_2x2
                                when ('00', '01', '1') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_bfminnm_mz_zzw_2x2 // bfminnm_mz_zzw_2x2
                                when (!'00', '00', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_fmax_mz_zzw_2x2 // fmax_mz_zzw_2x2
                                when (!'00', '00', '1') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_fmin_mz_zzw_2x2 // fmin_mz_zzw_2x2
                                when (!'00', '01', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_fmaxnm_mz_zzw_2x2 // fmaxnm_mz_zzw_2x2
                                when (!'00', '01', '1') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fminmax_mm_fminnm_mz_zzw_2x2 // fminnm_mz_zzw_2x2
                        when (_, _, _, _, _, '011', _, _) => // mortlach_multi2_z_z_fscale_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 2
                            __field Zdn 1 +: 4
                            __field o2 0 +: 1
                            case (size, opc, o2) of
                                when (_, !'00', _) => __UNALLOCATED
                                when (_, '00', '1') => __UNALLOCATED
                                when ('00', '00', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fscale_mm_bfscale_mz_zzw_2x2 // bfscale_mz_zzw_2x2
                                when (!'00', '00', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_fscale_mm_fscale_mz_zzw_2x2 // fscale_mz_zzw_2x2
                        when (_, _, _, _, _, '10x', _, _) => // mortlach_multi2_z_z_shift_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field opc 5 +: 3
                            __field Zdn 1 +: 4
                            __field U 0 +: 1
                            case (opc, U) of
                                when (!'001', _) => __UNALLOCATED
                                when ('001', '0') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_shift_mm_srshl_mz_zzw_2x2 // srshl_mz_zzw_2x2
                                when ('001', '1') => __encoding A64_sme_mortlach_multi_sve_2c0_mortlach_multi2_z_z_shift_mm_urshl_mz_zzw_2x2 // urshl_mz_zzw_2x2
                        when (_, _, _, _, _, '11x', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxx0101101', _, _) =>
                    // mortlach_multi_sve_2c1
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 10 +: 7, 5 +: 5, 0 +: 5) of
                        when (_, _, _, _, _, '00000', _) => // mortlach_multi2_z_z_sqdmulh_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field Zdn 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_2c1_mortlach_multi2_z_z_sqdmulh_mm_sqdmulh_mz_zzw_2x2 // sqdmulh_mz_zzw_2x2
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, !'00000', _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxx01111xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxx11x11xx', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx100xxx', _, _) =>
                    // mortlach_multi_sve_1
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 7 +: 6, 5 +: 2, 2 +: 3, 0 +: 2) of
                        when (_, _, _, _, '01', _, _, '00', _, '00') => // mortlach_multi4_select_int
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field PNg 10 +: 3
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_sve_1_mortlach_multi4_select_int_sel_mz_p_zz_4 // sel_mz_p_zz_4
                        when (_, _, _, _, '01', _, _, '00', _, '10') => __UNPREDICTABLE
                        when (_, _, _, _, '01', _, _, '10', _, 'x0') => __UNPREDICTABLE
                        when (_, _, _, _, '11', _, _, 'x0', _, 'x0') => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, 'x0', _, 'x0') => // mortlach_multi2_select_int
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field PNg 10 +: 3
                            __field Zn 6 +: 4
                            __field Zd 1 +: 4
                            case () of
                                when () => __encoding A64_sme_mortlach_multi_sve_1_mortlach_multi2_select_int_sel_mz_p_zz_2 // sel_mz_p_zz_2
                        when (_, _, _, _, _, _, _, 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, 'x1', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx110xxx', _, _) =>
                    // mortlach_multi_sve_3
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 2 +: 8, 1 +: 1, 0 +: 1) of
                        when (_, '00', _, _, _, '101', _, _, _) => // mortlach_multi2_z_z_long_zip
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_z_z_long_zip_zip_mz_zz_2q // zip_mz_zz_2q
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_z_z_long_zip_uzp_mz_zz_2q // uzp_mz_zz_2q
                        when (_, '01', _, _, _, '101', _, _, _) => __UNPREDICTABLE
                        when (_, '10', _, _, _, '101', _, _, _) => __UNPREDICTABLE
                        when (_, '11', _, _, _, '101', _, _, _) => // mortlach_multi2_qrshr
                            __field op 20 +: 1
                            __field imm4 16 +: 4
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_qrshr_sqrshr_z_mz2_ // sqrshr_z_mz2_
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_qrshr_uqrshr_z_mz2_ // uqrshr_z_mz2_
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_qrshr_sqrshru_z_mz2_ // sqrshru_z_mz2_
                                when ('1', '1') => __UNALLOCATED
                        when (_, _, _, _, _, '000', _, _, _) => // mortlach_multi2_fclamp
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field op 0 +: 1
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_fclamp_bfclamp_mz_zz_2 // bfclamp_mz_zz_2
                                when (!'00', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_fclamp_fclamp_mz_zz_2 // fclamp_mz_zz_2
                        when (_, _, _, _, _, '001', _, _, _) => // mortlach_multi2_clamp_int
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_clamp_int_sclamp_mz_zz_2 // sclamp_mz_zz_2
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_clamp_int_uclamp_mz_zz_2 // uclamp_mz_zz_2
                        when (_, _, _, _, _, '010', _, '0', _) => // mortlach_multi4_fclamp
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            __field op 0 +: 1
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_fclamp_bfclamp_mz_zz_4 // bfclamp_mz_zz_4
                                when (!'00', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_fclamp_fclamp_mz_zz_4 // fclamp_mz_zz_4
                        when (_, _, _, _, _, '011', _, '0', _) => // mortlach_multi4_clamp_int
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 2 +: 3
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_clamp_int_sclamp_mz_zz_4 // sclamp_mz_zz_4
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_clamp_int_uclamp_mz_zz_4 // uclamp_mz_zz_4
                        when (_, _, _, _, _, '01x', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '100', _, _, _) => // mortlach_multi2_z_z_zip
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field op 0 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_z_z_zip_zip_mz_zz_2 // zip_mz_zz_2
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi2_z_z_zip_uzp_mz_zz_2 // uzp_mz_zz_2
                        when (_, _, _, _, _, '11x', _, _, _) => // mortlach_multi4_qrshr
                            __field tsize 22 +: 2
                            __field imm5 16 +: 5
                            __field N 10 +: 1
                            __field Zn 7 +: 3
                            __field op 6 +: 1
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (N, op, U) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_qrshr_sqrshr_z_mz4_ // sqrshr_z_mz4_
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_qrshr_uqrshr_z_mz4_ // uqrshr_z_mz4_
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_qrshr_sqrshru_z_mz4_ // sqrshru_z_mz4_
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_qrshr_sqrshrn_z_mz4_ // sqrshrn_z_mz4_
                                when ('1', '0', '1') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_qrshr_uqrshrn_z_mz4_ // uqrshrn_z_mz4_
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_sve_3_mortlach_multi4_qrshr_sqrshrun_z_mz4_ // sqrshrun_z_mz4_
                when (_, '10', _, '1xx1xxxxx111000', _, _) =>
                    // mortlach_multi_sve_4
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 10 +: 6, 7 +: 3, 5 +: 2, 2 +: 3, 0 +: 2) of
                        when (_, '00', _, '000', '01', _, _, _, _, 'x0') => // mortlach_multi2_fpint_cvrt
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 1 +: 4
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_fpint_cvrt_fcvtzs_mz_z_2 // fcvtzs_mz_z_2
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_fpint_cvrt_fcvtzu_mz_z_2 // fcvtzu_mz_z_2
                        when (_, '00', _, '000', '10', _, _, _, _, 'x0') => // mortlach_multi2_intfp_cvrt
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 1 +: 4
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_intfp_cvrt_scvtf_mz_z_2 // scvtf_mz_z_2
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_intfp_cvrt_ucvtf_mz_z_2 // ucvtf_mz_z_2
                        when (_, '00', _, '001', '11', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '00', _, '100', '01', _, _, '0x', _, '00') => // mortlach_multi4_fpint_cvrt
                            __field Zn 7 +: 3
                            __field U 5 +: 1
                            __field Zd 2 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_fpint_cvrt_fcvtzs_mz_z_4 // fcvtzs_mz_z_4
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_fpint_cvrt_fcvtzu_mz_z_4 // fcvtzu_mz_z_4
                        when (_, '00', _, '100', '10', _, _, '0x', _, '00') => // mortlach_multi4_intfp_cvrt
                            __field Zn 7 +: 3
                            __field U 5 +: 1
                            __field Zd 2 +: 3
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_intfp_cvrt_scvtf_mz_z_4 // scvtf_mz_z_4
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_intfp_cvrt_ucvtf_mz_z_4 // ucvtf_mz_z_4
                        when (_, '00', _, '101', '00', _, _, '0x', _, _) => // mortlach_multi4_narrow_fp8_cvrt
                            __field Zn 7 +: 3
                            __field N 5 +: 1
                            __field Zd 0 +: 5
                            case (N) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_narrow_fp8_cvrt_fcvt_z8_mz4_ // fcvt_z8_mz4_
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_narrow_fp8_cvrt_fcvtn_z8_mz4_ // fcvtn_z8_mz4_
                        when (_, '00', _, '101', '11', _, _, '00', _, 'x0') => // mortlach_multi4_z_z_long_zip
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            __field op 1 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_z_z_long_zip_zip_mz_z_4q // zip_mz_z_4q
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_z_z_long_zip_uzp_mz_z_4q // uzp_mz_z_4q
                        when (_, '01', _, '000', '01', _, _, _, _, 'x0') => __UNPREDICTABLE
                        when (_, '01', _, '101', '00', _, _, '0x', _, '1x') => __UNPREDICTABLE
                        when (_, '01', _, '10x', '00', _, _, '0x', _, '0x') => __UNPREDICTABLE
                        when (_, '0x', _, '000', '00', _, _, _, _, _) => // mortlach_multi2_narrow_fp_cvrt
                            __field op 22 +: 1
                            __field Zn 6 +: 4
                            __field N 5 +: 1
                            __field Zd 0 +: 5
                            case (op, N) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_fp_cvrt_fcvt_z_mz2_ // fcvt_z_mz2_
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_fp_cvrt_fcvtn_z_mz2_ // fcvtn_z_mz2_
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_fp_cvrt_bfcvt_z_mz2_ // bfcvt_z_mz2_
                                when ('1', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_fp_cvrt_bfcvtn_z_mz2_ // bfcvtn_z_mz2_
                        when (_, '0x', _, '000', '11', _, _, _, _, _) => // mortlach_multi2_narrow_int_cvrt
                            __field op 22 +: 1
                            __field Zn 6 +: 4
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_int_cvrt_sqcvt_z_mz2_ // sqcvt_z_mz2_
                                when ('0', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_int_cvrt_uqcvt_z_mz2_ // uqcvt_z_mz2_
                                when ('1', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_int_cvrt_sqcvtu_z_mz2_ // sqcvtu_z_mz2_
                                when ('1', '1') => __UNALLOCATED
                        when (_, '0x', _, '001', '00', _, _, 'x0', _, _) => // mortlach_multi2_narrow_fp8_cvrt
                            __field op 22 +: 1
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_fp8_cvrt_fcvt_z8_mz2_ // fcvt_z8_mz2_
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_narrow_fp8_cvrt_bfcvt_z8_mz2_ // bfcvt_z8_mz2_
                        when (_, '0x', _, '001', '00', _, _, 'x1', _, _) => __UNPREDICTABLE
                        when (_, '10', _, '000', '00', _, _, _, _, _) => // mortlach_multi2_wide_fp_cvrt
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field L 0 +: 1
                            case (L) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp_cvrt_fcvt_mz2_z_ // fcvt_mz2_z_
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp_cvrt_fcvtl_mz2_z_ // fcvtl_mz2_z_
                        when (_, '10', _, '001', '00', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, '10', _, 'x01', '00', _, _, '0x', _, _) => __UNPREDICTABLE
                        when (_, '11', _, '00x', '00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '11', _, '101', '00', _, _, '0x', _, '1x') => __UNPREDICTABLE
                        when (_, '11', _, '10x', '00', _, _, '0x', _, '0x') => __UNPREDICTABLE
                        when (_, '1x', _, '000', '11', _, _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, '1x', _, '000', 'x1', _, _, _, _, 'x0') => __UNPREDICTABLE
                        when (_, 'x0', _, '100', '00', _, _, '0x', _, '0x') => __UNPREDICTABLE
                        when (_, _, _, '000', '01', _, _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, !'00', _, '000', '10', _, _, _, _, 'x0') => __UNPREDICTABLE
                        when (_, _, _, '000', '10', _, _, _, _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, '001', '01', _, _, _, _, _) => // mortlach_multi2_wide_int
                            __field size 22 +: 2
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_int_sunpk_mz_z_2 // sunpk_mz_z_2
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_int_uunpk_mz_z_2 // uunpk_mz_z_2
                        when (_, _, _, '001', '10', _, _, _, _, _) => // mortlach_multi2_wide_fp8_cvrt
                            __field opc 22 +: 2
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            __field L 0 +: 1
                            case (opc, L) of
                                when ('00', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp8_cvrt_f1cvt_mz2_z8_ // f1cvt_mz2_z8_
                                when ('00', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp8_cvrt_f1cvtl_mz2_z8_ // f1cvtl_mz2_z8_
                                when ('01', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp8_cvrt_bf1cvt_mz2_z8_ // bf1cvt_mz2_z8_
                                when ('01', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp8_cvrt_bf1cvtl_mz2_z8_ // bf1cvtl_mz2_z8_
                                when ('10', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp8_cvrt_f2cvt_mz2_z8_ // f2cvt_mz2_z8_
                                when ('10', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp8_cvrt_f2cvtl_mz2_z8_ // f2cvtl_mz2_z8_
                                when ('11', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp8_cvrt_bf2cvt_mz2_z8_ // bf2cvt_mz2_z8_
                                when ('11', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_wide_fp8_cvrt_bf2cvtl_mz2_z8_ // bf2cvtl_mz2_z8_
                        when (_, !'00', _, '001', '11', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '01x', _, _, _, 'x0', _, 'x0') => // mortlach_multi2_frint
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Zn 6 +: 4
                            __field Zd 1 +: 4
                            case (size, opc) of
                                when (!'10', _) => __UNALLOCATED
                                when ('10', '000') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_frint_frintn_mz_z_2 // frintn_mz_z_2
                                when ('10', '001') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_frint_frintp_mz_z_2 // frintp_mz_z_2
                                when ('10', '010') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_frint_frintm_mz_z_2 // frintm_mz_z_2
                                when ('10', '011') => __UNALLOCATED
                                when ('10', '100') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi2_frint_frinta_mz_z_2 // frinta_mz_z_2
                                when ('10', '101') => __UNALLOCATED
                                when ('10', '11x') => __UNALLOCATED
                        when (_, !'00', _, '100', '01', _, _, '0x', _, '00') => __UNPREDICTABLE
                        when (_, _, _, '100', '01', _, _, '0x', _, '01') => __UNPREDICTABLE
                        when (_, _, _, '100', '01', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '100', '10', _, _, '0x', _, '00') => __UNPREDICTABLE
                        when (_, _, _, '100', '10', _, _, '0x', _, '01') => __UNPREDICTABLE
                        when (_, _, _, '100', '11', _, _, _, _, _) => // mortlach_multi4_narrow_int_cvrt
                            __field sz 23 +: 1
                            __field op 22 +: 1
                            __field Zn 7 +: 3
                            __field N 6 +: 1
                            __field U 5 +: 1
                            __field Zd 0 +: 5
                            case (op, N, U) of
                                when ('0', '0', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_narrow_int_cvrt_sqcvt_z_mz4_ // sqcvt_z_mz4_
                                when ('0', '0', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_narrow_int_cvrt_uqcvt_z_mz4_ // uqcvt_z_mz4_
                                when ('0', '1', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_narrow_int_cvrt_sqcvtn_z_mz4_ // sqcvtn_z_mz4_
                                when ('0', '1', '1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_narrow_int_cvrt_uqcvtn_z_mz4_ // uqcvtn_z_mz4_
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_narrow_int_cvrt_sqcvtu_z_mz4_ // sqcvtu_z_mz4_
                                when ('1', '1', '0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_narrow_int_cvrt_sqcvtun_z_mz4_ // sqcvtun_z_mz4_
                        when (_, _, _, '100', !'11', _, _, '0x', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, '101', '01', _, _, 'x0', _, '0x') => // mortlach_multi4_wide_int
                            __field size 22 +: 2
                            __field Zn 6 +: 4
                            __field Zd 2 +: 3
                            __field U 0 +: 1
                            case (U) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_wide_int_sunpk_mz_z_4 // sunpk_mz_z_4
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_wide_int_uunpk_mz_z_4 // uunpk_mz_z_4
                        when (_, _, _, '101', '01', _, _, 'x0', _, '1x') => __UNPREDICTABLE
                        when (_, _, _, '101', '01', _, _, 'x1', _, _) => __UNPREDICTABLE
                        when (_, _, _, '101', '10', _, _, '00', _, 'x0') => // mortlach_multi4_z_z_zip
                            __field size 22 +: 2
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            __field op 1 +: 1
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_z_z_zip_zip_mz_z_4 // zip_mz_z_4
                                when ('1') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_z_z_zip_uzp_mz_z_4 // uzp_mz_z_4
                        when (_, !'00', _, '101', '11', _, _, '00', _, 'x0') => __UNPREDICTABLE
                        when (_, _, _, '101', '11', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, _, _, '101', '1x', _, _, '00', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, '101', '1x', _, _, '01', _, _) => __UNPREDICTABLE
                        when (_, _, _, '10x', 'x0', _, _, '1x', _, _) => __UNPREDICTABLE
                        when (_, _, _, '11x', _, _, _, '00', _, '00') => // mortlach_multi4_frint
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            case (size, opc) of
                                when (!'10', _) => __UNALLOCATED
                                when ('10', '000') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_frint_frintn_mz_z_4 // frintn_mz_z_4
                                when ('10', '001') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_frint_frintp_mz_z_4 // frintp_mz_z_4
                                when ('10', '010') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_frint_frintm_mz_z_4 // frintm_mz_z_4
                                when ('10', '011') => __UNALLOCATED
                                when ('10', '100') => __encoding A64_sme_mortlach_multi_sve_4_mortlach_multi4_frint_frinta_mz_z_4 // frinta_mz_z_4
                                when ('10', '101') => __UNALLOCATED
                                when ('10', '11x') => __UNALLOCATED
                        when (_, _, _, '11x', _, _, _, '00', _, '10') => __UNPREDICTABLE
                        when (_, _, _, '11x', _, _, _, '10', _, 'x0') => __UNPREDICTABLE
                        when (_, _, _, 'x1x', _, _, _, 'x0', _, 'x1') => __UNPREDICTABLE
                        when (_, _, _, 'x1x', _, _, _, 'x1', _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx111001', _, '0xxxx0') =>
                    // mortlach_multi_sve_5a
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 10 +: 6, 7 +: 3, 6 +: 1, 5 +: 1, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, _, _, _, '01', _, _, '0', _, _, '0', _) => // mortlach_multi4_fmul_mm
                            __field size 22 +: 2
                            __field Zm 18 +: 3
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            case (size) of
                                when ('00') => __encoding A64_sme_mortlach_multi_sve_5a_mortlach_multi4_fmul_mm_bfmul_mz_zzw_4x4 // bfmul_mz_zzw_4x4
                                when (!'00') => __encoding A64_sme_mortlach_multi_sve_5a_mortlach_multi4_fmul_mm_fmul_mz_zzw_4x4 // fmul_mz_zzw_4x4
                        when (_, _, _, _, '01', _, _, '0', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, '01', _, _, '1', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '11', _, _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x0', _, _, _, _, _, _, _) => // mortlach_multi2_fmul_mm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field Zn 6 +: 4
                            __field Zd 1 +: 4
                            case (size) of
                                when ('00') => __encoding A64_sme_mortlach_multi_sve_5a_mortlach_multi2_fmul_mm_bfmul_mz_zzw_2x2 // bfmul_mz_zzw_2x2
                                when (!'00') => __encoding A64_sme_mortlach_multi_sve_5a_mortlach_multi2_fmul_mm_fmul_mz_zzw_2x2 // fmul_mz_zzw_2x2
                when (_, '10', _, '1xx1xxxxx111001', _, '0xxxx1') => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx111001', _, '1xxxxx') => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx111010', _, '0xxxx0') =>
                    // mortlach_multi_sve_5b
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 16 +: 1, 10 +: 6, 7 +: 3, 6 +: 1, 5 +: 1, 2 +: 3, 1 +: 1, 0 +: 1) of
                        when (_, _, _, _, '0', _, _, _, _, _, _, _) => // mortlach_multi2_fmul_sm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field Zn 6 +: 4
                            __field Zd 1 +: 4
                            case (size) of
                                when ('00') => __encoding A64_sme_mortlach_multi_sve_5b_mortlach_multi2_fmul_sm_bfmul_mz_zzv_2x1 // bfmul_mz_zzv_2x1
                                when (!'00') => __encoding A64_sme_mortlach_multi_sve_5b_mortlach_multi2_fmul_sm_fmul_mz_zzv_2x1 // fmul_mz_zzv_2x1
                        when (_, _, _, _, '1', _, _, '0', _, _, '0', _) => // mortlach_multi4_fmul_sm
                            __field size 22 +: 2
                            __field Zm 17 +: 4
                            __field Zn 7 +: 3
                            __field Zd 2 +: 3
                            case (size) of
                                when ('00') => __encoding A64_sme_mortlach_multi_sve_5b_mortlach_multi4_fmul_sm_bfmul_mz_zzv_4x1 // bfmul_mz_zzv_4x1
                                when (!'00') => __encoding A64_sme_mortlach_multi_sve_5b_mortlach_multi4_fmul_sm_fmul_mz_zzv_4x1 // fmul_mz_zzv_4x1
                        when (_, _, _, _, '1', _, _, '0', _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, '1', _, _, '1', _, _, _, _) => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx111010', _, '0xxxx1') => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx111010', _, '1xxxxx') => __UNPREDICTABLE
                when (_, '10', _, '1xx1xxxxx111011', _, _) => __UNPREDICTABLE
                when (_, '11', _, _, _, _) =>
                    // mortlach_mem
                    case (25 +: 7, 21 +: 4, 16 +: 5, 15 +: 1, 10 +: 5, 5 +: 5, 2 +: 3, 0 +: 2) of
                        when (_, '0xx0', _, _, _, _, '0xx', _) => // mortlach_contig_load
                            __field msz 22 +: 2
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field opc 0 +: 4
                            case (msz) of
                                when ('00') => __encoding A64_sme_mortlach_mem_mortlach_contig_load_ld1b_za_p_rrr_ // ld1b_za_p_rrr_
                                when ('01') => __encoding A64_sme_mortlach_mem_mortlach_contig_load_ld1h_za_p_rrr_ // ld1h_za_p_rrr_
                                when ('10') => __encoding A64_sme_mortlach_mem_mortlach_contig_load_ld1w_za_p_rrr_ // ld1w_za_p_rrr_
                                when ('11') => __encoding A64_sme_mortlach_mem_mortlach_contig_load_ld1d_za_p_rrr_ // ld1d_za_p_rrr_
                        when (_, '0xx1', _, _, _, _, '0xx', _) => // mortlach_contig_store
                            __field msz 22 +: 2
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field opc 0 +: 4
                            case (msz) of
                                when ('00') => __encoding A64_sme_mortlach_mem_mortlach_contig_store_st1b_za_p_rrr_ // st1b_za_p_rrr_
                                when ('01') => __encoding A64_sme_mortlach_mem_mortlach_contig_store_st1h_za_p_rrr_ // st1h_za_p_rrr_
                                when ('10') => __encoding A64_sme_mortlach_mem_mortlach_contig_store_st1w_za_p_rrr_ // st1w_za_p_rrr_
                                when ('11') => __encoding A64_sme_mortlach_mem_mortlach_contig_store_st1d_za_p_rrr_ // st1d_za_p_rrr_
                        when (_, '100x', '00000', '0', 'xx000', _, '0xx', _) => // mortlach_ctxt_ldst
                            __field op 21 +: 1
                            __field Rv 13 +: 2
                            __field Rn 5 +: 5
                            __field imm4 0 +: 4
                            case (op) of
                                when ('0') => __encoding A64_sme_mortlach_mem_mortlach_ctxt_ldst_ldr_za_ri_ // ldr_za_ri_
                                when ('1') => __encoding A64_sme_mortlach_mem_mortlach_ctxt_ldst_str_za_ri_ // str_za_ri_
                        when (_, '100x', !'00000', '0', 'xx000', _, '0xx', _) => __UNPREDICTABLE
                        when (_, '100x', _, '1', '00000', _, '000', _) => // mortlach_zt_ldst
                            __field opc 16 +: 6
                            __field Rn 5 +: 5
                            __field opc2 0 +: 2
                            case (opc, opc2) of
                                when ('x0xxxx', _) => __UNALLOCATED
                                when ('x10xxx', _) => __UNALLOCATED
                                when ('x110xx', _) => __UNALLOCATED
                                when ('x1110x', _) => __UNALLOCATED
                                when ('x11110', _) => __UNALLOCATED
                                when ('x11111', !'00') => __UNALLOCATED
                                when ('011111', '00') => __encoding A64_sme_mortlach_mem_mortlach_zt_ldst_ldr_zt_br_ // ldr_zt_br_
                                when ('111111', '00') => __encoding A64_sme_mortlach_mem_mortlach_zt_ldst_str_zt_br_ // str_zt_br_
                        when (_, '100x', _, '1', '00000', _, '001', _) => __UNPREDICTABLE
                        when (_, '100x', _, '1', '00000', _, '01x', _) => __UNPREDICTABLE
                        when (_, '100x', _, '1', '01000', _, '0xx', _) => __UNPREDICTABLE
                        when (_, '100x', _, '1', '1x000', _, '0xx', _) => __UNPREDICTABLE
                        when (_, '100x', _, _, 'xx001', _, '0xx', _) => __UNPREDICTABLE
                        when (_, '100x', _, _, 'xx01x', _, '0xx', _) => __UNPREDICTABLE
                        when (_, '100x', _, _, 'xx1xx', _, '0xx', _) => __UNPREDICTABLE
                        when (_, '101x', _, _, _, _, '0xx', _) => __UNPREDICTABLE
                        when (_, '110x', _, _, _, _, '0xx', _) => __UNPREDICTABLE
                        when (_, '1110', _, _, _, _, '0xx', _) => // mortlach_contig_qload
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field ZAt 0 +: 4
                            case () of
                                when () => __encoding A64_sme_mortlach_mem_mortlach_contig_qload_ld1q_za_p_rrr_ // ld1q_za_p_rrr_
                        when (_, '1111', _, _, _, _, '0xx', _) => // mortlach_contig_qstore
                            __field Rm 16 +: 5
                            __field V 15 +: 1
                            __field Rs 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field ZAt 0 +: 4
                            case () of
                                when () => __encoding A64_sme_mortlach_mem_mortlach_contig_qstore_st1q_za_p_rrr_ // st1q_za_p_rrr_
                        when (_, _, _, _, _, _, '1xx', _) => __UNPREDICTABLE
        when (_, _, '0010', _) =>
            // sve
            case (29 +: 3, 25 +: 4, 17 +: 8, 16 +: 1, 10 +: 6, 5 +: 5, 4 +: 1, 0 +: 4) of
                when ('000', _, '0xx0xxxx', _, '000xxx', _, _, _) =>
                    // sve_int_pred_bin
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '00x', _, _, _, _, _) => // sve_int_bin_pred_arit_0
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, opc) of
                                when (_, '000') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_0_add_z_p_zz_ // add_z_p_zz_
                                when (_, '001') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_0_sub_z_p_zz_ // sub_z_p_zz_
                                when (_, '010') => __UNALLOCATED
                                when (_, '011') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_0_subr_z_p_zz_ // subr_z_p_zz_
                                when (!'11', '1xx') => __UNALLOCATED
                                when ('11', '100') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_0_addpt_z_p_zz_ // addpt_z_p_zz_
                                when ('11', '101') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_0_subpt_z_p_zz_ // subpt_z_p_zz_
                                when ('11', '11x') => __UNALLOCATED
                        when (_, _, _, '01x', _, _, _, _, _) => // sve_int_bin_pred_arit_1
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, U) of
                                when ('00', '0') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_1_smax_z_p_zz_ // smax_z_p_zz_
                                when ('00', '1') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_1_umax_z_p_zz_ // umax_z_p_zz_
                                when ('01', '0') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_1_smin_z_p_zz_ // smin_z_p_zz_
                                when ('01', '1') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_1_umin_z_p_zz_ // umin_z_p_zz_
                                when ('10', '0') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_1_sabd_z_p_zz_ // sabd_z_p_zz_
                                when ('10', '1') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_1_uabd_z_p_zz_ // uabd_z_p_zz_
                                when ('11', _) => __UNALLOCATED
                        when (_, _, _, '100', _, _, _, _, _) => // sve_int_bin_pred_arit_2
                            __field size 22 +: 2
                            __field H 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (H, U) of
                                when ('0', '0') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_2_mul_z_p_zz_ // mul_z_p_zz_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', '0') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_2_smulh_z_p_zz_ // smulh_z_p_zz_
                                when ('1', '1') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_arit_2_umulh_z_p_zz_ // umulh_z_p_zz_
                        when (_, _, _, '101', _, _, _, _, _) => // sve_int_bin_pred_div
                            __field size 22 +: 2
                            __field R 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, U) of
                                when ('0', '0') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_div_sdiv_z_p_zz_ // sdiv_z_p_zz_
                                when ('0', '1') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_div_udiv_z_p_zz_ // udiv_z_p_zz_
                                when ('1', '0') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_div_sdivr_z_p_zz_ // sdivr_z_p_zz_
                                when ('1', '1') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_div_udivr_z_p_zz_ // udivr_z_p_zz_
                        when (_, _, _, '11x', _, _, _, _, _) => // sve_int_bin_pred_log
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_log_orr_z_p_zz_ // orr_z_p_zz_
                                when ('001') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_log_eor_z_p_zz_ // eor_z_p_zz_
                                when ('010') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_log_and_z_p_zz_ // and_z_p_zz_
                                when ('011') => __encoding A64_sve_sve_int_pred_bin_sve_int_bin_pred_log_bic_z_p_zz_ // bic_z_p_zz_
                                when ('1xx') => __UNALLOCATED
                when ('000', _, '0xx0xxxx', _, '001xxx', _, _, _) =>
                    // sve_int_pred_red
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '000', _, _, _, _, _) => // sve_int_reduce_0
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_0_saddv_r_p_z_ // saddv_r_p_z_
                                when ('0', '1') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_0_uaddv_r_p_z_ // uaddv_r_p_z_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '001', _, _, _, _, _) => // sve_int_reduce_0q
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __UNALLOCATED
                                when ('0', '1') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_0q_addqv_z_p_z_ // addqv_z_p_z_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '010', _, _, _, _, _) => // sve_int_reduce_1
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_1_smaxv_r_p_z_ // smaxv_r_p_z_
                                when ('0', '1') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_1_umaxv_r_p_z_ // umaxv_r_p_z_
                                when ('1', '0') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_1_sminv_r_p_z_ // sminv_r_p_z_
                                when ('1', '1') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_1_uminv_r_p_z_ // uminv_r_p_z_
                        when (_, _, _, '011', _, _, _, _, _) => // sve_int_reduce_1q
                            __field op 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (op, U) of
                                when ('0', '0') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_1q_smaxqv_z_p_z_ // smaxqv_z_p_z_
                                when ('0', '1') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_1q_umaxqv_z_p_z_ // umaxqv_z_p_z_
                                when ('1', '0') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_1q_sminqv_z_p_z_ // sminqv_z_p_z_
                                when ('1', '1') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_1q_uminqv_z_p_z_ // uminqv_z_p_z_
                        when (_, _, _, '10x', _, _, _, _, _) => // sve_int_movprfx_pred
                            __field opc 17 +: 2
                            __field M 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sve_sve_int_pred_red_sve_int_movprfx_pred_movprfx_z_p_z_ // movprfx_z_p_z_
                        when (_, _, _, '110', _, _, _, _, _) => // sve_int_reduce_2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_2_orv_r_p_z_ // orv_r_p_z_
                                when ('01') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_2_eorv_r_p_z_ // eorv_r_p_z_
                                when ('10') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_2_andv_r_p_z_ // andv_r_p_z_
                                when ('11') => __UNALLOCATED
                        when (_, _, _, '111', _, _, _, _, _) => // sve_int_reduce_2q
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_2q_orqv_z_p_z_ // orqv_z_p_z_
                                when ('01') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_2q_eorqv_z_p_z_ // eorqv_z_p_z_
                                when ('10') => __encoding A64_sve_sve_int_pred_red_sve_int_reduce_2q_andqv_z_p_z_ // andqv_z_p_z_
                                when ('11') => __UNALLOCATED
                when ('000', _, '0xx0xxxx', _, '100xxx', _, _, _) =>
                    // sve_int_pred_shift
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0x', _, _, _, _, _) => // sve_int_bin_pred_shift_0
                            __field tszh 22 +: 2
                            __field opc 18 +: 2
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field tszl 8 +: 2
                            __field imm3 5 +: 3
                            __field Zdn 0 +: 5
                            case (opc, L, U) of
                                when ('00', '0', '0') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_asr_z_p_zi_ // asr_z_p_zi_
                                when ('00', '0', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_lsr_z_p_zi_ // lsr_z_p_zi_
                                when ('00', '1', '0') => __UNALLOCATED
                                when ('00', '1', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_lsl_z_p_zi_ // lsl_z_p_zi_
                                when ('01', '0', '0') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_asrd_z_p_zi_ // asrd_z_p_zi_
                                when ('01', '0', '1') => __UNALLOCATED
                                when ('01', '1', '0') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_sqshl_z_p_zi_ // sqshl_z_p_zi_
                                when ('01', '1', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_uqshl_z_p_zi_ // uqshl_z_p_zi_
                                when ('10', _, _) => __UNALLOCATED
                                when ('11', '0', '0') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_srshr_z_p_zi_ // srshr_z_p_zi_
                                when ('11', '0', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_urshr_z_p_zi_ // urshr_z_p_zi_
                                when ('11', '1', '0') => __UNALLOCATED
                                when ('11', '1', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_0_sqshlu_z_p_zi_ // sqshlu_z_p_zi_
                        when (_, _, _, '10', _, _, _, _, _) => // sve_int_bin_pred_shift_1
                            __field R 18 +: 1
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, L, U) of
                                when (_, '1', '0') => __UNALLOCATED
                                when ('0', '0', '0') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_1_asr_z_p_zz_ // asr_z_p_zz_
                                when ('0', '0', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_1_lsr_z_p_zz_ // lsr_z_p_zz_
                                when ('0', '1', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_1_lsl_z_p_zz_ // lsl_z_p_zz_
                                when ('1', '0', '0') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_1_asrr_z_p_zz_ // asrr_z_p_zz_
                                when ('1', '0', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_1_lsrr_z_p_zz_ // lsrr_z_p_zz_
                                when ('1', '1', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_1_lslr_z_p_zz_ // lslr_z_p_zz_
                        when (_, _, _, '11', _, _, _, _, _) => // sve_int_bin_pred_shift_2
                            __field R 18 +: 1
                            __field L 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, L, U) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_2_asr_z_p_zw_ // asr_z_p_zw_
                                when ('0', '0', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_2_lsr_z_p_zw_ // lsr_z_p_zw_
                                when ('0', '1', '0') => __UNALLOCATED
                                when ('0', '1', '1') => __encoding A64_sve_sve_int_pred_shift_sve_int_bin_pred_shift_2_lsl_z_p_zw_ // lsl_z_p_zw_
                                when ('1', _, _) => __UNALLOCATED
                when ('000', _, '0xx0xxxx', _, '101xxx', _, _, _) =>
                    // sve_int_pred_un
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, 'x0', _, _, _, _, _) => // sve_int_un_pred_arit_0
                            __field size 22 +: 2
                            __field M 20 +: 1
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (M, opc) of
                                when ('0', '000') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_sxtb_z_p_z_z // sxtb_z_p_z_z
                                when ('0', '001') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_uxtb_z_p_z_z // uxtb_z_p_z_z
                                when ('0', '010') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_sxth_z_p_z_z // sxth_z_p_z_z
                                when ('0', '011') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_uxth_z_p_z_z // uxth_z_p_z_z
                                when ('0', '100') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_sxtw_z_p_z_z // sxtw_z_p_z_z
                                when ('0', '101') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_uxtw_z_p_z_z // uxtw_z_p_z_z
                                when ('0', '110') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_abs_z_p_z_z // abs_z_p_z_z
                                when ('0', '111') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_neg_z_p_z_z // neg_z_p_z_z
                                when ('1', '000') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_sxtb_z_p_z_m // sxtb_z_p_z_m
                                when ('1', '001') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_uxtb_z_p_z_m // uxtb_z_p_z_m
                                when ('1', '010') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_sxth_z_p_z_m // sxth_z_p_z_m
                                when ('1', '011') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_uxth_z_p_z_m // uxth_z_p_z_m
                                when ('1', '100') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_sxtw_z_p_z_m // sxtw_z_p_z_m
                                when ('1', '101') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_uxtw_z_p_z_m // uxtw_z_p_z_m
                                when ('1', '110') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_abs_z_p_z_m // abs_z_p_z_m
                                when ('1', '111') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_0_neg_z_p_z_m // neg_z_p_z_m
                        when (_, _, _, 'x1', _, _, _, _, _) => // sve_int_un_pred_arit_1
                            __field size 22 +: 2
                            __field M 20 +: 1
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (M, opc) of
                                when (_, '111') => __UNALLOCATED
                                when ('0', '000') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_cls_z_p_z_z // cls_z_p_z_z
                                when ('0', '001') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_clz_z_p_z_z // clz_z_p_z_z
                                when ('0', '010') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_cnt_z_p_z_z // cnt_z_p_z_z
                                when ('0', '011') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_cnot_z_p_z_z // cnot_z_p_z_z
                                when ('0', '100') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_fabs_z_p_z_z // fabs_z_p_z_z
                                when ('0', '101') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_fneg_z_p_z_z // fneg_z_p_z_z
                                when ('0', '110') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_not_z_p_z_z // not_z_p_z_z
                                when ('1', '000') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_cls_z_p_z_m // cls_z_p_z_m
                                when ('1', '001') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_clz_z_p_z_m // clz_z_p_z_m
                                when ('1', '010') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_cnt_z_p_z_m // cnt_z_p_z_m
                                when ('1', '011') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_cnot_z_p_z_m // cnot_z_p_z_m
                                when ('1', '100') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_fabs_z_p_z_m // fabs_z_p_z_m
                                when ('1', '101') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_fneg_z_p_z_m // fneg_z_p_z_m
                                when ('1', '110') => __encoding A64_sve_sve_int_pred_un_sve_int_un_pred_arit_1_not_z_p_z_m // not_z_p_z_m
                when ('000', _, '0xx0xxxx', _, 'x1xxxx', _, _, _) =>
                    // sve_int_muladd_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 14 +: 1, 5 +: 9, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, '0', _, _, _, _) => // sve_int_mlas_vvv_pred
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_int_muladd_pred_sve_int_mlas_vvv_pred_mla_z_p_zzz_ // mla_z_p_zzz_
                                when ('1') => __encoding A64_sve_sve_int_muladd_pred_sve_int_mlas_vvv_pred_mls_z_p_zzz_ // mls_z_p_zzz_
                        when (_, _, _, _, '1', _, _, _, _) => // sve_int_mladdsub_vvv_pred
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field Pg 10 +: 3
                            __field Za 5 +: 5
                            __field Zdn 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_int_muladd_pred_sve_int_mladdsub_vvv_pred_mad_z_p_zzz_ // mad_z_p_zzz_
                                when ('1') => __encoding A64_sve_sve_int_muladd_pred_sve_int_mladdsub_vvv_pred_msb_z_p_zzz_ // msb_z_p_zzz_
                when ('000', _, '0xx1xxxx', _, '001xxx', _, _, _) =>
                    // sve_int_unpred_logical
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '0xx', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '100', _, _, _) => // sve_int_bin_cons_log
                            __field opc 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_int_unpred_logical_sve_int_bin_cons_log_and_z_zz_ // and_z_zz_
                                when ('01') => __encoding A64_sve_sve_int_unpred_logical_sve_int_bin_cons_log_orr_z_zz_ // orr_z_zz_
                                when ('10') => __encoding A64_sve_sve_int_unpred_logical_sve_int_bin_cons_log_eor_z_zz_ // eor_z_zz_
                                when ('11') => __encoding A64_sve_sve_int_unpred_logical_sve_int_bin_cons_log_bic_z_zz_ // bic_z_zz_
                        when (_, _, _, _, _, '101', _, _, _) => // sve_int_rotate_imm
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_int_unpred_logical_sve_int_rotate_imm_xar_z_zzi_ // xar_z_zzi_
                        when (_, _, _, _, _, '11x', _, _, _) => // sve_int_tern_log
                            __field opc 22 +: 2
                            __field Zm 16 +: 5
                            __field o2 10 +: 1
                            __field Zk 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when ('00', '0') => __encoding A64_sve_sve_int_unpred_logical_sve_int_tern_log_eor3_z_zzz_ // eor3_z_zzz_
                                when ('00', '1') => __encoding A64_sve_sve_int_unpred_logical_sve_int_tern_log_bsl_z_zzz_ // bsl_z_zzz_
                                when ('01', '0') => __encoding A64_sve_sve_int_unpred_logical_sve_int_tern_log_bcax_z_zzz_ // bcax_z_zzz_
                                when ('01', '1') => __encoding A64_sve_sve_int_unpred_logical_sve_int_tern_log_bsl1n_z_zzz_ // bsl1n_z_zzz_
                                when ('1x', '0') => __UNALLOCATED
                                when ('10', '1') => __encoding A64_sve_sve_int_unpred_logical_sve_int_tern_log_bsl2n_z_zzz_ // bsl2n_z_zzz_
                                when ('11', '1') => __encoding A64_sve_sve_int_unpred_logical_sve_int_tern_log_nbsl_z_zzz_ // nbsl_z_zzz_
                when ('000', _, '0xx1xxxx', _, '0100xx', _, _, _) =>
                    // sve_index
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 12 +: 4, 10 +: 2, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '00', _, _, _) => // sve_int_index_ii
                            __field imm5b 16 +: 5
                            __field imm5 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_index_sve_int_index_ii_index_z_ii_ // index_z_ii_
                        when (_, _, _, _, _, '01', _, _, _) => // sve_int_index_ri
                            __field imm5 16 +: 5
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_index_sve_int_index_ri_index_z_ri_ // index_z_ri_
                        when (_, _, _, _, _, '10', _, _, _) => // sve_int_index_ir
                            __field Rm 16 +: 5
                            __field imm5 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_index_sve_int_index_ir_index_z_ir_ // index_z_ir_
                        when (_, _, _, _, _, '11', _, _, _) => // sve_int_index_rr
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_index_sve_int_index_rr_index_z_rr_ // index_z_rr_
                when ('000', _, '0xx1xxxx', _, '0101xx', _, _, _) =>
                    // sve_alloca
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 12 +: 4, 11 +: 1, 5 +: 6, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, _, _, '0', _, _, _) => // sve_int_arith_vl
                            __field op 22 +: 1
                            __field Rn 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_alloca_sve_int_arith_vl_addvl_r_ri_ // addvl_r_ri_
                                when ('1') => __encoding A64_sve_sve_alloca_sve_int_arith_vl_addpl_r_ri_ // addpl_r_ri_
                        when (_, '0', _, _, _, _, '1', _, _, _) => // sve_int_arith_svl
                            __field op 22 +: 1
                            __field Rn 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_alloca_sve_int_arith_svl_addsvl_r_ri_ // addsvl_r_ri_
                                when ('1') => __encoding A64_sve_sve_alloca_sve_int_arith_svl_addspl_r_ri_ // addspl_r_ri_
                        when (_, '1', _, _, _, _, '0', _, _, _) => // sve_int_read_vl_a
                            __field op 22 +: 1
                            __field opc2 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op, opc2) of
                                when ('0', !'11111') => __UNALLOCATED
                                when ('0', '11111') => __encoding A64_sve_sve_alloca_sve_int_read_vl_a_rdvl_r_i_ // rdvl_r_i_
                                when ('1', _) => __UNALLOCATED
                        when (_, '1', _, _, _, _, '1', _, _, _) => // sve_int_read_svl_a
                            __field op 22 +: 1
                            __field opc2 16 +: 5
                            __field imm6 5 +: 6
                            __field Rd 0 +: 5
                            case (op, opc2) of
                                when ('0', !'11111') => __UNALLOCATED
                                when ('0', '11111') => __encoding A64_sve_sve_alloca_sve_int_read_svl_a_rdsvl_r_i_ // rdsvl_r_i_
                                when ('1', _) => __UNALLOCATED
                when ('000', _, '0xx1xxxx', _, '011xxx', _, _, _) =>
                    // sve_int_unpred_arit_b
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 11 +: 2, 5 +: 6, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '0x', _, _, _) => // sve_int_mul_b
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, opc) of
                                when (_, '00') => __encoding A64_sve_sve_int_unpred_arit_b_sve_int_mul_b_mul_z_zz_ // mul_z_zz_
                                when (!'00', '01') => __UNALLOCATED
                                when (_, '10') => __encoding A64_sve_sve_int_unpred_arit_b_sve_int_mul_b_smulh_z_zz_ // smulh_z_zz_
                                when (_, '11') => __encoding A64_sve_sve_int_unpred_arit_b_sve_int_mul_b_umulh_z_zz_ // umulh_z_zz_
                                when ('00', '01') => __encoding A64_sve_sve_int_unpred_arit_b_sve_int_mul_b_pmul_z_zz_ // pmul_z_zz_
                        when (_, _, _, _, _, '10', _, _, _) => // sve_int_sqdmulh
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field R 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (R) of
                                when ('0') => __encoding A64_sve_sve_int_unpred_arit_b_sve_int_sqdmulh_sqdmulh_z_zz_ // sqdmulh_z_zz_
                                when ('1') => __encoding A64_sve_sve_int_unpred_arit_b_sve_int_sqdmulh_sqrdmulh_z_zz_ // sqrdmulh_z_zz_
                        when (_, _, _, _, _, '11', _, _, _) => __UNPREDICTABLE
                when ('000', _, '0xx1xxxx', _, '100xxx', _, _, _) =>
                    // sve_int_unpred_shift
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 12 +: 1, 5 +: 7, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '0', _, _, _) => // sve_int_bin_cons_shift_a
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_int_unpred_shift_sve_int_bin_cons_shift_a_asr_z_zw_ // asr_z_zw_
                                when ('01') => __encoding A64_sve_sve_int_unpred_shift_sve_int_bin_cons_shift_a_lsr_z_zw_ // lsr_z_zw_
                                when ('10') => __UNALLOCATED
                                when ('11') => __encoding A64_sve_sve_int_unpred_shift_sve_int_bin_cons_shift_a_lsl_z_zw_ // lsl_z_zw_
                        when (_, _, _, _, _, '1', _, _, _) => // sve_int_bin_cons_shift_b
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_int_unpred_shift_sve_int_bin_cons_shift_b_asr_z_zi_ // asr_z_zi_
                                when ('01') => __encoding A64_sve_sve_int_unpred_shift_sve_int_bin_cons_shift_b_lsr_z_zi_ // lsr_z_zi_
                                when ('10') => __UNALLOCATED
                                when ('11') => __encoding A64_sve_sve_int_unpred_shift_sve_int_bin_cons_shift_b_lsl_z_zi_ // lsl_z_zi_
                when ('000', _, '0xx1xxxx', _, '1011xx', _, _, _) =>
                    // sve_int_unpred_misc
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 12 +: 4, 10 +: 2, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '0x', _, _, _) => // sve_int_bin_cons_misc_0_b
                            __field Zm 16 +: 5
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_int_unpred_misc_sve_int_bin_cons_misc_0_b_ftssel_z_zz_ // ftssel_z_zz_
                                when ('1') => __UNALLOCATED
                        when (_, _, _, _, _, '10', _, _, _) => // sve_int_bin_cons_misc_0_c
                            __field opc 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when (!'00000') => __UNALLOCATED
                                when ('00000') => __encoding A64_sve_sve_int_unpred_misc_sve_int_bin_cons_misc_0_c_fexpa_z_z_ // fexpa_z_z_
                        when (_, _, _, _, _, '11', _, _, _) => // sve_int_bin_cons_misc_0_d
                            __field opc 22 +: 2
                            __field opc2 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when (!'00', _) => __UNALLOCATED
                                when ('00', !'00000') => __UNALLOCATED
                                when ('00', '00000') => __encoding A64_sve_sve_int_unpred_misc_sve_int_bin_cons_misc_0_d_movprfx_z_z_ // movprfx_z_z_
                when ('000', _, '0xx1xxxx', _, '11xxxx', _, _, _) =>
                    // sve_countelt
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 16 +: 4, 14 +: 2, 11 +: 3, 5 +: 6, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0', _, _, '00x', _, _, _) => // sve_int_countvlv0
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 11 +: 1
                            __field U 10 +: 1
                            __field pattern 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, D, U) of
                                when ('00', _, _) => __UNALLOCATED
                                when ('01', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_sqinch_z_zs_ // sqinch_z_zs_
                                when ('01', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_uqinch_z_zs_ // uqinch_z_zs_
                                when ('01', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_sqdech_z_zs_ // sqdech_z_zs_
                                when ('01', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_uqdech_z_zs_ // uqdech_z_zs_
                                when ('10', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_sqincw_z_zs_ // sqincw_z_zs_
                                when ('10', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_uqincw_z_zs_ // uqincw_z_zs_
                                when ('10', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_sqdecw_z_zs_ // sqdecw_z_zs_
                                when ('10', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_uqdecw_z_zs_ // uqdecw_z_zs_
                                when ('11', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_sqincd_z_zs_ // sqincd_z_zs_
                                when ('11', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_uqincd_z_zs_ // uqincd_z_zs_
                                when ('11', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_sqdecd_z_zs_ // sqdecd_z_zs_
                                when ('11', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv0_uqdecd_z_zs_ // uqdecd_z_zs_
                        when (_, _, _, '0', _, _, '100', _, _, _) => // sve_int_count
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field op 10 +: 1
                            __field pattern 5 +: 5
                            __field Rd 0 +: 5
                            case (size, op) of
                                when (_, '1') => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sve_sve_countelt_sve_int_count_cntb_r_s_ // cntb_r_s_
                                when ('01', '0') => __encoding A64_sve_sve_countelt_sve_int_count_cnth_r_s_ // cnth_r_s_
                                when ('10', '0') => __encoding A64_sve_sve_countelt_sve_int_count_cntw_r_s_ // cntw_r_s_
                                when ('11', '0') => __encoding A64_sve_sve_countelt_sve_int_count_cntd_r_s_ // cntd_r_s_
                        when (_, _, _, '0', _, _, '101', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, _, '000', _, _, _) => // sve_int_countvlv1
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 10 +: 1
                            __field pattern 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, D) of
                                when ('00', _) => __UNALLOCATED
                                when ('01', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv1_inch_z_zs_ // inch_z_zs_
                                when ('01', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv1_dech_z_zs_ // dech_z_zs_
                                when ('10', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv1_incw_z_zs_ // incw_z_zs_
                                when ('10', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv1_decw_z_zs_ // decw_z_zs_
                                when ('11', '0') => __encoding A64_sve_sve_countelt_sve_int_countvlv1_incd_z_zs_ // incd_z_zs_
                                when ('11', '1') => __encoding A64_sve_sve_countelt_sve_int_countvlv1_decd_z_zs_ // decd_z_zs_
                        when (_, _, _, '1', _, _, '100', _, _, _) => // sve_int_pred_pattern_a
                            __field size 22 +: 2
                            __field imm4 16 +: 4
                            __field D 10 +: 1
                            __field pattern 5 +: 5
                            __field Rdn 0 +: 5
                            case (size, D) of
                                when ('00', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_a_incb_r_rs_ // incb_r_rs_
                                when ('00', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_a_decb_r_rs_ // decb_r_rs_
                                when ('01', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_a_inch_r_rs_ // inch_r_rs_
                                when ('01', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_a_dech_r_rs_ // dech_r_rs_
                                when ('10', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_a_incw_r_rs_ // incw_r_rs_
                                when ('10', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_a_decw_r_rs_ // decw_r_rs_
                                when ('11', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_a_incd_r_rs_ // incd_r_rs_
                                when ('11', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_a_decd_r_rs_ // decd_r_rs_
                        when (_, _, _, '1', _, _, 'x01', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '01x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '11x', _, _, _) => // sve_int_pred_pattern_b
                            __field size 22 +: 2
                            __field sf 20 +: 1
                            __field imm4 16 +: 4
                            __field D 11 +: 1
                            __field U 10 +: 1
                            __field pattern 5 +: 5
                            __field Rdn 0 +: 5
                            case (size, sf, D, U) of
                                when ('00', '0', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqincb_r_rs_sx // sqincb_r_rs_sx
                                when ('00', '0', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqincb_r_rs_uw // uqincb_r_rs_uw
                                when ('00', '0', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqdecb_r_rs_sx // sqdecb_r_rs_sx
                                when ('00', '0', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqdecb_r_rs_uw // uqdecb_r_rs_uw
                                when ('00', '1', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqincb_r_rs_x // sqincb_r_rs_x
                                when ('00', '1', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqincb_r_rs_x // uqincb_r_rs_x
                                when ('00', '1', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqdecb_r_rs_x // sqdecb_r_rs_x
                                when ('00', '1', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqdecb_r_rs_x // uqdecb_r_rs_x
                                when ('01', '0', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqinch_r_rs_sx // sqinch_r_rs_sx
                                when ('01', '0', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqinch_r_rs_uw // uqinch_r_rs_uw
                                when ('01', '0', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqdech_r_rs_sx // sqdech_r_rs_sx
                                when ('01', '0', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqdech_r_rs_uw // uqdech_r_rs_uw
                                when ('01', '1', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqinch_r_rs_x // sqinch_r_rs_x
                                when ('01', '1', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqinch_r_rs_x // uqinch_r_rs_x
                                when ('01', '1', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqdech_r_rs_x // sqdech_r_rs_x
                                when ('01', '1', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqdech_r_rs_x // uqdech_r_rs_x
                                when ('10', '0', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqincw_r_rs_sx // sqincw_r_rs_sx
                                when ('10', '0', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqincw_r_rs_uw // uqincw_r_rs_uw
                                when ('10', '0', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqdecw_r_rs_sx // sqdecw_r_rs_sx
                                when ('10', '0', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqdecw_r_rs_uw // uqdecw_r_rs_uw
                                when ('10', '1', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqincw_r_rs_x // sqincw_r_rs_x
                                when ('10', '1', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqincw_r_rs_x // uqincw_r_rs_x
                                when ('10', '1', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqdecw_r_rs_x // sqdecw_r_rs_x
                                when ('10', '1', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqdecw_r_rs_x // uqdecw_r_rs_x
                                when ('11', '0', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqincd_r_rs_sx // sqincd_r_rs_sx
                                when ('11', '0', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqincd_r_rs_uw // uqincd_r_rs_uw
                                when ('11', '0', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqdecd_r_rs_sx // sqdecd_r_rs_sx
                                when ('11', '0', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqdecd_r_rs_uw // uqdecd_r_rs_uw
                                when ('11', '1', '0', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqincd_r_rs_x // sqincd_r_rs_x
                                when ('11', '1', '0', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqincd_r_rs_x // uqincd_r_rs_x
                                when ('11', '1', '1', '0') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_sqdecd_r_rs_x // sqdecd_r_rs_x
                                when ('11', '1', '1', '1') => __encoding A64_sve_sve_countelt_sve_int_pred_pattern_b_uqdecd_r_rs_x // uqdecd_r_rs_x
                when ('000', _, '10x1xxxx', _, '000xxx', _, _, _) =>
                    // sve_perm_extract
                    case (23 +: 9, 22 +: 1, 21 +: 1, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, _, _, _, _) => // sve_int_perm_extract_i
                            __field imm8h 16 +: 5
                            __field imm8l 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_extract_sve_int_perm_extract_i_ext_z_zi_des // ext_z_zi_des
                        when (_, '1', _, _, _, _, _, _) => // sve_intx_perm_extract_i
                            __field imm8h 16 +: 5
                            __field imm8l 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_extract_sve_intx_perm_extract_i_ext_z_zi_con // ext_z_zi_con
                when ('000', _, '11x1xxxx', _, '000xxx', _, _, _) =>
                    // sve_perm_inter_long
                    case (23 +: 9, 22 +: 1, 21 +: 1, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, _, _, _, _) => // sve_int_perm_bin_long_perm_zz
                            __field Zm 16 +: 5
                            __field opc 11 +: 2
                            __field H 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, H) of
                                when ('00', '0') => __encoding A64_sve_sve_perm_inter_long_sve_int_perm_bin_long_perm_zz_zip1_z_zz_q // zip1_z_zz_q
                                when ('00', '1') => __encoding A64_sve_sve_perm_inter_long_sve_int_perm_bin_long_perm_zz_zip2_z_zz_q // zip2_z_zz_q
                                when ('01', '0') => __encoding A64_sve_sve_perm_inter_long_sve_int_perm_bin_long_perm_zz_uzp1_z_zz_q // uzp1_z_zz_q
                                when ('01', '1') => __encoding A64_sve_sve_perm_inter_long_sve_int_perm_bin_long_perm_zz_uzp2_z_zz_q // uzp2_z_zz_q
                                when ('10', _) => __UNALLOCATED
                                when ('11', '0') => __encoding A64_sve_sve_perm_inter_long_sve_int_perm_bin_long_perm_zz_trn1_z_zz_q // trn1_z_zz_q
                                when ('11', '1') => __encoding A64_sve_sve_perm_inter_long_sve_int_perm_bin_long_perm_zz_trn2_z_zz_q // trn2_z_zz_q
                        when (_, '1', _, _, _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx00xxx', _, _, _, _, _) =>
                    // sve_maskimm
                    case (24 +: 8, 22 +: 2, 20 +: 2, 18 +: 2, 16 +: 2, 10 +: 6, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, '11', _, '00', _, _, _, _, _) => // sve_int_dup_mask_imm
                            __field imm13 5 +: 13
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_maskimm_sve_int_dup_mask_imm_dupm_z_i_ // dupm_z_i_
                        when (_, _, _, !'00', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'11', _, '00', _, _, _, _, _) => // sve_int_log_imm
                            __field opc 22 +: 2
                            __field imm13 5 +: 13
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_maskimm_sve_int_log_imm_orr_z_zi_ // orr_z_zi_
                                when ('01') => __encoding A64_sve_sve_maskimm_sve_int_log_imm_eor_z_zi_ // eor_z_zi_
                                when ('10') => __encoding A64_sve_sve_maskimm_sve_int_log_imm_and_z_zi_ // and_z_zi_
                when ('000', _, '1xx01xxx', _, _, _, _, _) =>
                    // sve_wideimm_pred
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, '0xx', _, _, _) => // sve_int_dup_imm_pred
                            __field size 22 +: 2
                            __field Pg 16 +: 4
                            __field M 14 +: 1
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (M) of
                                when ('0') => __encoding A64_sve_sve_wideimm_pred_sve_int_dup_imm_pred_cpy_z_o_i_ // cpy_z_o_i_
                                when ('1') => __encoding A64_sve_sve_wideimm_pred_sve_int_dup_imm_pred_cpy_z_p_i_ // cpy_z_p_i_
                        when (_, _, _, _, '10x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '110', _, _, _) => // sve_int_dup_fpimm_pred
                            __field size 22 +: 2
                            __field Pg 16 +: 4
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_wideimm_pred_sve_int_dup_fpimm_pred_fcpy_z_p_i_ // fcpy_z_p_i_
                        when (_, _, _, _, '111', _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '001001', _, _, _) =>
                    // sve_perm_quads_a
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 16 +: 4, 10 +: 6, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, '00', _, _, _, _, _, _, _) => // sve_int_perm_dupq_i
                            __field i1 20 +: 1
                            __field tsz 16 +: 4
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_quads_a_sve_int_perm_dupq_i_dupq_z_zi_ // dupq_z_zi_
                        when (_, '01', _, '0', _, _, _, _, _) => // sve_int_perm_extq
                            __field imm4 16 +: 4
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_quads_a_sve_int_perm_extq_extq_z_zi_des // extq_z_zi_des
                        when (_, '01', _, '1', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1x', _, _, _, _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '001110', _, _, _) =>
                    // sve_perm_unpred_d
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 10 +: 6, 9 +: 1, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '00', '000', _, _, _, _, _) => // sve_int_perm_dup_r
                            __field size 22 +: 2
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_unpred_d_sve_int_perm_dup_r_dup_z_r_ // dup_z_r_
                        when (_, _, _, '00', '100', _, _, _, _, _) => // sve_int_perm_insrs
                            __field size 22 +: 2
                            __field Rm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_unpred_d_sve_int_perm_insrs_insr_z_r_ // insr_z_r_
                        when (_, _, _, '00', 'x01', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '00', 'x1x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '01', 'xx0', _, _, _, '0', _) => // sve_int_mov_v2p
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field Zn 5 +: 5
                            __field Pd 0 +: 4
                            case (opc, opc2) of
                                when ('00', '00') => __UNALLOCATED
                                when ('00', '01') => __encoding A64_sve_sve_perm_unpred_d_sve_int_mov_v2p_pmov_p_zi_b // pmov_p_zi_b
                                when ('00', '1x') => __encoding A64_sve_sve_perm_unpred_d_sve_int_mov_v2p_pmov_p_zi_h // pmov_p_zi_h
                                when ('01', _) => __encoding A64_sve_sve_perm_unpred_d_sve_int_mov_v2p_pmov_p_zi_s // pmov_p_zi_s
                                when ('1x', _) => __encoding A64_sve_sve_perm_unpred_d_sve_int_mov_v2p_pmov_p_zi_d // pmov_p_zi_d
                        when (_, _, _, '01', 'xx0', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '01', 'xx1', _, '0', _, _, _) => // sve_int_mov_p2v
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field Pn 5 +: 4
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('00', '00') => __UNALLOCATED
                                when ('00', '01') => __encoding A64_sve_sve_perm_unpred_d_sve_int_mov_p2v_pmov_z_pi_b // pmov_z_pi_b
                                when ('00', '1x') => __encoding A64_sve_sve_perm_unpred_d_sve_int_mov_p2v_pmov_z_pi_h // pmov_z_pi_h
                                when ('01', _) => __encoding A64_sve_sve_perm_unpred_d_sve_int_mov_p2v_pmov_z_pi_s // pmov_z_pi_s
                                when ('1x', _) => __encoding A64_sve_sve_perm_unpred_d_sve_int_mov_p2v_pmov_z_pi_d // pmov_z_pi_d
                        when (_, _, _, '01', 'xx1', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10', '0xx', _, _, _, _, _) => // sve_int_perm_unpk
                            __field size 22 +: 2
                            __field U 17 +: 1
                            __field H 16 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (U, H) of
                                when ('0', '0') => __encoding A64_sve_sve_perm_unpred_d_sve_int_perm_unpk_sunpklo_z_z_ // sunpklo_z_z_
                                when ('0', '1') => __encoding A64_sve_sve_perm_unpred_d_sve_int_perm_unpk_sunpkhi_z_z_ // sunpkhi_z_z_
                                when ('1', '0') => __encoding A64_sve_sve_perm_unpred_d_sve_int_perm_unpk_uunpklo_z_z_ // uunpklo_z_z_
                                when ('1', '1') => __encoding A64_sve_sve_perm_unpred_d_sve_int_perm_unpk_uunpkhi_z_z_ // uunpkhi_z_z_
                        when (_, _, _, '10', '100', _, _, _, _, _) => // sve_int_perm_insrv
                            __field size 22 +: 2
                            __field Vm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_unpred_d_sve_int_perm_insrv_insr_z_v_ // insr_z_v_
                        when (_, _, _, '10', '101', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10', '11x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '11', '000', _, _, _, _, _) => // sve_int_perm_reverse_z
                            __field size 22 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_unpred_d_sve_int_perm_reverse_z_rev_z_z_ // rev_z_z_
                        when (_, _, _, '11', !'000', _, _, _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '001111', _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '010xxx', _, _, _) =>
                    // sve_perm_predicates
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 13 +: 3, 9 +: 4, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, '00', _, '1000x', _, '0000', _, '0', _) => // sve_int_perm_punpk
                            __field H 16 +: 1
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case (H) of
                                when ('0') => __encoding A64_sve_sve_perm_predicates_sve_int_perm_punpk_punpklo_p_p_ // punpklo_p_p_
                                when ('1') => __encoding A64_sve_sve_perm_predicates_sve_int_perm_punpk_punpkhi_p_p_ // punpkhi_p_p_
                        when (_, _, _, '0xxxx', _, 'xxx0', _, '0', _) => // sve_int_perm_bin_perm_pp
                            __field size 22 +: 2
                            __field Pm 16 +: 4
                            __field opc 11 +: 2
                            __field H 10 +: 1
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case (opc, H) of
                                when ('00', '0') => __encoding A64_sve_sve_perm_predicates_sve_int_perm_bin_perm_pp_zip1_p_pp_ // zip1_p_pp_
                                when ('00', '1') => __encoding A64_sve_sve_perm_predicates_sve_int_perm_bin_perm_pp_zip2_p_pp_ // zip2_p_pp_
                                when ('01', '0') => __encoding A64_sve_sve_perm_predicates_sve_int_perm_bin_perm_pp_uzp1_p_pp_ // uzp1_p_pp_
                                when ('01', '1') => __encoding A64_sve_sve_perm_predicates_sve_int_perm_bin_perm_pp_uzp2_p_pp_ // uzp2_p_pp_
                                when ('10', '0') => __encoding A64_sve_sve_perm_predicates_sve_int_perm_bin_perm_pp_trn1_p_pp_ // trn1_p_pp_
                                when ('10', '1') => __encoding A64_sve_sve_perm_predicates_sve_int_perm_bin_perm_pp_trn2_p_pp_ // trn2_p_pp_
                                when ('11', _) => __UNALLOCATED
                        when (_, !'00', _, '1000x', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10100', _, '0000', _, '0', _) => // sve_int_perm_reverse_p
                            __field size 22 +: 2
                            __field Pn 5 +: 4
                            __field Pd 0 +: 4
                            case () of
                                when () => __encoding A64_sve_sve_perm_predicates_sve_int_perm_reverse_p_rev_p_p_ // rev_p_p_
                        when (_, _, _, '10101', _, '0000', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, '0010', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, '01x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x0x', _, '1xx0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '10x1x', _, 'xxx0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '11xxx', _, 'xxx0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, 'xxx0', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, _, _, 'xxx1', _, _, _) => __UNPREDICTABLE
                when ('000', _, '1xx1xxxx', _, '10xxxx', _, _, _) =>
                    // sve_perm_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 20 +: 1, 17 +: 3, 16 +: 1, 14 +: 2, 13 +: 1, 0 +: 13) of
                        when (_, _, _, '0', '000', '0', _, '0', _) => // sve_int_perm_cpy_v
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Vn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_pred_sve_int_perm_cpy_v_cpy_z_p_v_ // cpy_z_p_v_
                        when (_, _, _, '0', '000', '1', _, '0', _) => // sve_int_perm_compact
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size) of
                                when ('0x') => __encoding A64_sve_sve_perm_pred_sve_int_perm_compact_compact_z_p_z_s // compact_z_p_z_s
                                when ('1x') => __encoding A64_sve_sve_perm_pred_sve_int_perm_compact_compact_z_p_z_ // compact_z_p_z_
                        when (_, _, _, '0', '000', _, _, '1', _) => // sve_int_perm_last_r
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Rd 0 +: 5
                            case (B) of
                                when ('0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_last_r_lasta_r_p_z_ // lasta_r_p_z_
                                when ('1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_last_r_lastb_r_p_z_ // lastb_r_p_z_
                        when (_, _, _, '0', '001', '1', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '001', _, _, '0', _) => // sve_int_perm_last_v
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Vd 0 +: 5
                            case (B) of
                                when ('0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_last_v_lasta_v_p_z_ // lasta_v_p_z_
                                when ('1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_last_v_lastb_v_p_z_ // lastb_v_p_z_
                        when (_, _, _, '0', '01x', _, _, _, _) => // sve_int_perm_rev
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Z 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, Z) of
                                when ('00', '0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_rev_revb_z_z_m // revb_z_z_m
                                when ('00', '1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_rev_revb_z_z_z // revb_z_z_z
                                when ('01', '0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_rev_revh_z_z_m // revh_z_z_m
                                when ('01', '1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_rev_revh_z_z_z // revh_z_z_z
                                when ('10', '0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_rev_revw_z_z_m // revw_z_z_m
                                when ('10', '1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_rev_revw_z_z_z // revw_z_z_z
                                when ('11', '0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_rev_rbit_z_p_z_m // rbit_z_p_z_m
                                when ('11', '1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_rev_rbit_z_p_z_z // rbit_z_p_z_z
                        when (_, _, _, '0', '100', '0', _, '1', _) => // sve_int_perm_cpy_r
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_pred_sve_int_perm_cpy_r_cpy_z_p_r_ // cpy_z_p_r_
                        when (_, _, _, '0', '100', _, _, '0', _) => // sve_int_perm_clast_zz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_clast_zz_clasta_z_p_zz_ // clasta_z_p_zz_
                                when ('1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_clast_zz_clastb_z_p_zz_ // clastb_z_p_zz_
                        when (_, _, _, '0', '101', _, _, '0', _) => // sve_int_perm_clast_vz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Vdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_clast_vz_clasta_v_p_z_ // clasta_v_p_z_
                                when ('1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_clast_vz_clastb_v_p_z_ // clastb_v_p_z_
                        when (_, _, _, '0', '110', '0', _, '0', _) => // sve_int_perm_splice
                            __field size 22 +: 2
                            __field Pv 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_pred_sve_int_perm_splice_splice_z_p_zz_des // splice_z_p_zz_des
                        when (_, _, _, '0', '110', '0', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '110', '1', _, '0', _) => // sve_intx_perm_splice
                            __field size 22 +: 2
                            __field Pv 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_pred_sve_intx_perm_splice_splice_z_p_zz_con // splice_z_p_zz_con
                        when (_, _, _, '0', '111', '0', _, _, _) => // sve_int_perm_revd
                            __field size 22 +: 2
                            __field Z 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, Z) of
                                when (!'00', _) => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_revd_revd_z_p_z_m // revd_z_p_z_m
                                when ('00', '1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_revd_revd_z_p_z_z // revd_z_p_z_z
                        when (_, _, _, '0', '111', '1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0', '1xx', '1', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '0', 'x01', '0', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '1', '000', '0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1', '000', '1', _, '0', _) => // sve_int_perm_expand
                            __field size 22 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_perm_pred_sve_int_perm_expand_expand_z_p_z_ // expand_z_p_z_
                        when (_, _, _, '1', '000', _, _, '1', _) => // sve_int_perm_clast_rz
                            __field size 22 +: 2
                            __field B 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Rdn 0 +: 5
                            case (B) of
                                when ('0') => __encoding A64_sve_sve_perm_pred_sve_int_perm_clast_rz_clasta_r_p_z_ // clasta_r_p_z_
                                when ('1') => __encoding A64_sve_sve_perm_pred_sve_int_perm_clast_rz_clastb_r_p_z_ // clastb_r_p_z_
                        when (_, _, _, '1', !'000', _, _, _, _) => __UNPREDICTABLE
                when ('001', _, '0xx0xxxx', _, _, _, _, _) =>
                    // sve_cmpvec
                    case (24 +: 8, 22 +: 2, 21 +: 1, 15 +: 6, 14 +: 1, 5 +: 9, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, '0', _, _, _) => // sve_int_cmp_0
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 15 +: 1
                            __field o2 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (op, o2, ne) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_0_cmphs_p_p_zz_ // cmphs_p_p_zz_
                                when ('0', '0', '1') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_0_cmphi_p_p_zz_ // cmphi_p_p_zz_
                                when ('0', '1', '0') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_0_cmpeq_p_p_zw_ // cmpeq_p_p_zw_
                                when ('0', '1', '1') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_0_cmpne_p_p_zw_ // cmpne_p_p_zw_
                                when ('1', '0', '0') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_0_cmpge_p_p_zz_ // cmpge_p_p_zz_
                                when ('1', '0', '1') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_0_cmpgt_p_p_zz_ // cmpgt_p_p_zz_
                                when ('1', '1', '0') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_0_cmpeq_p_p_zz_ // cmpeq_p_p_zz_
                                when ('1', '1', '1') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_0_cmpne_p_p_zz_ // cmpne_p_p_zz_
                        when (_, _, _, _, '1', _, _, _) => // sve_int_cmp_1
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 15 +: 1
                            __field lt 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (U, lt, ne) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_1_cmpge_p_p_zw_ // cmpge_p_p_zw_
                                when ('0', '0', '1') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_1_cmpgt_p_p_zw_ // cmpgt_p_p_zw_
                                when ('0', '1', '0') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_1_cmplt_p_p_zw_ // cmplt_p_p_zw_
                                when ('0', '1', '1') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_1_cmple_p_p_zw_ // cmple_p_p_zw_
                                when ('1', '0', '0') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_1_cmphs_p_p_zw_ // cmphs_p_p_zw_
                                when ('1', '0', '1') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_1_cmphi_p_p_zw_ // cmphi_p_p_zw_
                                when ('1', '1', '0') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_1_cmplo_p_p_zw_ // cmplo_p_p_zw_
                                when ('1', '1', '1') => __encoding A64_sve_sve_cmpvec_sve_int_cmp_1_cmpls_p_p_zw_ // cmpls_p_p_zw_
                when ('001', _, '1xx00xxx', _, '11xxxx', _, _, _) =>
                    // sve_pred_gen_b
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 14 +: 2, 10 +: 4, 9 +: 1, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, _, '0', _, _, _) => // sve_int_brkp
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pm 16 +: 4
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field B 4 +: 1
                            __field Pd 0 +: 4
                            case (op, S, B) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_pred_gen_b_sve_int_brkp_brkpa_p_p_pp_ // brkpa_p_p_pp_
                                when ('0', '0', '1') => __encoding A64_sve_sve_pred_gen_b_sve_int_brkp_brkpb_p_p_pp_ // brkpb_p_p_pp_
                                when ('0', '1', '0') => __encoding A64_sve_sve_pred_gen_b_sve_int_brkp_brkpas_p_p_pp_ // brkpas_p_p_pp_
                                when ('0', '1', '1') => __encoding A64_sve_sve_pred_gen_b_sve_int_brkp_brkpbs_p_p_pp_ // brkpbs_p_p_pp_
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, _, _, _, '1', _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx01xxx', _, '01xxxx', _, _, _) =>
                    // sve_pred_gen_c
                    case (24 +: 8, 23 +: 1, 22 +: 1, 20 +: 2, 16 +: 4, 14 +: 2, 10 +: 4, 9 +: 1, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, '1000', _, _, '0', _, '0', _) => // sve_int_brkn
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field Pdm 0 +: 4
                            case (S) of
                                when ('0') => __encoding A64_sve_sve_pred_gen_c_sve_int_brkn_brkn_p_p_pp_ // brkn_p_p_pp_
                                when ('1') => __encoding A64_sve_sve_pred_gen_c_sve_int_brkn_brkns_p_p_pp_ // brkns_p_p_pp_
                        when (_, '0', _, _, '1000', _, _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, _, '1000', _, _, '0', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '0000', _, _, '0', _, _, _) => // sve_int_break
                            __field B 23 +: 1
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field M 4 +: 1
                            __field Pd 0 +: 4
                            case (B, S, M) of
                                when (_, '1', '1') => __UNALLOCATED
                                when ('0', '0', _) => __encoding A64_sve_sve_pred_gen_c_sve_int_break_brka_p_p_p_ // brka_p_p_p_
                                when ('0', '1', '0') => __encoding A64_sve_sve_pred_gen_c_sve_int_break_brkas_p_p_p_z // brkas_p_p_p_z
                                when ('1', '0', _) => __encoding A64_sve_sve_pred_gen_c_sve_int_break_brkb_p_p_p_ // brkb_p_p_p_
                                when ('1', '1', '0') => __encoding A64_sve_sve_pred_gen_c_sve_int_break_brkbs_p_p_p_z // brkbs_p_p_p_z
                        when (_, _, _, _, 'x000', _, _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x001', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x01x', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, 'x1xx', _, _, _, _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx01xxx', _, '11xxxx', _, _, _) =>
                    // sve_pred_gen_d
                    case (24 +: 8, 22 +: 2, 20 +: 2, 16 +: 4, 14 +: 2, 11 +: 3, 9 +: 2, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0000', _, _, 'x0', _, '0', _) => // sve_int_ptest
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field opc2 0 +: 4
                            case (op, S, opc2) of
                                when ('0', '0', _) => __UNALLOCATED
                                when ('0', '1', !'0000') => __UNALLOCATED
                                when ('0', '1', '0000') => __encoding A64_sve_sve_pred_gen_d_sve_int_ptest_ptest__p_p_ // ptest__p_p_
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, '0000', _, _, 'x1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '0001', _, _, _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '000', '00', _, '0', _) => // sve_int_pfirst
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 5 +: 4
                            __field Pdn 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __UNALLOCATED
                                when ('0', '1') => __encoding A64_sve_sve_pred_gen_d_sve_int_pfirst_pfirst_p_p_p_ // pfirst_p_p_p_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1000', _, '000', '10', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '100', '10', '0000', '0', _) => // sve_int_pfalse
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sve_sve_pred_gen_d_sve_int_pfalse_pfalse_p_ // pfalse_p_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1000', _, '100', '10', !'0000', '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1000', _, '110', '00', _, '0', _) => // sve_int_rdffr
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pg 5 +: 4
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sve_sve_pred_gen_d_sve_int_rdffr_rdffr_p_p_f_ // rdffr_p_p_f_
                                when ('0', '1') => __encoding A64_sve_sve_pred_gen_d_sve_int_rdffr_rdffrs_p_p_f_ // rdffrs_p_p_f_
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1001', _, '000', '00', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1001', _, '000', '10', _, '0', _) => // sve_int_pnext
                            __field size 22 +: 2
                            __field Pv 5 +: 4
                            __field Pdn 0 +: 4
                            case () of
                                when () => __encoding A64_sve_sve_pred_gen_d_sve_int_pnext_pnext_p_p_p_ // pnext_p_p_p_
                        when (_, _, _, '1001', _, '100', '10', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '1001', _, '110', '00', '0000', '0', _) => // sve_int_rdffr_2
                            __field op 23 +: 1
                            __field S 22 +: 1
                            __field Pd 0 +: 4
                            case (op, S) of
                                when ('0', '0') => __encoding A64_sve_sve_pred_gen_d_sve_int_rdffr_2_rdffr_p_f_ // rdffr_p_f_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', _) => __UNALLOCATED
                        when (_, _, _, '1001', _, '110', '00', !'0000', '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '010', 'x0', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '0x0', 'x1', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '100', '0x', _, '0', _) => // sve_int_ptrue
                            __field size 22 +: 2
                            __field S 16 +: 1
                            __field pattern 5 +: 5
                            __field Pd 0 +: 4
                            case (S) of
                                when ('0') => __encoding A64_sve_sve_pred_gen_d_sve_int_ptrue_ptrue_p_s_ // ptrue_p_s_
                                when ('1') => __encoding A64_sve_sve_pred_gen_d_sve_int_ptrue_ptrues_p_s_ // ptrues_p_s_
                        when (_, _, _, '100x', _, '100', '11', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, '110', !'00', _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, '100x', _, 'xx1', _, _, '0', _) => __UNPREDICTABLE
                        when (_, _, _, 'x00x', _, _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, 'x01x', _, _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, 'x1xx', _, _, _, _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx100xx', _, '10xxxx', _, _, _) =>
                    // sve_pred_count_a
                    case (24 +: 8, 22 +: 2, 19 +: 3, 16 +: 3, 14 +: 2, 11 +: 3, 10 +: 1, 9 +: 1, 5 +: 4, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '000', _, '1', _, _, _) => // sve_int_pcount_pn
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field vl 10 +: 1
                            __field PNn 5 +: 4
                            __field Rd 0 +: 5
                            case (opc) of
                                when (!'000') => __UNALLOCATED
                                when ('000') => __encoding A64_sve_sve_pred_count_a_sve_int_pcount_pn_cntp_r_pn_ // cntp_r_pn_
                        when (_, _, _, _, _, _, _, '0', _, _, _) => // sve_int_pcount_pred
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 4
                            __field Pn 5 +: 4
                            __field Rd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding A64_sve_sve_pred_count_a_sve_int_pcount_pred_cntp_r_p_p_ // cntp_r_p_p_
                                when ('001') => __encoding A64_sve_sve_pred_count_a_sve_int_pcount_pred_firstp_r_p_p_ // firstp_r_p_p_
                                when ('010') => __encoding A64_sve_sve_pred_count_a_sve_int_pcount_pred_lastp_r_p_p_ // lastp_r_p_p_
                                when ('011') => __UNALLOCATED
                                when ('1xx') => __UNALLOCATED
                        when (_, _, _, _, _, !'000', _, '1', _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx101xx', _, '1000xx', _, _, _) =>
                    // sve_pred_count_b
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 12 +: 4, 11 +: 1, 5 +: 6, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0', _, _, '0', _, _, _) => // sve_int_count_v_sat
                            __field size 22 +: 2
                            __field D 17 +: 1
                            __field U 16 +: 1
                            __field opc 9 +: 2
                            __field Pm 5 +: 4
                            __field Zdn 0 +: 5
                            case (D, U, opc) of
                                when (_, _, !'00') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding A64_sve_sve_pred_count_b_sve_int_count_v_sat_sqincp_z_p_z_ // sqincp_z_p_z_
                                when ('0', '1', '00') => __encoding A64_sve_sve_pred_count_b_sve_int_count_v_sat_uqincp_z_p_z_ // uqincp_z_p_z_
                                when ('1', '0', '00') => __encoding A64_sve_sve_pred_count_b_sve_int_count_v_sat_sqdecp_z_p_z_ // sqdecp_z_p_z_
                                when ('1', '1', '00') => __encoding A64_sve_sve_pred_count_b_sve_int_count_v_sat_uqdecp_z_p_z_ // uqdecp_z_p_z_
                        when (_, _, _, '0', _, _, '1', _, _, _) => // sve_int_count_r_sat
                            __field size 22 +: 2
                            __field D 17 +: 1
                            __field U 16 +: 1
                            __field sf 10 +: 1
                            __field op 9 +: 1
                            __field Pm 5 +: 4
                            __field Rdn 0 +: 5
                            case (D, U, sf, op) of
                                when (_, _, _, '1') => __UNALLOCATED
                                when ('0', '0', '0', '0') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_sat_sqincp_r_p_r_sx // sqincp_r_p_r_sx
                                when ('0', '0', '1', '0') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_sat_sqincp_r_p_r_x // sqincp_r_p_r_x
                                when ('0', '1', '0', '0') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_sat_uqincp_r_p_r_uw // uqincp_r_p_r_uw
                                when ('0', '1', '1', '0') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_sat_uqincp_r_p_r_x // uqincp_r_p_r_x
                                when ('1', '0', '0', '0') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_sat_sqdecp_r_p_r_sx // sqdecp_r_p_r_sx
                                when ('1', '0', '1', '0') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_sat_sqdecp_r_p_r_x // sqdecp_r_p_r_x
                                when ('1', '1', '0', '0') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_sat_uqdecp_r_p_r_uw // uqdecp_r_p_r_uw
                                when ('1', '1', '1', '0') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_sat_uqdecp_r_p_r_x // uqdecp_r_p_r_x
                        when (_, _, _, '1', _, _, '0', _, _, _) => // sve_int_count_v
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field D 16 +: 1
                            __field opc2 9 +: 2
                            __field Pm 5 +: 4
                            __field Zdn 0 +: 5
                            case (op, D, opc2) of
                                when ('0', _, !'00') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding A64_sve_sve_pred_count_b_sve_int_count_v_incp_z_p_z_ // incp_z_p_z_
                                when ('0', '1', '00') => __encoding A64_sve_sve_pred_count_b_sve_int_count_v_decp_z_p_z_ // decp_z_p_z_
                                when ('1', _, _) => __UNALLOCATED
                        when (_, _, _, '1', _, _, '1', _, _, _) => // sve_int_count_r
                            __field size 22 +: 2
                            __field op 17 +: 1
                            __field D 16 +: 1
                            __field opc2 9 +: 2
                            __field Pm 5 +: 4
                            __field Rdn 0 +: 5
                            case (op, D, opc2) of
                                when ('0', _, !'00') => __UNALLOCATED
                                when ('0', '0', '00') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_incp_r_p_r_ // incp_r_p_r_
                                when ('0', '1', '00') => __encoding A64_sve_sve_pred_count_b_sve_int_count_r_decp_r_p_r_ // decp_r_p_r_
                                when ('1', _, _) => __UNALLOCATED
                when ('001', _, '1xx101xx', _, '1001xx', _, _, _) =>
                    // sve_pred_wrffr
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 12 +: 4, 9 +: 3, 5 +: 4, 0 +: 5) of
                        when (_, _, _, '0', '00', _, '000', _, '00000') => // sve_int_wrffr
                            __field opc 22 +: 2
                            __field Pn 5 +: 4
                            case (opc) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sve_sve_pred_wrffr_sve_int_wrffr_wrffr_f_p_ // wrffr_f_p_
                        when (_, _, _, '1', '00', _, '000', '0000', '00000') => // sve_int_setffr
                            __field opc 22 +: 2
                            case (opc) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sve_sve_pred_wrffr_sve_int_setffr_setffr_f_ // setffr_f_
                        when (_, _, _, '1', '00', _, '000', !'0000', '00000') => __UNPREDICTABLE
                        when (_, _, _, _, '00', _, '000', _, !'00000') => __UNPREDICTABLE
                        when (_, _, _, _, '00', _, !'000', _, _) => __UNPREDICTABLE
                        when (_, _, _, _, !'00', _, _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx101xx', _, '101xxx', _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx11xxx', _, '10xxxx', _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx1xxxx', _, '00xxxx', _, _, _) =>
                    // sve_cmpgpr
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 14 +: 2, 12 +: 2, 10 +: 2, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '0x', _, _, _, _) => // sve_int_while_rr
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field sf 12 +: 1
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field eq 4 +: 1
                            __field Pd 0 +: 4
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_cmpgpr_sve_int_while_rr_whilege_p_p_rr_ // whilege_p_p_rr_
                                when ('0', '0', '1') => __encoding A64_sve_sve_cmpgpr_sve_int_while_rr_whilegt_p_p_rr_ // whilegt_p_p_rr_
                                when ('0', '1', '0') => __encoding A64_sve_sve_cmpgpr_sve_int_while_rr_whilelt_p_p_rr_ // whilelt_p_p_rr_
                                when ('0', '1', '1') => __encoding A64_sve_sve_cmpgpr_sve_int_while_rr_whilele_p_p_rr_ // whilele_p_p_rr_
                                when ('1', '0', '0') => __encoding A64_sve_sve_cmpgpr_sve_int_while_rr_whilehs_p_p_rr_ // whilehs_p_p_rr_
                                when ('1', '0', '1') => __encoding A64_sve_sve_cmpgpr_sve_int_while_rr_whilehi_p_p_rr_ // whilehi_p_p_rr_
                                when ('1', '1', '0') => __encoding A64_sve_sve_cmpgpr_sve_int_while_rr_whilelo_p_p_rr_ // whilelo_p_p_rr_
                                when ('1', '1', '1') => __encoding A64_sve_sve_cmpgpr_sve_int_while_rr_whilels_p_p_rr_ // whilels_p_p_rr_
                        when (_, _, _, _, _, '10', '00', _, _, '0000') => // sve_int_cterm
                            __field op 23 +: 1
                            __field sz 22 +: 1
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field ne 4 +: 1
                            case (op, ne) of
                                when ('0', _) => __UNALLOCATED
                                when ('1', '0') => __encoding A64_sve_sve_cmpgpr_sve_int_cterm_ctermeq_rr_ // ctermeq_rr_
                                when ('1', '1') => __encoding A64_sve_sve_cmpgpr_sve_int_cterm_ctermne_rr_ // ctermne_rr_
                        when (_, _, _, _, _, '10', '00', _, _, !'0000') => __UNPREDICTABLE
                        when (_, _, _, _, _, '11', '00', _, _, _) => // sve_int_whilenc
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field Rn 5 +: 5
                            __field rw 4 +: 1
                            __field Pd 0 +: 4
                            case (rw) of
                                when ('0') => __encoding A64_sve_sve_cmpgpr_sve_int_whilenc_whilewr_p_rr_ // whilewr_p_rr_
                                when ('1') => __encoding A64_sve_sve_cmpgpr_sve_int_whilenc_whilerw_p_rr_ // whilerw_p_rr_
                        when (_, _, _, _, _, '1x', !'00', _, _, _) => __UNPREDICTABLE
                when ('001', _, '1xx1xxxx', _, '01xxxx', _, '1', _) =>
                    // sve_while_pn
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 14 +: 2, 11 +: 3, 5 +: 6, 4 +: 1, 3 +: 1, 0 +: 3) of
                        when (_, _, _, '00000', _, '110', _, _, _, _) => // sve_int_ctr_to_mask
                            __field size 22 +: 2
                            __field opc 8 +: 3
                            __field PNn 5 +: 3
                            __field Pd 0 +: 4
                            case (opc) of
                                when ('0xx') => __encoding A64_sve_sve_while_pn_sve_int_ctr_to_mask_pext_pn_rr_ // pext_pn_rr_
                                when ('10x') => __encoding A64_sve_sve_while_pn_sve_int_ctr_to_mask_pext_pp_rr_ // pext_pp_rr_
                                when ('11x') => __UNALLOCATED
                        when (_, _, _, '00000', _, '111', '000000', _, '0', _) => // sve_int_pn_ptrue
                            __field size 22 +: 2
                            __field PNd 0 +: 3
                            case () of
                                when () => __encoding A64_sve_sve_while_pn_sve_int_pn_ptrue_ptrue_pn_i_ // ptrue_pn_i_
                        when (_, _, _, '00000', _, '111', '000000', _, '1', _) => __UNPREDICTABLE
                        when (_, _, _, '00000', _, '111', !'000000', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '01x', _, _, _, _) => // sve_int_while_rr_pair
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field Pd 1 +: 3
                            __field eq 0 +: 1
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pair_whilege_pp_rr_ // whilege_pp_rr_
                                when ('0', '0', '1') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pair_whilegt_pp_rr_ // whilegt_pp_rr_
                                when ('0', '1', '0') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pair_whilelt_pp_rr_ // whilelt_pp_rr_
                                when ('0', '1', '1') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pair_whilele_pp_rr_ // whilele_pp_rr_
                                when ('1', '0', '0') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pair_whilehs_pp_rr_ // whilehs_pp_rr_
                                when ('1', '0', '1') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pair_whilehi_pp_rr_ // whilehi_pp_rr_
                                when ('1', '1', '0') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pair_whilelo_pp_rr_ // whilelo_pp_rr_
                                when ('1', '1', '1') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pair_whilels_pp_rr_ // whilels_pp_rr_
                        when (_, _, _, !'00000', _, '11x', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, 'x0x', _, _, _, _) => // sve_int_while_rr_pn
                            __field size 22 +: 2
                            __field Rm 16 +: 5
                            __field vl 13 +: 1
                            __field U 11 +: 1
                            __field lt 10 +: 1
                            __field Rn 5 +: 5
                            __field eq 3 +: 1
                            __field PNd 0 +: 3
                            case (U, lt, eq) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pn_whilege_pn_rr_ // whilege_pn_rr_
                                when ('0', '0', '1') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pn_whilegt_pn_rr_ // whilegt_pn_rr_
                                when ('0', '1', '0') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pn_whilelt_pn_rr_ // whilelt_pn_rr_
                                when ('0', '1', '1') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pn_whilele_pn_rr_ // whilele_pn_rr_
                                when ('1', '0', '0') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pn_whilehs_pn_rr_ // whilehs_pn_rr_
                                when ('1', '0', '1') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pn_whilehi_pn_rr_ // whilehi_pn_rr_
                                when ('1', '1', '0') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pn_whilelo_pn_rr_ // whilelo_pn_rr_
                                when ('1', '1', '1') => __encoding A64_sve_sve_while_pn_sve_int_while_rr_pn_whilels_pn_rr_ // whilels_pn_rr_
                when ('001', _, '1xx1xxxx', _, '11xxxx', _, _, _) =>
                    // sve_wideimm_unpred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 17 +: 2, 16 +: 1, 14 +: 2, 5 +: 9, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '00', _, _, _, _, _, _) => // sve_int_arith_imm0
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm0_add_z_zi_ // add_z_zi_
                                when ('001') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm0_sub_z_zi_ // sub_z_zi_
                                when ('010') => __UNALLOCATED
                                when ('011') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm0_subr_z_zi_ // subr_z_zi_
                                when ('100') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm0_sqadd_z_zi_ // sqadd_z_zi_
                                when ('101') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm0_uqadd_z_zi_ // uqadd_z_zi_
                                when ('110') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm0_sqsub_z_zi_ // sqsub_z_zi_
                                when ('111') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm0_uqsub_z_zi_ // uqsub_z_zi_
                        when (_, _, _, '01', _, _, _, _, _, _) => // sve_int_arith_imm1
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when ('0xx', '1') => __UNALLOCATED
                                when ('000', '0') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm1_smax_z_zi_ // smax_z_zi_
                                when ('001', '0') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm1_umax_z_zi_ // umax_z_zi_
                                when ('010', '0') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm1_smin_z_zi_ // smin_z_zi_
                                when ('011', '0') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm1_umin_z_zi_ // umin_z_zi_
                                when ('1xx', _) => __UNALLOCATED
                        when (_, _, _, '10', _, _, _, _, _, _) => // sve_int_arith_imm2
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zdn 0 +: 5
                            case (opc, o2) of
                                when (!'000', _) => __UNALLOCATED
                                when ('000', '0') => __encoding A64_sve_sve_wideimm_unpred_sve_int_arith_imm2_mul_z_zi_ // mul_z_zi_
                                when ('000', '1') => __UNALLOCATED
                        when (_, _, _, '11', _, '0', _, _, _, _) => // sve_int_dup_imm
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field sh 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (opc) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sve_sve_wideimm_unpred_sve_int_dup_imm_dup_z_i_ // dup_z_i_
                        when (_, _, _, '11', _, '1', _, _, _, _) => // sve_int_dup_fpimm
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field o2 13 +: 1
                            __field imm8 5 +: 8
                            __field Zd 0 +: 5
                            case (opc, o2) of
                                when (!'00', _) => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sve_sve_wideimm_unpred_sve_int_dup_fpimm_fdup_z_i_ // fdup_z_i_
                                when ('00', '1') => __UNALLOCATED
                when ('010', _, '0x10xxxx', _, '11001x', _, _, _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxx', _, '0xxxxx', _, _, _) =>
                    // sve_intx_muladd_unpred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 10 +: 5, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '0000x', _, _, _) => // sve_intx_dot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_dot_sdot_z_zzz_ // sdot_z_zzz_
                                when ('1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_dot_udot_z_zzz_ // udot_z_zzz_
                        when (_, _, _, _, _, '0001x', _, _, _) => // sve_intx_qdmlalbt
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S) of
                                when ('0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_qdmlalbt_sqdmlalbt_z_zzz_ // sqdmlalbt_z_zzz_
                                when ('1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_qdmlalbt_sqdmlslbt_z_zzz_ // sqdmlslbt_z_zzz_
                        when (_, _, _, _, _, '001xx', _, _, _) => // sve_intx_cdot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_cdot_cdot_z_zzz_ // cdot_z_zzz_
                        when (_, _, _, _, _, '01xxx', _, _, _) => // sve_intx_cmla
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 12 +: 1
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_cmla_cmla_z_zzz_ // cmla_z_zzz_
                                when ('1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_cmla_sqrdcmlah_z_zzz_ // sqrdcmlah_z_zzz_
                        when (_, _, _, _, _, '10xxx', _, _, _) => // sve_intx_mlal_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S, U, T) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mlal_long_smlalb_z_zzz_ // smlalb_z_zzz_
                                when ('0', '0', '1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mlal_long_smlalt_z_zzz_ // smlalt_z_zzz_
                                when ('0', '1', '0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mlal_long_umlalb_z_zzz_ // umlalb_z_zzz_
                                when ('0', '1', '1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mlal_long_umlalt_z_zzz_ // umlalt_z_zzz_
                                when ('1', '0', '0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mlal_long_smlslb_z_zzz_ // smlslb_z_zzz_
                                when ('1', '0', '1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mlal_long_smlslt_z_zzz_ // smlslt_z_zzz_
                                when ('1', '1', '0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mlal_long_umlslb_z_zzz_ // umlslb_z_zzz_
                                when ('1', '1', '1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mlal_long_umlslt_z_zzz_ // umlslt_z_zzz_
                        when (_, _, _, _, _, '110xx', _, _, _) => // sve_intx_qdmlal_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S, T) of
                                when ('0', '0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_qdmlal_long_sqdmlalb_z_zzz_ // sqdmlalb_z_zzz_
                                when ('0', '1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_qdmlal_long_sqdmlalt_z_zzz_ // sqdmlalt_z_zzz_
                                when ('1', '0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_qdmlal_long_sqdmlslb_z_zzz_ // sqdmlslb_z_zzz_
                                when ('1', '1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_qdmlal_long_sqdmlslt_z_zzz_ // sqdmlslt_z_zzz_
                        when (_, _, _, _, _, '1110x', _, _, _) => // sve_intx_qrdmlah
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (S) of
                                when ('0') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_qrdmlah_sqrdmlah_z_zzz_ // sqrdmlah_z_zzz_
                                when ('1') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_qrdmlah_sqrdmlsh_z_zzz_ // sqrdmlsh_z_zzz_
                        when (_, _, _, _, _, '11110', _, _, _) => // sve_intx_mixed_dot
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when (!'10') => __UNALLOCATED
                                when ('10') => __encoding A64_sve_sve_intx_muladd_unpred_sve_intx_mixed_dot_usdot_z_zzz_s // usdot_z_zzz_s
                        when (_, _, _, _, _, '11111', _, _, _) => __UNPREDICTABLE
                when ('010', _, '0xx0xxxx', _, '10xxxx', _, _, _) =>
                    // sve_intx_predicated
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 16 +: 1, 14 +: 2, 13 +: 1, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0010', _, _, '1', _, _, _) => // sve_intx_accumulate_long_pairs
                            __field size 22 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding A64_sve_sve_intx_predicated_sve_intx_accumulate_long_pairs_sadalp_z_p_z_ // sadalp_z_p_z_
                                when ('1') => __encoding A64_sve_sve_intx_predicated_sve_intx_accumulate_long_pairs_uadalp_z_p_z_ // uadalp_z_p_z_
                        when (_, _, _, '0011', _, _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '011x', _, _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '0x0x', _, _, '1', _, _, _) => // sve_intx_pred_arith_unary
                            __field size 22 +: 2
                            __field Q 19 +: 1
                            __field Z 17 +: 1
                            __field op 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (Q, Z, op) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_unary_urecpe_z_p_z_m // urecpe_z_p_z_m
                                when ('0', '0', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_unary_ursqrte_z_p_z_m // ursqrte_z_p_z_m
                                when ('0', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_unary_urecpe_z_p_z_z // urecpe_z_p_z_z
                                when ('0', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_unary_ursqrte_z_p_z_z // ursqrte_z_p_z_z
                                when ('1', '0', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_unary_sqabs_z_p_z_m // sqabs_z_p_z_m
                                when ('1', '0', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_unary_sqneg_z_p_z_m // sqneg_z_p_z_m
                                when ('1', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_unary_sqabs_z_p_z_z // sqabs_z_p_z_z
                                when ('1', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_unary_sqneg_z_p_z_z // sqneg_z_p_z_z
                        when (_, _, _, '0xxx', _, _, '0', _, _, _) => // sve_intx_bin_pred_shift_sat_round
                            __field size 22 +: 2
                            __field Q 19 +: 1
                            __field R 18 +: 1
                            __field N 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (Q, R, N, U) of
                                when ('0', _, '0', _) => __UNALLOCATED
                                when ('0', '0', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_srshl_z_p_zz_ // srshl_z_p_zz_
                                when ('0', '0', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_urshl_z_p_zz_ // urshl_z_p_zz_
                                when ('0', '1', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_srshlr_z_p_zz_ // srshlr_z_p_zz_
                                when ('0', '1', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_urshlr_z_p_zz_ // urshlr_z_p_zz_
                                when ('1', '0', '0', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_sqshl_z_p_zz_ // sqshl_z_p_zz_
                                when ('1', '0', '0', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_uqshl_z_p_zz_ // uqshl_z_p_zz_
                                when ('1', '0', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_sqrshl_z_p_zz_ // sqrshl_z_p_zz_
                                when ('1', '0', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_uqrshl_z_p_zz_ // uqrshl_z_p_zz_
                                when ('1', '1', '0', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_sqshlr_z_p_zz_ // sqshlr_z_p_zz_
                                when ('1', '1', '0', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_uqshlr_z_p_zz_ // uqshlr_z_p_zz_
                                when ('1', '1', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_sqrshlr_z_p_zz_ // sqrshlr_z_p_zz_
                                when ('1', '1', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_bin_pred_shift_sat_round_uqrshlr_z_p_zz_ // uqrshlr_z_p_zz_
                        when (_, _, _, '10xx', _, _, '0', _, _, _) => // sve_intx_pred_arith_binary
                            __field size 22 +: 2
                            __field R 18 +: 1
                            __field S 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (R, S, U) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_shadd_z_p_zz_ // shadd_z_p_zz_
                                when ('0', '0', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_uhadd_z_p_zz_ // uhadd_z_p_zz_
                                when ('0', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_shsub_z_p_zz_ // shsub_z_p_zz_
                                when ('0', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_uhsub_z_p_zz_ // uhsub_z_p_zz_
                                when ('1', '0', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_srhadd_z_p_zz_ // srhadd_z_p_zz_
                                when ('1', '0', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_urhadd_z_p_zz_ // urhadd_z_p_zz_
                                when ('1', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_shsubr_z_p_zz_ // shsubr_z_p_zz_
                                when ('1', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_uhsubr_z_p_zz_ // uhsubr_z_p_zz_
                        when (_, _, _, '10xx', _, _, '1', _, _, _) => // sve_intx_arith_binary_pairs
                            __field size 22 +: 2
                            __field opc 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc, U) of
                                when ('00', '0') => __UNALLOCATED
                                when ('00', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_arith_binary_pairs_addp_z_p_zz_ // addp_z_p_zz_
                                when ('01', _) => __UNALLOCATED
                                when ('10', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_arith_binary_pairs_smaxp_z_p_zz_ // smaxp_z_p_zz_
                                when ('10', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_arith_binary_pairs_umaxp_z_p_zz_ // umaxp_z_p_zz_
                                when ('11', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_arith_binary_pairs_sminp_z_p_zz_ // sminp_z_p_zz_
                                when ('11', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_arith_binary_pairs_uminp_z_p_zz_ // uminp_z_p_zz_
                        when (_, _, _, '11xx', _, _, '0', _, _, _) => // sve_intx_pred_arith_binary_sat
                            __field size 22 +: 2
                            __field op 18 +: 1
                            __field S 17 +: 1
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (op, S, U) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_sat_sqadd_z_p_zz_ // sqadd_z_p_zz_
                                when ('0', '0', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_sat_uqadd_z_p_zz_ // uqadd_z_p_zz_
                                when ('0', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_sat_sqsub_z_p_zz_ // sqsub_z_p_zz_
                                when ('0', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_sat_uqsub_z_p_zz_ // uqsub_z_p_zz_
                                when ('1', '0', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_sat_suqadd_z_p_zz_ // suqadd_z_p_zz_
                                when ('1', '0', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_sat_usqadd_z_p_zz_ // usqadd_z_p_zz_
                                when ('1', '1', '0') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_sat_sqsubr_z_p_zz_ // sqsubr_z_p_zz_
                                when ('1', '1', '1') => __encoding A64_sve_sve_intx_predicated_sve_intx_pred_arith_binary_sat_uqsubr_z_p_zz_ // uqsubr_z_p_zz_
                        when (_, _, _, '11xx', _, _, '1', _, _, _) => __UNPREDICTABLE
                when ('010', _, '0xx1xxxx', _, _, _, _, _) =>
                    // sve_intx_by_indexed_elem
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 10 +: 6, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, '00000x', _, _, _) => // sve_intx_dot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, U) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_dot_by_indexed_elem_sdot_z_zzzi_s // sdot_z_zzzi_s
                                when ('10', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_dot_by_indexed_elem_udot_z_zzzi_s // udot_z_zzzi_s
                                when ('11', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_dot_by_indexed_elem_sdot_z_zzzi_d // sdot_z_zzzi_d
                                when ('11', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_dot_by_indexed_elem_udot_z_zzzi_d // udot_z_zzzi_d
                        when (_, _, _, _, '00001x', _, _, _) => // sve_intx_mla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S) of
                                when ('0x', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_by_indexed_elem_mla_z_zzzi_h // mla_z_zzzi_h
                                when ('0x', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_by_indexed_elem_mls_z_zzzi_h // mls_z_zzzi_h
                                when ('10', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_by_indexed_elem_mla_z_zzzi_s // mla_z_zzzi_s
                                when ('10', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_by_indexed_elem_mls_z_zzzi_s // mls_z_zzzi_s
                                when ('11', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_by_indexed_elem_mla_z_zzzi_d // mla_z_zzzi_d
                                when ('11', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_by_indexed_elem_mls_z_zzzi_d // mls_z_zzzi_d
                        when (_, _, _, _, '00010x', _, _, _) => // sve_intx_qrdmlah_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S) of
                                when ('0x', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qrdmlah_by_indexed_elem_sqrdmlah_z_zzzi_h // sqrdmlah_z_zzzi_h
                                when ('0x', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qrdmlah_by_indexed_elem_sqrdmlsh_z_zzzi_h // sqrdmlsh_z_zzzi_h
                                when ('10', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qrdmlah_by_indexed_elem_sqrdmlah_z_zzzi_s // sqrdmlah_z_zzzi_s
                                when ('10', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qrdmlah_by_indexed_elem_sqrdmlsh_z_zzzi_s // sqrdmlsh_z_zzzi_s
                                when ('11', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qrdmlah_by_indexed_elem_sqrdmlah_z_zzzi_d // sqrdmlah_z_zzzi_d
                                when ('11', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qrdmlah_by_indexed_elem_sqrdmlsh_z_zzzi_d // sqrdmlsh_z_zzzi_d
                        when (_, _, _, _, '00011x', _, _, _) => // sve_intx_mixed_dot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, U) of
                                when (!'10', _) => __UNALLOCATED
                                when ('10', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mixed_dot_by_indexed_elem_usdot_z_zzzi_s // usdot_z_zzzi_s
                                when ('10', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mixed_dot_by_indexed_elem_sudot_z_zzzi_s // sudot_z_zzzi_s
                        when (_, _, _, _, '001xxx', _, _, _) => // sve_intx_qdmla_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S, T) of
                                when ('0x', _, _) => __UNALLOCATED
                                when ('10', '0', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmla_long_by_indexed_elem_sqdmlalb_z_zzzi_s // sqdmlalb_z_zzzi_s
                                when ('10', '0', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmla_long_by_indexed_elem_sqdmlalt_z_zzzi_s // sqdmlalt_z_zzzi_s
                                when ('10', '1', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmla_long_by_indexed_elem_sqdmlslb_z_zzzi_s // sqdmlslb_z_zzzi_s
                                when ('10', '1', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmla_long_by_indexed_elem_sqdmlslt_z_zzzi_s // sqdmlslt_z_zzzi_s
                                when ('11', '0', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmla_long_by_indexed_elem_sqdmlalb_z_zzzi_d // sqdmlalb_z_zzzi_d
                                when ('11', '0', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmla_long_by_indexed_elem_sqdmlalt_z_zzzi_d // sqdmlalt_z_zzzi_d
                                when ('11', '1', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmla_long_by_indexed_elem_sqdmlslb_z_zzzi_d // sqdmlslb_z_zzzi_d
                                when ('11', '1', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmla_long_by_indexed_elem_sqdmlslt_z_zzzi_d // sqdmlslt_z_zzzi_d
                        when (_, _, _, _, '0100xx', _, _, _) => // sve_intx_cdot_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_cdot_by_indexed_elem_cdot_z_zzzi_s // cdot_z_zzzi_s
                                when ('11') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_cdot_by_indexed_elem_cdot_z_zzzi_d // cdot_z_zzzi_d
                        when (_, _, _, _, '0101xx', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '0110xx', _, _, _) => // sve_intx_cmla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_cmla_by_indexed_elem_cmla_z_zzzi_h // cmla_z_zzzi_h
                                when ('11') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_cmla_by_indexed_elem_cmla_z_zzzi_s // cmla_z_zzzi_s
                        when (_, _, _, _, '0111xx', _, _, _) => // sve_intx_qrdcmla_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field rot 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qrdcmla_by_indexed_elem_sqrdcmlah_z_zzzi_h // sqrdcmlah_z_zzzi_h
                                when ('11') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qrdcmla_by_indexed_elem_sqrdcmlah_z_zzzi_s // sqrdcmlah_z_zzzi_s
                        when (_, _, _, _, '10xxxx', _, _, _) => // sve_intx_mla_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field S 13 +: 1
                            __field U 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, S, U, T) of
                                when ('0x', _, _, _) => __UNALLOCATED
                                when ('10', '0', '0', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_smlalb_z_zzzi_s // smlalb_z_zzzi_s
                                when ('10', '0', '0', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_smlalt_z_zzzi_s // smlalt_z_zzzi_s
                                when ('10', '0', '1', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_umlalb_z_zzzi_s // umlalb_z_zzzi_s
                                when ('10', '0', '1', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_umlalt_z_zzzi_s // umlalt_z_zzzi_s
                                when ('10', '1', '0', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_smlslb_z_zzzi_s // smlslb_z_zzzi_s
                                when ('10', '1', '0', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_smlslt_z_zzzi_s // smlslt_z_zzzi_s
                                when ('10', '1', '1', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_umlslb_z_zzzi_s // umlslb_z_zzzi_s
                                when ('10', '1', '1', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_umlslt_z_zzzi_s // umlslt_z_zzzi_s
                                when ('11', '0', '0', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_smlalb_z_zzzi_d // smlalb_z_zzzi_d
                                when ('11', '0', '0', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_smlalt_z_zzzi_d // smlalt_z_zzzi_d
                                when ('11', '0', '1', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_umlalb_z_zzzi_d // umlalb_z_zzzi_d
                                when ('11', '0', '1', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_umlalt_z_zzzi_d // umlalt_z_zzzi_d
                                when ('11', '1', '0', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_smlslb_z_zzzi_d // smlslb_z_zzzi_d
                                when ('11', '1', '0', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_smlslt_z_zzzi_d // smlslt_z_zzzi_d
                                when ('11', '1', '1', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_umlslb_z_zzzi_d // umlslb_z_zzzi_d
                                when ('11', '1', '1', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mla_long_by_indexed_elem_umlslt_z_zzzi_d // umlslt_z_zzzi_d
                        when (_, _, _, _, '110xxx', _, _, _) => // sve_intx_mul_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field U 12 +: 1
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, U, T) of
                                when ('0x', _, _) => __UNALLOCATED
                                when ('10', '0', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_long_by_indexed_elem_smullb_z_zzi_s // smullb_z_zzi_s
                                when ('10', '0', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_long_by_indexed_elem_smullt_z_zzi_s // smullt_z_zzi_s
                                when ('10', '1', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_long_by_indexed_elem_umullb_z_zzi_s // umullb_z_zzi_s
                                when ('10', '1', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_long_by_indexed_elem_umullt_z_zzi_s // umullt_z_zzi_s
                                when ('11', '0', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_long_by_indexed_elem_smullb_z_zzi_d // smullb_z_zzi_d
                                when ('11', '0', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_long_by_indexed_elem_smullt_z_zzi_d // smullt_z_zzi_d
                                when ('11', '1', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_long_by_indexed_elem_umullb_z_zzi_d // umullb_z_zzi_d
                                when ('11', '1', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_long_by_indexed_elem_umullt_z_zzi_d // umullt_z_zzi_d
                        when (_, _, _, _, '1110xx', _, _, _) => // sve_intx_qdmul_long_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field il 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, T) of
                                when ('0x', _) => __UNALLOCATED
                                when ('10', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmul_long_by_indexed_elem_sqdmullb_z_zzi_s // sqdmullb_z_zzi_s
                                when ('10', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmul_long_by_indexed_elem_sqdmullt_z_zzi_s // sqdmullt_z_zzi_s
                                when ('11', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmul_long_by_indexed_elem_sqdmullb_z_zzi_d // sqdmullb_z_zzi_d
                                when ('11', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmul_long_by_indexed_elem_sqdmullt_z_zzi_d // sqdmullt_z_zzi_d
                        when (_, _, _, _, '11110x', _, _, _) => // sve_intx_qdmulh_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field R 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, R) of
                                when ('0x', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmulh_by_indexed_elem_sqdmulh_z_zzi_h // sqdmulh_z_zzi_h
                                when ('0x', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmulh_by_indexed_elem_sqrdmulh_z_zzi_h // sqrdmulh_z_zzi_h
                                when ('10', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmulh_by_indexed_elem_sqdmulh_z_zzi_s // sqdmulh_z_zzi_s
                                when ('10', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmulh_by_indexed_elem_sqrdmulh_z_zzi_s // sqrdmulh_z_zzi_s
                                when ('11', '0') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmulh_by_indexed_elem_sqdmulh_z_zzi_d // sqdmulh_z_zzi_d
                                when ('11', '1') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_qdmulh_by_indexed_elem_sqrdmulh_z_zzi_d // sqrdmulh_z_zzi_d
                        when (_, _, _, _, '111110', _, _, _) => // sve_intx_mul_by_indexed_elem
                            __field size 22 +: 2
                            __field opc 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size) of
                                when ('0x') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_by_indexed_elem_mul_z_zzi_h // mul_z_zzi_h
                                when ('10') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_by_indexed_elem_mul_z_zzi_s // mul_z_zzi_s
                                when ('11') => __encoding A64_sve_sve_intx_by_indexed_elem_sve_intx_mul_by_indexed_elem_mul_z_zzi_d // mul_z_zzi_d
                        when (_, _, _, _, '111111', _, _, _) => __UNPREDICTABLE
                when ('010', _, '1xx0xxxx', _, '0xxxxx', _, _, _) =>
                    // sve_intx_cons_widening
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 13 +: 2, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, _, '0x', _, _, _) => // sve_intx_cons_arith_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op, S, U, T) of
                                when ('0', '0', '0', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_saddlb_z_zz_ // saddlb_z_zz_
                                when ('0', '0', '0', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_saddlt_z_zz_ // saddlt_z_zz_
                                when ('0', '0', '1', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_uaddlb_z_zz_ // uaddlb_z_zz_
                                when ('0', '0', '1', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_uaddlt_z_zz_ // uaddlt_z_zz_
                                when ('0', '1', '0', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_ssublb_z_zz_ // ssublb_z_zz_
                                when ('0', '1', '0', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_ssublt_z_zz_ // ssublt_z_zz_
                                when ('0', '1', '1', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_usublb_z_zz_ // usublb_z_zz_
                                when ('0', '1', '1', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_usublt_z_zz_ // usublt_z_zz_
                                when ('1', '0', _, _) => __UNALLOCATED
                                when ('1', '1', '0', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_sabdlb_z_zz_ // sabdlb_z_zz_
                                when ('1', '1', '0', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_sabdlt_z_zz_ // sabdlt_z_zz_
                                when ('1', '1', '1', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_uabdlb_z_zz_ // uabdlb_z_zz_
                                when ('1', '1', '1', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_long_uabdlt_z_zz_ // uabdlt_z_zz_
                        when (_, _, _, _, _, '10', _, _, _) => // sve_intx_cons_arith_wide
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, U, T) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_wide_saddwb_z_zz_ // saddwb_z_zz_
                                when ('0', '0', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_wide_saddwt_z_zz_ // saddwt_z_zz_
                                when ('0', '1', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_wide_uaddwb_z_zz_ // uaddwb_z_zz_
                                when ('0', '1', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_wide_uaddwt_z_zz_ // uaddwt_z_zz_
                                when ('1', '0', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_wide_ssubwb_z_zz_ // ssubwb_z_zz_
                                when ('1', '0', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_wide_ssubwt_z_zz_ // ssubwt_z_zz_
                                when ('1', '1', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_wide_usubwb_z_zz_ // usubwb_z_zz_
                                when ('1', '1', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_arith_wide_usubwt_z_zz_ // usubwt_z_zz_
                        when (_, _, _, _, _, '11', _, _, _) => // sve_intx_cons_mul_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 12 +: 1
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, op, U, T) of
                                when (_, '0', '0', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_sqdmullb_z_zz_ // sqdmullb_z_zz_
                                when (_, '0', '0', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_sqdmullt_z_zz_ // sqdmullt_z_zz_
                                when (_, '1', '0', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_smullb_z_zz_ // smullb_z_zz_
                                when (_, '1', '0', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_smullt_z_zz_ // smullt_z_zz_
                                when (_, '1', '1', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_umullb_z_zz_ // umullb_z_zz_
                                when (_, '1', '1', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_umullt_z_zz_ // umullt_z_zz_
                                when ('00', '0', '1', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_pmullb_z_zz_q // pmullb_z_zz_q
                                when ('00', '0', '1', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_pmullt_z_zz_q // pmullt_z_zz_q
                                when (!'00', '0', '1', '0') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_pmullb_z_zz_ // pmullb_z_zz_
                                when (!'00', '0', '1', '1') => __encoding A64_sve_sve_intx_cons_widening_sve_intx_cons_mul_long_pmullt_z_zz_ // pmullt_z_zz_
                when ('010', _, '1xx0xxxx', _, '10xxxx', _, _, _) =>
                    // sve_intx_constructive
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 10 +: 4, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, _, _, '10xx', _, _, _) => // sve_intx_shift_long
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (U, T) of
                                when ('0', '0') => __encoding A64_sve_sve_intx_constructive_sve_intx_shift_long_sshllb_z_zi_ // sshllb_z_zi_
                                when ('0', '1') => __encoding A64_sve_sve_intx_constructive_sve_intx_shift_long_sshllt_z_zi_ // sshllt_z_zi_
                                when ('1', '0') => __encoding A64_sve_sve_intx_constructive_sve_intx_shift_long_ushllb_z_zi_ // ushllb_z_zi_
                                when ('1', '1') => __encoding A64_sve_sve_intx_constructive_sve_intx_shift_long_ushllt_z_zi_ // ushllt_z_zi_
                        when (_, '1', _, _, _, _, '10xx', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '00xx', _, _, _) => // sve_intx_clong
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 11 +: 1
                            __field tb 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, tb) of
                                when ('0', '0') => __encoding A64_sve_sve_intx_constructive_sve_intx_clong_saddlbt_z_zz_ // saddlbt_z_zz_
                                when ('0', '1') => __UNALLOCATED
                                when ('1', '0') => __encoding A64_sve_sve_intx_constructive_sve_intx_clong_ssublbt_z_zz_ // ssublbt_z_zz_
                                when ('1', '1') => __encoding A64_sve_sve_intx_constructive_sve_intx_clong_ssubltb_z_zz_ // ssubltb_z_zz_
                        when (_, _, _, _, _, _, '010x', _, _, _) => // sve_intx_eorx
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field tb 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (tb) of
                                when ('0') => __encoding A64_sve_sve_intx_constructive_sve_intx_eorx_eorbt_z_zz_ // eorbt_z_zz_
                                when ('1') => __encoding A64_sve_sve_intx_constructive_sve_intx_eorx_eortb_z_zz_ // eortb_z_zz_
                        when (_, _, _, _, _, _, '0110', _, _, _) => // sve_intx_mmla
                            __field uns 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (uns) of
                                when ('00') => __encoding A64_sve_sve_intx_constructive_sve_intx_mmla_smmla_z_zzz_ // smmla_z_zzz_
                                when ('01') => __UNALLOCATED
                                when ('10') => __encoding A64_sve_sve_intx_constructive_sve_intx_mmla_usmmla_z_zzz_ // usmmla_z_zzz_
                                when ('11') => __encoding A64_sve_sve_intx_constructive_sve_intx_mmla_ummla_z_zzz_ // ummla_z_zzz_
                        when (_, _, _, _, _, _, '0111', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '11xx', _, _, _) => // sve_intx_perm_bit
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_intx_constructive_sve_intx_perm_bit_bext_z_zz_ // bext_z_zz_
                                when ('01') => __encoding A64_sve_sve_intx_constructive_sve_intx_perm_bit_bdep_z_zz_ // bdep_z_zz_
                                when ('10') => __encoding A64_sve_sve_intx_constructive_sve_intx_perm_bit_bgrp_z_zz_ // bgrp_z_zz_
                                when ('11') => __UNALLOCATED
                when ('010', _, '1xx0xxxx', _, '11xxxx', _, _, _) =>
                    // sve_intx_acc
                    case (24 +: 8, 22 +: 2, 21 +: 1, 17 +: 4, 16 +: 1, 14 +: 2, 11 +: 3, 5 +: 6, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0000', _, _, '011', _, _, _) => // sve_intx_cadd
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field rot 10 +: 1
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_intx_acc_sve_intx_cadd_cadd_z_zz_ // cadd_z_zz_
                                when ('1') => __encoding A64_sve_sve_intx_acc_sve_intx_cadd_sqcadd_z_zz_ // sqcadd_z_zz_
                        when (_, _, _, _, _, _, '00x', _, _, _) => // sve_intx_aba_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U, T) of
                                when ('0', '0') => __encoding A64_sve_sve_intx_acc_sve_intx_aba_long_sabalb_z_zzz_ // sabalb_z_zzz_
                                when ('0', '1') => __encoding A64_sve_sve_intx_acc_sve_intx_aba_long_sabalt_z_zzz_ // sabalt_z_zzz_
                                when ('1', '0') => __encoding A64_sve_sve_intx_acc_sve_intx_aba_long_uabalb_z_zzz_ // uabalb_z_zzz_
                                when ('1', '1') => __encoding A64_sve_sve_intx_acc_sve_intx_aba_long_uabalt_z_zzz_ // uabalt_z_zzz_
                        when (_, _, _, _, _, _, '010', _, _, _) => // sve_intx_adc_long
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, T) of
                                when ('0x', '0') => __encoding A64_sve_sve_intx_acc_sve_intx_adc_long_adclb_z_zzz_ // adclb_z_zzz_
                                when ('0x', '1') => __encoding A64_sve_sve_intx_acc_sve_intx_adc_long_adclt_z_zzz_ // adclt_z_zzz_
                                when ('1x', '0') => __encoding A64_sve_sve_intx_acc_sve_intx_adc_long_sbclb_z_zzz_ // sbclb_z_zzz_
                                when ('1x', '1') => __encoding A64_sve_sve_intx_acc_sve_intx_adc_long_sbclt_z_zzz_ // sbclt_z_zzz_
                        when (_, _, _, !'0000', _, _, '011', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '10x', _, _, _) => // sve_intx_sra
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field R 11 +: 1
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (R, U) of
                                when ('0', '0') => __encoding A64_sve_sve_intx_acc_sve_intx_sra_ssra_z_zi_ // ssra_z_zi_
                                when ('0', '1') => __encoding A64_sve_sve_intx_acc_sve_intx_sra_usra_z_zi_ // usra_z_zi_
                                when ('1', '0') => __encoding A64_sve_sve_intx_acc_sve_intx_sra_srsra_z_zi_ // srsra_z_zi_
                                when ('1', '1') => __encoding A64_sve_sve_intx_acc_sve_intx_sra_ursra_z_zi_ // ursra_z_zi_
                        when (_, _, _, _, _, _, '110', _, _, _) => // sve_intx_shift_insert
                            __field tszh 22 +: 2
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_intx_acc_sve_intx_shift_insert_sri_z_zzi_ // sri_z_zzi_
                                when ('1') => __encoding A64_sve_sve_intx_acc_sve_intx_shift_insert_sli_z_zzi_ // sli_z_zzi_
                        when (_, _, _, _, _, _, '111', _, _, _) => // sve_intx_aba
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field U 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (U) of
                                when ('0') => __encoding A64_sve_sve_intx_acc_sve_intx_aba_saba_z_zzz_ // saba_z_zzz_
                                when ('1') => __encoding A64_sve_sve_intx_acc_sve_intx_aba_uaba_z_zzz_ // uaba_z_zzz_
                when ('010', _, '1xx1xxxx', _, '0xxxxx', _, _, _) =>
                    // sve_intx_narrowing
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 19 +: 2, 17 +: 2, 16 +: 1, 15 +: 1, 13 +: 2, 11 +: 2, 10 +: 1, 6 +: 4, 5 +: 1, 0 +: 5) of
                        when (_, '0', _, _, _, '00', '0', _, '10', _, _, _, _, _) => // sve_intx_extract_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field opc 11 +: 2
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, T) of
                                when ('00', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_extract_narrow_sqxtnb_z_zz_ // sqxtnb_z_zz_
                                when ('00', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_extract_narrow_sqxtnt_z_zz_ // sqxtnt_z_zz_
                                when ('01', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_extract_narrow_uqxtnb_z_zz_ // uqxtnb_z_zz_
                                when ('01', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_extract_narrow_uqxtnt_z_zz_ // uqxtnt_z_zz_
                                when ('10', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_extract_narrow_sqxtunb_z_zz_ // sqxtunb_z_zz_
                                when ('10', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_extract_narrow_sqxtunt_z_zz_ // sqxtunt_z_zz_
                                when ('11', _) => __UNALLOCATED
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '0', _, '0', _) => // sve_intx_multi_extract_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field opc 11 +: 2
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (tszh, tszl, opc) of
                                when ('0', !'10', _) => __UNALLOCATED
                                when ('0', '10', '00') => __encoding A64_sve_sve_intx_narrowing_sve_intx_multi_extract_narrow_sqcvtn_z_mz2_ // sqcvtn_z_mz2_
                                when ('0', '10', '01') => __encoding A64_sve_sve_intx_narrowing_sve_intx_multi_extract_narrow_uqcvtn_z_mz2_ // uqcvtn_z_mz2_
                                when ('0', '10', '10') => __encoding A64_sve_sve_intx_narrowing_sve_intx_multi_extract_narrow_sqcvtun_z_mz2_ // sqcvtun_z_mz2_
                                when ('0', '10', '11') => __UNALLOCATED
                                when ('1', _, _) => __UNALLOCATED
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, '00', '1', _, '10', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '0', _, _, _, _, _, _, '0x', _, _, _, _, _) => // sve_intx_shift_narrow
                            __field tszh 22 +: 1
                            __field tszl 19 +: 2
                            __field imm3 16 +: 3
                            __field op 13 +: 1
                            __field U 12 +: 1
                            __field R 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op, U, R, T) of
                                when ('0', '0', '0', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_sqshrunb_z_zi_ // sqshrunb_z_zi_
                                when ('0', '0', '0', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_sqshrunt_z_zi_ // sqshrunt_z_zi_
                                when ('0', '0', '1', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_sqrshrunb_z_zi_ // sqrshrunb_z_zi_
                                when ('0', '0', '1', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_sqrshrunt_z_zi_ // sqrshrunt_z_zi_
                                when ('0', '1', '0', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_shrnb_z_zi_ // shrnb_z_zi_
                                when ('0', '1', '0', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_shrnt_z_zi_ // shrnt_z_zi_
                                when ('0', '1', '1', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_rshrnb_z_zi_ // rshrnb_z_zi_
                                when ('0', '1', '1', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_rshrnt_z_zi_ // rshrnt_z_zi_
                                when ('1', '0', '0', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_sqshrnb_z_zi_ // sqshrnb_z_zi_
                                when ('1', '0', '0', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_sqshrnt_z_zi_ // sqshrnt_z_zi_
                                when ('1', '0', '1', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_sqrshrnb_z_zi_ // sqrshrnb_z_zi_
                                when ('1', '0', '1', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_sqrshrnt_z_zi_ // sqrshrnt_z_zi_
                                when ('1', '1', '0', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_uqshrnb_z_zi_ // uqshrnb_z_zi_
                                when ('1', '1', '0', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_uqshrnt_z_zi_ // uqshrnt_z_zi_
                                when ('1', '1', '1', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_uqrshrnb_z_zi_ // uqrshrnb_z_zi_
                                when ('1', '1', '1', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_shift_narrow_uqrshrnt_z_zi_ // uqrshrnt_z_zi_
                        when (_, '0', _, _, _, !'00', _, _, '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, '0x', _, '0', _, '0', _) => // sve_intx_multi_shift_narrow
                            __field tszh 22 +: 1
                            __field tszl 20 +: 1
                            __field imm4 16 +: 4
                            __field op 13 +: 1
                            __field U 12 +: 1
                            __field R 11 +: 1
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (tszh, tszl, op, U, R) of
                                when ('0', '0', _, _, _) => __UNALLOCATED
                                when ('0', '1', _, _, '0') => __UNALLOCATED
                                when ('0', '1', '0', '0', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_multi_shift_narrow_sqrshrun_z_mz2_ // sqrshrun_z_mz2_
                                when ('0', '1', '0', '1', '1') => __UNALLOCATED
                                when ('0', '1', '1', '0', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_multi_shift_narrow_sqrshrn_z_mz2_ // sqrshrn_z_mz2_
                                when ('0', '1', '1', '1', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_multi_shift_narrow_uqrshrn_z_mz2_ // uqrshrn_z_mz2_
                                when ('1', _, _, _, _) => __UNALLOCATED
                        when (_, '1', _, _, _, _, _, _, '0x', _, '0', _, '1', _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, '0x', _, '1', _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, '10', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, _, _, '11', _, _, _, _, _) => // sve_intx_arith_narrow
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field S 12 +: 1
                            __field R 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (S, R, T) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_arith_narrow_addhnb_z_zz_ // addhnb_z_zz_
                                when ('0', '0', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_arith_narrow_addhnt_z_zz_ // addhnt_z_zz_
                                when ('0', '1', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_arith_narrow_raddhnb_z_zz_ // raddhnb_z_zz_
                                when ('0', '1', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_arith_narrow_raddhnt_z_zz_ // raddhnt_z_zz_
                                when ('1', '0', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_arith_narrow_subhnb_z_zz_ // subhnb_z_zz_
                                when ('1', '0', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_arith_narrow_subhnt_z_zz_ // subhnt_z_zz_
                                when ('1', '1', '0') => __encoding A64_sve_sve_intx_narrowing_sve_intx_arith_narrow_rsubhnb_z_zz_ // rsubhnb_z_zz_
                                when ('1', '1', '1') => __encoding A64_sve_sve_intx_narrowing_sve_intx_arith_narrow_rsubhnt_z_zz_ // rsubhnt_z_zz_
                when ('010', _, '1xx1xxxx', _, '101xxx', _, _, _) =>
                    // sve_intx_histseg_lut
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 13 +: 3, 10 +: 3, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, _, '0', _, _, _, '0x1', _, _, _) => __UNPREDICTABLE
                        when (_, _, '1', _, _, _, '001', _, _, _) => // sve_intx_lut4_8
                            __field i1 23 +: 1
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_intx_histseg_lut_sve_intx_lut4_8_luti4_z_zz_8 // luti4_z_zz_8
                        when (_, _, '1', _, _, _, '011', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '000', _, _, _) => // sve_intx_histseg
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_intx_histseg_lut_sve_intx_histseg_histseg_z_zz_ // histseg_z_zz_
                        when (_, _, _, _, _, _, '100', _, _, _) => // sve_intx_lut2_8
                            __field i2 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_intx_histseg_lut_sve_intx_lut2_8_luti2_z_zz_8 // luti2_z_zz_8
                        when (_, _, _, _, _, _, '1x1', _, _, _) => // sve_intx_lut4_16
                            __field i2 22 +: 2
                            __field Zm 16 +: 5
                            __field op 11 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_intx_histseg_lut_sve_intx_lut4_16_luti4_z_zz_2x16 // luti4_z_zz_2x16
                                when ('1') => __encoding A64_sve_sve_intx_histseg_lut_sve_intx_lut4_16_luti4_z_zz_1x16 // luti4_z_zz_1x16
                        when (_, _, _, _, _, _, 'x10', _, _, _) => // sve_intx_lut2_16
                            __field i3h 22 +: 2
                            __field Zm 16 +: 5
                            __field i3l 12 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_intx_histseg_lut_sve_intx_lut2_16_luti2_z_zz_16 // luti2_z_zz_16
                when ('010', _, '1xx1xxxx', _, '111xxx', _, _, _) =>
                    // sve_intx_crypto
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 10 +: 3, 5 +: 5, 1 +: 4, 0 +: 1) of
                        when (_, _, _, '000', '00', _, '00x', '00000', _, _) => // sve_crypto_unary
                            __field size 22 +: 2
                            __field op 10 +: 1
                            __field Zdn 0 +: 5
                            case (size, op) of
                                when (!'00', _) => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sve_sve_intx_crypto_sve_crypto_unary_aesmc_z_z_ // aesmc_z_z_
                                when ('00', '1') => __encoding A64_sve_sve_intx_crypto_sve_crypto_unary_aesimc_z_z_ // aesimc_z_z_
                        when (_, _, _, '000', '00', _, '00x', !'00000', _, _) => __UNPREDICTABLE
                        when (_, _, _, '000', '01', _, '00x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '000', '1x', _, '00x', _, _, _) => // sve_crypto_binary_dest
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field o2 10 +: 1
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, op, o2) of
                                when (!'00', _, _) => __UNALLOCATED
                                when ('00', '0', '0') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_dest_aese_z_zz_ // aese_z_zz_
                                when ('00', '0', '1') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_dest_aesd_z_zz_ // aesd_z_zz_
                                when ('00', '1', '0') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_dest_sm4e_z_zz_ // sm4e_z_zz_
                                when ('00', '1', '1') => __UNALLOCATED
                        when (_, _, _, 'xx0', '1x', _, '01x', _, _, _) => // sve_crypto_binary_multi2
                            __field size 22 +: 2
                            __field i2 19 +: 2
                            __field op 16 +: 1
                            __field o2 10 +: 1
                            __field Zm 5 +: 5
                            __field Zdn 1 +: 4
                            __field o3 0 +: 1
                            case (size, op, o2, o3) of
                                when (!'00', _, _, _) => __UNALLOCATED
                                when ('00', _, _, '1') => __UNALLOCATED
                                when ('00', '0', '0', '0') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_multi2_aese_mz_zzi_2x1 // aese_mz_zzi_2x1
                                when ('00', '0', '1', '0') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_multi2_aesd_mz_zzi_2x1 // aesd_mz_zzi_2x1
                                when ('00', '1', '0', '0') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_multi2_aesemc_mz_zzi_2x1 // aesemc_mz_zzi_2x1
                                when ('00', '1', '1', '0') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_multi2_aesdimc_mz_zzi_2x1 // aesdimc_mz_zzi_2x1
                        when (_, _, _, 'xx1', '1x', _, '01x', _, _, _) => // sve_crypto_binary_multi4
                            __field size 22 +: 2
                            __field i2 19 +: 2
                            __field op 16 +: 1
                            __field o2 10 +: 1
                            __field Zm 5 +: 5
                            __field Zdn 2 +: 3
                            __field opc3 0 +: 2
                            case (size, op, o2, opc3) of
                                when (!'00', _, _, _) => __UNALLOCATED
                                when ('00', _, _, !'00') => __UNALLOCATED
                                when ('00', '0', '0', '00') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_multi4_aese_mz_zzi_4x1 // aese_mz_zzi_4x1
                                when ('00', '0', '1', '00') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_multi4_aesd_mz_zzi_4x1 // aesd_mz_zzi_4x1
                                when ('00', '1', '0', '00') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_multi4_aesemc_mz_zzi_4x1 // aesemc_mz_zzi_4x1
                                when ('00', '1', '1', '00') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_multi4_aesdimc_mz_zzi_4x1 // aesdimc_mz_zzi_4x1
                        when (_, _, _, _, '00', _, '01x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, '01', _, '01x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, !'000', _, _, '00x', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, _, '10x', _, _, _) => // sve_crypto_binary_const
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field op 10 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (size, op) of
                                when (!'00', _) => __UNALLOCATED
                                when ('00', '0') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_const_sm4ekey_z_zz_ // sm4ekey_z_zz_
                                when ('00', '1') => __encoding A64_sve_sve_intx_crypto_sve_crypto_binary_const_rax1_z_zz_ // rax1_z_zz_
                        when (_, _, _, _, _, _, '110', _, _, '0') => // sve_crypto_pmull_multi
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zd 1 +: 4
                            case (size) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sve_sve_intx_crypto_sve_crypto_pmull_multi_pmull_mz_zzw_1x2 // pmull_mz_zzw_1x2
                        when (_, _, _, _, _, _, '111', _, _, '0') => // sve_crypto_pmlal_multi
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field Zn 5 +: 5
                            __field Zda 1 +: 4
                            case (size) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sve_sve_intx_crypto_sve_crypto_pmlal_multi_pmlal_mz_zzzw_1x2 // pmlal_mz_zzzw_1x2
                        when (_, _, _, _, _, _, '11x', _, _, '1') => __UNPREDICTABLE
                when ('011', _, '01x1xxxx', _, '111000', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '0111xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '10xx10', _, _, _) =>
                    // sve_fp8_fma_w
                    case (24 +: 8, 23 +: 1, 21 +: 2, 16 +: 5, 14 +: 2, 13 +: 1, 12 +: 1, 10 +: 2, 5 +: 5, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, _, _, _, _, _, _, _) => // sve_fp8_fma_long_long
                            __field Zm 16 +: 5
                            __field TT 12 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (TT) of
                                when ('00') => __encoding A64_sve_sve_fp8_fma_w_sve_fp8_fma_long_long_fmlallbb_z32_z8z8z8_ // fmlallbb_z32_z8z8z8_
                                when ('01') => __encoding A64_sve_sve_fp8_fma_w_sve_fp8_fma_long_long_fmlallbt_z32_z8z8z8_ // fmlallbt_z32_z8z8z8_
                                when ('10') => __encoding A64_sve_sve_fp8_fma_w_sve_fp8_fma_long_long_fmlalltb_z32_z8z8z8_ // fmlalltb_z32_z8z8z8_
                                when ('11') => __encoding A64_sve_sve_fp8_fma_w_sve_fp8_fma_long_long_fmlalltt_z32_z8z8z8_ // fmlalltt_z32_z8z8z8_
                        when (_, '1', _, _, _, '0', _, _, _, _, _) => // sve_fp8_fma_long
                            __field Zm 16 +: 5
                            __field T 12 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (T) of
                                when ('0') => __encoding A64_sve_sve_fp8_fma_w_sve_fp8_fma_long_fmlalb_z_z8z8z8_ // fmlalb_z_z8z8z8_
                                when ('1') => __encoding A64_sve_sve_fp8_fma_w_sve_fp8_fma_long_fmlalt_z_z8z8z8_ // fmlalt_z_z8z8z8_
                        when (_, '1', _, _, _, '1', _, _, _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '10xx11', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x01xxxx', _, '11x1xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x11xxxx', _, '10xx1x', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0x11xxxx', _, 'x1x1xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00001', _, '100xxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx0010x', _, '100xxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00x0x', _, '11xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx00x1x', _, '1xxxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx010xx', _, '11xxxx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx011xx', _, '1xxxxx', _, _, _) =>
                    // sve_fp_zeroing_unary
                    case (24 +: 8, 22 +: 2, 19 +: 3, 16 +: 3, 15 +: 1, 5 +: 10, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '00x', _, _, _, _) => // sve_fp_z2op_p_zd_a
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field opc2 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op, opc2) of
                                when ('0', '00') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_a_frintn_z_p_z_z // frintn_z_p_z_z
                                when ('0', '01') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_a_frintp_z_p_z_z // frintp_z_p_z_z
                                when ('0', '10') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_a_frintm_z_p_z_z // frintm_z_p_z_z
                                when ('0', '11') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_a_frintz_z_p_z_z // frintz_z_p_z_z
                                when ('1', '00') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_a_frinta_z_p_z_z // frinta_z_p_z_z
                                when ('1', '01') => __UNALLOCATED
                                when ('1', '10') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_a_frintx_z_p_z_z // frintx_z_p_z_z
                                when ('1', '11') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_a_frinti_z_p_z_z // frinti_z_p_z_z
                        when (_, _, _, '010', _, _, _, _) => // sve_fp_z2op_p_zd_b_0
                            __field opc 22 +: 2
                            __field opc2 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('x0', '11') => __UNALLOCATED
                                when ('00', '0x') => __UNALLOCATED
                                when ('00', '10') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_0_fcvtx_z_p_z_d2sz // fcvtx_z_p_z_d2sz
                                when ('01', _) => __UNALLOCATED
                                when ('10', '00') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_0_fcvt_z_p_z_s2hz // fcvt_z_p_z_s2hz
                                when ('10', '01') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_0_fcvt_z_p_z_h2sz // fcvt_z_p_z_h2sz
                                when ('10', '10') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_0_bfcvt_z_p_z_s2bfz // bfcvt_z_p_z_s2bfz
                                when ('11', '00') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_0_fcvt_z_p_z_d2hz // fcvt_z_p_z_d2hz
                                when ('11', '01') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_0_fcvt_z_p_z_h2dz // fcvt_z_p_z_h2dz
                                when ('11', '10') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_0_fcvt_z_p_z_d2sz // fcvt_z_p_z_d2sz
                                when ('11', '11') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_0_fcvt_z_p_z_s2dz // fcvt_z_p_z_s2dz
                        when (_, _, _, '011', _, _, _, _) => // sve_fp_z2op_p_zd_b_1
                            __field size 22 +: 2
                            __field opc 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_1_frecpx_z_p_z_z // frecpx_z_p_z_z
                                when ('01') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_b_1_fsqrt_z_p_z_z // fsqrt_z_p_z_z
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '10x', _, _, _, _) => // sve_fp_z2op_p_zd_c
                            __field opc 22 +: 2
                            __field o2 16 +: 1
                            __field o3 14 +: 1
                            __field U 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, o2, o3, U) of
                                when ('00', '0', _, '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_frint32z_z_p_z_z // frint32z_z_p_z_z
                                when ('00', '0', _, '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_frint32x_z_p_z_z // frint32x_z_p_z_z
                                when ('00', '1', _, '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_frint64z_z_p_z_z // frint64z_z_p_z_z
                                when ('00', '1', _, '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_frint64x_z_p_z_z // frint64x_z_p_z_z
                                when ('01', '0', '0', _) => __UNALLOCATED
                                when ('01', '0', '1', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_scvtf_z_p_z_h2fp16z // scvtf_z_p_z_h2fp16z
                                when ('01', '0', '1', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_ucvtf_z_p_z_h2fp16z // ucvtf_z_p_z_h2fp16z
                                when ('01', '1', '0', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_scvtf_z_p_z_w2fp16z // scvtf_z_p_z_w2fp16z
                                when ('01', '1', '0', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_ucvtf_z_p_z_w2fp16z // ucvtf_z_p_z_w2fp16z
                                when ('01', '1', '1', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_scvtf_z_p_z_x2fp16z // scvtf_z_p_z_x2fp16z
                                when ('01', '1', '1', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_ucvtf_z_p_z_x2fp16z // ucvtf_z_p_z_x2fp16z
                                when ('10', '0', _, _) => __UNALLOCATED
                                when ('10', '1', '0', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_scvtf_z_p_z_w2sz // scvtf_z_p_z_w2sz
                                when ('10', '1', '0', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_ucvtf_z_p_z_w2sz // ucvtf_z_p_z_w2sz
                                when ('10', '1', '1', _) => __UNALLOCATED
                                when ('11', '0', '0', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_scvtf_z_p_z_w2dz // scvtf_z_p_z_w2dz
                                when ('11', '0', '0', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_ucvtf_z_p_z_w2dz // ucvtf_z_p_z_w2dz
                                when ('11', '0', '1', _) => __UNALLOCATED
                                when ('11', '1', '0', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_scvtf_z_p_z_x2sz // scvtf_z_p_z_x2sz
                                when ('11', '1', '0', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_ucvtf_z_p_z_x2sz // ucvtf_z_p_z_x2sz
                                when ('11', '1', '1', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_scvtf_z_p_z_x2dz // scvtf_z_p_z_x2dz
                                when ('11', '1', '1', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_c_ucvtf_z_p_z_x2dz // ucvtf_z_p_z_x2dz
                        when (_, _, _, '11x', _, _, _, _) => // sve_fp_z2op_p_zd_d
                            __field opc 22 +: 2
                            __field o2 16 +: 1
                            __field o3 14 +: 1
                            __field U 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, o2, o3, U) of
                                when ('00', '0', _, _) => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_flogb_z_p_z_z // flogb_z_p_z_z
                                when ('00', '1', _, _) => __UNALLOCATED
                                when ('01', '0', '0', _) => __UNALLOCATED
                                when ('01', '0', '1', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzs_z_p_z_fp162hz // fcvtzs_z_p_z_fp162hz
                                when ('01', '0', '1', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzu_z_p_z_fp162hz // fcvtzu_z_p_z_fp162hz
                                when ('01', '1', '0', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzs_z_p_z_fp162wz // fcvtzs_z_p_z_fp162wz
                                when ('01', '1', '0', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzu_z_p_z_fp162wz // fcvtzu_z_p_z_fp162wz
                                when ('01', '1', '1', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzs_z_p_z_fp162xz // fcvtzs_z_p_z_fp162xz
                                when ('01', '1', '1', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzu_z_p_z_fp162xz // fcvtzu_z_p_z_fp162xz
                                when ('10', '0', _, _) => __UNALLOCATED
                                when ('10', '1', '0', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzs_z_p_z_s2wz // fcvtzs_z_p_z_s2wz
                                when ('10', '1', '0', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzu_z_p_z_s2wz // fcvtzu_z_p_z_s2wz
                                when ('10', '1', '1', _) => __UNALLOCATED
                                when ('11', '0', '0', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzs_z_p_z_d2wz // fcvtzs_z_p_z_d2wz
                                when ('11', '0', '0', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzu_z_p_z_d2wz // fcvtzu_z_p_z_d2wz
                                when ('11', '0', '1', _) => __UNALLOCATED
                                when ('11', '1', '0', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzs_z_p_z_s2xz // fcvtzs_z_p_z_s2xz
                                when ('11', '1', '0', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzu_z_p_z_s2xz // fcvtzu_z_p_z_s2xz
                                when ('11', '1', '1', '0') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzs_z_p_z_d2xz // fcvtzs_z_p_z_d2xz
                                when ('11', '1', '1', '1') => __encoding A64_sve_sve_fp_zeroing_unary_sve_fp_z2op_p_zd_d_fcvtzu_z_p_z_d2xz // fcvtzu_z_p_z_d2xz
                when ('011', _, '0xx1xxxx', _, '001011', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxx', _, '0011xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxx', _, '01x0xx', _, _, _) =>
                    // sve_fp_fma_w_by_indexed_elem
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 13 +: 1, 12 +: 1, 5 +: 7, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, _, _, '0', _, _, _, _) => // sve_fp_fdot_by_indexed_elem
                            __field op 22 +: 1
                            __field i2 19 +: 2
                            __field Zm 16 +: 3
                            __field opc2 10 +: 2
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op, opc2) of
                                when ('0', 'x1') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fdot_by_indexed_elem_fdot_z_zz8z8i_ // fdot_z_zz8z8i_
                                when ('0', '00') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fdot_by_indexed_elem_fdot_z_zzzi_ // fdot_z_zzzi_
                                when ('0', '10') => __UNALLOCATED
                                when ('1', '00') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fdot_by_indexed_elem_bfdot_z_zzzi_ // bfdot_z_zzzi_
                                when ('1', '01') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fdot_by_indexed_elem_fdot_z32_zz8z8i_ // fdot_z32_zz8z8i_
                                when ('1', '1x') => __UNALLOCATED
                        when (_, '0', _, _, _, _, '1', _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _, _, _) => // sve_fp_fma_long_by_indexed_elem
                            __field o2 22 +: 1
                            __field i3h 19 +: 2
                            __field Zm 16 +: 3
                            __field op 13 +: 1
                            __field i3l 11 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (o2, op, T) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fma_long_by_indexed_elem_fmlalb_z_zzzi_s // fmlalb_z_zzzi_s
                                when ('0', '0', '1') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fma_long_by_indexed_elem_fmlalt_z_zzzi_s // fmlalt_z_zzzi_s
                                when ('0', '1', '0') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fma_long_by_indexed_elem_fmlslb_z_zzzi_s // fmlslb_z_zzzi_s
                                when ('0', '1', '1') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fma_long_by_indexed_elem_fmlslt_z_zzzi_s // fmlslt_z_zzzi_s
                                when ('1', '0', '0') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fma_long_by_indexed_elem_bfmlalb_z_zzzi_ // bfmlalb_z_zzzi_
                                when ('1', '0', '1') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fma_long_by_indexed_elem_bfmlalt_z_zzzi_ // bfmlalt_z_zzzi_
                                when ('1', '1', '0') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fma_long_by_indexed_elem_bfmlslb_z_zzzi_ // bfmlslb_z_zzzi_
                                when ('1', '1', '1') => __encoding A64_sve_sve_fp_fma_w_by_indexed_elem_sve_fp_fma_long_by_indexed_elem_bfmlslt_z_zzzi_ // bfmlslt_z_zzzi_
                when ('011', _, '0xx1xxxx', _, '10x00x', _, _, _) =>
                    // sve_fp_fma_w
                    case (24 +: 8, 23 +: 1, 22 +: 1, 21 +: 1, 16 +: 5, 14 +: 2, 13 +: 1, 11 +: 2, 5 +: 6, 4 +: 1, 0 +: 4) of
                        when (_, '0', _, _, _, _, '0', _, _, _, _) => // sve_fp_fdot
                            __field op 22 +: 1
                            __field Zm 16 +: 5
                            __field o2 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (op, o2) of
                                when ('0', '0') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fdot_fdot_z_zzz_ // fdot_z_zzz_
                                when ('0', '1') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fdot_fdot_z_zz8z8_ // fdot_z_zz8z8_
                                when ('1', '0') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fdot_bfdot_z_zzz_ // bfdot_z_zzz_
                                when ('1', '1') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fdot_fdot_z32_zz8z8_ // fdot_z32_zz8z8_
                        when (_, '0', _, _, _, _, '1', _, _, _, _) => __UNPREDICTABLE
                        when (_, '1', _, _, _, _, _, _, _, _, _) => // sve_fp_fma_long
                            __field o2 22 +: 1
                            __field Zm 16 +: 5
                            __field op 13 +: 1
                            __field T 10 +: 1
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (o2, op, T) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fma_long_fmlalb_z_zzz_ // fmlalb_z_zzz_
                                when ('0', '0', '1') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fma_long_fmlalt_z_zzz_ // fmlalt_z_zzz_
                                when ('0', '1', '0') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fma_long_fmlslb_z_zzz_ // fmlslb_z_zzz_
                                when ('0', '1', '1') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fma_long_fmlslt_z_zzz_ // fmlslt_z_zzz_
                                when ('1', '0', '0') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fma_long_bfmlalb_z_zzz_ // bfmlalb_z_zzz_
                                when ('1', '0', '1') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fma_long_bfmlalt_z_zzz_ // bfmlalt_z_zzz_
                                when ('1', '1', '0') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fma_long_bfmlslb_z_zzz_ // bfmlslb_z_zzz_
                                when ('1', '1', '1') => __encoding A64_sve_sve_fp_fma_w_sve_fp_fma_long_bfmlslt_z_zzz_ // bfmlslt_z_zzz_
                when ('011', _, '0xx1xxxx', _, '10x10x', _, _, _) => __UNPREDICTABLE
                when ('011', _, '0xx1xxxx', _, '11101x', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx001xx', _, '0010xx', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx001xx', _, '0011xx', _, _, _) =>
                    // sve_fp_unary_unpred
                    case (24 +: 8, 22 +: 2, 19 +: 3, 16 +: 3, 12 +: 4, 10 +: 2, 6 +: 4, 5 +: 1, 0 +: 5) of
                        when (_, '00', _, '00x', _, _, _, _, _) => // sve_fp8_fcvt_wide
                            __field L 16 +: 1
                            __field opc 10 +: 2
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (L, opc) of
                                when ('0', '00') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_wide_f1cvt_z_z8_b2h // f1cvt_z_z8_b2h
                                when ('0', '01') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_wide_f2cvt_z_z8_b2h // f2cvt_z_z8_b2h
                                when ('0', '10') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_wide_bf1cvt_z_z8_b2bf // bf1cvt_z_z8_b2bf
                                when ('0', '11') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_wide_bf2cvt_z_z8_b2bf // bf2cvt_z_z8_b2bf
                                when ('1', '00') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_wide_f1cvtlt_z_z8_b2h // f1cvtlt_z_z8_b2h
                                when ('1', '01') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_wide_f2cvtlt_z_z8_b2h // f2cvtlt_z_z8_b2h
                                when ('1', '10') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_wide_bf1cvtlt_z_z8_b2bf // bf1cvtlt_z_z8_b2bf
                                when ('1', '11') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_wide_bf2cvtlt_z_z8_b2bf // bf2cvtlt_z_z8_b2bf
                        when (_, '00', _, '010', _, _, _, '0', _) => // sve_fp8_fcvt_narrow
                            __field opc 10 +: 2
                            __field Zn 6 +: 4
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_narrow_fcvtn_z8_mz2_h2b // fcvtn_z8_mz2_h2b
                                when ('01') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_narrow_fcvtnb_z8_mz2_s2b // fcvtnb_z8_mz2_s2b
                                when ('10') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_narrow_bfcvtn_z8_mz2_bf2b // bfcvtn_z8_mz2_bf2b
                                when ('11') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp8_fcvt_narrow_fcvtnt_z8_mz2_s2b // fcvtnt_z8_mz2_s2b
                        when (_, '00', _, '010', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, '00', _, '011', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, !'00', _, '0xx', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '10x', _, _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '11x', _, '00', _, _, _) => // sve_fp_2op_u_zd
                            __field size 22 +: 2
                            __field op 16 +: 1
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (op) of
                                when ('0') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp_2op_u_zd_frecpe_z_z_ // frecpe_z_z_
                                when ('1') => __encoding A64_sve_sve_fp_unary_unpred_sve_fp_2op_u_zd_frsqrte_z_z_ // frsqrte_z_z_
                        when (_, _, _, '11x', _, !'00', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx010xx', _, '001xxx', _, _, _) =>
                    // sve_fp_cmpzero
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0', _, _, _, _, _) => // sve_fp_2op_p_pd
                            __field size 22 +: 2
                            __field eq 17 +: 1
                            __field lt 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field ne 4 +: 1
                            __field Pd 0 +: 4
                            case (eq, lt, ne) of
                                when ('0', '0', '0') => __encoding A64_sve_sve_fp_cmpzero_sve_fp_2op_p_pd_fcmge_p_p_z0_ // fcmge_p_p_z0_
                                when ('0', '0', '1') => __encoding A64_sve_sve_fp_cmpzero_sve_fp_2op_p_pd_fcmgt_p_p_z0_ // fcmgt_p_p_z0_
                                when ('0', '1', '0') => __encoding A64_sve_sve_fp_cmpzero_sve_fp_2op_p_pd_fcmlt_p_p_z0_ // fcmlt_p_p_z0_
                                when ('0', '1', '1') => __encoding A64_sve_sve_fp_cmpzero_sve_fp_2op_p_pd_fcmle_p_p_z0_ // fcmle_p_p_z0_
                                when ('1', _, '1') => __UNALLOCATED
                                when ('1', '0', '0') => __encoding A64_sve_sve_fp_cmpzero_sve_fp_2op_p_pd_fcmeq_p_p_z0_ // fcmeq_p_p_z0_
                                when ('1', '1', '0') => __encoding A64_sve_sve_fp_cmpzero_sve_fp_2op_p_pd_fcmne_p_p_z0_ // fcmne_p_p_z0_
                        when (_, _, _, '1', _, _, _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx011xx', _, '001xxx', _, _, _) =>
                    // sve_fp_slowreduce
                    case (24 +: 8, 22 +: 2, 19 +: 3, 18 +: 1, 16 +: 2, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0', _, _, _, _, _) => // sve_fp_2op_p_vd
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Vdn 0 +: 5
                            case (opc) of
                                when (!'00') => __UNALLOCATED
                                when ('00') => __encoding A64_sve_sve_fp_slowreduce_sve_fp_2op_p_vd_fadda_v_p_z_ // fadda_v_p_z_
                        when (_, _, _, '1', _, _, _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx0xxxx', _, '100xxx', _, _, _) =>
                    // sve_fp_pred
                    case (24 +: 8, 22 +: 2, 21 +: 1, 19 +: 2, 16 +: 3, 13 +: 3, 10 +: 3, 6 +: 4, 5 +: 1, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '0x', _, _, _, _, _, _, _) => // sve_fp_2op_p_zds
                            __field size 22 +: 2
                            __field opc 16 +: 4
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (size, opc) of
                                when (_, '0011') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fsubr_z_p_zz_ // fsubr_z_p_zz_
                                when (_, '1000') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fabd_z_p_zz_ // fabd_z_p_zz_
                                when (_, '1010') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fmulx_z_p_zz_ // fmulx_z_p_zz_
                                when (_, '1011') => __UNALLOCATED
                                when (_, '1100') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fdivr_z_p_zz_ // fdivr_z_p_zz_
                                when (_, '1101') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fdiv_z_p_zz_ // fdiv_z_p_zz_
                                when (_, '1110') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_famax_z_p_zz_ // famax_z_p_zz_
                                when (_, '1111') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_famin_z_p_zz_ // famin_z_p_zz_
                                when ('00', '0000') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_bfadd_z_p_zz_ // bfadd_z_p_zz_
                                when ('00', '0001') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_bfsub_z_p_zz_ // bfsub_z_p_zz_
                                when ('00', '0010') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_bfmul_z_p_zz_ // bfmul_z_p_zz_
                                when ('00', '0100') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_bfmaxnm_z_p_zz_ // bfmaxnm_z_p_zz_
                                when ('00', '0101') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_bfminnm_z_p_zz_ // bfminnm_z_p_zz_
                                when ('00', '0110') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_bfmax_z_p_zz_ // bfmax_z_p_zz_
                                when ('00', '0111') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_bfmin_z_p_zz_ // bfmin_z_p_zz_
                                when ('00', '1001') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_bfscale_z_p_zz_ // bfscale_z_p_zz_
                                when (!'00', '0000') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fadd_z_p_zz_ // fadd_z_p_zz_
                                when (!'00', '0001') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fsub_z_p_zz_ // fsub_z_p_zz_
                                when (!'00', '0010') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fmul_z_p_zz_ // fmul_z_p_zz_
                                when (!'00', '0100') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fmaxnm_z_p_zz_ // fmaxnm_z_p_zz_
                                when (!'00', '0101') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fminnm_z_p_zz_ // fminnm_z_p_zz_
                                when (!'00', '0110') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fmax_z_p_zz_ // fmax_z_p_zz_
                                when (!'00', '0111') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fmin_z_p_zz_ // fmin_z_p_zz_
                                when (!'00', '1001') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_p_zds_fscale_z_p_zz_ // fscale_z_p_zz_
                        when (_, _, _, '10', _, _, '000', _, _, _, _) => // sve_fp_ftmad
                            __field size 22 +: 2
                            __field imm3 16 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_fp_pred_sve_fp_ftmad_ftmad_z_zzi_ // ftmad_z_zzi_
                        when (_, _, _, '10', _, _, !'000', _, _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '11', _, _, _, '0000', _, _, _) => // sve_fp_2op_i_p_zds
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field i1 5 +: 1
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('000') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_i_p_zds_fadd_z_p_zs_ // fadd_z_p_zs_
                                when ('001') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_i_p_zds_fsub_z_p_zs_ // fsub_z_p_zs_
                                when ('010') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_i_p_zds_fmul_z_p_zs_ // fmul_z_p_zs_
                                when ('011') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_i_p_zds_fsubr_z_p_zs_ // fsubr_z_p_zs_
                                when ('100') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_i_p_zds_fmaxnm_z_p_zs_ // fmaxnm_z_p_zs_
                                when ('101') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_i_p_zds_fminnm_z_p_zs_ // fminnm_z_p_zs_
                                when ('110') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_i_p_zds_fmax_z_p_zs_ // fmax_z_p_zs_
                                when ('111') => __encoding A64_sve_sve_fp_pred_sve_fp_2op_i_p_zds_fmin_z_p_zs_ // fmin_z_p_zs_
                        when (_, _, _, '11', _, _, _, !'0000', _, _, _) => __UNPREDICTABLE
                when ('011', _, '1xx0xxxx', _, '101xxx', _, _, _) =>
                    // sve_fp_unary
                    case (24 +: 8, 22 +: 2, 21 +: 1, 18 +: 3, 16 +: 2, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, _, '00x', _, _, _, _, _) => // sve_fp_2op_p_zd_a
                            __field size 22 +: 2
                            __field opc 16 +: 3
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('000') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_a_frintn_z_p_z_m // frintn_z_p_z_m
                                when ('001') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_a_frintp_z_p_z_m // frintp_z_p_z_m
                                when ('010') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_a_frintm_z_p_z_m // frintm_z_p_z_m
                                when ('011') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_a_frintz_z_p_z_m // frintz_z_p_z_m
                                when ('100') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_a_frinta_z_p_z_m // frinta_z_p_z_m
                                when ('101') => __UNALLOCATED
                                when ('110') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_a_frintx_z_p_z_m // frintx_z_p_z_m
                                when ('111') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_a_frinti_z_p_z_m // frinti_z_p_z_m
                        when (_, _, _, '010', _, _, _, _, _) => // sve_fp_2op_p_zd_b_0
                            __field opc 22 +: 2
                            __field opc2 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2) of
                                when ('x0', '11') => __UNALLOCATED
                                when ('00', '0x') => __UNALLOCATED
                                when ('00', '10') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_0_fcvtx_z_p_z_d2s // fcvtx_z_p_z_d2s
                                when ('01', _) => __UNALLOCATED
                                when ('10', '00') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_0_fcvt_z_p_z_s2h // fcvt_z_p_z_s2h
                                when ('10', '01') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_0_fcvt_z_p_z_h2s // fcvt_z_p_z_h2s
                                when ('10', '10') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_0_bfcvt_z_p_z_s2bf // bfcvt_z_p_z_s2bf
                                when ('11', '00') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_0_fcvt_z_p_z_d2h // fcvt_z_p_z_d2h
                                when ('11', '01') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_0_fcvt_z_p_z_h2d // fcvt_z_p_z_h2d
                                when ('11', '10') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_0_fcvt_z_p_z_d2s // fcvt_z_p_z_d2s
                                when ('11', '11') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_0_fcvt_z_p_z_s2d // fcvt_z_p_z_s2d
                        when (_, _, _, '011', _, _, _, _, _) => // sve_fp_2op_p_zd_b_1
                            __field size 22 +: 2
                            __field opc 16 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_1_frecpx_z_p_z_m // frecpx_z_p_z_m
                                when ('01') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_b_1_fsqrt_z_p_z_m // fsqrt_z_p_z_m
                                when ('1x') => __UNALLOCATED
                        when (_, _, _, '10x', _, _, _, _, _) => // sve_fp_2op_p_zd_c
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2, U) of
                                when ('00', '0x', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_frint32z_z_p_z_m // frint32z_z_p_z_m
                                when ('00', '0x', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_frint32x_z_p_z_m // frint32x_z_p_z_m
                                when ('00', '1x', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_frint64z_z_p_z_m // frint64z_z_p_z_m
                                when ('00', '1x', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_frint64x_z_p_z_m // frint64x_z_p_z_m
                                when ('01', '00', _) => __UNALLOCATED
                                when ('01', '01', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_scvtf_z_p_z_h2fp16 // scvtf_z_p_z_h2fp16
                                when ('01', '01', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_ucvtf_z_p_z_h2fp16 // ucvtf_z_p_z_h2fp16
                                when ('01', '10', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_scvtf_z_p_z_w2fp16 // scvtf_z_p_z_w2fp16
                                when ('01', '10', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_ucvtf_z_p_z_w2fp16 // ucvtf_z_p_z_w2fp16
                                when ('01', '11', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_scvtf_z_p_z_x2fp16 // scvtf_z_p_z_x2fp16
                                when ('01', '11', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_ucvtf_z_p_z_x2fp16 // ucvtf_z_p_z_x2fp16
                                when ('10', !'10', _) => __UNALLOCATED
                                when ('10', '10', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_scvtf_z_p_z_w2s // scvtf_z_p_z_w2s
                                when ('10', '10', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_ucvtf_z_p_z_w2s // ucvtf_z_p_z_w2s
                                when ('11', '00', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_scvtf_z_p_z_w2d // scvtf_z_p_z_w2d
                                when ('11', '00', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_ucvtf_z_p_z_w2d // ucvtf_z_p_z_w2d
                                when ('11', '01', _) => __UNALLOCATED
                                when ('11', '10', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_scvtf_z_p_z_x2s // scvtf_z_p_z_x2s
                                when ('11', '10', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_ucvtf_z_p_z_x2s // ucvtf_z_p_z_x2s
                                when ('11', '11', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_scvtf_z_p_z_x2d // scvtf_z_p_z_x2d
                                when ('11', '11', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_c_ucvtf_z_p_z_x2d // ucvtf_z_p_z_x2d
                        when (_, _, _, '11x', _, _, _, _, _) => // sve_fp_2op_p_zd_d
                            __field opc 22 +: 2
                            __field opc2 17 +: 2
                            __field U 16 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zd 0 +: 5
                            case (opc, opc2, U) of
                                when ('00', _, '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_flogb_z_p_z_m // flogb_z_p_z_m
                                when ('00', _, '1') => __UNALLOCATED
                                when ('01', '00', _) => __UNALLOCATED
                                when ('01', '01', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzs_z_p_z_fp162h // fcvtzs_z_p_z_fp162h
                                when ('01', '01', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzu_z_p_z_fp162h // fcvtzu_z_p_z_fp162h
                                when ('01', '10', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzs_z_p_z_fp162w // fcvtzs_z_p_z_fp162w
                                when ('01', '10', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzu_z_p_z_fp162w // fcvtzu_z_p_z_fp162w
                                when ('01', '11', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzs_z_p_z_fp162x // fcvtzs_z_p_z_fp162x
                                when ('01', '11', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzu_z_p_z_fp162x // fcvtzu_z_p_z_fp162x
                                when ('10', !'10', _) => __UNALLOCATED
                                when ('10', '10', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzs_z_p_z_s2w // fcvtzs_z_p_z_s2w
                                when ('10', '10', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzu_z_p_z_s2w // fcvtzu_z_p_z_s2w
                                when ('11', '00', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzs_z_p_z_d2w // fcvtzs_z_p_z_d2w
                                when ('11', '00', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzu_z_p_z_d2w // fcvtzu_z_p_z_d2w
                                when ('11', '01', _) => __UNALLOCATED
                                when ('11', '10', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzs_z_p_z_s2x // fcvtzs_z_p_z_s2x
                                when ('11', '10', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzu_z_p_z_s2x // fcvtzu_z_p_z_s2x
                                when ('11', '11', '0') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzs_z_p_z_d2x // fcvtzs_z_p_z_d2x
                                when ('11', '11', '1') => __encoding A64_sve_sve_fp_unary_sve_fp_2op_p_zd_d_fcvtzu_z_p_z_d2x // fcvtzu_z_p_z_d2x
                when ('011', _, '1xx1xxxx', _, _, _, _, _) =>
                    // sve_fp_fma
                    case (24 +: 8, 22 +: 2, 21 +: 1, 16 +: 5, 15 +: 1, 5 +: 10, 4 +: 1, 0 +: 4) of
                        when (_, _, _, _, '0', _, _, _) => // sve_fp_3op_p_zds_a
                            __field size 22 +: 2
                            __field Zm 16 +: 5
                            __field opc 13 +: 2
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zda 0 +: 5
                            case (size, opc) of
                                when ('00', '00') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_a_bfmla_z_p_zzz_ // bfmla_z_p_zzz_
                                when ('00', '01') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_a_bfmls_z_p_zzz_ // bfmls_z_p_zzz_
                                when ('00', '1x') => __UNALLOCATED
                                when (!'00', '00') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_a_fmla_z_p_zzz_ // fmla_z_p_zzz_
                                when (!'00', '01') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_a_fmls_z_p_zzz_ // fmls_z_p_zzz_
                                when (!'00', '10') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_a_fnmla_z_p_zzz_ // fnmla_z_p_zzz_
                                when (!'00', '11') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_a_fnmls_z_p_zzz_ // fnmls_z_p_zzz_
                        when (_, _, _, _, '1', _, _, _) => // sve_fp_3op_p_zds_b
                            __field size 22 +: 2
                            __field Za 16 +: 5
                            __field opc 13 +: 2
                            __field Pg 10 +: 3
                            __field Zm 5 +: 5
                            __field Zdn 0 +: 5
                            case (opc) of
                                when ('00') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_b_fmad_z_p_zzz_ // fmad_z_p_zzz_
                                when ('01') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_b_fmsb_z_p_zzz_ // fmsb_z_p_zzz_
                                when ('10') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_b_fnmad_z_p_zzz_ // fnmad_z_p_zzz_
                                when ('11') => __encoding A64_sve_sve_fp_fma_sve_fp_3op_p_zds_b_fnmsb_z_p_zzz_ // fnmsb_z_p_zzz_
                when ('100', _, _, _, _, _, _, _) =>
                    // sve_mem32
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '00', 'x1', _, '0xx', _, '0', _) => // sve_mem_32b_prfm_sv
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_mem32_sve_mem_32b_prfm_sv_prfb_i_p_bz_s_x32_scaled // prfb_i_p_bz_s_x32_scaled
                                when ('01') => __encoding A64_sve_sve_mem32_sve_mem_32b_prfm_sv_prfh_i_p_bz_s_x32_scaled // prfh_i_p_bz_s_x32_scaled
                                when ('10') => __encoding A64_sve_sve_mem32_sve_mem_32b_prfm_sv_prfw_i_p_bz_s_x32_scaled // prfw_i_p_bz_s_x32_scaled
                                when ('11') => __encoding A64_sve_sve_mem32_sve_mem_32b_prfm_sv_prfd_i_p_bz_s_x32_scaled // prfd_i_p_bz_s_x32_scaled
                        when (_, '00', 'x1', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, '01', 'x1', _, '0xx', _, _, _) => // sve_mem_32b_gld_sv_a
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (U, ff) of
                                when ('0', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_sv_a_ld1sh_z_p_bz_s_x32_scaled // ld1sh_z_p_bz_s_x32_scaled
                                when ('0', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_sv_a_ldff1sh_z_p_bz_s_x32_scaled // ldff1sh_z_p_bz_s_x32_scaled
                                when ('1', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_sv_a_ld1h_z_p_bz_s_x32_scaled // ld1h_z_p_bz_s_x32_scaled
                                when ('1', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_sv_a_ldff1h_z_p_bz_s_x32_scaled // ldff1h_z_p_bz_s_x32_scaled
                        when (_, '10', 'x1', _, '0xx', _, _, _) => // sve_mem_32b_gld_sv_b
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (U, ff) of
                                when ('0', _) => __UNALLOCATED
                                when ('1', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_sv_b_ld1w_z_p_bz_s_x32_scaled // ld1w_z_p_bz_s_x32_scaled
                                when ('1', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_sv_b_ldff1w_z_p_bz_s_x32_scaled // ldff1w_z_p_bz_s_x32_scaled
                        when (_, '11', '0x', _, '000', _, '0', _) => // sve_mem_32b_pfill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Pt 0 +: 4
                            case () of
                                when () => __encoding A64_sve_sve_mem32_sve_mem_32b_pfill_ldr_p_bi_ // ldr_p_bi_
                        when (_, '11', '0x', _, '000', _, '1', _) => __UNPREDICTABLE
                        when (_, '11', '0x', _, '010', _, _, _) => // sve_mem_32b_fill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_mem32_sve_mem_32b_fill_ldr_z_bi_ // ldr_z_bi_
                        when (_, '11', '0x', _, '0x1', _, _, _) => __UNPREDICTABLE
                        when (_, '11', '1x', _, '0xx', _, '0', _) => // sve_mem_prfm_si
                            __field imm6 16 +: 6
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_mem32_sve_mem_prfm_si_prfb_i_p_bi_s // prfb_i_p_bi_s
                                when ('01') => __encoding A64_sve_sve_mem32_sve_mem_prfm_si_prfh_i_p_bi_s // prfh_i_p_bi_s
                                when ('10') => __encoding A64_sve_sve_mem32_sve_mem_prfm_si_prfw_i_p_bi_s // prfw_i_p_bi_s
                                when ('11') => __encoding A64_sve_sve_mem32_sve_mem_prfm_si_prfd_i_p_bi_s // prfd_i_p_bi_s
                        when (_, '11', '1x', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, _, '00', _, '10x', _, _, _) => // sve_mem_32b_gldnt_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field U 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U) of
                                when ('00', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gldnt_vs_ldnt1sb_z_p_ar_s_x32_unscaled // ldnt1sb_z_p_ar_s_x32_unscaled
                                when ('00', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gldnt_vs_ldnt1b_z_p_ar_s_x32_unscaled // ldnt1b_z_p_ar_s_x32_unscaled
                                when ('01', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gldnt_vs_ldnt1sh_z_p_ar_s_x32_unscaled // ldnt1sh_z_p_ar_s_x32_unscaled
                                when ('01', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gldnt_vs_ldnt1h_z_p_ar_s_x32_unscaled // ldnt1h_z_p_ar_s_x32_unscaled
                                when ('10', '0') => __UNALLOCATED
                                when ('10', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gldnt_vs_ldnt1w_z_p_ar_s_x32_unscaled // ldnt1w_z_p_ar_s_x32_unscaled
                                when ('11', _) => __UNALLOCATED
                        when (_, _, '00', _, '110', _, '0', _) => // sve_mem_prfm_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz, Rm) of
                                when (_, '11111') => __UNALLOCATED
                                when ('00', !'11111') => __encoding A64_sve_sve_mem32_sve_mem_prfm_ss_prfb_i_p_br_s // prfb_i_p_br_s
                                when ('01', !'11111') => __encoding A64_sve_sve_mem32_sve_mem_prfm_ss_prfh_i_p_br_s // prfh_i_p_br_s
                                when ('10', !'11111') => __encoding A64_sve_sve_mem32_sve_mem_prfm_ss_prfw_i_p_br_s // prfw_i_p_br_s
                                when ('11', !'11111') => __encoding A64_sve_sve_mem32_sve_mem_prfm_ss_prfd_i_p_br_s // prfd_i_p_br_s
                        when (_, _, '00', _, '111', _, '0', _) => // sve_mem_32b_prfm_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_mem32_sve_mem_32b_prfm_vi_prfb_i_p_ai_s // prfb_i_p_ai_s
                                when ('01') => __encoding A64_sve_sve_mem32_sve_mem_32b_prfm_vi_prfh_i_p_ai_s // prfh_i_p_ai_s
                                when ('10') => __encoding A64_sve_sve_mem32_sve_mem_32b_prfm_vi_prfw_i_p_ai_s // prfw_i_p_ai_s
                                when ('11') => __encoding A64_sve_sve_mem32_sve_mem_32b_prfm_vi_prfd_i_p_ai_s // prfd_i_p_ai_s
                        when (_, _, '00', _, '11x', _, '1', _) => __UNPREDICTABLE
                        when (_, _, '01', _, '1xx', _, _, _) => // sve_mem_32b_gld_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ld1sb_z_p_ai_s // ld1sb_z_p_ai_s
                                when ('00', '0', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ldff1sb_z_p_ai_s // ldff1sb_z_p_ai_s
                                when ('00', '1', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ld1b_z_p_ai_s // ld1b_z_p_ai_s
                                when ('00', '1', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ldff1b_z_p_ai_s // ldff1b_z_p_ai_s
                                when ('01', '0', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ld1sh_z_p_ai_s // ld1sh_z_p_ai_s
                                when ('01', '0', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ldff1sh_z_p_ai_s // ldff1sh_z_p_ai_s
                                when ('01', '1', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ld1h_z_p_ai_s // ld1h_z_p_ai_s
                                when ('01', '1', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ldff1h_z_p_ai_s // ldff1h_z_p_ai_s
                                when ('10', '0', _) => __UNALLOCATED
                                when ('10', '1', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ld1w_z_p_ai_s // ld1w_z_p_ai_s
                                when ('10', '1', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vi_ldff1w_z_p_ai_s // ldff1w_z_p_ai_s
                                when ('11', _, _) => __UNALLOCATED
                        when (_, _, '1x', _, '1xx', _, _, _) => // sve_mem_ld_dup
                            __field dtypeh 23 +: 2
                            __field imm6 16 +: 6
                            __field dtypel 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtypeh, dtypel) of
                                when ('00', '00') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rb_z_p_bi_u8 // ld1rb_z_p_bi_u8
                                when ('00', '01') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rb_z_p_bi_u16 // ld1rb_z_p_bi_u16
                                when ('00', '10') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rb_z_p_bi_u32 // ld1rb_z_p_bi_u32
                                when ('00', '11') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rb_z_p_bi_u64 // ld1rb_z_p_bi_u64
                                when ('01', '00') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rsw_z_p_bi_s64 // ld1rsw_z_p_bi_s64
                                when ('01', '01') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rh_z_p_bi_u16 // ld1rh_z_p_bi_u16
                                when ('01', '10') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rh_z_p_bi_u32 // ld1rh_z_p_bi_u32
                                when ('01', '11') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rh_z_p_bi_u64 // ld1rh_z_p_bi_u64
                                when ('10', '00') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rsh_z_p_bi_s64 // ld1rsh_z_p_bi_s64
                                when ('10', '01') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rsh_z_p_bi_s32 // ld1rsh_z_p_bi_s32
                                when ('10', '10') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rw_z_p_bi_u32 // ld1rw_z_p_bi_u32
                                when ('10', '11') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rw_z_p_bi_u64 // ld1rw_z_p_bi_u64
                                when ('11', '00') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rsb_z_p_bi_s64 // ld1rsb_z_p_bi_s64
                                when ('11', '01') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rsb_z_p_bi_s32 // ld1rsb_z_p_bi_s32
                                when ('11', '10') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rsb_z_p_bi_s16 // ld1rsb_z_p_bi_s16
                                when ('11', '11') => __encoding A64_sve_sve_mem32_sve_mem_ld_dup_ld1rd_z_p_bi_u64 // ld1rd_z_p_bi_u64
                        when (_, !'11', 'x0', _, '0xx', _, _, _) => // sve_mem_32b_gld_vs
                            __field opc 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('00', '0', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ld1sb_z_p_bz_s_x32_unscaled // ld1sb_z_p_bz_s_x32_unscaled
                                when ('00', '0', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ldff1sb_z_p_bz_s_x32_unscaled // ldff1sb_z_p_bz_s_x32_unscaled
                                when ('00', '1', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ld1b_z_p_bz_s_x32_unscaled // ld1b_z_p_bz_s_x32_unscaled
                                when ('00', '1', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ldff1b_z_p_bz_s_x32_unscaled // ldff1b_z_p_bz_s_x32_unscaled
                                when ('01', '0', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ld1sh_z_p_bz_s_x32_unscaled // ld1sh_z_p_bz_s_x32_unscaled
                                when ('01', '0', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ldff1sh_z_p_bz_s_x32_unscaled // ldff1sh_z_p_bz_s_x32_unscaled
                                when ('01', '1', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ld1h_z_p_bz_s_x32_unscaled // ld1h_z_p_bz_s_x32_unscaled
                                when ('01', '1', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ldff1h_z_p_bz_s_x32_unscaled // ldff1h_z_p_bz_s_x32_unscaled
                                when ('10', '0', _) => __UNALLOCATED
                                when ('10', '1', '0') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ld1w_z_p_bz_s_x32_unscaled // ld1w_z_p_bz_s_x32_unscaled
                                when ('10', '1', '1') => __encoding A64_sve_sve_mem32_sve_mem_32b_gld_vs_ldff1w_z_p_bz_s_x32_unscaled // ldff1w_z_p_bz_s_x32_unscaled
                when ('101', _, _, _, _, _, _, _) =>
                    // sve_memcld
                    case (25 +: 7, 23 +: 2, 21 +: 2, 20 +: 1, 16 +: 4, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, '00', '0', _, '111', _, _, _) => // sve_mem_cldnt_si
                            __field msz 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memcld_sve_mem_cldnt_si_ldnt1b_z_p_bi_contiguous // ldnt1b_z_p_bi_contiguous
                                when ('01') => __encoding A64_sve_sve_memcld_sve_mem_cldnt_si_ldnt1h_z_p_bi_contiguous // ldnt1h_z_p_bi_contiguous
                                when ('10') => __encoding A64_sve_sve_memcld_sve_mem_cldnt_si_ldnt1w_z_p_bi_contiguous // ldnt1w_z_p_bi_contiguous
                                when ('11') => __encoding A64_sve_sve_memcld_sve_mem_cldnt_si_ldnt1d_z_p_bi_contiguous // ldnt1d_z_p_bi_contiguous
                        when (_, _, '00', '1', _, '001', _, _, _) => // sve_mem_cld_si_q
                            __field dtype 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0x') => __UNALLOCATED
                                when ('10') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_q_ld1w_z_p_bi_u128 // ld1w_z_p_bi_u128
                                when ('11') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_q_ld1d_z_p_bi_u128 // ld1d_z_p_bi_u128
                        when (_, _, '00', '1', _, '111', _, _, _) => // sve_mem_eldq_si
                            __field num 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding A64_sve_sve_memcld_sve_mem_eldq_si_ld2q_z_p_bi_contiguous // ld2q_z_p_bi_contiguous
                                when ('10') => __encoding A64_sve_sve_memcld_sve_mem_eldq_si_ld3q_z_p_bi_contiguous // ld3q_z_p_bi_contiguous
                                when ('11') => __encoding A64_sve_sve_memcld_sve_mem_eldq_si_ld4q_z_p_bi_contiguous // ld4q_z_p_bi_contiguous
                        when (_, _, '00', _, _, '100', _, _, _) => // sve_mem_cld_ss_q
                            __field dtype 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype, Rm) of
                                when ('0x', _) => __UNALLOCATED
                                when ('1x', '11111') => __UNALLOCATED
                                when ('10', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_q_ld1w_z_p_br_u128 // ld1w_z_p_br_u128
                                when ('11', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_q_ld1d_z_p_br_u128 // ld1d_z_p_br_u128
                        when (_, _, '00', _, _, '110', _, _, _) => // sve_mem_cldnt_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, Rm) of
                                when (_, '11111') => __UNALLOCATED
                                when ('00', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cldnt_ss_ldnt1b_z_p_br_contiguous // ldnt1b_z_p_br_contiguous
                                when ('01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cldnt_ss_ldnt1h_z_p_br_contiguous // ldnt1h_z_p_br_contiguous
                                when ('10', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cldnt_ss_ldnt1w_z_p_br_contiguous // ldnt1w_z_p_br_contiguous
                                when ('11', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cldnt_ss_ldnt1d_z_p_br_contiguous // ldnt1d_z_p_br_contiguous
                        when (_, _, '01', _, _, '100', _, _, _) => // sve_mem_eldq_ss
                            __field num 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num, Rm) of
                                when (!'00', '11111') => __UNALLOCATED
                                when ('00', _) => __UNALLOCATED
                                when ('01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eldq_ss_ld2q_z_p_br_contiguous // ld2q_z_p_br_contiguous
                                when ('10', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eldq_ss_ld3q_z_p_br_contiguous // ld3q_z_p_br_contiguous
                                when ('11', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eldq_ss_ld4q_z_p_br_contiguous // ld4q_z_p_br_contiguous
                        when (_, _, '1x', _, _, '100', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '0', _, '001', _, _, _) => // sve_mem_ldqr_si
                            __field msz 23 +: 2
                            __field ssz 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, ssz) of
                                when (_, '1x') => __UNALLOCATED
                                when ('00', '00') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_si_ld1rqb_z_p_bi_u8 // ld1rqb_z_p_bi_u8
                                when ('00', '01') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_si_ld1rob_z_p_bi_u8 // ld1rob_z_p_bi_u8
                                when ('01', '00') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_si_ld1rqh_z_p_bi_u16 // ld1rqh_z_p_bi_u16
                                when ('01', '01') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_si_ld1roh_z_p_bi_u16 // ld1roh_z_p_bi_u16
                                when ('10', '00') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_si_ld1rqw_z_p_bi_u32 // ld1rqw_z_p_bi_u32
                                when ('10', '01') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_si_ld1row_z_p_bi_u32 // ld1row_z_p_bi_u32
                                when ('11', '00') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_si_ld1rqd_z_p_bi_u64 // ld1rqd_z_p_bi_u64
                                when ('11', '01') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_si_ld1rod_z_p_bi_u64 // ld1rod_z_p_bi_u64
                        when (_, _, _, '0', _, '101', _, _, _) => // sve_mem_cld_si
                            __field dtype 21 +: 4
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1b_z_p_bi_u8 // ld1b_z_p_bi_u8
                                when ('0001') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1b_z_p_bi_u16 // ld1b_z_p_bi_u16
                                when ('0010') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1b_z_p_bi_u32 // ld1b_z_p_bi_u32
                                when ('0011') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1b_z_p_bi_u64 // ld1b_z_p_bi_u64
                                when ('0100') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1sw_z_p_bi_s64 // ld1sw_z_p_bi_s64
                                when ('0101') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1h_z_p_bi_u16 // ld1h_z_p_bi_u16
                                when ('0110') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1h_z_p_bi_u32 // ld1h_z_p_bi_u32
                                when ('0111') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1h_z_p_bi_u64 // ld1h_z_p_bi_u64
                                when ('1000') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1sh_z_p_bi_s64 // ld1sh_z_p_bi_s64
                                when ('1001') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1sh_z_p_bi_s32 // ld1sh_z_p_bi_s32
                                when ('1010') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1w_z_p_bi_u32 // ld1w_z_p_bi_u32
                                when ('1011') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1w_z_p_bi_u64 // ld1w_z_p_bi_u64
                                when ('1100') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1sb_z_p_bi_s64 // ld1sb_z_p_bi_s64
                                when ('1101') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1sb_z_p_bi_s32 // ld1sb_z_p_bi_s32
                                when ('1110') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1sb_z_p_bi_s16 // ld1sb_z_p_bi_s16
                                when ('1111') => __encoding A64_sve_sve_memcld_sve_mem_cld_si_ld1d_z_p_bi_u64 // ld1d_z_p_bi_u64
                        when (_, _, !'00', '1', _, '001', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, '1', _, '101', _, _, _) => // sve_mem_cldnf_si
                            __field dtype 21 +: 4
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1b_z_p_bi_u8 // ldnf1b_z_p_bi_u8
                                when ('0001') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1b_z_p_bi_u16 // ldnf1b_z_p_bi_u16
                                when ('0010') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1b_z_p_bi_u32 // ldnf1b_z_p_bi_u32
                                when ('0011') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1b_z_p_bi_u64 // ldnf1b_z_p_bi_u64
                                when ('0100') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1sw_z_p_bi_s64 // ldnf1sw_z_p_bi_s64
                                when ('0101') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1h_z_p_bi_u16 // ldnf1h_z_p_bi_u16
                                when ('0110') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1h_z_p_bi_u32 // ldnf1h_z_p_bi_u32
                                when ('0111') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1h_z_p_bi_u64 // ldnf1h_z_p_bi_u64
                                when ('1000') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1sh_z_p_bi_s64 // ldnf1sh_z_p_bi_s64
                                when ('1001') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1sh_z_p_bi_s32 // ldnf1sh_z_p_bi_s32
                                when ('1010') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1w_z_p_bi_u32 // ldnf1w_z_p_bi_u32
                                when ('1011') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1w_z_p_bi_u64 // ldnf1w_z_p_bi_u64
                                when ('1100') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1sb_z_p_bi_s64 // ldnf1sb_z_p_bi_s64
                                when ('1101') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1sb_z_p_bi_s32 // ldnf1sb_z_p_bi_s32
                                when ('1110') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1sb_z_p_bi_s16 // ldnf1sb_z_p_bi_s16
                                when ('1111') => __encoding A64_sve_sve_memcld_sve_mem_cldnf_si_ldnf1d_z_p_bi_u64 // ldnf1d_z_p_bi_u64
                        when (_, _, !'00', '1', _, '111', _, _, _) => __UNPREDICTABLE
                        when (_, _, _, _, _, '000', _, _, _) => // sve_mem_ldqr_ss
                            __field msz 23 +: 2
                            __field ssz 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, ssz, Rm) of
                                when (_, '0x', '11111') => __UNALLOCATED
                                when (_, '1x', _) => __UNALLOCATED
                                when ('00', '00', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_ss_ld1rqb_z_p_br_contiguous // ld1rqb_z_p_br_contiguous
                                when ('00', '01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_ss_ld1rob_z_p_br_contiguous // ld1rob_z_p_br_contiguous
                                when ('01', '00', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_ss_ld1rqh_z_p_br_contiguous // ld1rqh_z_p_br_contiguous
                                when ('01', '01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_ss_ld1roh_z_p_br_contiguous // ld1roh_z_p_br_contiguous
                                when ('10', '00', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_ss_ld1rqw_z_p_br_contiguous // ld1rqw_z_p_br_contiguous
                                when ('10', '01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_ss_ld1row_z_p_br_contiguous // ld1row_z_p_br_contiguous
                                when ('11', '00', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_ss_ld1rqd_z_p_br_contiguous // ld1rqd_z_p_br_contiguous
                                when ('11', '01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_ldqr_ss_ld1rod_z_p_br_contiguous // ld1rod_z_p_br_contiguous
                        when (_, _, _, _, _, '010', _, _, _) => // sve_mem_cld_ss
                            __field dtype 21 +: 4
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype, Rm) of
                                when (_, '11111') => __UNALLOCATED
                                when ('0000', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1b_z_p_br_u8 // ld1b_z_p_br_u8
                                when ('0001', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1b_z_p_br_u16 // ld1b_z_p_br_u16
                                when ('0010', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1b_z_p_br_u32 // ld1b_z_p_br_u32
                                when ('0011', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1b_z_p_br_u64 // ld1b_z_p_br_u64
                                when ('0100', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1sw_z_p_br_s64 // ld1sw_z_p_br_s64
                                when ('0101', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1h_z_p_br_u16 // ld1h_z_p_br_u16
                                when ('0110', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1h_z_p_br_u32 // ld1h_z_p_br_u32
                                when ('0111', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1h_z_p_br_u64 // ld1h_z_p_br_u64
                                when ('1000', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1sh_z_p_br_s64 // ld1sh_z_p_br_s64
                                when ('1001', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1sh_z_p_br_s32 // ld1sh_z_p_br_s32
                                when ('1010', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1w_z_p_br_u32 // ld1w_z_p_br_u32
                                when ('1011', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1w_z_p_br_u64 // ld1w_z_p_br_u64
                                when ('1100', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1sb_z_p_br_s64 // ld1sb_z_p_br_s64
                                when ('1101', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1sb_z_p_br_s32 // ld1sb_z_p_br_s32
                                when ('1110', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1sb_z_p_br_s16 // ld1sb_z_p_br_s16
                                when ('1111', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_cld_ss_ld1d_z_p_br_u64 // ld1d_z_p_br_u64
                        when (_, _, _, _, _, '011', _, _, _) => // sve_mem_cldff_ss
                            __field dtype 21 +: 4
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (dtype) of
                                when ('0000') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1b_z_p_br_u8 // ldff1b_z_p_br_u8
                                when ('0001') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1b_z_p_br_u16 // ldff1b_z_p_br_u16
                                when ('0010') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1b_z_p_br_u32 // ldff1b_z_p_br_u32
                                when ('0011') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1b_z_p_br_u64 // ldff1b_z_p_br_u64
                                when ('0100') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1sw_z_p_br_s64 // ldff1sw_z_p_br_s64
                                when ('0101') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1h_z_p_br_u16 // ldff1h_z_p_br_u16
                                when ('0110') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1h_z_p_br_u32 // ldff1h_z_p_br_u32
                                when ('0111') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1h_z_p_br_u64 // ldff1h_z_p_br_u64
                                when ('1000') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1sh_z_p_br_s64 // ldff1sh_z_p_br_s64
                                when ('1001') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1sh_z_p_br_s32 // ldff1sh_z_p_br_s32
                                when ('1010') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1w_z_p_br_u32 // ldff1w_z_p_br_u32
                                when ('1011') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1w_z_p_br_u64 // ldff1w_z_p_br_u64
                                when ('1100') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1sb_z_p_br_s64 // ldff1sb_z_p_br_s64
                                when ('1101') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1sb_z_p_br_s32 // ldff1sb_z_p_br_s32
                                when ('1110') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1sb_z_p_br_s16 // ldff1sb_z_p_br_s16
                                when ('1111') => __encoding A64_sve_sve_memcld_sve_mem_cldff_ss_ldff1d_z_p_br_u64 // ldff1d_z_p_br_u64
                        when (_, _, !'00', '0', _, '111', _, _, _) => // sve_mem_eld_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld2b_z_p_bi_contiguous // ld2b_z_p_bi_contiguous
                                when ('00', '10') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld3b_z_p_bi_contiguous // ld3b_z_p_bi_contiguous
                                when ('00', '11') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld4b_z_p_bi_contiguous // ld4b_z_p_bi_contiguous
                                when ('01', '01') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld2h_z_p_bi_contiguous // ld2h_z_p_bi_contiguous
                                when ('01', '10') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld3h_z_p_bi_contiguous // ld3h_z_p_bi_contiguous
                                when ('01', '11') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld4h_z_p_bi_contiguous // ld4h_z_p_bi_contiguous
                                when ('10', '01') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld2w_z_p_bi_contiguous // ld2w_z_p_bi_contiguous
                                when ('10', '10') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld3w_z_p_bi_contiguous // ld3w_z_p_bi_contiguous
                                when ('10', '11') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld4w_z_p_bi_contiguous // ld4w_z_p_bi_contiguous
                                when ('11', '01') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld2d_z_p_bi_contiguous // ld2d_z_p_bi_contiguous
                                when ('11', '10') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld3d_z_p_bi_contiguous // ld3d_z_p_bi_contiguous
                                when ('11', '11') => __encoding A64_sve_sve_memcld_sve_mem_eld_si_ld4d_z_p_bi_contiguous // ld4d_z_p_bi_contiguous
                        when (_, _, !'00', _, _, '110', _, _, _) => // sve_mem_eld_ss
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc, Rm) of
                                when (_, !'00', '11111') => __UNALLOCATED
                                when ('00', '01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld2b_z_p_br_contiguous // ld2b_z_p_br_contiguous
                                when ('00', '10', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld3b_z_p_br_contiguous // ld3b_z_p_br_contiguous
                                when ('00', '11', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld4b_z_p_br_contiguous // ld4b_z_p_br_contiguous
                                when ('01', '01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld2h_z_p_br_contiguous // ld2h_z_p_br_contiguous
                                when ('01', '10', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld3h_z_p_br_contiguous // ld3h_z_p_br_contiguous
                                when ('01', '11', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld4h_z_p_br_contiguous // ld4h_z_p_br_contiguous
                                when ('10', '01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld2w_z_p_br_contiguous // ld2w_z_p_br_contiguous
                                when ('10', '10', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld3w_z_p_br_contiguous // ld3w_z_p_br_contiguous
                                when ('10', '11', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld4w_z_p_br_contiguous // ld4w_z_p_br_contiguous
                                when ('11', '01', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld2d_z_p_br_contiguous // ld2d_z_p_br_contiguous
                                when ('11', '10', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld3d_z_p_br_contiguous // ld3d_z_p_br_contiguous
                                when ('11', '11', !'11111') => __encoding A64_sve_sve_memcld_sve_mem_eld_ss_ld4d_z_p_br_contiguous // ld4d_z_p_br_contiguous
                when ('110', _, _, _, _, _, _, _) =>
                    // sve_mem64
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '00', '00', _, '101', _, _, _) => // sve_mem_64b_gldq_vs
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_mem64_sve_mem_64b_gldq_vs_ld1q_z_p_ar_d_64_unscaled // ld1q_z_p_ar_d_64_unscaled
                        when (_, '00', '01', _, '0xx', _, '1', _) => __UNPREDICTABLE
                        when (_, '00', '11', _, '1xx', _, '0', _) => // sve_mem_64b_prfm_sv2
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_sv2_prfb_i_p_bz_d_64_scaled // prfb_i_p_bz_d_64_scaled
                                when ('01') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_sv2_prfh_i_p_bz_d_64_scaled // prfh_i_p_bz_d_64_scaled
                                when ('10') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_sv2_prfw_i_p_bz_d_64_scaled // prfw_i_p_bz_d_64_scaled
                                when ('11') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_sv2_prfd_i_p_bz_d_64_scaled // prfd_i_p_bz_d_64_scaled
                        when (_, '00', '11', _, _, _, '1', _) => __UNPREDICTABLE
                        when (_, '00', 'x1', _, '0xx', _, '0', _) => // sve_mem_64b_prfm_sv
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field msz 13 +: 2
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_sv_prfb_i_p_bz_d_x32_scaled // prfb_i_p_bz_d_x32_scaled
                                when ('01') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_sv_prfh_i_p_bz_d_x32_scaled // prfh_i_p_bz_d_x32_scaled
                                when ('10') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_sv_prfw_i_p_bz_d_x32_scaled // prfw_i_p_bz_d_x32_scaled
                                when ('11') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_sv_prfd_i_p_bz_d_x32_scaled // prfd_i_p_bz_d_x32_scaled
                        when (_, !'00', '00', _, '101', _, _, _) => __UNPREDICTABLE
                        when (_, _, '00', _, '111', _, '0', _) => // sve_mem_64b_prfm_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field prfop 0 +: 4
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_vi_prfb_i_p_ai_d // prfb_i_p_ai_d
                                when ('01') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_vi_prfh_i_p_ai_d // prfh_i_p_ai_d
                                when ('10') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_vi_prfw_i_p_ai_d // prfw_i_p_ai_d
                                when ('11') => __encoding A64_sve_sve_mem64_sve_mem_64b_prfm_vi_prfd_i_p_ai_d // prfd_i_p_ai_d
                        when (_, _, '00', _, '111', _, '1', _) => __UNPREDICTABLE
                        when (_, _, '00', _, '1x0', _, _, _) => // sve_mem_64b_gldnt_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field U 14 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U) of
                                when ('00', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gldnt_vs_ldnt1sb_z_p_ar_d_64_unscaled // ldnt1sb_z_p_ar_d_64_unscaled
                                when ('00', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gldnt_vs_ldnt1b_z_p_ar_d_64_unscaled // ldnt1b_z_p_ar_d_64_unscaled
                                when ('01', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gldnt_vs_ldnt1sh_z_p_ar_d_64_unscaled // ldnt1sh_z_p_ar_d_64_unscaled
                                when ('01', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gldnt_vs_ldnt1h_z_p_ar_d_64_unscaled // ldnt1h_z_p_ar_d_64_unscaled
                                when ('10', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gldnt_vs_ldnt1sw_z_p_ar_d_64_unscaled // ldnt1sw_z_p_ar_d_64_unscaled
                                when ('10', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gldnt_vs_ldnt1w_z_p_ar_d_64_unscaled // ldnt1w_z_p_ar_d_64_unscaled
                                when ('11', '0') => __UNALLOCATED
                                when ('11', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gldnt_vs_ldnt1d_z_p_ar_d_64_unscaled // ldnt1d_z_p_ar_d_64_unscaled
                        when (_, _, '01', _, '1xx', _, _, _) => // sve_mem_64b_gld_vi
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ld1sb_z_p_ai_d // ld1sb_z_p_ai_d
                                when ('00', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ldff1sb_z_p_ai_d // ldff1sb_z_p_ai_d
                                when ('00', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ld1b_z_p_ai_d // ld1b_z_p_ai_d
                                when ('00', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ldff1b_z_p_ai_d // ldff1b_z_p_ai_d
                                when ('01', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ld1sh_z_p_ai_d // ld1sh_z_p_ai_d
                                when ('01', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ldff1sh_z_p_ai_d // ldff1sh_z_p_ai_d
                                when ('01', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ld1h_z_p_ai_d // ld1h_z_p_ai_d
                                when ('01', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ldff1h_z_p_ai_d // ldff1h_z_p_ai_d
                                when ('10', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ld1sw_z_p_ai_d // ld1sw_z_p_ai_d
                                when ('10', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ldff1sw_z_p_ai_d // ldff1sw_z_p_ai_d
                                when ('10', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ld1w_z_p_ai_d // ld1w_z_p_ai_d
                                when ('10', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ldff1w_z_p_ai_d // ldff1w_z_p_ai_d
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ld1d_z_p_ai_d // ld1d_z_p_ai_d
                                when ('11', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vi_ldff1d_z_p_ai_d // ldff1d_z_p_ai_d
                        when (_, _, '10', _, '1xx', _, _, _) => // sve_mem_64b_gld_vs2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ld1sb_z_p_bz_d_64_unscaled // ld1sb_z_p_bz_d_64_unscaled
                                when ('00', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ldff1sb_z_p_bz_d_64_unscaled // ldff1sb_z_p_bz_d_64_unscaled
                                when ('00', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ld1b_z_p_bz_d_64_unscaled // ld1b_z_p_bz_d_64_unscaled
                                when ('00', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ldff1b_z_p_bz_d_64_unscaled // ldff1b_z_p_bz_d_64_unscaled
                                when ('01', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ld1sh_z_p_bz_d_64_unscaled // ld1sh_z_p_bz_d_64_unscaled
                                when ('01', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ldff1sh_z_p_bz_d_64_unscaled // ldff1sh_z_p_bz_d_64_unscaled
                                when ('01', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ld1h_z_p_bz_d_64_unscaled // ld1h_z_p_bz_d_64_unscaled
                                when ('01', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ldff1h_z_p_bz_d_64_unscaled // ldff1h_z_p_bz_d_64_unscaled
                                when ('10', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ld1sw_z_p_bz_d_64_unscaled // ld1sw_z_p_bz_d_64_unscaled
                                when ('10', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ldff1sw_z_p_bz_d_64_unscaled // ldff1sw_z_p_bz_d_64_unscaled
                                when ('10', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ld1w_z_p_bz_d_64_unscaled // ld1w_z_p_bz_d_64_unscaled
                                when ('10', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ldff1w_z_p_bz_d_64_unscaled // ldff1w_z_p_bz_d_64_unscaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ld1d_z_p_bz_d_64_unscaled // ld1d_z_p_bz_d_64_unscaled
                                when ('11', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs2_ldff1d_z_p_bz_d_64_unscaled // ldff1d_z_p_bz_d_64_unscaled
                        when (_, _, 'x0', _, '0xx', _, _, _) => // sve_mem_64b_gld_vs
                            __field msz 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, U, ff) of
                                when ('00', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ld1sb_z_p_bz_d_x32_unscaled // ld1sb_z_p_bz_d_x32_unscaled
                                when ('00', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ldff1sb_z_p_bz_d_x32_unscaled // ldff1sb_z_p_bz_d_x32_unscaled
                                when ('00', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ld1b_z_p_bz_d_x32_unscaled // ld1b_z_p_bz_d_x32_unscaled
                                when ('00', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ldff1b_z_p_bz_d_x32_unscaled // ldff1b_z_p_bz_d_x32_unscaled
                                when ('01', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ld1sh_z_p_bz_d_x32_unscaled // ld1sh_z_p_bz_d_x32_unscaled
                                when ('01', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ldff1sh_z_p_bz_d_x32_unscaled // ldff1sh_z_p_bz_d_x32_unscaled
                                when ('01', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ld1h_z_p_bz_d_x32_unscaled // ld1h_z_p_bz_d_x32_unscaled
                                when ('01', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ldff1h_z_p_bz_d_x32_unscaled // ldff1h_z_p_bz_d_x32_unscaled
                                when ('10', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ld1sw_z_p_bz_d_x32_unscaled // ld1sw_z_p_bz_d_x32_unscaled
                                when ('10', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ldff1sw_z_p_bz_d_x32_unscaled // ldff1sw_z_p_bz_d_x32_unscaled
                                when ('10', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ld1w_z_p_bz_d_x32_unscaled // ld1w_z_p_bz_d_x32_unscaled
                                when ('10', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ldff1w_z_p_bz_d_x32_unscaled // ldff1w_z_p_bz_d_x32_unscaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ld1d_z_p_bz_d_x32_unscaled // ld1d_z_p_bz_d_x32_unscaled
                                when ('11', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_vs_ldff1d_z_p_bz_d_x32_unscaled // ldff1d_z_p_bz_d_x32_unscaled
                        when (_, !'00', '11', _, '1xx', _, _, _) => // sve_mem_64b_gld_sv2
                            __field opc 23 +: 2
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('01', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ld1sh_z_p_bz_d_64_scaled // ld1sh_z_p_bz_d_64_scaled
                                when ('01', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ldff1sh_z_p_bz_d_64_scaled // ldff1sh_z_p_bz_d_64_scaled
                                when ('01', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ld1h_z_p_bz_d_64_scaled // ld1h_z_p_bz_d_64_scaled
                                when ('01', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ldff1h_z_p_bz_d_64_scaled // ldff1h_z_p_bz_d_64_scaled
                                when ('10', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ld1sw_z_p_bz_d_64_scaled // ld1sw_z_p_bz_d_64_scaled
                                when ('10', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ldff1sw_z_p_bz_d_64_scaled // ldff1sw_z_p_bz_d_64_scaled
                                when ('10', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ld1w_z_p_bz_d_64_scaled // ld1w_z_p_bz_d_64_scaled
                                when ('10', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ldff1w_z_p_bz_d_64_scaled // ldff1w_z_p_bz_d_64_scaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ld1d_z_p_bz_d_64_scaled // ld1d_z_p_bz_d_64_scaled
                                when ('11', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv2_ldff1d_z_p_bz_d_64_scaled // ldff1d_z_p_bz_d_64_scaled
                        when (_, !'00', 'x1', _, '0xx', _, _, _) => // sve_mem_64b_gld_sv
                            __field opc 23 +: 2
                            __field xs 22 +: 1
                            __field Zm 16 +: 5
                            __field U 14 +: 1
                            __field ff 13 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, U, ff) of
                                when ('01', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ld1sh_z_p_bz_d_x32_scaled // ld1sh_z_p_bz_d_x32_scaled
                                when ('01', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ldff1sh_z_p_bz_d_x32_scaled // ldff1sh_z_p_bz_d_x32_scaled
                                when ('01', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ld1h_z_p_bz_d_x32_scaled // ld1h_z_p_bz_d_x32_scaled
                                when ('01', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ldff1h_z_p_bz_d_x32_scaled // ldff1h_z_p_bz_d_x32_scaled
                                when ('10', '0', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ld1sw_z_p_bz_d_x32_scaled // ld1sw_z_p_bz_d_x32_scaled
                                when ('10', '0', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ldff1sw_z_p_bz_d_x32_scaled // ldff1sw_z_p_bz_d_x32_scaled
                                when ('10', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ld1w_z_p_bz_d_x32_scaled // ld1w_z_p_bz_d_x32_scaled
                                when ('10', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ldff1w_z_p_bz_d_x32_scaled // ldff1w_z_p_bz_d_x32_scaled
                                when ('11', '0', _) => __UNALLOCATED
                                when ('11', '1', '0') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ld1d_z_p_bz_d_x32_scaled // ld1d_z_p_bz_d_x32_scaled
                                when ('11', '1', '1') => __encoding A64_sve_sve_mem64_sve_mem_64b_gld_sv_ldff1d_z_p_bz_d_x32_scaled // ldff1d_z_p_bz_d_x32_scaled
                when ('111', _, _, _, '001xxx', _, _, _) =>
                    // sve_memsst_nt
                    case (25 +: 7, 22 +: 3, 21 +: 1, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '000', '1', _, _, _, _, _) => // sve_mem_sstq_64b_vs
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_memsst_nt_sve_mem_sstq_64b_vs_st1q_z_p_ar_d_64_unscaled // st1q_z_p_ar_d_64_unscaled
                        when (_, 'xx0', '0', _, _, _, _, _) => // sve_mem_sstnt_64b_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memsst_nt_sve_mem_sstnt_64b_vs_stnt1b_z_p_ar_d_64_unscaled // stnt1b_z_p_ar_d_64_unscaled
                                when ('01') => __encoding A64_sve_sve_memsst_nt_sve_mem_sstnt_64b_vs_stnt1h_z_p_ar_d_64_unscaled // stnt1h_z_p_ar_d_64_unscaled
                                when ('10') => __encoding A64_sve_sve_memsst_nt_sve_mem_sstnt_64b_vs_stnt1w_z_p_ar_d_64_unscaled // stnt1w_z_p_ar_d_64_unscaled
                                when ('11') => __encoding A64_sve_sve_memsst_nt_sve_mem_sstnt_64b_vs_stnt1d_z_p_ar_d_64_unscaled // stnt1d_z_p_ar_d_64_unscaled
                        when (_, 'xx1', '0', _, _, _, _, _) => // sve_mem_sstnt_32b_vs
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memsst_nt_sve_mem_sstnt_32b_vs_stnt1b_z_p_ar_s_x32_unscaled // stnt1b_z_p_ar_s_x32_unscaled
                                when ('01') => __encoding A64_sve_sve_memsst_nt_sve_mem_sstnt_32b_vs_stnt1h_z_p_ar_s_x32_unscaled // stnt1h_z_p_ar_s_x32_unscaled
                                when ('10') => __encoding A64_sve_sve_memsst_nt_sve_mem_sstnt_32b_vs_stnt1w_z_p_ar_s_x32_unscaled // stnt1w_z_p_ar_s_x32_unscaled
                                when ('11') => __UNALLOCATED
                        when (_, !'000', '1', _, _, _, _, _) => __UNPREDICTABLE
                when ('111', _, _, _, '011xxx', _, _, _) =>
                    // sve_memcst_nt
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, '00', _, _, _, _, _) => // sve_mem_cstnt_ss
                            __field msz 23 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, Rm) of
                                when (_, '11111') => __UNALLOCATED
                                when ('00', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_cstnt_ss_stnt1b_z_p_br_contiguous // stnt1b_z_p_br_contiguous
                                when ('01', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_cstnt_ss_stnt1h_z_p_br_contiguous // stnt1h_z_p_br_contiguous
                                when ('10', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_cstnt_ss_stnt1w_z_p_br_contiguous // stnt1w_z_p_br_contiguous
                                when ('11', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_cstnt_ss_stnt1d_z_p_br_contiguous // stnt1d_z_p_br_contiguous
                        when (_, _, !'00', _, _, _, _, _) => // sve_mem_est_ss
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc, Rm) of
                                when (_, !'00', '11111') => __UNALLOCATED
                                when ('00', '01', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st2b_z_p_br_contiguous // st2b_z_p_br_contiguous
                                when ('00', '10', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st3b_z_p_br_contiguous // st3b_z_p_br_contiguous
                                when ('00', '11', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st4b_z_p_br_contiguous // st4b_z_p_br_contiguous
                                when ('01', '01', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st2h_z_p_br_contiguous // st2h_z_p_br_contiguous
                                when ('01', '10', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st3h_z_p_br_contiguous // st3h_z_p_br_contiguous
                                when ('01', '11', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st4h_z_p_br_contiguous // st4h_z_p_br_contiguous
                                when ('10', '01', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st2w_z_p_br_contiguous // st2w_z_p_br_contiguous
                                when ('10', '10', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st3w_z_p_br_contiguous // st3w_z_p_br_contiguous
                                when ('10', '11', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st4w_z_p_br_contiguous // st4w_z_p_br_contiguous
                                when ('11', '01', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st2d_z_p_br_contiguous // st2d_z_p_br_contiguous
                                when ('11', '10', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st3d_z_p_br_contiguous // st3d_z_p_br_contiguous
                                when ('11', '11', !'11111') => __encoding A64_sve_sve_memcst_nt_sve_mem_est_ss_st4d_z_p_br_contiguous // st4d_z_p_br_contiguous
                when ('111', _, _, _, '0x0xxx', _, _, _) =>
                    // sve_memst_cs
                    case (25 +: 7, 22 +: 3, 20 +: 2, 16 +: 4, 15 +: 1, 14 +: 1, 13 +: 1, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, '0xx', '00', _, _, '0', _, _, _, _) => // sve_mem_estq_si
                            __field num 22 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding A64_sve_sve_memst_cs_sve_mem_estq_si_st2q_z_p_bi_contiguous // st2q_z_p_bi_contiguous
                                when ('10') => __encoding A64_sve_sve_memst_cs_sve_mem_estq_si_st3q_z_p_bi_contiguous // st3q_z_p_bi_contiguous
                                when ('11') => __encoding A64_sve_sve_memst_cs_sve_mem_estq_si_st4q_z_p_bi_contiguous // st4q_z_p_bi_contiguous
                        when (_, '0xx', '01', _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, '0xx', '1x', _, _, '0', _, _, _, _) => // sve_mem_estq_ss
                            __field num 22 +: 2
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (num, Rm) of
                                when (!'00', '11111') => __UNALLOCATED
                                when ('00', _) => __UNALLOCATED
                                when ('01', !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_estq_ss_st2q_z_p_br_contiguous // st2q_z_p_br_contiguous
                                when ('10', !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_estq_ss_st3q_z_p_br_contiguous // st3q_z_p_br_contiguous
                                when ('11', !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_estq_ss_st4q_z_p_br_contiguous // st4q_z_p_br_contiguous
                        when (_, '10x', _, _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, '110', _, _, _, '0', _, _, '0', _) => // sve_mem_pspill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Pt 0 +: 4
                            case () of
                                when () => __encoding A64_sve_sve_memst_cs_sve_mem_pspill_str_p_bi_ // str_p_bi_
                        when (_, '110', _, _, _, '0', _, _, '1', _) => __UNPREDICTABLE
                        when (_, '110', _, _, _, '1', _, _, _, _) => // sve_mem_spill
                            __field imm9h 16 +: 6
                            __field imm9l 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case () of
                                when () => __encoding A64_sve_sve_memst_cs_sve_mem_spill_str_z_bi_ // str_z_bi_
                        when (_, '111', _, _, _, '0', _, _, _, _) => __UNPREDICTABLE
                        when (_, !'110', _, _, _, '1', _, _, _, _) => // sve_mem_cst_ss
                            __field opc 22 +: 3
                            __field o2 21 +: 1
                            __field Rm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (opc, o2, Rm) of
                                when ('xx1', _, '11111') => __UNALLOCATED
                                when ('0x0', _, '11111') => __UNALLOCATED
                                when ('00x', _, !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_cst_ss_st1b_z_p_br_ // st1b_z_p_br_
                                when ('01x', _, !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_cst_ss_st1h_z_p_br_ // st1h_z_p_br_
                                when ('100', '0', !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_cst_ss_st1w_z_p_br_u128 // st1w_z_p_br_u128
                                when ('100', '0', '11111') => __UNALLOCATED
                                when ('100', '1', _) => __UNALLOCATED
                                when ('101', _, !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_cst_ss_st1w_z_p_br_ // st1w_z_p_br_
                                when ('111', '0', !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_cst_ss_st1d_z_p_br_u128 // st1d_z_p_br_u128
                                when ('111', '1', !'11111') => __encoding A64_sve_sve_memst_cs_sve_mem_cst_ss_st1d_z_p_br_ // st1d_z_p_br_
                when ('111', _, _, _, '101xxx', _, _, _) =>
                    // sve_memst_ss2
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, '00', _, _, _, _, _) => // sve_mem_sst_vs2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vs2_st1b_z_p_bz_d_64_unscaled // st1b_z_p_bz_d_64_unscaled
                                when ('01') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vs2_st1h_z_p_bz_d_64_unscaled // st1h_z_p_bz_d_64_unscaled
                                when ('10') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vs2_st1w_z_p_bz_d_64_unscaled // st1w_z_p_bz_d_64_unscaled
                                when ('11') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vs2_st1d_z_p_bz_d_64_unscaled // st1d_z_p_bz_d_64_unscaled
                        when (_, _, '01', _, _, _, _, _) => // sve_mem_sst_sv2
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_sv2_st1h_z_p_bz_d_64_scaled // st1h_z_p_bz_d_64_scaled
                                when ('10') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_sv2_st1w_z_p_bz_d_64_scaled // st1w_z_p_bz_d_64_scaled
                                when ('11') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_sv2_st1d_z_p_bz_d_64_scaled // st1d_z_p_bz_d_64_scaled
                        when (_, _, '10', _, _, _, _, _) => // sve_mem_sst_vi_a
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vi_a_st1b_z_p_ai_d // st1b_z_p_ai_d
                                when ('01') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vi_a_st1h_z_p_ai_d // st1h_z_p_ai_d
                                when ('10') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vi_a_st1w_z_p_ai_d // st1w_z_p_ai_d
                                when ('11') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vi_a_st1d_z_p_ai_d // st1d_z_p_ai_d
                        when (_, _, '11', _, _, _, _, _) => // sve_mem_sst_vi_b
                            __field msz 23 +: 2
                            __field imm5 16 +: 5
                            __field Pg 10 +: 3
                            __field Zn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vi_b_st1b_z_p_ai_s // st1b_z_p_ai_s
                                when ('01') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vi_b_st1h_z_p_ai_s // st1h_z_p_ai_s
                                when ('10') => __encoding A64_sve_sve_memst_ss2_sve_mem_sst_vi_b_st1w_z_p_ai_s // st1w_z_p_ai_s
                                when ('11') => __UNALLOCATED
                when ('111', _, _, _, '111xxx', _, _, _) =>
                    // sve_memst_si
                    case (25 +: 7, 23 +: 2, 21 +: 2, 20 +: 1, 16 +: 4, 13 +: 3, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, '00', '1', _, _, _, _, _) => // sve_mem_cstnt_si
                            __field msz 23 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memst_si_sve_mem_cstnt_si_stnt1b_z_p_bi_contiguous // stnt1b_z_p_bi_contiguous
                                when ('01') => __encoding A64_sve_sve_memst_si_sve_mem_cstnt_si_stnt1h_z_p_bi_contiguous // stnt1h_z_p_bi_contiguous
                                when ('10') => __encoding A64_sve_sve_memst_si_sve_mem_cstnt_si_stnt1w_z_p_bi_contiguous // stnt1w_z_p_bi_contiguous
                                when ('11') => __encoding A64_sve_sve_memst_si_sve_mem_cstnt_si_stnt1d_z_p_bi_contiguous // stnt1d_z_p_bi_contiguous
                        when (_, _, _, '0', _, _, _, _, _) => // sve_mem_cst_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', _) => __encoding A64_sve_sve_memst_si_sve_mem_cst_si_st1b_z_p_bi_ // st1b_z_p_bi_
                                when ('01', _) => __encoding A64_sve_sve_memst_si_sve_mem_cst_si_st1h_z_p_bi_ // st1h_z_p_bi_
                                when ('10', '00') => __encoding A64_sve_sve_memst_si_sve_mem_cst_si_st1w_z_p_bi_u128 // st1w_z_p_bi_u128
                                when ('10', '01') => __UNALLOCATED
                                when ('10', '1x') => __encoding A64_sve_sve_memst_si_sve_mem_cst_si_st1w_z_p_bi_ // st1w_z_p_bi_
                                when ('11', '0x') => __UNALLOCATED
                                when ('11', '10') => __encoding A64_sve_sve_memst_si_sve_mem_cst_si_st1d_z_p_bi_u128 // st1d_z_p_bi_u128
                                when ('11', '11') => __encoding A64_sve_sve_memst_si_sve_mem_cst_si_st1d_z_p_bi_ // st1d_z_p_bi_
                        when (_, _, !'00', '1', _, _, _, _, _) => // sve_mem_est_si
                            __field msz 23 +: 2
                            __field opc 21 +: 2
                            __field imm4 16 +: 4
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz, opc) of
                                when ('00', '01') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st2b_z_p_bi_contiguous // st2b_z_p_bi_contiguous
                                when ('00', '10') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st3b_z_p_bi_contiguous // st3b_z_p_bi_contiguous
                                when ('00', '11') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st4b_z_p_bi_contiguous // st4b_z_p_bi_contiguous
                                when ('01', '01') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st2h_z_p_bi_contiguous // st2h_z_p_bi_contiguous
                                when ('01', '10') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st3h_z_p_bi_contiguous // st3h_z_p_bi_contiguous
                                when ('01', '11') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st4h_z_p_bi_contiguous // st4h_z_p_bi_contiguous
                                when ('10', '01') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st2w_z_p_bi_contiguous // st2w_z_p_bi_contiguous
                                when ('10', '10') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st3w_z_p_bi_contiguous // st3w_z_p_bi_contiguous
                                when ('10', '11') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st4w_z_p_bi_contiguous // st4w_z_p_bi_contiguous
                                when ('11', '01') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st2d_z_p_bi_contiguous // st2d_z_p_bi_contiguous
                                when ('11', '10') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st3d_z_p_bi_contiguous // st3d_z_p_bi_contiguous
                                when ('11', '11') => __encoding A64_sve_sve_memst_si_sve_mem_est_si_st4d_z_p_bi_contiguous // st4d_z_p_bi_contiguous
                when ('111', _, _, _, '1x0xxx', _, _, _) =>
                    // sve_memst_ss
                    case (25 +: 7, 23 +: 2, 21 +: 2, 16 +: 5, 15 +: 1, 14 +: 1, 13 +: 1, 5 +: 8, 4 +: 1, 0 +: 4) of
                        when (_, _, '00', _, _, _, _, _, _, _) => // sve_mem_sst_vs_a
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_vs_a_st1b_z_p_bz_d_x32_unscaled // st1b_z_p_bz_d_x32_unscaled
                                when ('01') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_vs_a_st1h_z_p_bz_d_x32_unscaled // st1h_z_p_bz_d_x32_unscaled
                                when ('10') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_vs_a_st1w_z_p_bz_d_x32_unscaled // st1w_z_p_bz_d_x32_unscaled
                                when ('11') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_vs_a_st1d_z_p_bz_d_x32_unscaled // st1d_z_p_bz_d_x32_unscaled
                        when (_, _, '01', _, _, _, _, _, _, _) => // sve_mem_sst_sv_a
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_sv_a_st1h_z_p_bz_d_x32_scaled // st1h_z_p_bz_d_x32_scaled
                                when ('10') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_sv_a_st1w_z_p_bz_d_x32_scaled // st1w_z_p_bz_d_x32_scaled
                                when ('11') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_sv_a_st1d_z_p_bz_d_x32_scaled // st1d_z_p_bz_d_x32_scaled
                        when (_, _, '10', _, _, _, _, _, _, _) => // sve_mem_sst_vs_b
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_vs_b_st1b_z_p_bz_s_x32_unscaled // st1b_z_p_bz_s_x32_unscaled
                                when ('01') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_vs_b_st1h_z_p_bz_s_x32_unscaled // st1h_z_p_bz_s_x32_unscaled
                                when ('10') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_vs_b_st1w_z_p_bz_s_x32_unscaled // st1w_z_p_bz_s_x32_unscaled
                                when ('11') => __UNALLOCATED
                        when (_, _, '11', _, _, _, _, _, _, _) => // sve_mem_sst_sv_b
                            __field msz 23 +: 2
                            __field Zm 16 +: 5
                            __field xs 14 +: 1
                            __field Pg 10 +: 3
                            __field Rn 5 +: 5
                            __field Zt 0 +: 5
                            case (msz) of
                                when ('00') => __UNALLOCATED
                                when ('01') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_sv_b_st1h_z_p_bz_s_x32_scaled // st1h_z_p_bz_s_x32_scaled
                                when ('10') => __encoding A64_sve_sve_memst_ss_sve_mem_sst_sv_b_st1w_z_p_bz_s_x32_scaled // st1w_z_p_bz_s_x32_scaled
                                when ('11') => __UNALLOCATED
                when ('000', _, '0xx1xxxx', _, '000xxx', _, _, _) => // sve_int_bin_cons_arit_0
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size, opc) of
                        when (_, '000') => __encoding A64_sve_sve_int_unpred_arit_sve_int_bin_cons_arit_0_add_z_zz_ // add_z_zz_
                        when (_, '001') => __encoding A64_sve_sve_int_unpred_arit_sve_int_bin_cons_arit_0_sub_z_zz_ // sub_z_zz_
                        when (!'11', '01x') => __UNALLOCATED
                        when (_, '100') => __encoding A64_sve_sve_int_unpred_arit_sve_int_bin_cons_arit_0_sqadd_z_zz_ // sqadd_z_zz_
                        when (_, '101') => __encoding A64_sve_sve_int_unpred_arit_sve_int_bin_cons_arit_0_uqadd_z_zz_ // uqadd_z_zz_
                        when (_, '110') => __encoding A64_sve_sve_int_unpred_arit_sve_int_bin_cons_arit_0_sqsub_z_zz_ // sqsub_z_zz_
                        when (_, '111') => __encoding A64_sve_sve_int_unpred_arit_sve_int_bin_cons_arit_0_uqsub_z_zz_ // uqsub_z_zz_
                        when ('11', '010') => __encoding A64_sve_sve_int_unpred_arit_sve_int_bin_cons_arit_0_addpt_z_zz_ // addpt_z_zz_
                        when ('11', '011') => __encoding A64_sve_sve_int_unpred_arit_sve_int_bin_cons_arit_0_subpt_z_zz_ // subpt_z_zz_
                when ('000', _, '0xx1xxxx', _, '1010xx', _, _, _) => // sve_int_bin_cons_misc_0_a
                    __field opc 22 +: 2
                    __field Zm 16 +: 5
                    __field msz 10 +: 2
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('00') => __encoding A64_sve_sve_int_adr_sve_int_bin_cons_misc_0_a_adr_z_az_d_s32_scaled // adr_z_az_d_s32_scaled
                        when ('01') => __encoding A64_sve_sve_int_adr_sve_int_bin_cons_misc_0_a_adr_z_az_d_u32_scaled // adr_z_az_d_u32_scaled
                        when ('1x') => __encoding A64_sve_sve_int_adr_sve_int_bin_cons_misc_0_a_adr_z_az_sd_same_scaled // adr_z_az_sd_same_scaled
                when ('000', _, '1xx1xxxx', _, '001000', _, _, _) => // sve_int_perm_dup_i
                    __field imm2 22 +: 2
                    __field tsz 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding A64_sve_sve_perm_unpred_a_sve_int_perm_dup_i_dup_z_zi_ // dup_z_zi_
                when ('000', _, '1xx1xxxx', _, '00101x', _, _, _) => // sve_int_perm_tbl_3src
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field op 10 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (op) of
                        when ('0') => __encoding A64_sve_sve_perm_unpred_b_sve_int_perm_tbl_3src_tbl_z_zz_2 // tbl_z_zz_2
                        when ('1') => __encoding A64_sve_sve_perm_unpred_b_sve_int_perm_tbl_3src_tbx_z_zz_ // tbx_z_zz_
                when ('000', _, '1xx1xxxx', _, '001100', _, _, _) => // sve_int_perm_tbl
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding A64_sve_sve_perm_unpred_c_sve_int_perm_tbl_tbl_z_zz_1 // tbl_z_zz_1
                when ('000', _, '1xx1xxxx', _, '001101', _, _, _) => // sve_int_perm_tbxquads
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding A64_sve_sve_perm_quads_c_sve_int_perm_tbxquads_tbxq_z_zz_ // tbxq_z_zz_
                when ('000', _, '1xx1xxxx', _, '011xxx', _, _, _) => // sve_int_perm_bin_perm_zz
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding A64_sve_sve_perm_inter_sve_int_perm_bin_perm_zz_zip1_z_zz_ // zip1_z_zz_
                        when ('001') => __encoding A64_sve_sve_perm_inter_sve_int_perm_bin_perm_zz_zip2_z_zz_ // zip2_z_zz_
                        when ('010') => __encoding A64_sve_sve_perm_inter_sve_int_perm_bin_perm_zz_uzp1_z_zz_ // uzp1_z_zz_
                        when ('011') => __encoding A64_sve_sve_perm_inter_sve_int_perm_bin_perm_zz_uzp2_z_zz_ // uzp2_z_zz_
                        when ('100') => __encoding A64_sve_sve_perm_inter_sve_int_perm_bin_perm_zz_trn1_z_zz_ // trn1_z_zz_
                        when ('101') => __encoding A64_sve_sve_perm_inter_sve_int_perm_bin_perm_zz_trn2_z_zz_ // trn2_z_zz_
                        when ('11x') => __UNALLOCATED
                when ('000', _, '1xx1xxxx', _, '11xxxx', _, _, _) => // sve_int_sel_vvv
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pv 10 +: 4
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding A64_sve_sve_int_select_sve_int_sel_vvv_sel_z_p_zz_ // sel_z_p_zz_
                when ('001', _, '0xx1xxxx', _, _, _, _, _) => // sve_int_ucmp_vi
                    __field imm7 14 +: 7
                    __field lt 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field ne 4 +: 1
                    __field Pd 0 +: 4
                    case (lt, ne) of
                        when ('0', '0') => __encoding A64_sve_sve_cmpuimm_sve_int_ucmp_vi_cmphs_p_p_zi_ // cmphs_p_p_zi_
                        when ('0', '1') => __encoding A64_sve_sve_cmpuimm_sve_int_ucmp_vi_cmphi_p_p_zi_ // cmphi_p_p_zi_
                        when ('1', '0') => __encoding A64_sve_sve_cmpuimm_sve_int_ucmp_vi_cmplo_p_p_zi_ // cmplo_p_p_zi_
                        when ('1', '1') => __encoding A64_sve_sve_cmpuimm_sve_int_ucmp_vi_cmpls_p_p_zi_ // cmpls_p_p_zi_
                when ('001', _, '1xx00xxx', _, '01xxxx', _, _, _) => // sve_int_pred_log
                    __field op 23 +: 1
                    __field S 22 +: 1
                    __field Pm 16 +: 4
                    __field Pg 10 +: 4
                    __field o2 9 +: 1
                    __field Pn 5 +: 4
                    __field o3 4 +: 1
                    __field Pd 0 +: 4
                    case (op, S, o2, o3) of
                        when ('0', '0', '0', '0') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_and_p_p_pp_z // and_p_p_pp_z
                        when ('0', '0', '0', '1') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_bic_p_p_pp_z // bic_p_p_pp_z
                        when ('0', '0', '1', '0') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_eor_p_p_pp_z // eor_p_p_pp_z
                        when ('0', '0', '1', '1') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_sel_p_p_pp_ // sel_p_p_pp_
                        when ('0', '1', '0', '0') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_ands_p_p_pp_z // ands_p_p_pp_z
                        when ('0', '1', '0', '1') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_bics_p_p_pp_z // bics_p_p_pp_z
                        when ('0', '1', '1', '0') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_eors_p_p_pp_z // eors_p_p_pp_z
                        when ('0', '1', '1', '1') => __UNALLOCATED
                        when ('1', '0', '0', '0') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_orr_p_p_pp_z // orr_p_p_pp_z
                        when ('1', '0', '0', '1') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_orn_p_p_pp_z // orn_p_p_pp_z
                        when ('1', '0', '1', '0') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_nor_p_p_pp_z // nor_p_p_pp_z
                        when ('1', '0', '1', '1') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_nand_p_p_pp_z // nand_p_p_pp_z
                        when ('1', '1', '0', '0') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_orrs_p_p_pp_z // orrs_p_p_pp_z
                        when ('1', '1', '0', '1') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_orns_p_p_pp_z // orns_p_p_pp_z
                        when ('1', '1', '1', '0') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_nors_p_p_pp_z // nors_p_p_pp_z
                        when ('1', '1', '1', '1') => __encoding A64_sve_sve_pred_gen_a_sve_int_pred_log_nands_p_p_pp_z // nands_p_p_pp_z
                when ('001', _, '1xx0xxxx', _, 'x0xxxx', _, _, _) => // sve_int_scmp_vi
                    __field size 22 +: 2
                    __field imm5 16 +: 5
                    __field op 15 +: 1
                    __field o2 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field ne 4 +: 1
                    __field Pd 0 +: 4
                    case (op, o2, ne) of
                        when ('0', '0', '0') => __encoding A64_sve_sve_cmpsimm_sve_int_scmp_vi_cmpge_p_p_zi_ // cmpge_p_p_zi_
                        when ('0', '0', '1') => __encoding A64_sve_sve_cmpsimm_sve_int_scmp_vi_cmpgt_p_p_zi_ // cmpgt_p_p_zi_
                        when ('0', '1', '0') => __encoding A64_sve_sve_cmpsimm_sve_int_scmp_vi_cmplt_p_p_zi_ // cmplt_p_p_zi_
                        when ('0', '1', '1') => __encoding A64_sve_sve_cmpsimm_sve_int_scmp_vi_cmple_p_p_zi_ // cmple_p_p_zi_
                        when ('1', '0', '0') => __encoding A64_sve_sve_cmpsimm_sve_int_scmp_vi_cmpeq_p_p_zi_ // cmpeq_p_p_zi_
                        when ('1', '0', '1') => __encoding A64_sve_sve_cmpsimm_sve_int_scmp_vi_cmpne_p_p_zi_ // cmpne_p_p_zi_
                        when ('1', '1', _) => __UNALLOCATED
                when ('001', _, '1xx1xxxx', _, '01xxxx', _, '0', _) => // sve_int_pred_dup
                    __field i1 23 +: 1
                    __field tszh 22 +: 1
                    __field tszl 18 +: 3
                    __field Rv 16 +: 2
                    __field Pn 10 +: 4
                    __field S 9 +: 1
                    __field Pm 5 +: 4
                    __field Pd 0 +: 4
                    case (S) of
                        when ('0') => __encoding A64_sve_sve_pred_dup_sve_int_pred_dup_psel_p_ppi_ // psel_p_ppi_
                        when ('1') => __UNALLOCATED
                when ('010', _, '0000xxxx', _, '11001x', _, _, _) => // sve_intx_dot2
                    __field Zm 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (U) of
                        when ('0') => __encoding A64_sve_sve_intx_dot2_sve_intx_dot2_sdot_z32_zzz_ // sdot_z32_zzz_
                        when ('1') => __encoding A64_sve_sve_intx_dot2_sve_intx_dot2_udot_z32_zzz_ // udot_z32_zzz_
                when ('010', _, '0100xxxx', _, '11001x', _, _, _) => // sve_intx_dot2_by_indexed_elem
                    __field opc 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (U) of
                        when ('0') => __encoding A64_sve_sve_intx_dot2_by_indexed_elem_sve_intx_dot2_by_indexed_elem_sdot_z32_zzzi_ // sdot_z32_zzzi_
                        when ('1') => __encoding A64_sve_sve_intx_dot2_by_indexed_elem_sve_intx_dot2_by_indexed_elem_udot_z32_zzzi_ // udot_z32_zzzi_
                when ('010', _, '0xx0xxxx', _, '11000x', _, _, _) => // sve_intx_clamp
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field U 10 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (U) of
                        when ('0') => __encoding A64_sve_sve_intx_clamp_sve_intx_clamp_sclamp_z_zz_ // sclamp_z_zz_
                        when ('1') => __encoding A64_sve_sve_intx_clamp_sve_intx_clamp_uclamp_z_zz_ // uclamp_z_zz_
                when ('010', _, '0xx0xxxx', _, '1101xx', _, _, _) => // sve_ptr_muladd_unpred
                    __field opc 22 +: 2
                    __field Zm 16 +: 5
                    __field opc2 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (opc, opc2) of
                        when (!'11', _) => __UNALLOCATED
                        when ('11', 'x1') => __UNALLOCATED
                        when ('11', '00') => __encoding A64_sve_sve_ptr_muladd_unpred_sve_ptr_muladd_unpred_mlapt_z_zzz_ // mlapt_z_zzz_
                        when ('11', '10') => __encoding A64_sve_sve_ptr_muladd_unpred_sve_ptr_muladd_unpred_madpt_z_zzz_ // madpt_z_zzz_
                when ('010', _, '0xx0xxxx', _, '111xxx', _, _, _) => // sve_int_perm_binquads
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding A64_sve_sve_perm_quads_b_sve_int_perm_binquads_zipq1_z_zz_ // zipq1_z_zz_
                        when ('001') => __encoding A64_sve_sve_perm_quads_b_sve_int_perm_binquads_zipq2_z_zz_ // zipq2_z_zz_
                        when ('010') => __encoding A64_sve_sve_perm_quads_b_sve_int_perm_binquads_uzpq1_z_zz_ // uzpq1_z_zz_
                        when ('011') => __encoding A64_sve_sve_perm_quads_b_sve_int_perm_binquads_uzpq2_z_zz_ // uzpq2_z_zz_
                        when ('10x') => __UNALLOCATED
                        when ('110') => __encoding A64_sve_sve_perm_quads_b_sve_int_perm_binquads_tblq_z_zz_ // tblq_z_zz_
                        when ('111') => __UNALLOCATED
                when ('010', _, '1xx1xxxx', _, '100xxx', _, _, _) => // sve_intx_match
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field op 4 +: 1
                    __field Pd 0 +: 4
                    case (op) of
                        when ('0') => __encoding A64_sve_sve_intx_string_sve_intx_match_match_p_p_zz_ // match_p_p_zz_
                        when ('1') => __encoding A64_sve_sve_intx_string_sve_intx_match_nmatch_p_p_zz_ // nmatch_p_p_zz_
                when ('010', _, '1xx1xxxx', _, '110xxx', _, _, _) => // sve_intx_histcnt
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case () of
                        when () => __encoding A64_sve_sve_intx_histcnt_sve_intx_histcnt_histcnt_z_p_zz_ // histcnt_z_p_zz_
                when ('011', _, '00x1xxxx', _, '111000', _, _, _) => // sve_fp8_fmmla
                    __field op 22 +: 1
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (op) of
                        when ('0') => __encoding A64_sve_sve_fp8_fmmla_sve_fp8_fmmla_fmmla_z32_zz8z8_ // fmmla_z32_zz8z8_
                        when ('1') => __encoding A64_sve_sve_fp8_fmmla_sve_fp8_fmmla_fmmla_z16_zz8z8_ // fmmla_z16_zz8z8_
                when ('011', _, '0x01xxxx', _, '0101xx', _, _, _) => // sve_fp8_fma_long_by_indexed_elem
                    __field T 23 +: 1
                    __field i4h 19 +: 2
                    __field Zm 16 +: 3
                    __field i4l 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (T) of
                        when ('0') => __encoding A64_sve_sve_fp8_fma_w_by_indexed_elem_sve_fp8_fma_long_by_indexed_elem_fmlalb_z_z8z8z8i_ // fmlalb_z_z8z8z8i_
                        when ('1') => __encoding A64_sve_sve_fp8_fma_w_by_indexed_elem_sve_fp8_fma_long_by_indexed_elem_fmlalt_z_z8z8z8i_ // fmlalt_z_z8z8z8i_
                when ('011', _, '0xx00000', _, '100xxx', _, _, _) => // sve_fp_fcadd
                    __field size 22 +: 2
                    __field rot 16 +: 1
                    __field Pg 10 +: 3
                    __field Zm 5 +: 5
                    __field Zdn 0 +: 5
                    case () of
                        when () => __encoding A64_sve_sve_fp_fcadd_sve_fp_fcadd_fcadd_z_p_zz_ // fcadd_z_p_zz_
                when ('011', _, '0xx0000x', _, '101xxx', _, _, _) => // sve_fp_fcvt2z
                    __field opc 22 +: 2
                    __field opc2 16 +: 2
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc, opc2) of
                        when ('x0', '11') => __UNALLOCATED
                        when ('00', '0x') => __UNALLOCATED
                        when ('00', '10') => __encoding A64_sve_sve_fp_fcvt2z_sve_fp_fcvt2z_fcvtxnt_z_p_z_d2sz // fcvtxnt_z_p_z_d2sz
                        when ('01', _) => __UNALLOCATED
                        when ('10', '00') => __encoding A64_sve_sve_fp_fcvt2z_sve_fp_fcvt2z_fcvtnt_z_p_z_s2hz // fcvtnt_z_p_z_s2hz
                        when ('10', '01') => __encoding A64_sve_sve_fp_fcvt2z_sve_fp_fcvt2z_fcvtlt_z_p_z_h2sz // fcvtlt_z_p_z_h2sz
                        when ('10', '10') => __encoding A64_sve_sve_fp_fcvt2z_sve_fp_fcvt2z_bfcvtnt_z_p_z_s2bfz // bfcvtnt_z_p_z_s2bfz
                        when ('11', '0x') => __UNALLOCATED
                        when ('11', '10') => __encoding A64_sve_sve_fp_fcvt2z_sve_fp_fcvt2z_fcvtnt_z_p_z_d2sz // fcvtnt_z_p_z_d2sz
                        when ('11', '11') => __encoding A64_sve_sve_fp_fcvt2z_sve_fp_fcvt2z_fcvtlt_z_p_z_s2dz // fcvtlt_z_p_z_s2dz
                when ('011', _, '0xx0010x', _, '101xxx', _, _, _) => // sve_fp_fcvt2
                    __field opc 22 +: 2
                    __field opc2 16 +: 2
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (opc, opc2) of
                        when ('x0', '11') => __UNALLOCATED
                        when ('00', '0x') => __UNALLOCATED
                        when ('00', '10') => __encoding A64_sve_sve_fp_fcvt2_sve_fp_fcvt2_fcvtxnt_z_p_z_d2s // fcvtxnt_z_p_z_d2s
                        when ('01', _) => __UNALLOCATED
                        when ('10', '00') => __encoding A64_sve_sve_fp_fcvt2_sve_fp_fcvt2_fcvtnt_z_p_z_s2h // fcvtnt_z_p_z_s2h
                        when ('10', '01') => __encoding A64_sve_sve_fp_fcvt2_sve_fp_fcvt2_fcvtlt_z_p_z_h2s // fcvtlt_z_p_z_h2s
                        when ('10', '10') => __encoding A64_sve_sve_fp_fcvt2_sve_fp_fcvt2_bfcvtnt_z_p_z_s2bf // bfcvtnt_z_p_z_s2bf
                        when ('11', '0x') => __UNALLOCATED
                        when ('11', '10') => __encoding A64_sve_sve_fp_fcvt2_sve_fp_fcvt2_fcvtnt_z_p_z_d2s // fcvtnt_z_p_z_d2s
                        when ('11', '11') => __encoding A64_sve_sve_fp_fcvt2_sve_fp_fcvt2_fcvtlt_z_p_z_s2d // fcvtlt_z_p_z_s2d
                when ('011', _, '0xx010xx', _, '100xxx', _, _, _) => // sve_fp_pairwise
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zm 5 +: 5
                    __field Zdn 0 +: 5
                    case (opc) of
                        when ('000') => __encoding A64_sve_sve_fp_pairwise_sve_fp_pairwise_faddp_z_p_zz_ // faddp_z_p_zz_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding A64_sve_sve_fp_pairwise_sve_fp_pairwise_fmaxnmp_z_p_zz_ // fmaxnmp_z_p_zz_
                        when ('101') => __encoding A64_sve_sve_fp_pairwise_sve_fp_pairwise_fminnmp_z_p_zz_ // fminnmp_z_p_zz_
                        when ('110') => __encoding A64_sve_sve_fp_pairwise_sve_fp_pairwise_fmaxp_z_p_zz_ // fmaxp_z_p_zz_
                        when ('111') => __encoding A64_sve_sve_fp_pairwise_sve_fp_pairwise_fminp_z_p_zz_ // fminp_z_p_zz_
                when ('011', _, '0xx010xx', _, '101xxx', _, _, _) => // sve_fp_fast_redq
                    __field size 22 +: 2
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Vd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding A64_sve_sve_fp_fastreduceq_sve_fp_fast_redq_faddqv_z_p_z_ // faddqv_z_p_z_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding A64_sve_sve_fp_fastreduceq_sve_fp_fast_redq_fmaxnmqv_z_p_z_ // fmaxnmqv_z_p_z_
                        when ('101') => __encoding A64_sve_sve_fp_fastreduceq_sve_fp_fast_redq_fminnmqv_z_p_z_ // fminnmqv_z_p_z_
                        when ('110') => __encoding A64_sve_sve_fp_fastreduceq_sve_fp_fast_redq_fmaxqv_z_p_z_ // fmaxqv_z_p_z_
                        when ('111') => __encoding A64_sve_sve_fp_fastreduceq_sve_fp_fast_redq_fminqv_z_p_z_ // fminqv_z_p_z_
                when ('011', _, '0xx0xxxx', _, '0xxxxx', _, _, _) => // sve_fp_fcmla
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field rot 13 +: 2
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case () of
                        when () => __encoding A64_sve_sve_fp_fcmla_sve_fp_fcmla_fcmla_z_p_zzz_ // fcmla_z_p_zzz_
                when ('011', _, '0xx1xxxx', _, '0000xx', _, _, _) => // sve_fp_fma_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field o2 11 +: 1
                    __field op 10 +: 1
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (size, o2, op) of
                        when ('0x', '0', '0') => __encoding A64_sve_sve_fp_fma_by_indexed_elem_sve_fp_fma_by_indexed_elem_fmla_z_zzzi_h // fmla_z_zzzi_h
                        when ('0x', '0', '1') => __encoding A64_sve_sve_fp_fma_by_indexed_elem_sve_fp_fma_by_indexed_elem_fmls_z_zzzi_h // fmls_z_zzzi_h
                        when ('0x', '1', '0') => __encoding A64_sve_sve_fp_fma_by_indexed_elem_sve_fp_fma_by_indexed_elem_bfmla_z_zzzi_h // bfmla_z_zzzi_h
                        when ('0x', '1', '1') => __encoding A64_sve_sve_fp_fma_by_indexed_elem_sve_fp_fma_by_indexed_elem_bfmls_z_zzzi_h // bfmls_z_zzzi_h
                        when ('1x', '1', _) => __UNALLOCATED
                        when ('10', '0', '0') => __encoding A64_sve_sve_fp_fma_by_indexed_elem_sve_fp_fma_by_indexed_elem_fmla_z_zzzi_s // fmla_z_zzzi_s
                        when ('10', '0', '1') => __encoding A64_sve_sve_fp_fma_by_indexed_elem_sve_fp_fma_by_indexed_elem_fmls_z_zzzi_s // fmls_z_zzzi_s
                        when ('11', '0', '0') => __encoding A64_sve_sve_fp_fma_by_indexed_elem_sve_fp_fma_by_indexed_elem_fmla_z_zzzi_d // fmla_z_zzzi_d
                        when ('11', '0', '1') => __encoding A64_sve_sve_fp_fma_by_indexed_elem_sve_fp_fma_by_indexed_elem_fmls_z_zzzi_d // fmls_z_zzzi_d
                when ('011', _, '0xx1xxxx', _, '0001xx', _, _, _) => // sve_fp_fcmla_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field rot 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (size) of
                        when ('0x') => __UNALLOCATED
                        when ('10') => __encoding A64_sve_sve_fp_fcmla_by_indexed_elem_sve_fp_fcmla_by_indexed_elem_fcmla_z_zzzi_h // fcmla_z_zzzi_h
                        when ('11') => __encoding A64_sve_sve_fp_fcmla_by_indexed_elem_sve_fp_fcmla_by_indexed_elem_fcmla_z_zzzi_s // fcmla_z_zzzi_s
                when ('011', _, '0xx1xxxx', _, '001001', _, _, _) => // sve_fp_clamp
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size) of
                        when ('00') => __encoding A64_sve_sve_fp_clamp_sve_fp_clamp_bfclamp_z_zz_ // bfclamp_z_zz_
                        when (!'00') => __encoding A64_sve_sve_fp_clamp_sve_fp_clamp_fclamp_z_zz_ // fclamp_z_zz_
                when ('011', _, '0xx1xxxx', _, '0010x0', _, _, _) => // sve_fp_fmul_by_indexed_elem
                    __field size 22 +: 2
                    __field opc 16 +: 5
                    __field o2 11 +: 1
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size, o2) of
                        when ('0x', '0') => __encoding A64_sve_sve_fp_fmul_by_indexed_elem_sve_fp_fmul_by_indexed_elem_fmul_z_zzi_h // fmul_z_zzi_h
                        when ('0x', '1') => __encoding A64_sve_sve_fp_fmul_by_indexed_elem_sve_fp_fmul_by_indexed_elem_bfmul_z_zzi_h // bfmul_z_zzi_h
                        when ('1x', '1') => __UNALLOCATED
                        when ('10', '0') => __encoding A64_sve_sve_fp_fmul_by_indexed_elem_sve_fp_fmul_by_indexed_elem_fmul_z_zzi_s // fmul_z_zzi_s
                        when ('11', '0') => __encoding A64_sve_sve_fp_fmul_by_indexed_elem_sve_fp_fmul_by_indexed_elem_fmul_z_zzi_d // fmul_z_zzi_d
                when ('011', _, '0xx1xxxx', _, '1100xx', _, _, _) => // sve_fp8_fma_long_long_by_indexed_elem
                    __field TT 22 +: 2
                    __field i4h 19 +: 2
                    __field Zm 16 +: 3
                    __field i4l 10 +: 2
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (TT) of
                        when ('00') => __encoding A64_sve_sve_fp8_fma_ww_by_indexed_elem_sve_fp8_fma_long_long_by_indexed_elem_fmlallbb_z32_z8z8z8i_ // fmlallbb_z32_z8z8z8i_
                        when ('01') => __encoding A64_sve_sve_fp8_fma_ww_by_indexed_elem_sve_fp8_fma_long_long_by_indexed_elem_fmlallbt_z32_z8z8z8i_ // fmlallbt_z32_z8z8z8i_
                        when ('10') => __encoding A64_sve_sve_fp8_fma_ww_by_indexed_elem_sve_fp8_fma_long_long_by_indexed_elem_fmlalltb_z32_z8z8z8i_ // fmlalltb_z32_z8z8z8i_
                        when ('11') => __encoding A64_sve_sve_fp8_fma_ww_by_indexed_elem_sve_fp8_fma_long_long_by_indexed_elem_fmlalltt_z32_z8z8z8i_ // fmlalltt_z32_z8z8z8i_
                when ('011', _, '0xx1xxxx', _, '111001', _, _, _) => // sve_fp_fmmla
                    __field opc 22 +: 2
                    __field Zm 16 +: 5
                    __field Zn 5 +: 5
                    __field Zda 0 +: 5
                    case (opc) of
                        when ('00') => __encoding A64_sve_sve_fp_fmmla_sve_fp_fmmla_fmmla_z32_zzz_h // fmmla_z32_zzz_h
                        when ('01') => __encoding A64_sve_sve_fp_fmmla_sve_fp_fmmla_bfmmla_z_zzz_ // bfmmla_z_zzz_
                        when ('10') => __encoding A64_sve_sve_fp_fmmla_sve_fp_fmmla_fmmla_z_zzz_s // fmmla_z_zzz_s
                        when ('11') => __encoding A64_sve_sve_fp_fmmla_sve_fp_fmmla_fmmla_z_zzz_d // fmmla_z_zzz_d
                when ('011', _, '1xx000xx', _, '001xxx', _, _, _) => // sve_fp_fast_red
                    __field size 22 +: 2
                    __field opc 16 +: 3
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field Vd 0 +: 5
                    case (opc) of
                        when ('000') => __encoding A64_sve_sve_fp_fastreduce_sve_fp_fast_red_faddv_v_p_z_ // faddv_v_p_z_
                        when ('001') => __UNALLOCATED
                        when ('01x') => __UNALLOCATED
                        when ('100') => __encoding A64_sve_sve_fp_fastreduce_sve_fp_fast_red_fmaxnmv_v_p_z_ // fmaxnmv_v_p_z_
                        when ('101') => __encoding A64_sve_sve_fp_fastreduce_sve_fp_fast_red_fminnmv_v_p_z_ // fminnmv_v_p_z_
                        when ('110') => __encoding A64_sve_sve_fp_fastreduce_sve_fp_fast_red_fmaxv_v_p_z_ // fmaxv_v_p_z_
                        when ('111') => __encoding A64_sve_sve_fp_fastreduce_sve_fp_fast_red_fminv_v_p_z_ // fminv_v_p_z_
                when ('011', _, '1xx0xxxx', _, '000xxx', _, _, _) => // sve_fp_3op_u_zd
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field opc 10 +: 3
                    __field Zn 5 +: 5
                    __field Zd 0 +: 5
                    case (size, opc) of
                        when (_, '011') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_ftsmul_z_zz_ // ftsmul_z_zz_
                        when (_, '10x') => __UNALLOCATED
                        when (_, '110') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_frecps_z_zz_ // frecps_z_zz_
                        when (_, '111') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_frsqrts_z_zz_ // frsqrts_z_zz_
                        when ('00', '000') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_bfadd_z_zz_ // bfadd_z_zz_
                        when ('00', '001') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_bfsub_z_zz_ // bfsub_z_zz_
                        when ('00', '010') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_bfmul_z_zz_ // bfmul_z_zz_
                        when (!'00', '000') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_fadd_z_zz_ // fadd_z_zz_
                        when (!'00', '001') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_fsub_z_zz_ // fsub_z_zz_
                        when (!'00', '010') => __encoding A64_sve_sve_fp_unpred_sve_fp_3op_u_zd_fmul_z_zz_ // fmul_z_zz_
                when ('011', _, '1xx0xxxx', _, 'x1xxxx', _, _, _) => // sve_fp_3op_p_pd
                    __field size 22 +: 2
                    __field Zm 16 +: 5
                    __field op 15 +: 1
                    __field o2 13 +: 1
                    __field Pg 10 +: 3
                    __field Zn 5 +: 5
                    __field o3 4 +: 1
                    __field Pd 0 +: 4
                    case (op, o2, o3) of
                        when ('0', '0', '0') => __encoding A64_sve_sve_fp_cmpvev_sve_fp_3op_p_pd_fcmge_p_p_zz_ // fcmge_p_p_zz_
                        when ('0', '0', '1') => __encoding A64_sve_sve_fp_cmpvev_sve_fp_3op_p_pd_fcmgt_p_p_zz_ // fcmgt_p_p_zz_
                        when ('0', '1', '0') => __encoding A64_sve_sve_fp_cmpvev_sve_fp_3op_p_pd_fcmeq_p_p_zz_ // fcmeq_p_p_zz_
                        when ('0', '1', '1') => __encoding A64_sve_sve_fp_cmpvev_sve_fp_3op_p_pd_fcmne_p_p_zz_ // fcmne_p_p_zz_
                        when ('1', '0', '0') => __encoding A64_sve_sve_fp_cmpvev_sve_fp_3op_p_pd_fcmuo_p_p_zz_ // fcmuo_p_p_zz_
                        when ('1', '0', '1') => __encoding A64_sve_sve_fp_cmpvev_sve_fp_3op_p_pd_facge_p_p_zz_ // facge_p_p_zz_
                        when ('1', '1', '0') => __UNALLOCATED
                        when ('1', '1', '1') => __encoding A64_sve_sve_fp_cmpvev_sve_fp_3op_p_pd_facgt_p_p_zz_ // facgt_p_p_zz_
        when (_, _, '00x1', _) => __UNPREDICTABLE
        when (_, _, '100x', _) =>
            // dpimm
            case (31 +: 1, 29 +: 2, 26 +: 3, 22 +: 4, 0 +: 22) of
                when (_, '11', _, '111x', _) => // dp_1src_imm
                    __field sf 31 +: 1
                    __field opc 21 +: 2
                    __field imm16 5 +: 16
                    __field Rd 0 +: 5
                    case (sf, opc, Rd) of
                        when ('0', _, _) => __UNALLOCATED
                        when ('1', '0x', !'11111') => __UNALLOCATED
                        when ('1', '00', '11111') => __encoding A64_dpimm_dp_1src_imm_AUTIASPPC_only_dp_1src_imm // AUTIASPPC_only_dp_1src_imm
                        when ('1', '01', '11111') => __encoding A64_dpimm_dp_1src_imm_AUTIBSPPC_only_dp_1src_imm // AUTIBSPPC_only_dp_1src_imm
                        when ('1', '1x', _) => __UNALLOCATED
                when (_, _, _, '00xx', _) => // pcreladdr
                    __field op 31 +: 1
                    __field immlo 29 +: 2
                    __field immhi 5 +: 19
                    __field Rd 0 +: 5
                    case (op) of
                        when ('0') => __encoding A64_dpimm_pcreladdr_ADR_only_pcreladdr // ADR_only_pcreladdr
                        when ('1') => __encoding A64_dpimm_pcreladdr_ADRP_only_pcreladdr // ADRP_only_pcreladdr
                when (_, _, _, '010x', _) => // addsub_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field sh 22 +: 1
                    __field imm12 10 +: 12
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', '0', '0') => __encoding A64_dpimm_addsub_imm_ADD_32_addsub_imm // ADD_32_addsub_imm
                        when ('0', '0', '1') => __encoding A64_dpimm_addsub_imm_ADDS_32S_addsub_imm // ADDS_32S_addsub_imm
                        when ('0', '1', '0') => __encoding A64_dpimm_addsub_imm_SUB_32_addsub_imm // SUB_32_addsub_imm
                        when ('0', '1', '1') => __encoding A64_dpimm_addsub_imm_SUBS_32S_addsub_imm // SUBS_32S_addsub_imm
                        when ('1', '0', '0') => __encoding A64_dpimm_addsub_imm_ADD_32_addsub_imm // ADD_64_addsub_imm
                        when ('1', '0', '1') => __encoding A64_dpimm_addsub_imm_ADDS_32S_addsub_imm // ADDS_64S_addsub_imm
                        when ('1', '1', '0') => __encoding A64_dpimm_addsub_imm_SUB_32_addsub_imm // SUB_64_addsub_imm
                        when ('1', '1', '1') => __encoding A64_dpimm_addsub_imm_SUBS_32S_addsub_imm // SUBS_64S_addsub_imm
                when (_, _, _, '0110', _) => // addsub_immtags
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field imm6 16 +: 6
                    __field op3 14 +: 2
                    __field imm4 10 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', _, _) => __UNALLOCATED
                        when ('1', _, '1') => __UNALLOCATED
                        when ('1', '0', '0') => __encoding A64_dpimm_addsub_immtags_ADDG_64_addsub_immtags // ADDG_64_addsub_immtags
                        when ('1', '1', '0') => __encoding A64_dpimm_addsub_immtags_SUBG_64_addsub_immtags // SUBG_64_addsub_immtags
                when (_, _, _, '0111', _) => // minmax_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opc 18 +: 4
                    __field imm8 10 +: 8
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, opc) of
                        when (_, '0', '0', '01xx') => __UNALLOCATED
                        when (_, '0', '0', '1xxx') => __UNALLOCATED
                        when (_, '0', '1', _) => __UNALLOCATED
                        when (_, '1', _, _) => __UNALLOCATED
                        when ('0', '0', '0', '0000') => __encoding A64_dpimm_minmax_imm_SMAX_32_minmax_imm // SMAX_32_minmax_imm
                        when ('0', '0', '0', '0001') => __encoding A64_dpimm_minmax_imm_UMAX_32U_minmax_imm // UMAX_32U_minmax_imm
                        when ('0', '0', '0', '0010') => __encoding A64_dpimm_minmax_imm_SMIN_32_minmax_imm // SMIN_32_minmax_imm
                        when ('0', '0', '0', '0011') => __encoding A64_dpimm_minmax_imm_UMIN_32U_minmax_imm // UMIN_32U_minmax_imm
                        when ('1', '0', '0', '0000') => __encoding A64_dpimm_minmax_imm_SMAX_32_minmax_imm // SMAX_64_minmax_imm
                        when ('1', '0', '0', '0001') => __encoding A64_dpimm_minmax_imm_UMAX_32U_minmax_imm // UMAX_64U_minmax_imm
                        when ('1', '0', '0', '0010') => __encoding A64_dpimm_minmax_imm_SMIN_32_minmax_imm // SMIN_64_minmax_imm
                        when ('1', '0', '0', '0011') => __encoding A64_dpimm_minmax_imm_UMIN_32U_minmax_imm // UMIN_64U_minmax_imm
                when (_, _, _, '100x', _) => // log_imm
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field N 22 +: 1
                    __field immr 16 +: 6
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N) of
                        when ('0', _, '1') => __UNALLOCATED
                        when ('0', '00', '0') => __encoding A64_dpimm_log_imm_AND_32_log_imm // AND_32_log_imm
                        when ('0', '01', '0') => __encoding A64_dpimm_log_imm_ORR_32_log_imm // ORR_32_log_imm
                        when ('0', '10', '0') => __encoding A64_dpimm_log_imm_EOR_32_log_imm // EOR_32_log_imm
                        when ('0', '11', '0') => __encoding A64_dpimm_log_imm_ANDS_32S_log_imm // ANDS_32S_log_imm
                        when ('1', '00', _) => __encoding A64_dpimm_log_imm_AND_32_log_imm // AND_64_log_imm
                        when ('1', '01', _) => __encoding A64_dpimm_log_imm_ORR_32_log_imm // ORR_64_log_imm
                        when ('1', '10', _) => __encoding A64_dpimm_log_imm_EOR_32_log_imm // EOR_64_log_imm
                        when ('1', '11', _) => __encoding A64_dpimm_log_imm_ANDS_32S_log_imm // ANDS_64S_log_imm
                when (_, _, _, '101x', _) => // movewide
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field hw 21 +: 2
                    __field imm16 5 +: 16
                    __field Rd 0 +: 5
                    case (sf, opc, hw) of
                        when (_, '01', '0x') => __UNALLOCATED
                        when ('0', _, '1x') => __UNALLOCATED
                        when ('0', '00', '0x') => __encoding A64_dpimm_movewide_MOVN_32_movewide // MOVN_32_movewide
                        when ('0', '10', '0x') => __encoding A64_dpimm_movewide_MOVZ_32_movewide // MOVZ_32_movewide
                        when ('0', '11', '0x') => __encoding A64_dpimm_movewide_MOVK_32_movewide // MOVK_32_movewide
                        when ('1', '00', _) => __encoding A64_dpimm_movewide_MOVN_32_movewide // MOVN_64_movewide
                        when ('1', '01', '1x') => __UNALLOCATED
                        when ('1', '10', _) => __encoding A64_dpimm_movewide_MOVZ_32_movewide // MOVZ_64_movewide
                        when ('1', '11', _) => __encoding A64_dpimm_movewide_MOVK_32_movewide // MOVK_64_movewide
                when (_, _, _, '110x', _) => // bitfield
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field N 22 +: 1
                    __field immr 16 +: 6
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N) of
                        when ('0', _, '1') => __UNALLOCATED
                        when ('0', '00', '0') => __encoding A64_dpimm_bitfield_SBFM_32M_bitfield // SBFM_32M_bitfield
                        when ('0', '01', '0') => __encoding A64_dpimm_bitfield_BFM_32M_bitfield // BFM_32M_bitfield
                        when ('0', '10', '0') => __encoding A64_dpimm_bitfield_UBFM_32M_bitfield // UBFM_32M_bitfield
                        when ('0', '11', '0') => __UNALLOCATED
                        when ('1', _, '0') => __UNALLOCATED
                        when ('1', '00', '1') => __encoding A64_dpimm_bitfield_SBFM_32M_bitfield // SBFM_64M_bitfield
                        when ('1', '01', '1') => __encoding A64_dpimm_bitfield_BFM_32M_bitfield // BFM_64M_bitfield
                        when ('1', '10', '1') => __encoding A64_dpimm_bitfield_UBFM_32M_bitfield // UBFM_64M_bitfield
                        when ('1', '11', '1') => __UNALLOCATED
                when (_, !'11', _, '111x', _) => // extract
                    __field sf 31 +: 1
                    __field op21 29 +: 2
                    __field N 22 +: 1
                    __field o0 21 +: 1
                    __field Rm 16 +: 5
                    __field imms 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op21, N, o0, imms) of
                        when (_, '00', _, '1', _) => __UNALLOCATED
                        when (_, '01', _, _, _) => __UNALLOCATED
                        when (_, '10', _, _, _) => __UNALLOCATED
                        when ('0', '00', '0', '0', '0xxxxx') => __encoding A64_dpimm_extract_EXTR_32_extract // EXTR_32_extract
                        when ('0', '00', '0', '0', '1xxxxx') => __UNALLOCATED
                        when ('0', '00', '1', '0', _) => __UNALLOCATED
                        when ('1', '00', '0', '0', _) => __UNALLOCATED
                        when ('1', '00', '1', '0', _) => __encoding A64_dpimm_extract_EXTR_32_extract // EXTR_64_extract
        when (_, _, '101x', _) =>
            // control
            case (29 +: 3, 26 +: 3, 12 +: 14, 5 +: 7, 0 +: 5) of
                when ('010', _, '00xxxxxxxxxxxx', _, _) => // condbranch
                    __field imm19 5 +: 19
                    __field o0 4 +: 1
                    __field cond 0 +: 4
                    case (o0) of
                        when ('0') => __encoding A64_control_condbranch_B_only_condbranch // B_only_condbranch
                        when ('1') => __encoding A64_control_condbranch_BC_only_condbranch // BC_only_condbranch
                when ('010', _, '01xxxxxxxxxxxx', _, _) => // miscbranch
                    __field opc 21 +: 3
                    __field imm16 5 +: 16
                    __field op2 0 +: 5
                    case (opc, op2) of
                        when ('00x', !'11111') => __UNALLOCATED
                        when ('000', '11111') => __encoding A64_control_miscbranch_RETAASPPC_only_miscbranch // RETAASPPC_only_miscbranch
                        when ('001', '11111') => __encoding A64_control_miscbranch_RETAASPPC_only_miscbranch // RETABSPPC_only_miscbranch
                        when ('01x', _) => __UNALLOCATED
                        when ('1xx', _) => __UNALLOCATED
                when ('011', _, '00xxxxxxxx1xxx', _, _) => // compbranch_regs2
                    __field cc 21 +: 3
                    __field Rm 16 +: 5
                    __field H 14 +: 1
                    __field imm9 5 +: 9
                    __field Rt 0 +: 5
                    case (cc, H) of
                        when ('000', '0') => __encoding A64_control_compbranch_regs2_CBBGT_8_regs // CBBGT_8_regs
                        when ('000', '1') => __encoding A64_control_compbranch_regs2_CBHGT_16_regs // CBHGT_16_regs
                        when ('001', '0') => __encoding A64_control_compbranch_regs2_CBBGT_8_regs // CBBGE_8_regs
                        when ('001', '1') => __encoding A64_control_compbranch_regs2_CBHGT_16_regs // CBHGE_16_regs
                        when ('010', '0') => __encoding A64_control_compbranch_regs2_CBBGT_8_regs // CBBHI_8_regs
                        when ('010', '1') => __encoding A64_control_compbranch_regs2_CBHGT_16_regs // CBHHI_16_regs
                        when ('011', '0') => __encoding A64_control_compbranch_regs2_CBBGT_8_regs // CBBHS_8_regs
                        when ('011', '1') => __encoding A64_control_compbranch_regs2_CBHGT_16_regs // CBHHS_16_regs
                        when ('10x', _) => __UNALLOCATED
                        when ('110', '0') => __encoding A64_control_compbranch_regs2_CBBGT_8_regs // CBBEQ_8_regs
                        when ('110', '1') => __encoding A64_control_compbranch_regs2_CBHGT_16_regs // CBHEQ_16_regs
                        when ('111', '0') => __encoding A64_control_compbranch_regs2_CBBGT_8_regs // CBBNE_8_regs
                        when ('111', '1') => __encoding A64_control_compbranch_regs2_CBHGT_16_regs // CBHNE_16_regs
                when ('01x', _, '1xxxxxxxxxxxxx', _, _) => __UNPREDICTABLE
                when ('110', _, '00xxxxxxxxxxxx', _, _) => // exception
                    __field opc 21 +: 3
                    __field imm16 5 +: 16
                    __field op2 2 +: 3
                    __field LL 0 +: 2
                    case (opc, op2, LL) of
                        when (_, !'000', _) => __UNALLOCATED
                        when ('x11', '000', !'00') => __UNALLOCATED
                        when ('000', '000', '00') => __UNALLOCATED
                        when ('000', '000', '01') => __encoding A64_control_exception_SVC_EX_exception // SVC_EX_exception
                        when ('000', '000', '10') => __encoding A64_control_exception_HVC_EX_exception // HVC_EX_exception
                        when ('000', '000', '11') => __encoding A64_control_exception_SMC_EX_exception // SMC_EX_exception
                        when ('001', '000', !'00') => __UNALLOCATED
                        when ('001', '000', '00') => __encoding A64_control_exception_BRK_EX_exception // BRK_EX_exception
                        when ('010', '000', !'00') => __UNALLOCATED
                        when ('010', '000', '00') => __encoding A64_control_exception_HLT_EX_exception // HLT_EX_exception
                        when ('011', '000', '00') => __encoding A64_control_exception_TCANCEL_EX_exception // TCANCEL_EX_exception
                        when ('1x0', '000', _) => __UNALLOCATED
                        when ('1x1', '000', '00') => __UNALLOCATED
                        when ('101', '000', '01') => __encoding A64_control_exception_DCPS1_DC_exception // DCPS1_DC_exception
                        when ('101', '000', '10') => __encoding A64_control_exception_DCPS2_DC_exception // DCPS2_DC_exception
                        when ('101', '000', '11') => __encoding A64_control_exception_DCPS3_DC_exception // DCPS3_DC_exception
                when ('110', _, '010000000x00xx', _, _) => __UNPREDICTABLE
                when ('110', _, '010000001000xx', _, _) => __UNPREDICTABLE
                when ('110', _, '01000000110000', _, _) => __UNPREDICTABLE
                when ('110', _, '01000000110001', _, _) => // systeminstrswithreg
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (CRm, op2) of
                        when (!'0000', _) => __UNALLOCATED
                        when ('0000', '000') => __encoding A64_control_systeminstrswithreg_WFET_only_systeminstrswithreg // WFET_only_systeminstrswithreg
                        when ('0000', '001') => __encoding A64_control_systeminstrswithreg_WFIT_only_systeminstrswithreg // WFIT_only_systeminstrswithreg
                        when ('0000', '01x') => __UNALLOCATED
                        when ('0000', '1xx') => __UNALLOCATED
                when ('110', _, '01000000110010', _, '11111') => // hints
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    case (CRm, op2) of
                        when (_, _) => __encoding A64_control_hints_HINT_HM_hints // HINT_HM_hints
                        when ('0000', '000') => __encoding A64_control_hints_NOP_HI_hints // NOP_HI_hints
                        when ('0000', '001') => __encoding A64_control_hints_YIELD_HI_hints // YIELD_HI_hints
                        when ('0000', '010') => __encoding A64_control_hints_WFE_HI_hints // WFE_HI_hints
                        when ('0000', '011') => __encoding A64_control_hints_WFI_HI_hints // WFI_HI_hints
                        when ('0000', '100') => __encoding A64_control_hints_SEV_HI_hints // SEV_HI_hints
                        when ('0000', '101') => __encoding A64_control_hints_SEVL_HI_hints // SEVL_HI_hints
                        when ('0000', '110') => __encoding A64_control_hints_DGH_HI_hints // DGH_HI_hints
                        when ('0000', '111') => __encoding A64_control_hints_XPACLRI_HI_hints // XPACLRI_HI_hints
                        when ('0001', '000') => __encoding A64_control_hints_PACIA1716_HI_hints // PACIA1716_HI_hints
                        when ('0001', '010') => __encoding A64_control_hints_PACIB1716_HI_hints // PACIB1716_HI_hints
                        when ('0001', '100') => __encoding A64_control_hints_AUTIA1716_HI_hints // AUTIA1716_HI_hints
                        when ('0001', '110') => __encoding A64_control_hints_AUTIB1716_HI_hints // AUTIB1716_HI_hints
                        when ('0010', '000') => __encoding A64_control_hints_ESB_HI_hints // ESB_HI_hints
                        when ('0010', '001') => __encoding A64_control_hints_PSB_HC_hints // PSB_HC_hints
                        when ('0010', '010') => __encoding A64_control_hints_TSB_HC_hints // TSB_HC_hints
                        when ('0010', '011') => __encoding A64_control_hints_GCSB_HD_hints // GCSB_HD_hints
                        when ('0010', '100') => __encoding A64_control_hints_CSDB_HI_hints // CSDB_HI_hints
                        when ('0010', '110') => __encoding A64_control_hints_CLRBHB_HI_hints // CLRBHB_HI_hints
                        when ('0011', '000') => __encoding A64_control_hints_PACIA1716_HI_hints // PACIAZ_HI_hints
                        when ('0011', '001') => __encoding A64_control_hints_PACIA1716_HI_hints // PACIASP_HI_hints
                        when ('0011', '010') => __encoding A64_control_hints_PACIB1716_HI_hints // PACIBZ_HI_hints
                        when ('0011', '011') => __encoding A64_control_hints_PACIB1716_HI_hints // PACIBSP_HI_hints
                        when ('0011', '100') => __encoding A64_control_hints_AUTIA1716_HI_hints // AUTIAZ_HI_hints
                        when ('0011', '101') => __encoding A64_control_hints_AUTIA1716_HI_hints // AUTIASP_HI_hints
                        when ('0011', '110') => __encoding A64_control_hints_AUTIB1716_HI_hints // AUTIBZ_HI_hints
                        when ('0011', '111') => __encoding A64_control_hints_AUTIB1716_HI_hints // AUTIBSP_HI_hints
                        when ('0100', 'xx0') => __encoding A64_control_hints_BTI_HB_hints // BTI_HB_hints
                        when ('0100', '111') => __encoding A64_control_hints_PACM_HI_hints // PACM_HI_hints
                        when ('0101', '000') => __encoding A64_control_hints_CHKFEAT_HF_hints // CHKFEAT_HF_hints
                        when ('0110', '00x') => __encoding A64_control_hints_STSHH_HI_hints // STSHH_HI_hints
                when ('110', _, '01000000110010', _, !'11111') => __UNPREDICTABLE
                when ('110', _, '01000000110011', _, _) => // barriers
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (CRm, op2, Rt) of
                        when (_, _, !'11111') => __UNALLOCATED
                        when (_, '010', '11111') => __encoding A64_control_barriers_CLREX_BN_barriers // CLREX_BN_barriers
                        when (!'0000', '011', '11111') => __UNALLOCATED
                        when (_, '100', '11111') => __encoding A64_control_barriers_DSB_BO_barriers // DSB_BO_barriers
                        when (_, '101', '11111') => __encoding A64_control_barriers_DMB_BO_barriers // DMB_BO_barriers
                        when (_, '110', '11111') => __encoding A64_control_barriers_ISB_BI_barriers // ISB_BI_barriers
                        when (_, '111', '11111') => __encoding A64_control_barriers_SB_only_barriers // SB_only_barriers
                        when ('xx0x', '00x', '11111') => __UNALLOCATED
                        when ('xx1x', '000', '11111') => __UNALLOCATED
                        when ('xx10', '001', '11111') => __encoding A64_control_barriers_DSB_BOn_barriers // DSB_BOn_barriers
                        when ('xx11', '001', '11111') => __UNALLOCATED
                        when ('0000', '011', '11111') => __encoding A64_control_barriers_TCOMMIT_only_barriers // TCOMMIT_only_barriers
                when ('110', _, '01000001xx00xx', _, _) => __UNPREDICTABLE
                when ('110', _, '0100000xxx0100', _, _) => // pstate
                    __field op1 16 +: 3
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (op1, op2, Rt) of
                        when (_, _, !'11111') => __UNALLOCATED
                        when (_, _, '11111') => __encoding A64_control_pstate_MSR_SI_pstate // MSR_SI_pstate
                        when ('000', '000', '11111') => __encoding A64_control_pstate_CFINV_M_pstate // CFINV_M_pstate
                        when ('000', '001', '11111') => __encoding A64_control_pstate_XAFLAG_M_pstate // XAFLAG_M_pstate
                        when ('000', '010', '11111') => __encoding A64_control_pstate_AXFLAG_M_pstate // AXFLAG_M_pstate
                when ('110', _, '0100000xxx0101', _, _) => __UNPREDICTABLE
                when ('110', _, '0100000xxx011x', _, _) => __UNPREDICTABLE
                when ('110', _, '0100000xxx1xxx', _, _) => __UNPREDICTABLE
                when ('110', _, '0100100xxxxxxx', _, _) => // systemresult
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (op1, CRn, CRm, op2) of
                        when (!'011', _, _, _) => __UNALLOCATED
                        when ('011', !'0011', _, _) => __UNALLOCATED
                        when ('011', '0011', '000x', !'011') => __UNALLOCATED
                        when ('011', '0011', '0000', '011') => __encoding A64_control_systemresult_TSTART_BR_systemresult // TSTART_BR_systemresult
                        when ('011', '0011', '0001', '011') => __encoding A64_control_systemresult_TTEST_BR_systemresult // TTEST_BR_systemresult
                        when ('011', '0011', '001x', _) => __UNALLOCATED
                        when ('011', '0011', '01xx', _) => __UNALLOCATED
                        when ('011', '0011', '1xxx', _) => __UNALLOCATED
                when ('110', _, '0100x01xxxxxxx', _, _) => // systeminstrs
                    __field L 21 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding A64_control_systeminstrs_SYS_CR_systeminstrs // SYS_CR_systeminstrs
                        when ('1') => __encoding A64_control_systeminstrs_SYSL_RC_systeminstrs // SYSL_RC_systeminstrs
                when ('110', _, '0100x1xxxxxxxx', _, _) => // systemmove
                    __field L 21 +: 1
                    __field o0 19 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding A64_control_systemmove_MSR_SR_systemmove // MSR_SR_systemmove
                        when ('1') => __encoding A64_control_systemmove_MRS_RS_systemmove // MRS_RS_systemmove
                when ('110', _, '0101x00xxxxxxx', _, _) => __UNPREDICTABLE
                when ('110', _, '0101x01xxxxxxx', _, _) => // syspairinstrs
                    __field L 21 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding A64_control_syspairinstrs_SYSP_CR_syspairinstrs // SYSP_CR_syspairinstrs
                        when ('1') => __UNALLOCATED
                when ('110', _, '0101x1xxxxxxxx', _, _) => // systemmovepr
                    __field L 21 +: 1
                    __field o0 19 +: 1
                    __field op1 16 +: 3
                    __field CRn 12 +: 4
                    __field CRm 8 +: 4
                    __field op2 5 +: 3
                    __field Rt 0 +: 5
                    case (L) of
                        when ('0') => __encoding A64_control_systemmovepr_MSRR_SR_systemmovepr // MSRR_SR_systemmovepr
                        when ('1') => __encoding A64_control_systemmovepr_MRRS_RS_systemmovepr // MRRS_RS_systemmovepr
                when ('110', _, '011xxxxxxxxxxx', _, _) => __UNPREDICTABLE
                when ('110', _, '1xxxxxxxxxxxxx', _, _) => // branch_reg
                    __field opc 21 +: 4
                    __field op2 16 +: 5
                    __field op3 10 +: 6
                    __field Rn 5 +: 5
                    __field op4 0 +: 5
                    case (opc, op2, op3, Rn, op4) of
                        when (_, !'11111', _, _, _) => __UNALLOCATED
                        when (_, '11111', '0001xx', _, _) => __UNALLOCATED
                        when (_, '11111', '001xxx', _, _) => __UNALLOCATED
                        when (_, '11111', '01xxxx', _, _) => __UNALLOCATED
                        when (_, '11111', '1xxxxx', _, _) => __UNALLOCATED
                        when ('00x0', '11111', '000000', _, !'00000') => __UNALLOCATED
                        when ('00x0', '11111', '000001', _, _) => __UNALLOCATED
                        when ('000x', '11111', '00001x', _, !'11111') => __UNALLOCATED
                        when ('0000', '11111', '000000', _, '00000') => __encoding A64_control_branch_reg_BR_64_branch_reg // BR_64_branch_reg
                        when ('0000', '11111', '000010', _, '11111') => __encoding A64_control_branch_reg_BRAA_64P_branch_reg // BRAAZ_64_branch_reg
                        when ('0000', '11111', '000011', _, '11111') => __encoding A64_control_branch_reg_BRAA_64P_branch_reg // BRABZ_64_branch_reg
                        when ('0001', '11111', '000000', _, !'00000') => __UNALLOCATED
                        when ('0001', '11111', '000000', _, '00000') => __encoding A64_control_branch_reg_BLR_64_branch_reg // BLR_64_branch_reg
                        when ('0001', '11111', '000001', _, _) => __UNALLOCATED
                        when ('0001', '11111', '000010', _, '11111') => __encoding A64_control_branch_reg_BLRAA_64P_branch_reg // BLRAAZ_64_branch_reg
                        when ('0001', '11111', '000011', _, '11111') => __encoding A64_control_branch_reg_BLRAA_64P_branch_reg // BLRABZ_64_branch_reg
                        when ('0010', '11111', '000000', _, '00000') => __encoding A64_control_branch_reg_RET_64R_branch_reg // RET_64R_branch_reg
                        when ('0010', '11111', '00001x', !'11111', _) => __UNALLOCATED
                        when ('0010', '11111', '000010', '11111', '11111') => __encoding A64_control_branch_reg_RETAA_64E_branch_reg // RETAA_64E_branch_reg
                        when ('0010', '11111', '000010', '11111', !'11111') => __encoding A64_control_branch_reg_RETAASPPCR_64M_branch_reg // RETAASPPCR_64M_branch_reg
                        when ('0010', '11111', '000011', '11111', '11111') => __encoding A64_control_branch_reg_RETAA_64E_branch_reg // RETAB_64E_branch_reg
                        when ('0010', '11111', '000011', '11111', !'11111') => __encoding A64_control_branch_reg_RETAASPPCR_64M_branch_reg // RETABSPPCR_64M_branch_reg
                        when ('0011', '11111', '0000xx', _, _) => __UNALLOCATED
                        when ('010x', '11111', '0000xx', !'11111', _) => __UNALLOCATED
                        when ('010x', '11111', '000000', '11111', !'00000') => __UNALLOCATED
                        when ('010x', '11111', '000001', '11111', _) => __UNALLOCATED
                        when ('010x', '11111', '00001x', '11111', 'xxxx0') => __UNALLOCATED
                        when ('0100', '11111', '000000', '11111', '00000') => __encoding A64_control_branch_reg_ERET_64E_branch_reg // ERET_64E_branch_reg
                        when ('0100', '11111', '00001x', '11111', '0xxx1') => __UNALLOCATED
                        when ('0100', '11111', '00001x', '11111', '10xx1') => __UNALLOCATED
                        when ('0100', '11111', '00001x', '11111', '110x1') => __UNALLOCATED
                        when ('0100', '11111', '00001x', '11111', '11101') => __UNALLOCATED
                        when ('0100', '11111', '000010', '11111', '11111') => __encoding A64_control_branch_reg_ERETAA_64E_branch_reg // ERETAA_64E_branch_reg
                        when ('0100', '11111', '000011', '11111', '11111') => __encoding A64_control_branch_reg_ERETAA_64E_branch_reg // ERETAB_64E_branch_reg
                        when ('0101', '11111', '000000', '11111', '00000') => __encoding A64_control_branch_reg_DRPS_64E_branch_reg // DRPS_64E_branch_reg
                        when ('0101', '11111', '00001x', '11111', 'xxxx1') => __UNALLOCATED
                        when ('011x', '11111', '0000xx', _, _) => __UNALLOCATED
                        when ('100x', '11111', '00000x', _, _) => __UNALLOCATED
                        when ('1000', '11111', '000010', _, _) => __encoding A64_control_branch_reg_BRAA_64P_branch_reg // BRAA_64P_branch_reg
                        when ('1000', '11111', '000011', _, _) => __encoding A64_control_branch_reg_BRAA_64P_branch_reg // BRAB_64P_branch_reg
                        when ('1001', '11111', '000010', _, _) => __encoding A64_control_branch_reg_BLRAA_64P_branch_reg // BLRAA_64P_branch_reg
                        when ('1001', '11111', '000011', _, _) => __encoding A64_control_branch_reg_BLRAA_64P_branch_reg // BLRAB_64P_branch_reg
                        when ('101x', '11111', '0000xx', _, _) => __UNALLOCATED
                        when ('11xx', '11111', '0000xx', _, _) => __UNALLOCATED
                when ('111', _, '00xxxxxxxx1xxx', _, _) => __UNPREDICTABLE
                when ('111', _, '1xxxxxxxxxxxxx', _, _) => __UNPREDICTABLE
                when ('x00', _, _, _, _) => // branch_imm
                    __field op 31 +: 1
                    __field imm26 0 +: 26
                    case (op) of
                        when ('0') => __encoding A64_control_branch_imm_B_only_branch_imm // B_only_branch_imm
                        when ('1') => __encoding A64_control_branch_imm_BL_only_branch_imm // BL_only_branch_imm
                when ('x01', _, '0xxxxxxxxxxxxx', _, _) => // compbranch
                    __field sf 31 +: 1
                    __field op 24 +: 1
                    __field imm19 5 +: 19
                    __field Rt 0 +: 5
                    case (sf, op) of
                        when ('0', '0') => __encoding A64_control_compbranch_CBZ_32_compbranch // CBZ_32_compbranch
                        when ('0', '1') => __encoding A64_control_compbranch_CBNZ_32_compbranch // CBNZ_32_compbranch
                        when ('1', '0') => __encoding A64_control_compbranch_CBZ_32_compbranch // CBZ_64_compbranch
                        when ('1', '1') => __encoding A64_control_compbranch_CBNZ_32_compbranch // CBNZ_64_compbranch
                when ('x01', _, '1xxxxxxxxxxxxx', _, _) => // testbranch
                    __field b5 31 +: 1
                    __field op 24 +: 1
                    __field b40 19 +: 5
                    __field imm14 5 +: 14
                    __field Rt 0 +: 5
                    case (op) of
                        when ('0') => __encoding A64_control_testbranch_TBZ_only_testbranch // TBZ_only_testbranch
                        when ('1') => __encoding A64_control_testbranch_TBNZ_only_testbranch // TBNZ_only_testbranch
                when ('x11', _, '00xxxxxxxx00xx', _, _) => // compbranch_regs
                    __field sf 31 +: 1
                    __field cc 21 +: 3
                    __field Rm 16 +: 5
                    __field imm9 5 +: 9
                    __field Rt 0 +: 5
                    case (sf, cc) of
                        when (_, '10x') => __UNALLOCATED
                        when ('0', '000') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBGT_32_regs
                        when ('0', '001') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBGE_32_regs
                        when ('0', '010') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBHI_32_regs
                        when ('0', '011') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBHS_32_regs
                        when ('0', '110') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBEQ_32_regs
                        when ('0', '111') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBNE_32_regs
                        when ('1', '000') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBGT_64_regs
                        when ('1', '001') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBGE_64_regs
                        when ('1', '010') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBHI_64_regs
                        when ('1', '011') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBHS_64_regs
                        when ('1', '110') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBEQ_64_regs
                        when ('1', '111') => __encoding A64_control_compbranch_regs_CBGT_32_regs // CBNE_64_regs
                when ('x11', _, '00xxxxxxxx01xx', _, _) => __UNPREDICTABLE
                when ('x11', _, '01xxxxxxxxx0xx', _, _) => // compbranch_imm
                    __field sf 31 +: 1
                    __field cc 21 +: 3
                    __field imm6 15 +: 6
                    __field imm9 5 +: 9
                    __field Rt 0 +: 5
                    case (sf, cc) of
                        when (_, '10x') => __UNALLOCATED
                        when ('0', '000') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBGT_32_imm
                        when ('0', '001') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBLT_32_imm
                        when ('0', '010') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBHI_32_imm
                        when ('0', '011') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBLO_32_imm
                        when ('0', '110') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBEQ_32_imm
                        when ('0', '111') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBNE_32_imm
                        when ('1', '000') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBGT_64_imm
                        when ('1', '001') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBLT_64_imm
                        when ('1', '010') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBHI_64_imm
                        when ('1', '011') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBLO_64_imm
                        when ('1', '110') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBEQ_64_imm
                        when ('1', '111') => __encoding A64_control_compbranch_imm_CBGT_32_imm // CBNE_64_imm
                when ('x11', _, '01xxxxxxxxx1xx', _, _) => __UNPREDICTABLE
        when (_, _, 'x101', _) =>
            // dpreg
            case (31 +: 1, 30 +: 1, 29 +: 1, 28 +: 1, 25 +: 3, 21 +: 4, 16 +: 5, 10 +: 6, 0 +: 10) of
                when (_, '0', _, '1', _, '0110', _, _, _) => // dp_2src
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field opcode 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, opcode) of
                        when (_, _, '1xxxxx') => __UNALLOCATED
                        when (_, '0', '00011x') => __UNALLOCATED
                        when (_, '1', '00001x') => __UNALLOCATED
                        when (_, '1', '0001xx') => __UNALLOCATED
                        when (_, '1', '001xxx') => __UNALLOCATED
                        when (_, '1', '01xxxx') => __UNALLOCATED
                        when ('0', _, '00000x') => __UNALLOCATED
                        when ('0', '0', '0x11xx') => __UNALLOCATED
                        when ('0', '0', '000010') => __encoding A64_dpreg_dp_2src_UDIV_32_dp_2src // UDIV_32_dp_2src
                        when ('0', '0', '000011') => __encoding A64_dpreg_dp_2src_SDIV_32_dp_2src // SDIV_32_dp_2src
                        when ('0', '0', '00010x') => __UNALLOCATED
                        when ('0', '0', '001000') => __encoding A64_dpreg_dp_2src_LSLV_32_dp_2src // LSLV_32_dp_2src
                        when ('0', '0', '001001') => __encoding A64_dpreg_dp_2src_LSRV_32_dp_2src // LSRV_32_dp_2src
                        when ('0', '0', '001010') => __encoding A64_dpreg_dp_2src_ASRV_32_dp_2src // ASRV_32_dp_2src
                        when ('0', '0', '001011') => __encoding A64_dpreg_dp_2src_RORV_32_dp_2src // RORV_32_dp_2src
                        when ('0', '0', '010x11') => __UNALLOCATED
                        when ('0', '0', '010000') => __encoding A64_dpreg_dp_2src_CRC32B_32C_dp_2src // CRC32B_32C_dp_2src
                        when ('0', '0', '010001') => __encoding A64_dpreg_dp_2src_CRC32B_32C_dp_2src // CRC32H_32C_dp_2src
                        when ('0', '0', '010010') => __encoding A64_dpreg_dp_2src_CRC32B_32C_dp_2src // CRC32W_32C_dp_2src
                        when ('0', '0', '010100') => __encoding A64_dpreg_dp_2src_CRC32CB_32C_dp_2src // CRC32CB_32C_dp_2src
                        when ('0', '0', '010101') => __encoding A64_dpreg_dp_2src_CRC32CB_32C_dp_2src // CRC32CH_32C_dp_2src
                        when ('0', '0', '010110') => __encoding A64_dpreg_dp_2src_CRC32CB_32C_dp_2src // CRC32CW_32C_dp_2src
                        when ('0', '0', '011000') => __encoding A64_dpreg_dp_2src_SMAX_32_dp_2src // SMAX_32_dp_2src
                        when ('0', '0', '011001') => __encoding A64_dpreg_dp_2src_UMAX_32_dp_2src // UMAX_32_dp_2src
                        when ('0', '0', '011010') => __encoding A64_dpreg_dp_2src_SMIN_32_dp_2src // SMIN_32_dp_2src
                        when ('0', '0', '011011') => __encoding A64_dpreg_dp_2src_UMIN_32_dp_2src // UMIN_32_dp_2src
                        when ('1', _, '000001') => __UNALLOCATED
                        when ('1', '0', '000000') => __encoding A64_dpreg_dp_2src_SUBP_64S_dp_2src // SUBP_64S_dp_2src
                        when ('1', '0', '000010') => __encoding A64_dpreg_dp_2src_UDIV_32_dp_2src // UDIV_64_dp_2src
                        when ('1', '0', '000011') => __encoding A64_dpreg_dp_2src_SDIV_32_dp_2src // SDIV_64_dp_2src
                        when ('1', '0', '000100') => __encoding A64_dpreg_dp_2src_IRG_64I_dp_2src // IRG_64I_dp_2src
                        when ('1', '0', '000101') => __encoding A64_dpreg_dp_2src_GMI_64G_dp_2src // GMI_64G_dp_2src
                        when ('1', '0', '001000') => __encoding A64_dpreg_dp_2src_LSLV_32_dp_2src // LSLV_64_dp_2src
                        when ('1', '0', '001001') => __encoding A64_dpreg_dp_2src_LSRV_32_dp_2src // LSRV_64_dp_2src
                        when ('1', '0', '001010') => __encoding A64_dpreg_dp_2src_ASRV_32_dp_2src // ASRV_64_dp_2src
                        when ('1', '0', '001011') => __encoding A64_dpreg_dp_2src_RORV_32_dp_2src // RORV_64_dp_2src
                        when ('1', '0', '001100') => __encoding A64_dpreg_dp_2src_PACGA_64P_dp_2src // PACGA_64P_dp_2src
                        when ('1', '0', '001101') => __UNALLOCATED
                        when ('1', '0', '00111x') => __UNALLOCATED
                        when ('1', '0', '010xx0') => __UNALLOCATED
                        when ('1', '0', '010001') => __UNALLOCATED
                        when ('1', '0', '010011') => __encoding A64_dpreg_dp_2src_CRC32B_32C_dp_2src // CRC32X_64C_dp_2src
                        when ('1', '0', '010101') => __UNALLOCATED
                        when ('1', '0', '010111') => __encoding A64_dpreg_dp_2src_CRC32CB_32C_dp_2src // CRC32CX_64C_dp_2src
                        when ('1', '0', '011000') => __encoding A64_dpreg_dp_2src_SMAX_32_dp_2src // SMAX_64_dp_2src
                        when ('1', '0', '011001') => __encoding A64_dpreg_dp_2src_UMAX_32_dp_2src // UMAX_64_dp_2src
                        when ('1', '0', '011010') => __encoding A64_dpreg_dp_2src_SMIN_32_dp_2src // SMIN_64_dp_2src
                        when ('1', '0', '011011') => __encoding A64_dpreg_dp_2src_UMIN_32_dp_2src // UMIN_64_dp_2src
                        when ('1', '0', '0111xx') => __UNALLOCATED
                        when ('1', '1', '000000') => __encoding A64_dpreg_dp_2src_SUBPS_64S_dp_2src // SUBPS_64S_dp_2src
                when (_, '1', _, '1', _, '0110', _, _, _) => // dp_1src
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field opcode2 16 +: 5
                    __field opcode 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, opcode2, opcode, Rn, Rd) of
                        when (_, '0', '00000', '001001', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '00101x', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '0011xx', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '01xxxx', _, _) => __UNALLOCATED
                        when (_, '0', '00000', '1xxxxx', _, _) => __UNALLOCATED
                        when (_, '0', '0001x', _, _, _) => __UNALLOCATED
                        when (_, '0', '001xx', _, _, _) => __UNALLOCATED
                        when (_, '0', '01xxx', _, _, _) => __UNALLOCATED
                        when (_, '0', '1xxxx', _, _, _) => __UNALLOCATED
                        when (_, '1', _, _, _, _) => __UNALLOCATED
                        when ('0', '0', '00000', '000000', _, _) => __encoding A64_dpreg_dp_1src_RBIT_32_dp_1src // RBIT_32_dp_1src
                        when ('0', '0', '00000', '000001', _, _) => __encoding A64_dpreg_dp_1src_REV16_32_dp_1src // REV16_32_dp_1src
                        when ('0', '0', '00000', '000010', _, _) => __encoding A64_dpreg_dp_1src_REV_32_dp_1src // REV_32_dp_1src
                        when ('0', '0', '00000', '000011', _, _) => __UNALLOCATED
                        when ('0', '0', '00000', '000100', _, _) => __encoding A64_dpreg_dp_1src_CLZ_32_dp_1src // CLZ_32_dp_1src
                        when ('0', '0', '00000', '000101', _, _) => __encoding A64_dpreg_dp_1src_CLS_32_dp_1src // CLS_32_dp_1src
                        when ('0', '0', '00000', '000110', _, _) => __encoding A64_dpreg_dp_1src_CTZ_32_dp_1src // CTZ_32_dp_1src
                        when ('0', '0', '00000', '000111', _, _) => __encoding A64_dpreg_dp_1src_CNT_32_dp_1src // CNT_32_dp_1src
                        when ('0', '0', '00000', '001000', _, _) => __encoding A64_dpreg_dp_1src_ABS_32_dp_1src // ABS_32_dp_1src
                        when ('0', '0', '00001', _, _, _) => __UNALLOCATED
                        when ('1', '0', '00000', '000000', _, _) => __encoding A64_dpreg_dp_1src_RBIT_32_dp_1src // RBIT_64_dp_1src
                        when ('1', '0', '00000', '000001', _, _) => __encoding A64_dpreg_dp_1src_REV16_32_dp_1src // REV16_64_dp_1src
                        when ('1', '0', '00000', '000010', _, _) => __encoding A64_dpreg_dp_1src_REV32_64_dp_1src // REV32_64_dp_1src
                        when ('1', '0', '00000', '000011', _, _) => __encoding A64_dpreg_dp_1src_REV_32_dp_1src // REV_64_dp_1src
                        when ('1', '0', '00000', '000100', _, _) => __encoding A64_dpreg_dp_1src_CLZ_32_dp_1src // CLZ_64_dp_1src
                        when ('1', '0', '00000', '000101', _, _) => __encoding A64_dpreg_dp_1src_CLS_32_dp_1src // CLS_64_dp_1src
                        when ('1', '0', '00000', '000110', _, _) => __encoding A64_dpreg_dp_1src_CTZ_32_dp_1src // CTZ_64_dp_1src
                        when ('1', '0', '00000', '000111', _, _) => __encoding A64_dpreg_dp_1src_CNT_32_dp_1src // CNT_64_dp_1src
                        when ('1', '0', '00000', '001000', _, _) => __encoding A64_dpreg_dp_1src_ABS_32_dp_1src // ABS_64_dp_1src
                        when ('1', '0', '00001', '000000', _, _) => __encoding A64_dpreg_dp_1src_PACIA_64P_dp_1src // PACIA_64P_dp_1src
                        when ('1', '0', '00001', '000001', _, _) => __encoding A64_dpreg_dp_1src_PACIB_64P_dp_1src // PACIB_64P_dp_1src
                        when ('1', '0', '00001', '000010', _, _) => __encoding A64_dpreg_dp_1src_PACDA_64P_dp_1src // PACDA_64P_dp_1src
                        when ('1', '0', '00001', '000011', _, _) => __encoding A64_dpreg_dp_1src_PACDB_64P_dp_1src // PACDB_64P_dp_1src
                        when ('1', '0', '00001', '000100', _, _) => __encoding A64_dpreg_dp_1src_AUTIA_64P_dp_1src // AUTIA_64P_dp_1src
                        when ('1', '0', '00001', '000101', _, _) => __encoding A64_dpreg_dp_1src_AUTIB_64P_dp_1src // AUTIB_64P_dp_1src
                        when ('1', '0', '00001', '000110', _, _) => __encoding A64_dpreg_dp_1src_AUTDA_64P_dp_1src // AUTDA_64P_dp_1src
                        when ('1', '0', '00001', '000111', _, _) => __encoding A64_dpreg_dp_1src_AUTDB_64P_dp_1src // AUTDB_64P_dp_1src
                        when ('1', '0', '00001', '001xxx', !'11111', _) => __UNALLOCATED
                        when ('1', '0', '00001', '001000', '11111', _) => __encoding A64_dpreg_dp_1src_PACIA_64P_dp_1src // PACIZA_64Z_dp_1src
                        when ('1', '0', '00001', '001001', '11111', _) => __encoding A64_dpreg_dp_1src_PACIB_64P_dp_1src // PACIZB_64Z_dp_1src
                        when ('1', '0', '00001', '001010', '11111', _) => __encoding A64_dpreg_dp_1src_PACDA_64P_dp_1src // PACDZA_64Z_dp_1src
                        when ('1', '0', '00001', '001011', '11111', _) => __encoding A64_dpreg_dp_1src_PACDB_64P_dp_1src // PACDZB_64Z_dp_1src
                        when ('1', '0', '00001', '001100', '11111', _) => __encoding A64_dpreg_dp_1src_AUTIA_64P_dp_1src // AUTIZA_64Z_dp_1src
                        when ('1', '0', '00001', '001101', '11111', _) => __encoding A64_dpreg_dp_1src_AUTIB_64P_dp_1src // AUTIZB_64Z_dp_1src
                        when ('1', '0', '00001', '001110', '11111', _) => __encoding A64_dpreg_dp_1src_AUTDA_64P_dp_1src // AUTDZA_64Z_dp_1src
                        when ('1', '0', '00001', '001111', '11111', _) => __encoding A64_dpreg_dp_1src_AUTDB_64P_dp_1src // AUTDZB_64Z_dp_1src
                        when ('1', '0', '00001', '01000x', !'11111', _) => __UNALLOCATED
                        when ('1', '0', '00001', '010000', '11111', _) => __encoding A64_dpreg_dp_1src_XPACD_64Z_dp_1src // XPACI_64Z_dp_1src
                        when ('1', '0', '00001', '010001', '11111', _) => __encoding A64_dpreg_dp_1src_XPACD_64Z_dp_1src // XPACD_64Z_dp_1src
                        when ('1', '0', '00001', '01001x', _, _) => __UNALLOCATED
                        when ('1', '0', '00001', '0101xx', _, _) => __UNALLOCATED
                        when ('1', '0', '00001', '011xxx', _, _) => __UNALLOCATED
                        when ('1', '0', '00001', '10xxxx', _, !'11110') => __UNALLOCATED
                        when ('1', '0', '00001', '1000xx', !'11111', '11110') => __UNALLOCATED
                        when ('1', '0', '00001', '100000', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACNBIASPPC_64LR_dp_1src // PACNBIASPPC_64LR_dp_1src
                        when ('1', '0', '00001', '100001', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACNBIBSPPC_64LR_dp_1src // PACNBIBSPPC_64LR_dp_1src
                        when ('1', '0', '00001', '100010', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACIA171615_64LR_dp_1src // PACIA171615_64LR_dp_1src
                        when ('1', '0', '00001', '100011', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACIB171615_64LR_dp_1src // PACIB171615_64LR_dp_1src
                        when ('1', '0', '00001', '100100', _, '11110') => __encoding A64_dpreg_dp_1src_AUTIASPPCR_64LRR_dp_1src // AUTIASPPCR_64LRR_dp_1src
                        when ('1', '0', '00001', '100101', _, '11110') => __encoding A64_dpreg_dp_1src_AUTIBSPPCR_64LRR_dp_1src // AUTIBSPPCR_64LRR_dp_1src
                        when ('1', '0', '00001', '10011x', _, '11110') => __UNALLOCATED
                        when ('1', '0', '00001', '101xxx', !'11111', '11110') => __UNALLOCATED
                        when ('1', '0', '00001', '101000', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACIASPPC_64LR_dp_1src // PACIASPPC_64LR_dp_1src
                        when ('1', '0', '00001', '101001', '11111', '11110') => __encoding A64_dpreg_dp_1src_PACIBSPPC_64LR_dp_1src // PACIBSPPC_64LR_dp_1src
                        when ('1', '0', '00001', '10101x', '11111', '11110') => __UNALLOCATED
                        when ('1', '0', '00001', '10110x', '11111', '11110') => __UNALLOCATED
                        when ('1', '0', '00001', '101110', '11111', '11110') => __encoding A64_dpreg_dp_1src_AUTIA171615_64LR_dp_1src // AUTIA171615_64LR_dp_1src
                        when ('1', '0', '00001', '101111', '11111', '11110') => __encoding A64_dpreg_dp_1src_AUTIB171615_64LR_dp_1src // AUTIB171615_64LR_dp_1src
                        when ('1', '0', '00001', '11xxxx', _, _) => __UNALLOCATED
                when (_, _, _, '0', _, '0xxx', _, _, _) => // log_shift
                    __field sf 31 +: 1
                    __field opc 29 +: 2
                    __field shift 22 +: 2
                    __field N 21 +: 1
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, opc, N) of
                        when ('0', '00', '0') => __encoding A64_dpreg_log_shift_AND_32_log_shift // AND_32_log_shift
                        when ('0', '00', '1') => __encoding A64_dpreg_log_shift_BIC_32_log_shift // BIC_32_log_shift
                        when ('0', '01', '0') => __encoding A64_dpreg_log_shift_ORR_32_log_shift // ORR_32_log_shift
                        when ('0', '01', '1') => __encoding A64_dpreg_log_shift_ORN_32_log_shift // ORN_32_log_shift
                        when ('0', '10', '0') => __encoding A64_dpreg_log_shift_EOR_32_log_shift // EOR_32_log_shift
                        when ('0', '10', '1') => __encoding A64_dpreg_log_shift_EON_32_log_shift // EON_32_log_shift
                        when ('0', '11', '0') => __encoding A64_dpreg_log_shift_ANDS_32_log_shift // ANDS_32_log_shift
                        when ('0', '11', '1') => __encoding A64_dpreg_log_shift_BICS_32_log_shift // BICS_32_log_shift
                        when ('1', '00', '0') => __encoding A64_dpreg_log_shift_AND_32_log_shift // AND_64_log_shift
                        when ('1', '00', '1') => __encoding A64_dpreg_log_shift_BIC_32_log_shift // BIC_64_log_shift
                        when ('1', '01', '0') => __encoding A64_dpreg_log_shift_ORR_32_log_shift // ORR_64_log_shift
                        when ('1', '01', '1') => __encoding A64_dpreg_log_shift_ORN_32_log_shift // ORN_64_log_shift
                        when ('1', '10', '0') => __encoding A64_dpreg_log_shift_EOR_32_log_shift // EOR_64_log_shift
                        when ('1', '10', '1') => __encoding A64_dpreg_log_shift_EON_32_log_shift // EON_64_log_shift
                        when ('1', '11', '0') => __encoding A64_dpreg_log_shift_ANDS_32_log_shift // ANDS_64_log_shift
                        when ('1', '11', '1') => __encoding A64_dpreg_log_shift_BICS_32_log_shift // BICS_64_log_shift
                when (_, _, _, '0', _, '1xx0', _, _, _) => // addsub_shift
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field shift 22 +: 2
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', '0', '0') => __encoding A64_dpreg_addsub_shift_ADD_32_addsub_shift // ADD_32_addsub_shift
                        when ('0', '0', '1') => __encoding A64_dpreg_addsub_shift_ADDS_32_addsub_shift // ADDS_32_addsub_shift
                        when ('0', '1', '0') => __encoding A64_dpreg_addsub_shift_SUB_32_addsub_shift // SUB_32_addsub_shift
                        when ('0', '1', '1') => __encoding A64_dpreg_addsub_shift_SUBS_32_addsub_shift // SUBS_32_addsub_shift
                        when ('1', '0', '0') => __encoding A64_dpreg_addsub_shift_ADD_32_addsub_shift // ADD_64_addsub_shift
                        when ('1', '0', '1') => __encoding A64_dpreg_addsub_shift_ADDS_32_addsub_shift // ADDS_64_addsub_shift
                        when ('1', '1', '0') => __encoding A64_dpreg_addsub_shift_SUB_32_addsub_shift // SUB_64_addsub_shift
                        when ('1', '1', '1') => __encoding A64_dpreg_addsub_shift_SUBS_32_addsub_shift // SUBS_64_addsub_shift
                when (_, _, _, '0', _, '1xx1', _, _, _) => // addsub_ext
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opt 22 +: 2
                    __field Rm 16 +: 5
                    __field option 13 +: 3
                    __field imm3 10 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, opt) of
                        when (_, _, _, !'00') => __UNALLOCATED
                        when ('0', '0', '0', '00') => __encoding A64_dpreg_addsub_ext_ADD_32_addsub_ext // ADD_32_addsub_ext
                        when ('0', '0', '1', '00') => __encoding A64_dpreg_addsub_ext_ADDS_32S_addsub_ext // ADDS_32S_addsub_ext
                        when ('0', '1', '0', '00') => __encoding A64_dpreg_addsub_ext_SUB_32_addsub_ext // SUB_32_addsub_ext
                        when ('0', '1', '1', '00') => __encoding A64_dpreg_addsub_ext_SUBS_32S_addsub_ext // SUBS_32S_addsub_ext
                        when ('1', '0', '0', '00') => __encoding A64_dpreg_addsub_ext_ADD_32_addsub_ext // ADD_64_addsub_ext
                        when ('1', '0', '1', '00') => __encoding A64_dpreg_addsub_ext_ADDS_32S_addsub_ext // ADDS_64S_addsub_ext
                        when ('1', '1', '0', '00') => __encoding A64_dpreg_addsub_ext_SUB_32_addsub_ext // SUB_64_addsub_ext
                        when ('1', '1', '1', '00') => __encoding A64_dpreg_addsub_ext_SUBS_32S_addsub_ext // SUBS_64S_addsub_ext
                when (_, _, _, '1', _, '0000', _, '000000', _) => // addsub_carry
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', '0', '0') => __encoding A64_dpreg_addsub_carry_ADC_32_addsub_carry // ADC_32_addsub_carry
                        when ('0', '0', '1') => __encoding A64_dpreg_addsub_carry_ADCS_32_addsub_carry // ADCS_32_addsub_carry
                        when ('0', '1', '0') => __encoding A64_dpreg_addsub_carry_SBC_32_addsub_carry // SBC_32_addsub_carry
                        when ('0', '1', '1') => __encoding A64_dpreg_addsub_carry_SBCS_32_addsub_carry // SBCS_32_addsub_carry
                        when ('1', '0', '0') => __encoding A64_dpreg_addsub_carry_ADC_32_addsub_carry // ADC_64_addsub_carry
                        when ('1', '0', '1') => __encoding A64_dpreg_addsub_carry_ADCS_32_addsub_carry // ADCS_64_addsub_carry
                        when ('1', '1', '0') => __encoding A64_dpreg_addsub_carry_SBC_32_addsub_carry // SBC_64_addsub_carry
                        when ('1', '1', '1') => __encoding A64_dpreg_addsub_carry_SBCS_32_addsub_carry // SBCS_64_addsub_carry
                when (_, _, _, '1', _, '0000', _, '001xxx', _) => // addsub_pt
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field imm3 10 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S) of
                        when ('0', _, _) => __UNALLOCATED
                        when ('1', _, '1') => __UNALLOCATED
                        when ('1', '0', '0') => __encoding A64_dpreg_addsub_pt_ADDPT_64_addsub_pt // ADDPT_64_addsub_pt
                        when ('1', '1', '0') => __encoding A64_dpreg_addsub_pt_SUBPT_64_addsub_pt // SUBPT_64_addsub_pt
                when (_, _, _, '1', _, '0000', _, '011xxx', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, '100000', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, '1x1xxx', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, 'x00001', _) => // rmif
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field imm6 15 +: 6
                    __field Rn 5 +: 5
                    __field o2 4 +: 1
                    __field mask 0 +: 4
                    case (sf, op, S, o2) of
                        when ('0', _, _, _) => __UNALLOCATED
                        when ('1', '0', '0', _) => __UNALLOCATED
                        when ('1', '0', '1', '0') => __encoding A64_dpreg_rmif_RMIF_only_rmif // RMIF_only_rmif
                        when ('1', '0', '1', '1') => __UNALLOCATED
                        when ('1', '1', _, _) => __UNALLOCATED
                when (_, _, _, '1', _, '0000', _, 'x0010x', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, 'x10x0x', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, 'xx0010', _) => // setf
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field opcode2 15 +: 6
                    __field sz 14 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field mask 0 +: 4
                    case (sf, op, S, opcode2, sz, o3, mask) of
                        when ('0', '0', '0', _, _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', !'000000', _, _, _) => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '0', !'1101') => __UNALLOCATED
                        when ('0', '0', '1', '000000', _, '1', _) => __UNALLOCATED
                        when ('0', '0', '1', '000000', '0', '0', '1101') => __encoding A64_dpreg_setf_SETF8_only_setf // SETF8_only_setf
                        when ('0', '0', '1', '000000', '1', '0', '1101') => __encoding A64_dpreg_setf_SETF8_only_setf // SETF16_only_setf
                        when ('0', '1', _, _, _, _, _) => __UNALLOCATED
                        when ('1', _, _, _, _, _, _) => __UNALLOCATED
                when (_, _, _, '1', _, '0000', _, 'xx0011', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0000', _, 'xx011x', _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '0010', _, 'xxxx0x', _) => // condcmp_reg
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field o2 10 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field nzcv 0 +: 4
                    case (sf, op, S, o2, o3) of
                        when (_, _, '0', _, _) => __UNALLOCATED
                        when (_, _, '1', '0', '1') => __UNALLOCATED
                        when (_, _, '1', '1', _) => __UNALLOCATED
                        when ('0', '0', '1', '0', '0') => __encoding A64_dpreg_condcmp_reg_CCMN_32_condcmp_reg // CCMN_32_condcmp_reg
                        when ('0', '1', '1', '0', '0') => __encoding A64_dpreg_condcmp_reg_CCMP_32_condcmp_reg // CCMP_32_condcmp_reg
                        when ('1', '0', '1', '0', '0') => __encoding A64_dpreg_condcmp_reg_CCMN_32_condcmp_reg // CCMN_64_condcmp_reg
                        when ('1', '1', '1', '0', '0') => __encoding A64_dpreg_condcmp_reg_CCMP_32_condcmp_reg // CCMP_64_condcmp_reg
                when (_, _, _, '1', _, '0010', _, 'xxxx1x', _) => // condcmp_imm
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field imm5 16 +: 5
                    __field cond 12 +: 4
                    __field o2 10 +: 1
                    __field Rn 5 +: 5
                    __field o3 4 +: 1
                    __field nzcv 0 +: 4
                    case (sf, op, S, o2, o3) of
                        when (_, _, '0', _, _) => __UNALLOCATED
                        when (_, _, '1', '0', '1') => __UNALLOCATED
                        when (_, _, '1', '1', _) => __UNALLOCATED
                        when ('0', '0', '1', '0', '0') => __encoding A64_dpreg_condcmp_imm_CCMN_32_condcmp_imm // CCMN_32_condcmp_imm
                        when ('0', '1', '1', '0', '0') => __encoding A64_dpreg_condcmp_imm_CCMP_32_condcmp_imm // CCMP_32_condcmp_imm
                        when ('1', '0', '1', '0', '0') => __encoding A64_dpreg_condcmp_imm_CCMN_32_condcmp_imm // CCMN_64_condcmp_imm
                        when ('1', '1', '1', '0', '0') => __encoding A64_dpreg_condcmp_imm_CCMP_32_condcmp_imm // CCMP_64_condcmp_imm
                when (_, _, _, '1', _, '0100', _, _, _) => // condsel
                    __field sf 31 +: 1
                    __field op 30 +: 1
                    __field S 29 +: 1
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field op2 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op, S, op2) of
                        when (_, _, '0', '1x') => __UNALLOCATED
                        when (_, _, '1', _) => __UNALLOCATED
                        when ('0', '0', '0', '00') => __encoding A64_dpreg_condsel_CSEL_32_condsel // CSEL_32_condsel
                        when ('0', '0', '0', '01') => __encoding A64_dpreg_condsel_CSINC_32_condsel // CSINC_32_condsel
                        when ('0', '1', '0', '00') => __encoding A64_dpreg_condsel_CSINV_32_condsel // CSINV_32_condsel
                        when ('0', '1', '0', '01') => __encoding A64_dpreg_condsel_CSNEG_32_condsel // CSNEG_32_condsel
                        when ('1', '0', '0', '00') => __encoding A64_dpreg_condsel_CSEL_32_condsel // CSEL_64_condsel
                        when ('1', '0', '0', '01') => __encoding A64_dpreg_condsel_CSINC_32_condsel // CSINC_64_condsel
                        when ('1', '1', '0', '00') => __encoding A64_dpreg_condsel_CSINV_32_condsel // CSINV_64_condsel
                        when ('1', '1', '0', '01') => __encoding A64_dpreg_condsel_CSNEG_32_condsel // CSNEG_64_condsel
                when (_, _, _, '1', _, '0xx1', _, _, _) => __UNPREDICTABLE
                when (_, _, _, '1', _, '1xxx', _, _, _) => // dp_3src
                    __field sf 31 +: 1
                    __field op54 29 +: 2
                    __field op31 21 +: 3
                    __field Rm 16 +: 5
                    __field o0 15 +: 1
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, op54, op31, o0) of
                        when (_, !'00', _, _) => __UNALLOCATED
                        when (_, '00', '100', _) => __UNALLOCATED
                        when ('0', '00', 'x01', _) => __UNALLOCATED
                        when ('0', '00', 'x1x', _) => __UNALLOCATED
                        when ('0', '00', '000', '0') => __encoding A64_dpreg_dp_3src_MADD_32A_dp_3src // MADD_32A_dp_3src
                        when ('0', '00', '000', '1') => __encoding A64_dpreg_dp_3src_MSUB_32A_dp_3src // MSUB_32A_dp_3src
                        when ('1', '00', 'x10', '1') => __UNALLOCATED
                        when ('1', '00', '000', '0') => __encoding A64_dpreg_dp_3src_MADD_32A_dp_3src // MADD_64A_dp_3src
                        when ('1', '00', '000', '1') => __encoding A64_dpreg_dp_3src_MSUB_32A_dp_3src // MSUB_64A_dp_3src
                        when ('1', '00', '001', '0') => __encoding A64_dpreg_dp_3src_SMADDL_64WA_dp_3src // SMADDL_64WA_dp_3src
                        when ('1', '00', '001', '1') => __encoding A64_dpreg_dp_3src_SMSUBL_64WA_dp_3src // SMSUBL_64WA_dp_3src
                        when ('1', '00', '010', '0') => __encoding A64_dpreg_dp_3src_SMULH_64_dp_3src // SMULH_64_dp_3src
                        when ('1', '00', '011', '0') => __encoding A64_dpreg_dp_3src_MADDPT_64A_dp_3src // MADDPT_64A_dp_3src
                        when ('1', '00', '011', '1') => __encoding A64_dpreg_dp_3src_MSUBPT_64A_dp_3src // MSUBPT_64A_dp_3src
                        when ('1', '00', '101', '0') => __encoding A64_dpreg_dp_3src_UMADDL_64WA_dp_3src // UMADDL_64WA_dp_3src
                        when ('1', '00', '101', '1') => __encoding A64_dpreg_dp_3src_UMSUBL_64WA_dp_3src // UMSUBL_64WA_dp_3src
                        when ('1', '00', '110', '0') => __encoding A64_dpreg_dp_3src_UMULH_64_dp_3src // UMULH_64_dp_3src
                        when ('1', '00', '111', _) => __UNALLOCATED
        when (_, _, 'x111', _) =>
            // simd_dp
            case (28 +: 4, 25 +: 3, 23 +: 2, 19 +: 4, 10 +: 9, 0 +: 10) of
                when ('00x0', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('00x0', _, '11', _, 'xxxxxxxx1', _) => __UNPREDICTABLE
                when ('0100', _, '0x', 'x101', '00xxxxx10', _) => // cryptoaes
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when (!'00', _) => __UNALLOCATED
                        when ('00', '000xx') => __UNALLOCATED
                        when ('00', '00100') => __encoding A64_simd_dp_cryptoaes_AESE_B_cryptoaes // AESE_B_cryptoaes
                        when ('00', '00101') => __encoding A64_simd_dp_cryptoaes_AESD_B_cryptoaes // AESD_B_cryptoaes
                        when ('00', '00110') => __encoding A64_simd_dp_cryptoaes_AESMC_B_cryptoaes // AESMC_B_cryptoaes
                        when ('00', '00111') => __encoding A64_simd_dp_cryptoaes_AESIMC_B_cryptoaes // AESIMC_B_cryptoaes
                        when ('00', '01xxx') => __UNALLOCATED
                        when ('00', '1xxxx') => __UNALLOCATED
                when ('0101', _, '0x', 'x0xx', 'xxx0xxx00', _) => // cryptosha3
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when (!'00', _) => __UNALLOCATED
                        when ('00', '000') => __encoding A64_simd_dp_cryptosha3_SHA1C_QSV_cryptosha3 // SHA1C_QSV_cryptosha3
                        when ('00', '001') => __encoding A64_simd_dp_cryptosha3_SHA1P_QSV_cryptosha3 // SHA1P_QSV_cryptosha3
                        when ('00', '010') => __encoding A64_simd_dp_cryptosha3_SHA1M_QSV_cryptosha3 // SHA1M_QSV_cryptosha3
                        when ('00', '011') => __encoding A64_simd_dp_cryptosha3_SHA1SU0_VVV_cryptosha3 // SHA1SU0_VVV_cryptosha3
                        when ('00', '100') => __encoding A64_simd_dp_cryptosha3_SHA256H_QQV_cryptosha3 // SHA256H_QQV_cryptosha3
                        when ('00', '101') => __encoding A64_simd_dp_cryptosha3_SHA256H2_QQV_cryptosha3 // SHA256H2_QQV_cryptosha3
                        when ('00', '110') => __encoding A64_simd_dp_cryptosha3_SHA256SU1_VVV_cryptosha3 // SHA256SU1_VVV_cryptosha3
                        when ('00', '111') => __UNALLOCATED
                when ('0101', _, '0x', 'x0xx', 'xxx0xxx10', _) => __UNPREDICTABLE
                when ('0101', _, '0x', 'x0xx', 'xxx1xxxx0', _) => __UNPREDICTABLE
                when ('0101', _, '0x', 'x101', '00xxxxx10', _) => // cryptosha2
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (size, opcode) of
                        when (!'00', _) => __UNALLOCATED
                        when ('00', '00000') => __encoding A64_simd_dp_cryptosha2_SHA1H_SS_cryptosha2 // SHA1H_SS_cryptosha2
                        when ('00', '00001') => __encoding A64_simd_dp_cryptosha2_SHA1SU1_VV_cryptosha2 // SHA1SU1_VV_cryptosha2
                        when ('00', '00010') => __encoding A64_simd_dp_cryptosha2_SHA256SU0_VV_cryptosha2 // SHA256SU0_VV_cryptosha2
                        when ('00', '00011') => __UNALLOCATED
                        when ('00', '001xx') => __UNALLOCATED
                        when ('00', '01xxx') => __UNALLOCATED
                        when ('00', '1xxxx') => __UNALLOCATED
                when ('0111', _, '0x', 'x0xx', 'xxxxxxxx0', _) => __UNPREDICTABLE
                when ('011x', _, '0x', 'x101', '00xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '00', '00xx', 'xxx0xxxx1', _) => // asisdone
                    __field op 29 +: 1
                    __field imm5 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (op, imm4) of
                        when ('0', !'0000') => __UNALLOCATED
                        when ('0', '0000') => __encoding A64_simd_dp_asisdone_DUP_asisdone_only // DUP_asisdone_only
                        when ('1', _) => __UNALLOCATED
                when ('01x1', _, '01', '00xx', 'xxx0xxxx1', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '0111', '00xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '10xx', 'xxx00xxx1', _) => // asisdsamefp16
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field Rm 16 +: 5
                    __field opcode 11 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, '00x') => __UNALLOCATED
                        when (_, '0', '010') => __UNALLOCATED
                        when ('0', _, '101') => __UNALLOCATED
                        when ('0', '0', '011') => __encoding A64_simd_dp_asisdsamefp16_FMULX_asisdsamefp16_only // FMULX_asisdsamefp16_only
                        when ('0', '0', '100') => __encoding A64_simd_dp_asisdsamefp16_FCMEQ_asisdsamefp16_only // FCMEQ_asisdsamefp16_only
                        when ('0', '0', '110') => __UNALLOCATED
                        when ('0', '0', '111') => __encoding A64_simd_dp_asisdsamefp16_FRECPS_asisdsamefp16_only // FRECPS_asisdsamefp16_only
                        when ('0', '1', 'x10') => __UNALLOCATED
                        when ('0', '1', '011') => __UNALLOCATED
                        when ('0', '1', '100') => __UNALLOCATED
                        when ('0', '1', '111') => __encoding A64_simd_dp_asisdsamefp16_FRSQRTS_asisdsamefp16_only // FRSQRTS_asisdsamefp16_only
                        when ('1', _, '011') => __UNALLOCATED
                        when ('1', _, '11x') => __UNALLOCATED
                        when ('1', '0', '100') => __encoding A64_simd_dp_asisdsamefp16_FCMGE_asisdsamefp16_only // FCMGE_asisdsamefp16_only
                        when ('1', '0', '101') => __encoding A64_simd_dp_asisdsamefp16_FACGE_asisdsamefp16_only // FACGE_asisdsamefp16_only
                        when ('1', '1', '010') => __encoding A64_simd_dp_asisdsamefp16_FABD_asisdsamefp16_only // FABD_asisdsamefp16_only
                        when ('1', '1', '100') => __encoding A64_simd_dp_asisdsamefp16_FCMGT_asisdsamefp16_only // FCMGT_asisdsamefp16_only
                        when ('1', '1', '101') => __encoding A64_simd_dp_asisdsamefp16_FACGT_asisdsamefp16_only // FACGT_asisdsamefp16_only
                when ('01x1', _, '0x', '10xx', 'xxx01xxx1', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', '1111', '00xxxxx10', _) => // asisdmiscfp16
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, 'x0xxx') => __UNALLOCATED
                        when (_, _, '1100x') => __UNALLOCATED
                        when (_, '0', '01xxx') => __UNALLOCATED
                        when (_, '1', '010xx') => __UNALLOCATED
                        when (_, '1', '11100') => __UNALLOCATED
                        when ('0', '0', '11010') => __encoding A64_simd_dp_asisdmiscfp16_FCVTNS_asisdmiscfp16_R // FCVTNS_asisdmiscfp16_R
                        when ('0', '0', '11011') => __encoding A64_simd_dp_asisdmiscfp16_FCVTMS_asisdmiscfp16_R // FCVTMS_asisdmiscfp16_R
                        when ('0', '0', '11100') => __encoding A64_simd_dp_asisdmiscfp16_FCVTAS_asisdmiscfp16_R // FCVTAS_asisdmiscfp16_R
                        when ('0', '0', '11101') => __encoding A64_simd_dp_asisdmiscfp16_SCVTF_asisdmiscfp16_R // SCVTF_asisdmiscfp16_R
                        when ('0', '0', '1111x') => __UNALLOCATED
                        when ('0', '1', '01100') => __encoding A64_simd_dp_asisdmiscfp16_FCMGT_asisdmiscfp16_FZ // FCMGT_asisdmiscfp16_FZ
                        when ('0', '1', '01101') => __encoding A64_simd_dp_asisdmiscfp16_FCMEQ_asisdmiscfp16_FZ // FCMEQ_asisdmiscfp16_FZ
                        when ('0', '1', '01110') => __encoding A64_simd_dp_asisdmiscfp16_FCMLT_asisdmiscfp16_FZ // FCMLT_asisdmiscfp16_FZ
                        when ('0', '1', '01111') => __UNALLOCATED
                        when ('0', '1', '11010') => __encoding A64_simd_dp_asisdmiscfp16_FCVTPS_asisdmiscfp16_R // FCVTPS_asisdmiscfp16_R
                        when ('0', '1', '11011') => __encoding A64_simd_dp_asisdmiscfp16_FCVTZS_asisdmiscfp16_R // FCVTZS_asisdmiscfp16_R
                        when ('0', '1', '11101') => __encoding A64_simd_dp_asisdmiscfp16_FRECPE_asisdmiscfp16_R // FRECPE_asisdmiscfp16_R
                        when ('0', '1', '11110') => __UNALLOCATED
                        when ('0', '1', '11111') => __encoding A64_simd_dp_asisdmiscfp16_FRECPX_asisdmiscfp16_R // FRECPX_asisdmiscfp16_R
                        when ('1', _, '1111x') => __UNALLOCATED
                        when ('1', '0', '11010') => __encoding A64_simd_dp_asisdmiscfp16_FCVTNU_asisdmiscfp16_R // FCVTNU_asisdmiscfp16_R
                        when ('1', '0', '11011') => __encoding A64_simd_dp_asisdmiscfp16_FCVTMU_asisdmiscfp16_R // FCVTMU_asisdmiscfp16_R
                        when ('1', '0', '11100') => __encoding A64_simd_dp_asisdmiscfp16_FCVTAU_asisdmiscfp16_R // FCVTAU_asisdmiscfp16_R
                        when ('1', '0', '11101') => __encoding A64_simd_dp_asisdmiscfp16_UCVTF_asisdmiscfp16_R // UCVTF_asisdmiscfp16_R
                        when ('1', '1', '01100') => __encoding A64_simd_dp_asisdmiscfp16_FCMGE_asisdmiscfp16_FZ // FCMGE_asisdmiscfp16_FZ
                        when ('1', '1', '01101') => __encoding A64_simd_dp_asisdmiscfp16_FCMLE_asisdmiscfp16_FZ // FCMLE_asisdmiscfp16_FZ
                        when ('1', '1', '0111x') => __UNALLOCATED
                        when ('1', '1', '11010') => __encoding A64_simd_dp_asisdmiscfp16_FCVTPU_asisdmiscfp16_R // FCVTPU_asisdmiscfp16_R
                        when ('1', '1', '11011') => __encoding A64_simd_dp_asisdmiscfp16_FCVTZU_asisdmiscfp16_R // FCVTZU_asisdmiscfp16_R
                        when ('1', '1', '11101') => __encoding A64_simd_dp_asisdmiscfp16_FRSQRTE_asisdmiscfp16_R // FRSQRTE_asisdmiscfp16_R
                when ('01x1', _, '0x', 'x0xx', 'xxx1xxxx1', _) => // asisdsame2
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when ('0', _) => __UNALLOCATED
                        when ('1', '0000') => __encoding A64_simd_dp_asisdsame2_SQRDMLAH_asisdsame2_only // SQRDMLAH_asisdsame2_only
                        when ('1', '0001') => __encoding A64_simd_dp_asisdsame2_SQRDMLSH_asisdsame2_only // SQRDMLSH_asisdsame2_only
                        when ('1', '001x') => __UNALLOCATED
                        when ('1', '01xx') => __UNALLOCATED
                        when ('1', '1xxx') => __UNALLOCATED
                when ('01x1', _, '0x', 'x100', '00xxxxx10', _) => // asisdmisc
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '00x0x') => __UNALLOCATED
                        when (_, _, '1x000') => __UNALLOCATED
                        when (_, _, '10xx1') => __UNALLOCATED
                        when (_, _, '11001') => __UNALLOCATED
                        when (_, '0x', '01xxx') => __UNALLOCATED
                        when (_, '0x', '1111x') => __UNALLOCATED
                        when (_, '1x', '01111') => __UNALLOCATED
                        when (_, '1x', '11100') => __UNALLOCATED
                        when (_, '10', '010x1') => __UNALLOCATED
                        when (_, '10', '01000') => __UNALLOCATED
                        when ('0', _, 'x0x10') => __UNALLOCATED
                        when ('0', _, '00011') => __encoding A64_simd_dp_asisdmisc_SUQADD_asisdmisc_R // SUQADD_asisdmisc_R
                        when ('0', _, '00111') => __encoding A64_simd_dp_asisdmisc_SQABS_asisdmisc_R // SQABS_asisdmisc_R
                        when ('0', _, '10100') => __encoding A64_simd_dp_asisdmisc_SQXTN_asisdmisc_N // SQXTN_asisdmisc_N
                        when ('0', '0x', '11010') => __encoding A64_simd_dp_asisdmisc_FCVTNS_asisdmisc_R // FCVTNS_asisdmisc_R
                        when ('0', '0x', '11011') => __encoding A64_simd_dp_asisdmisc_FCVTMS_asisdmisc_R // FCVTMS_asisdmisc_R
                        when ('0', '0x', '11100') => __encoding A64_simd_dp_asisdmisc_FCVTAS_asisdmisc_R // FCVTAS_asisdmisc_R
                        when ('0', '0x', '11101') => __encoding A64_simd_dp_asisdmisc_SCVTF_asisdmisc_R // SCVTF_asisdmisc_R
                        when ('0', '1x', '01100') => __encoding A64_simd_dp_asisdmisc_FCMGT_asisdmisc_FZ // FCMGT_asisdmisc_FZ
                        when ('0', '1x', '01101') => __encoding A64_simd_dp_asisdmisc_FCMEQ_asisdmisc_FZ // FCMEQ_asisdmisc_FZ
                        when ('0', '1x', '01110') => __encoding A64_simd_dp_asisdmisc_FCMLT_asisdmisc_FZ // FCMLT_asisdmisc_FZ
                        when ('0', '1x', '11010') => __encoding A64_simd_dp_asisdmisc_FCVTPS_asisdmisc_R // FCVTPS_asisdmisc_R
                        when ('0', '1x', '11011') => __encoding A64_simd_dp_asisdmisc_FCVTZS_asisdmisc_R // FCVTZS_asisdmisc_R
                        when ('0', '1x', '11101') => __encoding A64_simd_dp_asisdmisc_FRECPE_asisdmisc_R // FRECPE_asisdmisc_R
                        when ('0', '1x', '11110') => __UNALLOCATED
                        when ('0', '1x', '11111') => __encoding A64_simd_dp_asisdmisc_FRECPX_asisdmisc_R // FRECPX_asisdmisc_R
                        when ('0', '10', '01010') => __UNALLOCATED
                        when ('0', '11', '01000') => __encoding A64_simd_dp_asisdmisc_CMGT_asisdmisc_Z // CMGT_asisdmisc_Z
                        when ('0', '11', '01001') => __encoding A64_simd_dp_asisdmisc_CMEQ_asisdmisc_Z // CMEQ_asisdmisc_Z
                        when ('0', '11', '01010') => __encoding A64_simd_dp_asisdmisc_CMLT_asisdmisc_Z // CMLT_asisdmisc_Z
                        when ('0', '11', '01011') => __encoding A64_simd_dp_asisdmisc_ABS_asisdmisc_R // ABS_asisdmisc_R
                        when ('1', _, '00x10') => __UNALLOCATED
                        when ('1', _, '00011') => __encoding A64_simd_dp_asisdmisc_USQADD_asisdmisc_R // USQADD_asisdmisc_R
                        when ('1', _, '00111') => __encoding A64_simd_dp_asisdmisc_SQNEG_asisdmisc_R // SQNEG_asisdmisc_R
                        when ('1', _, '10010') => __encoding A64_simd_dp_asisdmisc_SQXTUN_asisdmisc_N // SQXTUN_asisdmisc_N
                        when ('1', _, '10100') => __encoding A64_simd_dp_asisdmisc_UQXTN_asisdmisc_N // UQXTN_asisdmisc_N
                        when ('1', '0x', '11010') => __encoding A64_simd_dp_asisdmisc_FCVTNU_asisdmisc_R // FCVTNU_asisdmisc_R
                        when ('1', '0x', '11011') => __encoding A64_simd_dp_asisdmisc_FCVTMU_asisdmisc_R // FCVTMU_asisdmisc_R
                        when ('1', '0x', '11100') => __encoding A64_simd_dp_asisdmisc_FCVTAU_asisdmisc_R // FCVTAU_asisdmisc_R
                        when ('1', '0x', '11101') => __encoding A64_simd_dp_asisdmisc_UCVTF_asisdmisc_R // UCVTF_asisdmisc_R
                        when ('1', '00', '10110') => __UNALLOCATED
                        when ('1', '01', '10110') => __encoding A64_simd_dp_asisdmisc_FCVTXN_asisdmisc_N // FCVTXN_asisdmisc_N
                        when ('1', '1x', '01x10') => __UNALLOCATED
                        when ('1', '1x', '01100') => __encoding A64_simd_dp_asisdmisc_FCMGE_asisdmisc_FZ // FCMGE_asisdmisc_FZ
                        when ('1', '1x', '01101') => __encoding A64_simd_dp_asisdmisc_FCMLE_asisdmisc_FZ // FCMLE_asisdmisc_FZ
                        when ('1', '1x', '1x110') => __UNALLOCATED
                        when ('1', '1x', '11010') => __encoding A64_simd_dp_asisdmisc_FCVTPU_asisdmisc_R // FCVTPU_asisdmisc_R
                        when ('1', '1x', '11011') => __encoding A64_simd_dp_asisdmisc_FCVTZU_asisdmisc_R // FCVTZU_asisdmisc_R
                        when ('1', '1x', '11101') => __encoding A64_simd_dp_asisdmisc_FRSQRTE_asisdmisc_R // FRSQRTE_asisdmisc_R
                        when ('1', '1x', '11111') => __UNALLOCATED
                        when ('1', '11', '01000') => __encoding A64_simd_dp_asisdmisc_CMGE_asisdmisc_Z // CMGE_asisdmisc_Z
                        when ('1', '11', '01001') => __encoding A64_simd_dp_asisdmisc_CMLE_asisdmisc_Z // CMLE_asisdmisc_Z
                        when ('1', '11', '01011') => __encoding A64_simd_dp_asisdmisc_NEG_asisdmisc_R // NEG_asisdmisc_R
                when ('01x1', _, '0x', 'x110', '00xxxxx10', _) => // asisdpair
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, 'x0xxx') => __UNALLOCATED
                        when (_, _, '01110') => __UNALLOCATED
                        when (_, _, '111xx') => __UNALLOCATED
                        when (_, '10', '01101') => __UNALLOCATED
                        when ('0', !'11', 'x10xx') => __UNALLOCATED
                        when ('0', 'x1', '011x1') => __UNALLOCATED
                        when ('0', 'x1', '01100') => __UNALLOCATED
                        when ('0', '00', '01100') => __encoding A64_simd_dp_asisdpair_FMAXNMP_asisdpair_only_H // FMAXNMP_asisdpair_only_H
                        when ('0', '00', '01101') => __encoding A64_simd_dp_asisdpair_FADDP_asisdpair_only_H // FADDP_asisdpair_only_H
                        when ('0', '00', '01111') => __encoding A64_simd_dp_asisdpair_FMAXP_asisdpair_only_H // FMAXP_asisdpair_only_H
                        when ('0', '10', '01100') => __encoding A64_simd_dp_asisdpair_FMINNMP_asisdpair_only_H // FMINNMP_asisdpair_only_H
                        when ('0', '10', '01111') => __encoding A64_simd_dp_asisdpair_FMINP_asisdpair_only_H // FMINP_asisdpair_only_H
                        when ('0', '11', 'x100x') => __UNALLOCATED
                        when ('0', '11', 'x1010') => __UNALLOCATED
                        when ('0', '11', '01011') => __UNALLOCATED
                        when ('0', '11', '11011') => __encoding A64_simd_dp_asisdpair_ADDP_asisdpair_only // ADDP_asisdpair_only
                        when ('1', _, 'x10xx') => __UNALLOCATED
                        when ('1', '0x', '01100') => __encoding A64_simd_dp_asisdpair_FMAXNMP_asisdpair_only_SD // FMAXNMP_asisdpair_only_SD
                        when ('1', '0x', '01101') => __encoding A64_simd_dp_asisdpair_FADDP_asisdpair_only_SD // FADDP_asisdpair_only_SD
                        when ('1', '0x', '01111') => __encoding A64_simd_dp_asisdpair_FMAXP_asisdpair_only_SD // FMAXP_asisdpair_only_SD
                        when ('1', '1x', '01100') => __encoding A64_simd_dp_asisdpair_FMINNMP_asisdpair_only_SD // FMINNMP_asisdpair_only_SD
                        when ('1', '1x', '01111') => __encoding A64_simd_dp_asisdpair_FMINP_asisdpair_only_SD // FMINP_asisdpair_only_SD
                        when ('1', '11', '01101') => __UNALLOCATED
                when ('01x1', _, '0x', 'x1xx', '01xxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', 'x1xx', '1xxxxxx10', _) => __UNPREDICTABLE
                when ('01x1', _, '0x', 'x1xx', 'xxxxxxx00', _) => // asisddiff
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when ('0', '0xxx') => __UNALLOCATED
                        when ('0', '1xx0') => __UNALLOCATED
                        when ('0', '1001') => __encoding A64_simd_dp_asisddiff_SQDMLAL_asisddiff_only // SQDMLAL_asisddiff_only
                        when ('0', '1011') => __encoding A64_simd_dp_asisddiff_SQDMLSL_asisddiff_only // SQDMLSL_asisddiff_only
                        when ('0', '1101') => __encoding A64_simd_dp_asisddiff_SQDMULL_asisddiff_only // SQDMULL_asisddiff_only
                        when ('0', '1111') => __UNALLOCATED
                        when ('1', _) => __UNALLOCATED
                when ('01x1', _, '0x', 'x1xx', 'xxxxxxxx1', _) => // asisdsame
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, 'x0011') => __UNALLOCATED
                        when (_, !'11', '00111') => __UNALLOCATED
                        when (_, _, '011x1') => __UNALLOCATED
                        when (_, !'10', '10100') => __UNALLOCATED
                        when (_, _, '11001') => __UNALLOCATED
                        when (_, _, '11110') => __UNALLOCATED
                        when (_, 'x0', '0x1x0') => __UNALLOCATED
                        when (_, 'x1', '00100') => __UNALLOCATED
                        when (_, 'x1', '011x0') => __UNALLOCATED
                        when (_, '0x', 'xx0x0') => __UNALLOCATED
                        when (_, '0x', '10x01') => __UNALLOCATED
                        when (_, '01', '00110') => __UNALLOCATED
                        when (_, '1x', '10010') => __UNALLOCATED
                        when (_, '1x', '11000') => __UNALLOCATED
                        when (_, '10', '0x0x0') => __UNALLOCATED
                        when (_, '10', '10x0x') => __UNALLOCATED
                        when (_, '11', '00000') => __UNALLOCATED
                        when (_, '11', '00010') => __UNALLOCATED
                        when (_, '11', '10101') => __UNALLOCATED
                        when ('0', _, '00001') => __encoding A64_simd_dp_asisdsame_SQADD_asisdsame_only // SQADD_asisdsame_only
                        when ('0', _, '00101') => __encoding A64_simd_dp_asisdsame_SQSUB_asisdsame_only // SQSUB_asisdsame_only
                        when ('0', _, '01001') => __encoding A64_simd_dp_asisdsame_SQSHL_asisdsame_only // SQSHL_asisdsame_only
                        when ('0', _, '01011') => __encoding A64_simd_dp_asisdsame_SQRSHL_asisdsame_only // SQRSHL_asisdsame_only
                        when ('0', _, '10110') => __encoding A64_simd_dp_asisdsame_SQDMULH_asisdsame_only // SQDMULH_asisdsame_only
                        when ('0', _, '10111') => __UNALLOCATED
                        when ('0', _, '11101') => __UNALLOCATED
                        when ('0', '0x', '11011') => __encoding A64_simd_dp_asisdsame_FMULX_asisdsame_only // FMULX_asisdsame_only
                        when ('0', '0x', '11100') => __encoding A64_simd_dp_asisdsame_FCMEQ_asisdsame_only // FCMEQ_asisdsame_only
                        when ('0', '0x', '11111') => __encoding A64_simd_dp_asisdsame_FRECPS_asisdsame_only // FRECPS_asisdsame_only
                        when ('0', '1x', '11010') => __UNALLOCATED
                        when ('0', '1x', '11011') => __UNALLOCATED
                        when ('0', '1x', '11100') => __UNALLOCATED
                        when ('0', '1x', '11111') => __encoding A64_simd_dp_asisdsame_FRSQRTS_asisdsame_only // FRSQRTS_asisdsame_only
                        when ('0', '11', '00110') => __encoding A64_simd_dp_asisdsame_CMGT_asisdsame_only // CMGT_asisdsame_only
                        when ('0', '11', '00111') => __encoding A64_simd_dp_asisdsame_CMGE_asisdsame_only // CMGE_asisdsame_only
                        when ('0', '11', '01000') => __encoding A64_simd_dp_asisdsame_SSHL_asisdsame_only // SSHL_asisdsame_only
                        when ('0', '11', '01010') => __encoding A64_simd_dp_asisdsame_SRSHL_asisdsame_only // SRSHL_asisdsame_only
                        when ('0', '11', '10000') => __encoding A64_simd_dp_asisdsame_ADD_asisdsame_only // ADD_asisdsame_only
                        when ('0', '11', '10001') => __encoding A64_simd_dp_asisdsame_CMTST_asisdsame_only // CMTST_asisdsame_only
                        when ('1', _, '00001') => __encoding A64_simd_dp_asisdsame_UQADD_asisdsame_only // UQADD_asisdsame_only
                        when ('1', _, '00101') => __encoding A64_simd_dp_asisdsame_UQSUB_asisdsame_only // UQSUB_asisdsame_only
                        when ('1', _, '01001') => __encoding A64_simd_dp_asisdsame_UQSHL_asisdsame_only // UQSHL_asisdsame_only
                        when ('1', _, '01011') => __encoding A64_simd_dp_asisdsame_UQRSHL_asisdsame_only // UQRSHL_asisdsame_only
                        when ('1', _, '1x111') => __UNALLOCATED
                        when ('1', _, '10110') => __encoding A64_simd_dp_asisdsame_SQRDMULH_asisdsame_only // SQRDMULH_asisdsame_only
                        when ('1', _, '11011') => __UNALLOCATED
                        when ('1', '0x', '11100') => __encoding A64_simd_dp_asisdsame_FCMGE_asisdsame_only // FCMGE_asisdsame_only
                        when ('1', '0x', '11101') => __encoding A64_simd_dp_asisdsame_FACGE_asisdsame_only // FACGE_asisdsame_only
                        when ('1', '1x', '11010') => __encoding A64_simd_dp_asisdsame_FABD_asisdsame_only // FABD_asisdsame_only
                        when ('1', '1x', '11100') => __encoding A64_simd_dp_asisdsame_FCMGT_asisdsame_only // FCMGT_asisdsame_only
                        when ('1', '1x', '11101') => __encoding A64_simd_dp_asisdsame_FACGT_asisdsame_only // FACGT_asisdsame_only
                        when ('1', '11', '00110') => __encoding A64_simd_dp_asisdsame_CMHI_asisdsame_only // CMHI_asisdsame_only
                        when ('1', '11', '00111') => __encoding A64_simd_dp_asisdsame_CMHS_asisdsame_only // CMHS_asisdsame_only
                        when ('1', '11', '01000') => __encoding A64_simd_dp_asisdsame_USHL_asisdsame_only // USHL_asisdsame_only
                        when ('1', '11', '01010') => __encoding A64_simd_dp_asisdsame_URSHL_asisdsame_only // URSHL_asisdsame_only
                        when ('1', '11', '10000') => __encoding A64_simd_dp_asisdsame_SUB_asisdsame_only // SUB_asisdsame_only
                        when ('1', '11', '10001') => __encoding A64_simd_dp_asisdsame_CMEQ_asisdsame_only // CMEQ_asisdsame_only
                when ('01x1', _, '10', _, 'xxxxxxxx1', _) => // asisdshf
                    __field U 29 +: 1
                    __field immh 19 +: 4
                    __field immb 16 +: 3
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, immh, opcode) of
                        when (_, _, '0xxx1') => __UNALLOCATED
                        when (_, _, '101xx') => __UNALLOCATED
                        when (_, _, '11101') => __UNALLOCATED
                        when (_, !'0000', '11110') => __UNALLOCATED
                        when (_, '0xxx', 'x10x0') => __UNALLOCATED
                        when (_, '0xxx', '00xx0') => __UNALLOCATED
                        when (_, '0xxx', '110x1') => __UNALLOCATED
                        when (_, '0000', 'x1110') => __UNALLOCATED
                        when (_, '0000', '1001x') => __UNALLOCATED
                        when (_, '0000', '11100') => __UNALLOCATED
                        when (_, '0000', '11111') => __UNALLOCATED
                        when (_, '1xxx', '110xx') => __UNALLOCATED
                        when ('0', '1xxx', '00000') => __encoding A64_simd_dp_asisdshf_SSHR_asisdshf_R // SSHR_asisdshf_R
                        when ('0', '1xxx', '00010') => __encoding A64_simd_dp_asisdshf_SSRA_asisdshf_R // SSRA_asisdshf_R
                        when ('0', '1xxx', '00100') => __encoding A64_simd_dp_asisdshf_SRSHR_asisdshf_R // SRSHR_asisdshf_R
                        when ('0', '1xxx', '00110') => __encoding A64_simd_dp_asisdshf_SRSRA_asisdshf_R // SRSRA_asisdshf_R
                        when ('0', '1xxx', '01010') => __encoding A64_simd_dp_asisdshf_SHL_asisdshf_R // SHL_asisdshf_R
                        when ('0', _, '01100') => __UNALLOCATED
                        when ('0', !'0000', '01110') => __encoding A64_simd_dp_asisdshf_SQSHL_asisdshf_R // SQSHL_asisdshf_R
                        when ('0', _, '1000x') => __UNALLOCATED
                        when ('0', !'0000', '10010') => __encoding A64_simd_dp_asisdshf_SQSHRN_asisdshf_N // SQSHRN_asisdshf_N
                        when ('0', !'0000', '10011') => __encoding A64_simd_dp_asisdshf_SQRSHRN_asisdshf_N // SQRSHRN_asisdshf_N
                        when ('0', !'0000', '11100') => __encoding A64_simd_dp_asisdshf_SCVTF_asisdshf_C // SCVTF_asisdshf_C
                        when ('0', !'0000', '11111') => __encoding A64_simd_dp_asisdshf_FCVTZS_asisdshf_C // FCVTZS_asisdshf_C
                        when ('0', '1xxx', '01000') => __UNALLOCATED
                        when ('1', '1xxx', '00000') => __encoding A64_simd_dp_asisdshf_USHR_asisdshf_R // USHR_asisdshf_R
                        when ('1', '1xxx', '00010') => __encoding A64_simd_dp_asisdshf_USRA_asisdshf_R // USRA_asisdshf_R
                        when ('1', '1xxx', '00100') => __encoding A64_simd_dp_asisdshf_URSHR_asisdshf_R // URSHR_asisdshf_R
                        when ('1', '1xxx', '00110') => __encoding A64_simd_dp_asisdshf_URSRA_asisdshf_R // URSRA_asisdshf_R
                        when ('1', '1xxx', '01000') => __encoding A64_simd_dp_asisdshf_SRI_asisdshf_R // SRI_asisdshf_R
                        when ('1', '1xxx', '01010') => __encoding A64_simd_dp_asisdshf_SLI_asisdshf_R // SLI_asisdshf_R
                        when ('1', !'0000', '01100') => __encoding A64_simd_dp_asisdshf_SQSHLU_asisdshf_R // SQSHLU_asisdshf_R
                        when ('1', !'0000', '01110') => __encoding A64_simd_dp_asisdshf_UQSHL_asisdshf_R // UQSHL_asisdshf_R
                        when ('1', !'0000', '10000') => __encoding A64_simd_dp_asisdshf_SQSHRUN_asisdshf_N // SQSHRUN_asisdshf_N
                        when ('1', !'0000', '10001') => __encoding A64_simd_dp_asisdshf_SQRSHRUN_asisdshf_N // SQRSHRUN_asisdshf_N
                        when ('1', !'0000', '10010') => __encoding A64_simd_dp_asisdshf_UQSHRN_asisdshf_N // UQSHRN_asisdshf_N
                        when ('1', !'0000', '10011') => __encoding A64_simd_dp_asisdshf_UQRSHRN_asisdshf_N // UQRSHRN_asisdshf_N
                        when ('1', !'0000', '11100') => __encoding A64_simd_dp_asisdshf_UCVTF_asisdshf_C // UCVTF_asisdshf_C
                        when ('1', !'0000', '11111') => __encoding A64_simd_dp_asisdshf_FCVTZU_asisdshf_C // FCVTZU_asisdshf_C
                        when ('1', '0000', '01100') => __UNALLOCATED
                        when ('1', '0000', '1000x') => __UNALLOCATED
                when ('01x1', _, '1x', _, 'xxxxxxxx0', _) => // asisdelem
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field L 21 +: 1
                    __field M 20 +: 1
                    __field Rm 16 +: 4
                    __field opcode 12 +: 4
                    __field H 11 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, '01', '1001') => __UNALLOCATED
                        when ('0', _, '0xx0') => __UNALLOCATED
                        when ('0', _, '0011') => __encoding A64_simd_dp_asisdelem_SQDMLAL_asisdelem_L // SQDMLAL_asisdelem_L
                        when ('0', _, '0111') => __encoding A64_simd_dp_asisdelem_SQDMLSL_asisdelem_L // SQDMLSL_asisdelem_L
                        when ('0', _, '10x0') => __UNALLOCATED
                        when ('0', _, '1011') => __encoding A64_simd_dp_asisdelem_SQDMULL_asisdelem_L // SQDMULL_asisdelem_L
                        when ('0', _, '1100') => __encoding A64_simd_dp_asisdelem_SQDMULH_asisdelem_R // SQDMULH_asisdelem_R
                        when ('0', _, '1101') => __encoding A64_simd_dp_asisdelem_SQRDMULH_asisdelem_R // SQRDMULH_asisdelem_R
                        when ('0', _, '111x') => __UNALLOCATED
                        when ('0', '00', '0001') => __encoding A64_simd_dp_asisdelem_FMLA_asisdelem_RH_H // FMLA_asisdelem_RH_H
                        when ('0', '00', '0101') => __encoding A64_simd_dp_asisdelem_FMLS_asisdelem_RH_H // FMLS_asisdelem_RH_H
                        when ('0', '00', '1001') => __encoding A64_simd_dp_asisdelem_FMUL_asisdelem_RH_H // FMUL_asisdelem_RH_H
                        when ('0', '01', '0x01') => __UNALLOCATED
                        when ('0', '1x', '0001') => __encoding A64_simd_dp_asisdelem_FMLA_asisdelem_R_SD // FMLA_asisdelem_R_SD
                        when ('0', '1x', '0101') => __encoding A64_simd_dp_asisdelem_FMLS_asisdelem_R_SD // FMLS_asisdelem_R_SD
                        when ('0', '1x', '1001') => __encoding A64_simd_dp_asisdelem_FMUL_asisdelem_R_SD // FMUL_asisdelem_R_SD
                        when ('1', _, '0xxx') => __UNALLOCATED
                        when ('1', _, '1xx0') => __UNALLOCATED
                        when ('1', _, '1011') => __UNALLOCATED
                        when ('1', _, '1101') => __encoding A64_simd_dp_asisdelem_SQRDMLAH_asisdelem_R // SQRDMLAH_asisdelem_R
                        when ('1', _, '1111') => __encoding A64_simd_dp_asisdelem_SQRDMLSH_asisdelem_R // SQRDMLSH_asisdelem_R
                        when ('1', '00', '1001') => __encoding A64_simd_dp_asisdelem_FMULX_asisdelem_RH_H // FMULX_asisdelem_RH_H
                        when ('1', '1x', '1001') => __encoding A64_simd_dp_asisdelem_FMULX_asisdelem_R_SD // FMULX_asisdelem_R_SD
                when ('01xx', _, '11', _, 'xxxxxxxx1', _) => __UNPREDICTABLE
                when ('0x00', _, '0x', 'x0xx', 'xxx0xxx00', _) => // asimdtbl
                    __field Q 30 +: 1
                    __field op2 22 +: 2
                    __field Rm 16 +: 5
                    __field len 13 +: 2
                    __field op 12 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, op2, len, op) of
                        when (_, '00', '00', '0') => __encoding A64_simd_dp_asimdtbl_TBL_asimdtbl_L1_1 // TBL_asimdtbl_L1_1
                        when (_, '00', '00', '1') => __encoding A64_simd_dp_asimdtbl_TBX_asimdtbl_L1_1 // TBX_asimdtbl_L1_1
                        when (_, '00', '01', '0') => __encoding A64_simd_dp_asimdtbl_TBL_asimdtbl_L1_1 // TBL_asimdtbl_L2_2
                        when (_, '00', '01', '1') => __encoding A64_simd_dp_asimdtbl_TBX_asimdtbl_L1_1 // TBX_asimdtbl_L2_2
                        when (_, '00', '10', '0') => __encoding A64_simd_dp_asimdtbl_TBL_asimdtbl_L1_1 // TBL_asimdtbl_L3_3
                        when (_, '00', '10', '1') => __encoding A64_simd_dp_asimdtbl_TBX_asimdtbl_L1_1 // TBX_asimdtbl_L3_3
                        when (_, '00', '11', '0') => __encoding A64_simd_dp_asimdtbl_TBL_asimdtbl_L1_1 // TBL_asimdtbl_L4_4
                        when (_, '00', '11', '1') => __encoding A64_simd_dp_asimdtbl_TBX_asimdtbl_L1_1 // TBX_asimdtbl_L4_4
                        when ('0', !'00', _, _) => __UNALLOCATED
                        when ('1', '01', _, '1') => __encoding A64_simd_dp_asimdtbl_LUTI4_asimdtbl_L5 // LUTI4_asimdtbl_L7
                        when ('1', '01', 'x0', '0') => __UNALLOCATED
                        when ('1', '01', 'x1', '0') => __encoding A64_simd_dp_asimdtbl_LUTI4_asimdtbl_L5 // LUTI4_asimdtbl_L5
                        when ('1', '10', _, '0') => __UNALLOCATED
                        when ('1', '10', _, '1') => __encoding A64_simd_dp_asimdtbl_LUTI2_asimdtbl_L5 // LUTI2_asimdtbl_L5
                        when ('1', '11', _, _) => __encoding A64_simd_dp_asimdtbl_LUTI2_asimdtbl_L5 // LUTI2_asimdtbl_L6
                when ('0x00', _, '0x', 'x0xx', 'xxx0xxx10', _) => // asimdperm
                    __field Q 30 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('x00') => __UNALLOCATED
                        when ('001') => __encoding A64_simd_dp_asimdperm_UZP1_asimdperm_only // UZP1_asimdperm_only
                        when ('010') => __encoding A64_simd_dp_asimdperm_TRN1_asimdperm_only // TRN1_asimdperm_only
                        when ('011') => __encoding A64_simd_dp_asimdperm_ZIP1_asimdperm_only // ZIP1_asimdperm_only
                        when ('101') => __encoding A64_simd_dp_asimdperm_UZP2_asimdperm_only // UZP2_asimdperm_only
                        when ('110') => __encoding A64_simd_dp_asimdperm_TRN2_asimdperm_only // TRN2_asimdperm_only
                        when ('111') => __encoding A64_simd_dp_asimdperm_ZIP2_asimdperm_only // ZIP2_asimdperm_only
                when ('0x10', _, '0x', 'x0xx', 'xxx0xxxx0', _) => // asimdext
                    __field Q 30 +: 1
                    __field op2 22 +: 2
                    __field Rm 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (op2) of
                        when (!'00') => __UNALLOCATED
                        when ('00') => __encoding A64_simd_dp_asimdext_EXT_asimdext_only // EXT_asimdext_only
                when ('0xx0', _, '00', '00xx', 'xxx0xxxx1', _) => // asimdins
                    __field Q 30 +: 1
                    __field op 29 +: 1
                    __field imm5 16 +: 5
                    __field imm4 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, op, imm5, imm4) of
                        when (_, '0', _, '0000') => __encoding A64_simd_dp_asimdins_DUP_asimdins_DV_v // DUP_asimdins_DV_v
                        when (_, '0', _, '0001') => __encoding A64_simd_dp_asimdins_DUP_asimdins_DR_r // DUP_asimdins_DR_r
                        when (_, '0', _, '01x0') => __UNALLOCATED
                        when (_, '0', _, '1xxx') => __UNALLOCATED
                        when ('0', '0', _, '001x') => __UNALLOCATED
                        when ('0', '0', _, '0101') => __encoding A64_simd_dp_asimdins_SMOV_asimdins_W_w // SMOV_asimdins_W_w
                        when ('0', '0', _, '0111') => __encoding A64_simd_dp_asimdins_UMOV_asimdins_W_w // UMOV_asimdins_W_w
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', '0', _, '0010') => __UNALLOCATED
                        when ('1', '0', _, '0011') => __encoding A64_simd_dp_asimdins_INS_asimdins_IR_r // INS_asimdins_IR_r
                        when ('1', '0', _, '0101') => __encoding A64_simd_dp_asimdins_SMOV_asimdins_W_w // SMOV_asimdins_X_x
                        when ('1', '0', 'x0xxx', '0111') => __UNALLOCATED
                        when ('1', '0', 'x1000', '0111') => __encoding A64_simd_dp_asimdins_UMOV_asimdins_W_w // UMOV_asimdins_X_x
                        when ('1', '0', 'x1001', '0111') => __UNALLOCATED
                        when ('1', '0', 'x101x', '0111') => __UNALLOCATED
                        when ('1', '0', 'x11xx', '0111') => __UNALLOCATED
                        when ('1', '1', _, _) => __encoding A64_simd_dp_asimdins_INS_asimdins_IV_v // INS_asimdins_IV_v
                when ('0xx0', _, '01', '00xx', 'xxx0xxxx1', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '0111', '00xxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '10xx', 'xxx00xxx1', _) => // asimdsamefp16
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field Rm 16 +: 5
                    __field opcode 11 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when ('0', '0', '000') => __encoding A64_simd_dp_asimdsamefp16_FMAXNM_asimdsamefp16_only // FMAXNM_asimdsamefp16_only
                        when ('0', '0', '001') => __encoding A64_simd_dp_asimdsamefp16_FMLA_asimdsamefp16_only // FMLA_asimdsamefp16_only
                        when ('0', '0', '010') => __encoding A64_simd_dp_asimdsamefp16_FADD_asimdsamefp16_only // FADD_asimdsamefp16_only
                        when ('0', '0', '011') => __encoding A64_simd_dp_asimdsamefp16_FMULX_asimdsamefp16_only // FMULX_asimdsamefp16_only
                        when ('0', '0', '100') => __encoding A64_simd_dp_asimdsamefp16_FCMEQ_asimdsamefp16_only // FCMEQ_asimdsamefp16_only
                        when ('0', '0', '101') => __UNALLOCATED
                        when ('0', '0', '110') => __encoding A64_simd_dp_asimdsamefp16_FMAX_asimdsamefp16_only // FMAX_asimdsamefp16_only
                        when ('0', '0', '111') => __encoding A64_simd_dp_asimdsamefp16_FRECPS_asimdsamefp16_only // FRECPS_asimdsamefp16_only
                        when ('0', '1', '000') => __encoding A64_simd_dp_asimdsamefp16_FMINNM_asimdsamefp16_only // FMINNM_asimdsamefp16_only
                        when ('0', '1', '001') => __encoding A64_simd_dp_asimdsamefp16_FMLS_asimdsamefp16_only // FMLS_asimdsamefp16_only
                        when ('0', '1', '010') => __encoding A64_simd_dp_asimdsamefp16_FSUB_asimdsamefp16_only // FSUB_asimdsamefp16_only
                        when ('0', '1', '011') => __encoding A64_simd_dp_asimdsamefp16_FAMAX_asimdsamefp16_only // FAMAX_asimdsamefp16_only
                        when ('0', '1', '10x') => __UNALLOCATED
                        when ('0', '1', '110') => __encoding A64_simd_dp_asimdsamefp16_FMIN_asimdsamefp16_only // FMIN_asimdsamefp16_only
                        when ('0', '1', '111') => __encoding A64_simd_dp_asimdsamefp16_FRSQRTS_asimdsamefp16_only // FRSQRTS_asimdsamefp16_only
                        when ('1', _, '001') => __UNALLOCATED
                        when ('1', '0', '000') => __encoding A64_simd_dp_asimdsamefp16_FMAXNMP_asimdsamefp16_only // FMAXNMP_asimdsamefp16_only
                        when ('1', '0', '010') => __encoding A64_simd_dp_asimdsamefp16_FADDP_asimdsamefp16_only // FADDP_asimdsamefp16_only
                        when ('1', '0', '011') => __encoding A64_simd_dp_asimdsamefp16_FMUL_asimdsamefp16_only // FMUL_asimdsamefp16_only
                        when ('1', '0', '100') => __encoding A64_simd_dp_asimdsamefp16_FCMGE_asimdsamefp16_only // FCMGE_asimdsamefp16_only
                        when ('1', '0', '101') => __encoding A64_simd_dp_asimdsamefp16_FACGE_asimdsamefp16_only // FACGE_asimdsamefp16_only
                        when ('1', '0', '110') => __encoding A64_simd_dp_asimdsamefp16_FMAXP_asimdsamefp16_only // FMAXP_asimdsamefp16_only
                        when ('1', '0', '111') => __encoding A64_simd_dp_asimdsamefp16_FDIV_asimdsamefp16_only // FDIV_asimdsamefp16_only
                        when ('1', '1', '000') => __encoding A64_simd_dp_asimdsamefp16_FMINNMP_asimdsamefp16_only // FMINNMP_asimdsamefp16_only
                        when ('1', '1', '010') => __encoding A64_simd_dp_asimdsamefp16_FABD_asimdsamefp16_only // FABD_asimdsamefp16_only
                        when ('1', '1', '011') => __encoding A64_simd_dp_asimdsamefp16_FAMIN_asimdsamefp16_only // FAMIN_asimdsamefp16_only
                        when ('1', '1', '100') => __encoding A64_simd_dp_asimdsamefp16_FCMGT_asimdsamefp16_only // FCMGT_asimdsamefp16_only
                        when ('1', '1', '101') => __encoding A64_simd_dp_asimdsamefp16_FACGT_asimdsamefp16_only // FACGT_asimdsamefp16_only
                        when ('1', '1', '110') => __encoding A64_simd_dp_asimdsamefp16_FMINP_asimdsamefp16_only // FMINP_asimdsamefp16_only
                        when ('1', '1', '111') => __encoding A64_simd_dp_asimdsamefp16_FSCALE_asimdsamefp16_only // FSCALE_asimdsamefp16_only
                when ('0xx0', _, '0x', '10xx', 'xxx01xxx1', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', '1111', '00xxxxx10', _) => // asimdmiscfp16
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field a 23 +: 1
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, a, opcode) of
                        when (_, _, 'x0xxx') => __UNALLOCATED
                        when (_, '0', '01xxx') => __UNALLOCATED
                        when (_, '0', '1111x') => __UNALLOCATED
                        when (_, '1', '010xx') => __UNALLOCATED
                        when (_, '1', '11100') => __UNALLOCATED
                        when ('0', '0', '11000') => __encoding A64_simd_dp_asimdmiscfp16_FRINTN_asimdmiscfp16_R // FRINTN_asimdmiscfp16_R
                        when ('0', '0', '11001') => __encoding A64_simd_dp_asimdmiscfp16_FRINTM_asimdmiscfp16_R // FRINTM_asimdmiscfp16_R
                        when ('0', '0', '11010') => __encoding A64_simd_dp_asimdmiscfp16_FCVTNS_asimdmiscfp16_R // FCVTNS_asimdmiscfp16_R
                        when ('0', '0', '11011') => __encoding A64_simd_dp_asimdmiscfp16_FCVTMS_asimdmiscfp16_R // FCVTMS_asimdmiscfp16_R
                        when ('0', '0', '11100') => __encoding A64_simd_dp_asimdmiscfp16_FCVTAS_asimdmiscfp16_R // FCVTAS_asimdmiscfp16_R
                        when ('0', '0', '11101') => __encoding A64_simd_dp_asimdmiscfp16_SCVTF_asimdmiscfp16_R // SCVTF_asimdmiscfp16_R
                        when ('0', '1', '01100') => __encoding A64_simd_dp_asimdmiscfp16_FCMGT_asimdmiscfp16_FZ // FCMGT_asimdmiscfp16_FZ
                        when ('0', '1', '01101') => __encoding A64_simd_dp_asimdmiscfp16_FCMEQ_asimdmiscfp16_FZ // FCMEQ_asimdmiscfp16_FZ
                        when ('0', '1', '01110') => __encoding A64_simd_dp_asimdmiscfp16_FCMLT_asimdmiscfp16_FZ // FCMLT_asimdmiscfp16_FZ
                        when ('0', '1', '01111') => __encoding A64_simd_dp_asimdmiscfp16_FABS_asimdmiscfp16_R // FABS_asimdmiscfp16_R
                        when ('0', '1', '11000') => __encoding A64_simd_dp_asimdmiscfp16_FRINTP_asimdmiscfp16_R // FRINTP_asimdmiscfp16_R
                        when ('0', '1', '11001') => __encoding A64_simd_dp_asimdmiscfp16_FRINTZ_asimdmiscfp16_R // FRINTZ_asimdmiscfp16_R
                        when ('0', '1', '11010') => __encoding A64_simd_dp_asimdmiscfp16_FCVTPS_asimdmiscfp16_R // FCVTPS_asimdmiscfp16_R
                        when ('0', '1', '11011') => __encoding A64_simd_dp_asimdmiscfp16_FCVTZS_asimdmiscfp16_R // FCVTZS_asimdmiscfp16_R
                        when ('0', '1', '11101') => __encoding A64_simd_dp_asimdmiscfp16_FRECPE_asimdmiscfp16_R // FRECPE_asimdmiscfp16_R
                        when ('0', '1', '1111x') => __UNALLOCATED
                        when ('1', '0', '11000') => __encoding A64_simd_dp_asimdmiscfp16_FRINTA_asimdmiscfp16_R // FRINTA_asimdmiscfp16_R
                        when ('1', '0', '11001') => __encoding A64_simd_dp_asimdmiscfp16_FRINTX_asimdmiscfp16_R // FRINTX_asimdmiscfp16_R
                        when ('1', '0', '11010') => __encoding A64_simd_dp_asimdmiscfp16_FCVTNU_asimdmiscfp16_R // FCVTNU_asimdmiscfp16_R
                        when ('1', '0', '11011') => __encoding A64_simd_dp_asimdmiscfp16_FCVTMU_asimdmiscfp16_R // FCVTMU_asimdmiscfp16_R
                        when ('1', '0', '11100') => __encoding A64_simd_dp_asimdmiscfp16_FCVTAU_asimdmiscfp16_R // FCVTAU_asimdmiscfp16_R
                        when ('1', '0', '11101') => __encoding A64_simd_dp_asimdmiscfp16_UCVTF_asimdmiscfp16_R // UCVTF_asimdmiscfp16_R
                        when ('1', '1', 'x1110') => __UNALLOCATED
                        when ('1', '1', '01100') => __encoding A64_simd_dp_asimdmiscfp16_FCMGE_asimdmiscfp16_FZ // FCMGE_asimdmiscfp16_FZ
                        when ('1', '1', '01101') => __encoding A64_simd_dp_asimdmiscfp16_FCMLE_asimdmiscfp16_FZ // FCMLE_asimdmiscfp16_FZ
                        when ('1', '1', '01111') => __encoding A64_simd_dp_asimdmiscfp16_FNEG_asimdmiscfp16_R // FNEG_asimdmiscfp16_R
                        when ('1', '1', '11000') => __UNALLOCATED
                        when ('1', '1', '11001') => __encoding A64_simd_dp_asimdmiscfp16_FRINTI_asimdmiscfp16_R // FRINTI_asimdmiscfp16_R
                        when ('1', '1', '11010') => __encoding A64_simd_dp_asimdmiscfp16_FCVTPU_asimdmiscfp16_R // FCVTPU_asimdmiscfp16_R
                        when ('1', '1', '11011') => __encoding A64_simd_dp_asimdmiscfp16_FCVTZU_asimdmiscfp16_R // FCVTZU_asimdmiscfp16_R
                        when ('1', '1', '11101') => __encoding A64_simd_dp_asimdmiscfp16_FRSQRTE_asimdmiscfp16_R // FRSQRTE_asimdmiscfp16_R
                        when ('1', '1', '11111') => __encoding A64_simd_dp_asimdmiscfp16_FSQRT_asimdmiscfp16_R // FSQRT_asimdmiscfp16_R
                when ('0xx0', _, '0x', 'x0xx', 'xxx1xxxx0', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x0xx', 'xxx1xxxx1', _) => // asimdsame2
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, U, size, opcode) of
                        when (_, '0', !'10', 'x0x1') => __UNALLOCATED
                        when (_, '0', _, '0000') => __UNALLOCATED
                        when (_, '0', _, '0010') => __encoding A64_simd_dp_asimdsame2_SDOT_asimdsame2_D // SDOT_asimdsame2_D
                        when (_, '0', '0x', '1010') => __UNALLOCATED
                        when (_, '0', '0x', '1100') => __UNALLOCATED
                        when (_, '0', '00', '1110') => __encoding A64_simd_dp_asimdsame2_FCVTN_asimdsame2_H // FCVTN_asimdsame2_H
                        when (_, '0', '00', '1111') => __encoding A64_simd_dp_asimdsame2_FDOT_asimdsame2_DD // FDOT_asimdsame2_DD
                        when (_, '0', '01', '1110') => __encoding A64_simd_dp_asimdsame2_FCVTN_asimdsame2_D // FCVTN_asimdsame2_D
                        when (_, '0', '01', '1111') => __encoding A64_simd_dp_asimdsame2_FDOT_asimdsame2_D // FDOT_asimdsame2_D
                        when (_, '0', '10', '0001') => __UNALLOCATED
                        when (_, '0', '10', '0011') => __encoding A64_simd_dp_asimdsame2_USDOT_asimdsame2_D // USDOT_asimdsame2_D
                        when (_, '0', '10', '1xx0') => __UNALLOCATED
                        when (_, '0', '10', '1x11') => __UNALLOCATED
                        when (_, '0', '10', '1001') => __UNALLOCATED
                        when (_, '0', '11', '1xx0') => __UNALLOCATED
                        when (_, '1', _, '0000') => __encoding A64_simd_dp_asimdsame2_SQRDMLAH_asimdsame2_only // SQRDMLAH_asimdsame2_only
                        when (_, '1', _, '0001') => __encoding A64_simd_dp_asimdsame2_SQRDMLSH_asimdsame2_only // SQRDMLSH_asimdsame2_only
                        when (_, '1', _, '0010') => __encoding A64_simd_dp_asimdsame2_UDOT_asimdsame2_D // UDOT_asimdsame2_D
                        when (_, '1', _, '0011') => __UNALLOCATED
                        when (_, '1', _, '10xx') => __encoding A64_simd_dp_asimdsame2_FCMLA_asimdsame2_C // FCMLA_asimdsame2_C
                        when (_, '1', _, '11x0') => __encoding A64_simd_dp_asimdsame2_FCADD_asimdsame2_C // FCADD_asimdsame2_C
                        when (_, '1', 'x0', '1111') => __UNALLOCATED
                        when (_, '1', '01', '1111') => __encoding A64_simd_dp_asimdsame2_BFDOT_asimdsame2_D // BFDOT_asimdsame2_D
                        when (_, '1', '11', '1111') => __encoding A64_simd_dp_asimdsame2_BFMLAL_asimdsame2_F_ // BFMLAL_asimdsame2_F_
                        when ('0', _, _, '01xx') => __UNALLOCATED
                        when ('0', _, _, '1101') => __UNALLOCATED
                        when ('0', '0', '00', '1000') => __encoding A64_simd_dp_asimdsame2_FMLALLBB_asimdsame2_G // FMLALLBB_asimdsame2_G
                        when ('0', '0', '01', '1000') => __encoding A64_simd_dp_asimdsame2_FMLALLBB_asimdsame2_G // FMLALLBT_asimdsame2_G
                        when ('0', '0', '11', '1111') => __encoding A64_simd_dp_asimdsame2_FMLALB_asimdsame2_J // FMLALB_asimdsame2_J
                        when ('1', _, !'10', '01xx') => __UNALLOCATED
                        when ('1', _, '10', '011x') => __UNALLOCATED
                        when ('1', '0', !'11', '1101') => __UNALLOCATED
                        when ('1', '0', '00', '1000') => __encoding A64_simd_dp_asimdsame2_FMLALLBB_asimdsame2_G // FMLALLTB_asimdsame2_G
                        when ('1', '0', '01', '1000') => __encoding A64_simd_dp_asimdsame2_FMLALLBB_asimdsame2_G // FMLALLTT_asimdsame2_G
                        when ('1', '0', '10', '0100') => __encoding A64_simd_dp_asimdsame2_SMMLA_asimdsame2_G // SMMLA_asimdsame2_G
                        when ('1', '0', '10', '0101') => __encoding A64_simd_dp_asimdsame2_USMMLA_asimdsame2_G // USMMLA_asimdsame2_G
                        when ('1', '0', '11', '1101') => __UNALLOCATED
                        when ('1', '0', '11', '1111') => __encoding A64_simd_dp_asimdsame2_FMLALB_asimdsame2_J // FMLALT_asimdsame2_J
                        when ('1', '1', '00', '1101') => __encoding A64_simd_dp_asimdsame2_FMMLA_asimd_FP8FP16 // FMMLA_asimd_FP8FP16
                        when ('1', '1', '01', '1101') => __encoding A64_simd_dp_asimdsame2_BFMMLA_asimdsame2_E // BFMMLA_asimdsame2_E
                        when ('1', '1', '10', '0100') => __encoding A64_simd_dp_asimdsame2_UMMLA_asimdsame2_G // UMMLA_asimdsame2_G
                        when ('1', '1', '10', '0101') => __UNALLOCATED
                        when ('1', '1', '10', '1101') => __encoding A64_simd_dp_asimdsame2_FMMLA_asimd_FP8FP32 // FMMLA_asimd_FP8FP32
                        when ('1', '1', '11', '1101') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x100', '00xxxxx10', _) => // asimdmisc
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when (_, _, '1000x') => __UNALLOCATED
                        when (_, _, '10101') => __UNALLOCATED
                        when (_, '0x', '011xx') => __UNALLOCATED
                        when (_, '10', '11110') => __UNALLOCATED
                        when (_, '11', '1x110') => __UNALLOCATED
                        when ('0', _, '00000') => __encoding A64_simd_dp_asimdmisc_REV64_asimdmisc_R // REV64_asimdmisc_R
                        when ('0', _, '00001') => __encoding A64_simd_dp_asimdmisc_REV16_asimdmisc_R // REV16_asimdmisc_R
                        when ('0', _, '00010') => __encoding A64_simd_dp_asimdmisc_SADDLP_asimdmisc_P // SADDLP_asimdmisc_P
                        when ('0', _, '00011') => __encoding A64_simd_dp_asimdmisc_SUQADD_asimdmisc_R // SUQADD_asimdmisc_R
                        when ('0', _, '00100') => __encoding A64_simd_dp_asimdmisc_CLS_asimdmisc_R // CLS_asimdmisc_R
                        when ('0', _, '00101') => __encoding A64_simd_dp_asimdmisc_CNT_asimdmisc_R // CNT_asimdmisc_R
                        when ('0', _, '00110') => __encoding A64_simd_dp_asimdmisc_SADALP_asimdmisc_P // SADALP_asimdmisc_P
                        when ('0', _, '00111') => __encoding A64_simd_dp_asimdmisc_SQABS_asimdmisc_R // SQABS_asimdmisc_R
                        when ('0', _, '01000') => __encoding A64_simd_dp_asimdmisc_CMGT_asimdmisc_Z // CMGT_asimdmisc_Z
                        when ('0', _, '01001') => __encoding A64_simd_dp_asimdmisc_CMEQ_asimdmisc_Z // CMEQ_asimdmisc_Z
                        when ('0', _, '01010') => __encoding A64_simd_dp_asimdmisc_CMLT_asimdmisc_Z // CMLT_asimdmisc_Z
                        when ('0', _, '01011') => __encoding A64_simd_dp_asimdmisc_ABS_asimdmisc_R // ABS_asimdmisc_R
                        when ('0', _, '10010') => __encoding A64_simd_dp_asimdmisc_XTN_asimdmisc_N // XTN_asimdmisc_N
                        when ('0', _, '10011') => __UNALLOCATED
                        when ('0', _, '10100') => __encoding A64_simd_dp_asimdmisc_SQXTN_asimdmisc_N // SQXTN_asimdmisc_N
                        when ('0', '0x', '10110') => __encoding A64_simd_dp_asimdmisc_FCVTN_asimdmisc_N // FCVTN_asimdmisc_N
                        when ('0', '0x', '10111') => __encoding A64_simd_dp_asimdmisc_FCVTL_asimdmisc_L // FCVTL_asimdmisc_L
                        when ('0', '0x', '11000') => __encoding A64_simd_dp_asimdmisc_FRINTN_asimdmisc_R // FRINTN_asimdmisc_R
                        when ('0', '0x', '11001') => __encoding A64_simd_dp_asimdmisc_FRINTM_asimdmisc_R // FRINTM_asimdmisc_R
                        when ('0', '0x', '11010') => __encoding A64_simd_dp_asimdmisc_FCVTNS_asimdmisc_R // FCVTNS_asimdmisc_R
                        when ('0', '0x', '11011') => __encoding A64_simd_dp_asimdmisc_FCVTMS_asimdmisc_R // FCVTMS_asimdmisc_R
                        when ('0', '0x', '11100') => __encoding A64_simd_dp_asimdmisc_FCVTAS_asimdmisc_R // FCVTAS_asimdmisc_R
                        when ('0', '0x', '11101') => __encoding A64_simd_dp_asimdmisc_SCVTF_asimdmisc_R // SCVTF_asimdmisc_R
                        when ('0', '0x', '11110') => __encoding A64_simd_dp_asimdmisc_FRINT32Z_asimdmisc_R // FRINT32Z_asimdmisc_R
                        when ('0', '0x', '11111') => __encoding A64_simd_dp_asimdmisc_FRINT64Z_asimdmisc_R // FRINT64Z_asimdmisc_R
                        when ('0', '1x', '01100') => __encoding A64_simd_dp_asimdmisc_FCMGT_asimdmisc_FZ // FCMGT_asimdmisc_FZ
                        when ('0', '1x', '01101') => __encoding A64_simd_dp_asimdmisc_FCMEQ_asimdmisc_FZ // FCMEQ_asimdmisc_FZ
                        when ('0', '1x', '01110') => __encoding A64_simd_dp_asimdmisc_FCMLT_asimdmisc_FZ // FCMLT_asimdmisc_FZ
                        when ('0', '1x', '01111') => __encoding A64_simd_dp_asimdmisc_FABS_asimdmisc_R // FABS_asimdmisc_R
                        when ('0', '1x', '1x111') => __UNALLOCATED
                        when ('0', '1x', '11000') => __encoding A64_simd_dp_asimdmisc_FRINTP_asimdmisc_R // FRINTP_asimdmisc_R
                        when ('0', '1x', '11001') => __encoding A64_simd_dp_asimdmisc_FRINTZ_asimdmisc_R // FRINTZ_asimdmisc_R
                        when ('0', '1x', '11010') => __encoding A64_simd_dp_asimdmisc_FCVTPS_asimdmisc_R // FCVTPS_asimdmisc_R
                        when ('0', '1x', '11011') => __encoding A64_simd_dp_asimdmisc_FCVTZS_asimdmisc_R // FCVTZS_asimdmisc_R
                        when ('0', '1x', '11100') => __encoding A64_simd_dp_asimdmisc_URECPE_asimdmisc_R // URECPE_asimdmisc_R
                        when ('0', '1x', '11101') => __encoding A64_simd_dp_asimdmisc_FRECPE_asimdmisc_R // FRECPE_asimdmisc_R
                        when ('0', '10', '10110') => __encoding A64_simd_dp_asimdmisc_BFCVTN_asimdmisc_4S // BFCVTN_asimdmisc_4S
                        when ('1', _, '00000') => __encoding A64_simd_dp_asimdmisc_REV32_asimdmisc_R // REV32_asimdmisc_R
                        when ('1', _, '00010') => __encoding A64_simd_dp_asimdmisc_UADDLP_asimdmisc_P // UADDLP_asimdmisc_P
                        when ('1', _, '00011') => __encoding A64_simd_dp_asimdmisc_USQADD_asimdmisc_R // USQADD_asimdmisc_R
                        when ('1', _, '00100') => __encoding A64_simd_dp_asimdmisc_CLZ_asimdmisc_R // CLZ_asimdmisc_R
                        when ('1', _, '00110') => __encoding A64_simd_dp_asimdmisc_UADALP_asimdmisc_P // UADALP_asimdmisc_P
                        when ('1', _, '00111') => __encoding A64_simd_dp_asimdmisc_SQNEG_asimdmisc_R // SQNEG_asimdmisc_R
                        when ('1', _, '01000') => __encoding A64_simd_dp_asimdmisc_CMGE_asimdmisc_Z // CMGE_asimdmisc_Z
                        when ('1', _, '01001') => __encoding A64_simd_dp_asimdmisc_CMLE_asimdmisc_Z // CMLE_asimdmisc_Z
                        when ('1', _, '01010') => __UNALLOCATED
                        when ('1', _, '01011') => __encoding A64_simd_dp_asimdmisc_NEG_asimdmisc_R // NEG_asimdmisc_R
                        when ('1', _, '10010') => __encoding A64_simd_dp_asimdmisc_SQXTUN_asimdmisc_N // SQXTUN_asimdmisc_N
                        when ('1', _, '10011') => __encoding A64_simd_dp_asimdmisc_SHLL_asimdmisc_S // SHLL_asimdmisc_S
                        when ('1', _, '10100') => __encoding A64_simd_dp_asimdmisc_UQXTN_asimdmisc_N // UQXTN_asimdmisc_N
                        when ('1', 'x0', '10110') => __UNALLOCATED
                        when ('1', '0x', '00001') => __UNALLOCATED
                        when ('1', '0x', '11000') => __encoding A64_simd_dp_asimdmisc_FRINTA_asimdmisc_R // FRINTA_asimdmisc_R
                        when ('1', '0x', '11001') => __encoding A64_simd_dp_asimdmisc_FRINTX_asimdmisc_R // FRINTX_asimdmisc_R
                        when ('1', '0x', '11010') => __encoding A64_simd_dp_asimdmisc_FCVTNU_asimdmisc_R // FCVTNU_asimdmisc_R
                        when ('1', '0x', '11011') => __encoding A64_simd_dp_asimdmisc_FCVTMU_asimdmisc_R // FCVTMU_asimdmisc_R
                        when ('1', '0x', '11100') => __encoding A64_simd_dp_asimdmisc_FCVTAU_asimdmisc_R // FCVTAU_asimdmisc_R
                        when ('1', '0x', '11101') => __encoding A64_simd_dp_asimdmisc_UCVTF_asimdmisc_R // UCVTF_asimdmisc_R
                        when ('1', '0x', '11110') => __encoding A64_simd_dp_asimdmisc_FRINT32X_asimdmisc_R // FRINT32X_asimdmisc_R
                        when ('1', '0x', '11111') => __encoding A64_simd_dp_asimdmisc_FRINT64X_asimdmisc_R // FRINT64X_asimdmisc_R
                        when ('1', '00', '00101') => __encoding A64_simd_dp_asimdmisc_NOT_asimdmisc_R // NOT_asimdmisc_R
                        when ('1', '00', '10111') => __encoding A64_simd_dp_asimdmisc_F1CVTL_asimdmisc_V // F1CVTL_asimdmisc_V
                        when ('1', '01', '00101') => __encoding A64_simd_dp_asimdmisc_RBIT_asimdmisc_R // RBIT_asimdmisc_R
                        when ('1', '01', '10110') => __encoding A64_simd_dp_asimdmisc_FCVTXN_asimdmisc_N // FCVTXN_asimdmisc_N
                        when ('1', '01', '10111') => __encoding A64_simd_dp_asimdmisc_F1CVTL_asimdmisc_V // F2CVTL_asimdmisc_V
                        when ('1', '1x', '00x01') => __UNALLOCATED
                        when ('1', '1x', '01100') => __encoding A64_simd_dp_asimdmisc_FCMGE_asimdmisc_FZ // FCMGE_asimdmisc_FZ
                        when ('1', '1x', '01101') => __encoding A64_simd_dp_asimdmisc_FCMLE_asimdmisc_FZ // FCMLE_asimdmisc_FZ
                        when ('1', '1x', '01110') => __UNALLOCATED
                        when ('1', '1x', '01111') => __encoding A64_simd_dp_asimdmisc_FNEG_asimdmisc_R // FNEG_asimdmisc_R
                        when ('1', '1x', '11000') => __UNALLOCATED
                        when ('1', '1x', '11001') => __encoding A64_simd_dp_asimdmisc_FRINTI_asimdmisc_R // FRINTI_asimdmisc_R
                        when ('1', '1x', '11010') => __encoding A64_simd_dp_asimdmisc_FCVTPU_asimdmisc_R // FCVTPU_asimdmisc_R
                        when ('1', '1x', '11011') => __encoding A64_simd_dp_asimdmisc_FCVTZU_asimdmisc_R // FCVTZU_asimdmisc_R
                        when ('1', '1x', '11100') => __encoding A64_simd_dp_asimdmisc_URSQRTE_asimdmisc_R // URSQRTE_asimdmisc_R
                        when ('1', '1x', '11101') => __encoding A64_simd_dp_asimdmisc_FRSQRTE_asimdmisc_R // FRSQRTE_asimdmisc_R
                        when ('1', '1x', '11111') => __encoding A64_simd_dp_asimdmisc_FSQRT_asimdmisc_R // FSQRT_asimdmisc_R
                        when ('1', '10', '10111') => __encoding A64_simd_dp_asimdmisc_BF1CVTL_asimdmisc_V // BF1CVTL_asimdmisc_V
                        when ('1', '11', '10111') => __encoding A64_simd_dp_asimdmisc_BF1CVTL_asimdmisc_V // BF2CVTL_asimdmisc_V
                when ('0xx0', _, '0x', 'x110', '00xxxxx10', _) => // asimdall
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field opcode 12 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, U, size, opcode) of
                        when (_, _, _, 'x100x') => __UNALLOCATED
                        when (_, _, _, '000x0') => __UNALLOCATED
                        when (_, _, _, '00001') => __UNALLOCATED
                        when (_, _, _, '01011') => __UNALLOCATED
                        when (_, _, _, '100xx') => __UNALLOCATED
                        when (_, _, 'x0', '001xx') => __UNALLOCATED
                        when (_, _, 'x0', '01101') => __UNALLOCATED
                        when (_, _, 'x0', '101xx') => __UNALLOCATED
                        when (_, _, 'x0', '111xx') => __UNALLOCATED
                        when (_, _, 'x1', 'xx1xx') => __UNALLOCATED
                        when (_, '0', _, '00011') => __encoding A64_simd_dp_asimdall_SADDLV_asimdall_only // SADDLV_asimdall_only
                        when (_, '0', _, '01010') => __encoding A64_simd_dp_asimdall_SMAXV_asimdall_only // SMAXV_asimdall_only
                        when (_, '0', _, '11010') => __encoding A64_simd_dp_asimdall_SMINV_asimdall_only // SMINV_asimdall_only
                        when (_, '0', _, '11011') => __encoding A64_simd_dp_asimdall_ADDV_asimdall_only // ADDV_asimdall_only
                        when (_, '0', 'x0', '01110') => __UNALLOCATED
                        when (_, '0', '00', '01100') => __encoding A64_simd_dp_asimdall_FMAXNMV_asimdall_only_H // FMAXNMV_asimdall_only_H
                        when (_, '0', '00', '01111') => __encoding A64_simd_dp_asimdall_FMAXV_asimdall_only_H // FMAXV_asimdall_only_H
                        when (_, '0', '10', '01100') => __encoding A64_simd_dp_asimdall_FMINNMV_asimdall_only_H // FMINNMV_asimdall_only_H
                        when (_, '0', '10', '01111') => __encoding A64_simd_dp_asimdall_FMINV_asimdall_only_H // FMINV_asimdall_only_H
                        when (_, '1', _, '00011') => __encoding A64_simd_dp_asimdall_UADDLV_asimdall_only // UADDLV_asimdall_only
                        when (_, '1', _, '01010') => __encoding A64_simd_dp_asimdall_UMAXV_asimdall_only // UMAXV_asimdall_only
                        when (_, '1', _, '11010') => __encoding A64_simd_dp_asimdall_UMINV_asimdall_only // UMINV_asimdall_only
                        when (_, '1', _, '11011') => __UNALLOCATED
                        when ('1', '1', '00', '01100') => __encoding A64_simd_dp_asimdall_FMAXNMV_asimdall_only_SD // FMAXNMV_asimdall_only_SD
                        when ('1', '1', '00', '01111') => __encoding A64_simd_dp_asimdall_FMAXV_asimdall_only_SD // FMAXV_asimdall_only_SD
                        when ('1', '1', '10', '01100') => __encoding A64_simd_dp_asimdall_FMINNMV_asimdall_only_SD // FMINNMV_asimdall_only_SD
                        when ('1', '1', '10', '01111') => __encoding A64_simd_dp_asimdall_FMINV_asimdall_only_SD // FMINV_asimdall_only_SD
                        when ('0', '1', 'x0', '011x0') => __UNALLOCATED
                        when ('0', '1', 'x0', '01111') => __UNALLOCATED
                        when ('1', '1', 'x0', '01110') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x1xx', '01xxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x1xx', '1xxxxxx10', _) => __UNPREDICTABLE
                when ('0xx0', _, '0x', 'x1xx', 'xxxxxxx00', _) => // asimddiff
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, opcode) of
                        when ('0', '0000') => __encoding A64_simd_dp_asimddiff_SADDL_asimddiff_L // SADDL_asimddiff_L
                        when ('0', '0001') => __encoding A64_simd_dp_asimddiff_SADDW_asimddiff_W // SADDW_asimddiff_W
                        when ('0', '0010') => __encoding A64_simd_dp_asimddiff_SSUBL_asimddiff_L // SSUBL_asimddiff_L
                        when ('0', '0011') => __encoding A64_simd_dp_asimddiff_SSUBW_asimddiff_W // SSUBW_asimddiff_W
                        when ('0', '0100') => __encoding A64_simd_dp_asimddiff_ADDHN_asimddiff_N // ADDHN_asimddiff_N
                        when ('0', '0101') => __encoding A64_simd_dp_asimddiff_SABAL_asimddiff_L // SABAL_asimddiff_L
                        when ('0', '0110') => __encoding A64_simd_dp_asimddiff_SUBHN_asimddiff_N // SUBHN_asimddiff_N
                        when ('0', '0111') => __encoding A64_simd_dp_asimddiff_SABDL_asimddiff_L // SABDL_asimddiff_L
                        when ('0', '1000') => __encoding A64_simd_dp_asimddiff_SMLAL_asimddiff_L // SMLAL_asimddiff_L
                        when ('0', '1001') => __encoding A64_simd_dp_asimddiff_SQDMLAL_asimddiff_L // SQDMLAL_asimddiff_L
                        when ('0', '1010') => __encoding A64_simd_dp_asimddiff_SMLSL_asimddiff_L // SMLSL_asimddiff_L
                        when ('0', '1011') => __encoding A64_simd_dp_asimddiff_SQDMLSL_asimddiff_L // SQDMLSL_asimddiff_L
                        when ('0', '1100') => __encoding A64_simd_dp_asimddiff_SMULL_asimddiff_L // SMULL_asimddiff_L
                        when ('0', '1101') => __encoding A64_simd_dp_asimddiff_SQDMULL_asimddiff_L // SQDMULL_asimddiff_L
                        when ('0', '1110') => __encoding A64_simd_dp_asimddiff_PMULL_asimddiff_L // PMULL_asimddiff_L
                        when ('0', '1111') => __UNALLOCATED
                        when ('1', '0000') => __encoding A64_simd_dp_asimddiff_UADDL_asimddiff_L // UADDL_asimddiff_L
                        when ('1', '0001') => __encoding A64_simd_dp_asimddiff_UADDW_asimddiff_W // UADDW_asimddiff_W
                        when ('1', '0010') => __encoding A64_simd_dp_asimddiff_USUBL_asimddiff_L // USUBL_asimddiff_L
                        when ('1', '0011') => __encoding A64_simd_dp_asimddiff_USUBW_asimddiff_W // USUBW_asimddiff_W
                        when ('1', '0100') => __encoding A64_simd_dp_asimddiff_RADDHN_asimddiff_N // RADDHN_asimddiff_N
                        when ('1', '0101') => __encoding A64_simd_dp_asimddiff_UABAL_asimddiff_L // UABAL_asimddiff_L
                        when ('1', '0110') => __encoding A64_simd_dp_asimddiff_RSUBHN_asimddiff_N // RSUBHN_asimddiff_N
                        when ('1', '0111') => __encoding A64_simd_dp_asimddiff_UABDL_asimddiff_L // UABDL_asimddiff_L
                        when ('1', '1xx1') => __UNALLOCATED
                        when ('1', '1000') => __encoding A64_simd_dp_asimddiff_UMLAL_asimddiff_L // UMLAL_asimddiff_L
                        when ('1', '1010') => __encoding A64_simd_dp_asimddiff_UMLSL_asimddiff_L // UMLSL_asimddiff_L
                        when ('1', '1100') => __encoding A64_simd_dp_asimddiff_UMULL_asimddiff_L // UMULL_asimddiff_L
                        when ('1', '1110') => __UNALLOCATED
                when ('0xx0', _, '0x', 'x1xx', 'xxxxxxxx1', _) => // asimdsame
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, size, opcode) of
                        when ('0', _, '00000') => __encoding A64_simd_dp_asimdsame_SHADD_asimdsame_only // SHADD_asimdsame_only
                        when ('0', _, '00001') => __encoding A64_simd_dp_asimdsame_SQADD_asimdsame_only // SQADD_asimdsame_only
                        when ('0', _, '00010') => __encoding A64_simd_dp_asimdsame_SRHADD_asimdsame_only // SRHADD_asimdsame_only
                        when ('0', _, '00100') => __encoding A64_simd_dp_asimdsame_SHSUB_asimdsame_only // SHSUB_asimdsame_only
                        when ('0', _, '00101') => __encoding A64_simd_dp_asimdsame_SQSUB_asimdsame_only // SQSUB_asimdsame_only
                        when ('0', _, '00110') => __encoding A64_simd_dp_asimdsame_CMGT_asimdsame_only // CMGT_asimdsame_only
                        when ('0', _, '00111') => __encoding A64_simd_dp_asimdsame_CMGE_asimdsame_only // CMGE_asimdsame_only
                        when ('0', _, '01000') => __encoding A64_simd_dp_asimdsame_SSHL_asimdsame_only // SSHL_asimdsame_only
                        when ('0', _, '01001') => __encoding A64_simd_dp_asimdsame_SQSHL_asimdsame_only // SQSHL_asimdsame_only
                        when ('0', _, '01010') => __encoding A64_simd_dp_asimdsame_SRSHL_asimdsame_only // SRSHL_asimdsame_only
                        when ('0', _, '01011') => __encoding A64_simd_dp_asimdsame_SQRSHL_asimdsame_only // SQRSHL_asimdsame_only
                        when ('0', _, '01100') => __encoding A64_simd_dp_asimdsame_SMAX_asimdsame_only // SMAX_asimdsame_only
                        when ('0', _, '01101') => __encoding A64_simd_dp_asimdsame_SMIN_asimdsame_only // SMIN_asimdsame_only
                        when ('0', _, '01110') => __encoding A64_simd_dp_asimdsame_SABD_asimdsame_only // SABD_asimdsame_only
                        when ('0', _, '01111') => __encoding A64_simd_dp_asimdsame_SABA_asimdsame_only // SABA_asimdsame_only
                        when ('0', _, '10000') => __encoding A64_simd_dp_asimdsame_ADD_asimdsame_only // ADD_asimdsame_only
                        when ('0', _, '10001') => __encoding A64_simd_dp_asimdsame_CMTST_asimdsame_only // CMTST_asimdsame_only
                        when ('0', _, '10010') => __encoding A64_simd_dp_asimdsame_MLA_asimdsame_only // MLA_asimdsame_only
                        when ('0', _, '10011') => __encoding A64_simd_dp_asimdsame_MUL_asimdsame_only // MUL_asimdsame_only
                        when ('0', _, '10100') => __encoding A64_simd_dp_asimdsame_SMAXP_asimdsame_only // SMAXP_asimdsame_only
                        when ('0', _, '10101') => __encoding A64_simd_dp_asimdsame_SMINP_asimdsame_only // SMINP_asimdsame_only
                        when ('0', _, '10110') => __encoding A64_simd_dp_asimdsame_SQDMULH_asimdsame_only // SQDMULH_asimdsame_only
                        when ('0', _, '10111') => __encoding A64_simd_dp_asimdsame_ADDP_asimdsame_only // ADDP_asimdsame_only
                        when ('0', '1x', '11011') => __encoding A64_simd_dp_asimdsame_FAMAX_asimdsame_only // FAMAX_asimdsame_only
                        when ('0', 'x1', '11101') => __UNALLOCATED
                        when ('0', '0x', '11000') => __encoding A64_simd_dp_asimdsame_FMAXNM_asimdsame_only // FMAXNM_asimdsame_only
                        when ('0', '0x', '11001') => __encoding A64_simd_dp_asimdsame_FMLA_asimdsame_only // FMLA_asimdsame_only
                        when ('0', '0x', '11010') => __encoding A64_simd_dp_asimdsame_FADD_asimdsame_only // FADD_asimdsame_only
                        when ('0', '0x', '11011') => __encoding A64_simd_dp_asimdsame_FMULX_asimdsame_only // FMULX_asimdsame_only
                        when ('0', '0x', '11100') => __encoding A64_simd_dp_asimdsame_FCMEQ_asimdsame_only // FCMEQ_asimdsame_only
                        when ('0', '0x', '11110') => __encoding A64_simd_dp_asimdsame_FMAX_asimdsame_only // FMAX_asimdsame_only
                        when ('0', '0x', '11111') => __encoding A64_simd_dp_asimdsame_FRECPS_asimdsame_only // FRECPS_asimdsame_only
                        when ('0', '00', '00011') => __encoding A64_simd_dp_asimdsame_AND_asimdsame_only // AND_asimdsame_only
                        when ('0', '00', '11101') => __encoding A64_simd_dp_asimdsame_FMLAL_asimdsame_F // FMLAL_asimdsame_F
                        when ('0', '01', '00011') => __encoding A64_simd_dp_asimdsame_BIC_asimdsame_only // BIC_asimdsame_only
                        when ('0', '1x', '11000') => __encoding A64_simd_dp_asimdsame_FMINNM_asimdsame_only // FMINNM_asimdsame_only
                        when ('0', '1x', '11001') => __encoding A64_simd_dp_asimdsame_FMLS_asimdsame_only // FMLS_asimdsame_only
                        when ('0', '1x', '11010') => __encoding A64_simd_dp_asimdsame_FSUB_asimdsame_only // FSUB_asimdsame_only
                        when ('0', '1x', '11100') => __UNALLOCATED
                        when ('0', '1x', '11110') => __encoding A64_simd_dp_asimdsame_FMIN_asimdsame_only // FMIN_asimdsame_only
                        when ('0', '1x', '11111') => __encoding A64_simd_dp_asimdsame_FRSQRTS_asimdsame_only // FRSQRTS_asimdsame_only
                        when ('0', '10', '00011') => __encoding A64_simd_dp_asimdsame_ORR_asimdsame_only // ORR_asimdsame_only
                        when ('0', '10', '11101') => __encoding A64_simd_dp_asimdsame_FMLSL_asimdsame_F // FMLSL_asimdsame_F
                        when ('0', '11', '00011') => __encoding A64_simd_dp_asimdsame_ORN_asimdsame_only // ORN_asimdsame_only
                        when ('1', _, '00000') => __encoding A64_simd_dp_asimdsame_UHADD_asimdsame_only // UHADD_asimdsame_only
                        when ('1', _, '00001') => __encoding A64_simd_dp_asimdsame_UQADD_asimdsame_only // UQADD_asimdsame_only
                        when ('1', _, '00010') => __encoding A64_simd_dp_asimdsame_URHADD_asimdsame_only // URHADD_asimdsame_only
                        when ('1', _, '00100') => __encoding A64_simd_dp_asimdsame_UHSUB_asimdsame_only // UHSUB_asimdsame_only
                        when ('1', _, '00101') => __encoding A64_simd_dp_asimdsame_UQSUB_asimdsame_only // UQSUB_asimdsame_only
                        when ('1', _, '00110') => __encoding A64_simd_dp_asimdsame_CMHI_asimdsame_only // CMHI_asimdsame_only
                        when ('1', _, '00111') => __encoding A64_simd_dp_asimdsame_CMHS_asimdsame_only // CMHS_asimdsame_only
                        when ('1', _, '01000') => __encoding A64_simd_dp_asimdsame_USHL_asimdsame_only // USHL_asimdsame_only
                        when ('1', _, '01001') => __encoding A64_simd_dp_asimdsame_UQSHL_asimdsame_only // UQSHL_asimdsame_only
                        when ('1', _, '01010') => __encoding A64_simd_dp_asimdsame_URSHL_asimdsame_only // URSHL_asimdsame_only
                        when ('1', _, '01011') => __encoding A64_simd_dp_asimdsame_UQRSHL_asimdsame_only // UQRSHL_asimdsame_only
                        when ('1', _, '01100') => __encoding A64_simd_dp_asimdsame_UMAX_asimdsame_only // UMAX_asimdsame_only
                        when ('1', _, '01101') => __encoding A64_simd_dp_asimdsame_UMIN_asimdsame_only // UMIN_asimdsame_only
                        when ('1', _, '01110') => __encoding A64_simd_dp_asimdsame_UABD_asimdsame_only // UABD_asimdsame_only
                        when ('1', _, '01111') => __encoding A64_simd_dp_asimdsame_UABA_asimdsame_only // UABA_asimdsame_only
                        when ('1', _, '10000') => __encoding A64_simd_dp_asimdsame_SUB_asimdsame_only // SUB_asimdsame_only
                        when ('1', _, '10001') => __encoding A64_simd_dp_asimdsame_CMEQ_asimdsame_only // CMEQ_asimdsame_only
                        when ('1', _, '10010') => __encoding A64_simd_dp_asimdsame_MLS_asimdsame_only // MLS_asimdsame_only
                        when ('1', _, '10011') => __encoding A64_simd_dp_asimdsame_PMUL_asimdsame_only // PMUL_asimdsame_only
                        when ('1', _, '10100') => __encoding A64_simd_dp_asimdsame_UMAXP_asimdsame_only // UMAXP_asimdsame_only
                        when ('1', _, '10101') => __encoding A64_simd_dp_asimdsame_UMINP_asimdsame_only // UMINP_asimdsame_only
                        when ('1', _, '10110') => __encoding A64_simd_dp_asimdsame_SQRDMULH_asimdsame_only // SQRDMULH_asimdsame_only
                        when ('1', _, '10111') => __UNALLOCATED
                        when ('1', '1x', '11011') => __encoding A64_simd_dp_asimdsame_FAMIN_asimdsame_only // FAMIN_asimdsame_only
                        when ('1', '1x', '11111') => __encoding A64_simd_dp_asimdsame_FSCALE_asimdsame_only // FSCALE_asimdsame_only
                        when ('1', 'x1', '11001') => __UNALLOCATED
                        when ('1', '0x', '11000') => __encoding A64_simd_dp_asimdsame_FMAXNMP_asimdsame_only // FMAXNMP_asimdsame_only
                        when ('1', '0x', '11010') => __encoding A64_simd_dp_asimdsame_FADDP_asimdsame_only // FADDP_asimdsame_only
                        when ('1', '0x', '11011') => __encoding A64_simd_dp_asimdsame_FMUL_asimdsame_only // FMUL_asimdsame_only
                        when ('1', '0x', '11100') => __encoding A64_simd_dp_asimdsame_FCMGE_asimdsame_only // FCMGE_asimdsame_only
                        when ('1', '0x', '11101') => __encoding A64_simd_dp_asimdsame_FACGE_asimdsame_only // FACGE_asimdsame_only
                        when ('1', '0x', '11110') => __encoding A64_simd_dp_asimdsame_FMAXP_asimdsame_only // FMAXP_asimdsame_only
                        when ('1', '0x', '11111') => __encoding A64_simd_dp_asimdsame_FDIV_asimdsame_only // FDIV_asimdsame_only
                        when ('1', '00', '00011') => __encoding A64_simd_dp_asimdsame_EOR_asimdsame_only // EOR_asimdsame_only
                        when ('1', '00', '11001') => __encoding A64_simd_dp_asimdsame_FMLAL2_asimdsame_F // FMLAL2_asimdsame_F
                        when ('1', '01', '00011') => __encoding A64_simd_dp_asimdsame_BSL_asimdsame_only // BSL_asimdsame_only
                        when ('1', '1x', '11000') => __encoding A64_simd_dp_asimdsame_FMINNMP_asimdsame_only // FMINNMP_asimdsame_only
                        when ('1', '1x', '11010') => __encoding A64_simd_dp_asimdsame_FABD_asimdsame_only // FABD_asimdsame_only
                        when ('1', '1x', '11100') => __encoding A64_simd_dp_asimdsame_FCMGT_asimdsame_only // FCMGT_asimdsame_only
                        when ('1', '1x', '11101') => __encoding A64_simd_dp_asimdsame_FACGT_asimdsame_only // FACGT_asimdsame_only
                        when ('1', '1x', '11110') => __encoding A64_simd_dp_asimdsame_FMINP_asimdsame_only // FMINP_asimdsame_only
                        when ('1', '10', '00011') => __encoding A64_simd_dp_asimdsame_BIT_asimdsame_only // BIT_asimdsame_only
                        when ('1', '10', '11001') => __encoding A64_simd_dp_asimdsame_FMLSL2_asimdsame_F // FMLSL2_asimdsame_F
                        when ('1', '11', '00011') => __encoding A64_simd_dp_asimdsame_BIF_asimdsame_only // BIF_asimdsame_only
                when ('0xx0', _, '10', '0000', 'xxxxxxxx1', _) => // asimdimm
                    __field Q 30 +: 1
                    __field op 29 +: 1
                    __field a 18 +: 1
                    __field b 17 +: 1
                    __field c 16 +: 1
                    __field cmode 12 +: 4
                    __field o2 11 +: 1
                    __field d 9 +: 1
                    __field e 8 +: 1
                    __field f 7 +: 1
                    __field g 6 +: 1
                    __field h 5 +: 1
                    __field Rd 0 +: 5
                    case (Q, op, cmode, o2) of
                        when (_, '0', !'1111', '1') => __UNALLOCATED
                        when (_, '0', '0xx0', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_L_sl
                        when (_, '0', '0xx1', '0') => __encoding A64_simd_dp_asimdimm_ORR_asimdimm_L_hl // ORR_asimdimm_L_sl
                        when (_, '0', '10x0', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_L_hl
                        when (_, '0', '10x1', '0') => __encoding A64_simd_dp_asimdimm_ORR_asimdimm_L_hl // ORR_asimdimm_L_hl
                        when (_, '0', '110x', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_M_sm
                        when (_, '0', '1110', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_N_b
                        when (_, '0', '1111', '0') => __encoding A64_simd_dp_asimdimm_FMOV_asimdimm_S_s // FMOV_asimdimm_S_s
                        when (_, '0', '1111', '1') => __encoding A64_simd_dp_asimdimm_FMOV_asimdimm_H_h // FMOV_asimdimm_H_h
                        when (_, '1', _, '1') => __UNALLOCATED
                        when (_, '1', '0xx0', '0') => __encoding A64_simd_dp_asimdimm_MVNI_asimdimm_L_hl // MVNI_asimdimm_L_sl
                        when (_, '1', '0xx1', '0') => __encoding A64_simd_dp_asimdimm_BIC_asimdimm_L_hl // BIC_asimdimm_L_sl
                        when (_, '1', '10x0', '0') => __encoding A64_simd_dp_asimdimm_MVNI_asimdimm_L_hl // MVNI_asimdimm_L_hl
                        when (_, '1', '10x1', '0') => __encoding A64_simd_dp_asimdimm_BIC_asimdimm_L_hl // BIC_asimdimm_L_hl
                        when (_, '1', '110x', '0') => __encoding A64_simd_dp_asimdimm_MVNI_asimdimm_L_hl // MVNI_asimdimm_M_sm
                        when ('0', '1', '1110', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_D_ds
                        when ('0', '1', '1111', '0') => __UNALLOCATED
                        when ('1', '1', '1110', '0') => __encoding A64_simd_dp_asimdimm_MOVI_asimdimm_N_b // MOVI_asimdimm_D2_d
                        when ('1', '1', '1111', '0') => __encoding A64_simd_dp_asimdimm_FMOV_asimdimm_S_s // FMOV_asimdimm_D2_d
                when ('0xx0', _, '10', !'0000', 'xxxxxxxx1', _) => // asimdshf
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field immh 19 +: 4
                    __field immb 16 +: 3
                    __field opcode 11 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (U, immh, opcode) of
                        when (_, !'0000', '0xxx1') => __UNALLOCATED
                        when (_, !'0000', '1x110') => __UNALLOCATED
                        when (_, !'0000', '101x1') => __UNALLOCATED
                        when (_, !'0000', '110xx') => __UNALLOCATED
                        when (_, !'0000', '11101') => __UNALLOCATED
                        when ('0', !'0000', '00000') => __encoding A64_simd_dp_asimdshf_SSHR_asimdshf_R // SSHR_asimdshf_R
                        when ('0', !'0000', '00010') => __encoding A64_simd_dp_asimdshf_SSRA_asimdshf_R // SSRA_asimdshf_R
                        when ('0', !'0000', '00100') => __encoding A64_simd_dp_asimdshf_SRSHR_asimdshf_R // SRSHR_asimdshf_R
                        when ('0', !'0000', '00110') => __encoding A64_simd_dp_asimdshf_SRSRA_asimdshf_R // SRSRA_asimdshf_R
                        when ('0', !'0000', '01x00') => __UNALLOCATED
                        when ('0', !'0000', '01010') => __encoding A64_simd_dp_asimdshf_SHL_asimdshf_R // SHL_asimdshf_R
                        when ('0', !'0000', '01110') => __encoding A64_simd_dp_asimdshf_SQSHL_asimdshf_R // SQSHL_asimdshf_R
                        when ('0', !'0000', '10000') => __encoding A64_simd_dp_asimdshf_SHRN_asimdshf_N // SHRN_asimdshf_N
                        when ('0', !'0000', '10001') => __encoding A64_simd_dp_asimdshf_RSHRN_asimdshf_N // RSHRN_asimdshf_N
                        when ('0', !'0000', '10010') => __encoding A64_simd_dp_asimdshf_SQSHRN_asimdshf_N // SQSHRN_asimdshf_N
                        when ('0', !'0000', '10011') => __encoding A64_simd_dp_asimdshf_SQRSHRN_asimdshf_N // SQRSHRN_asimdshf_N
                        when ('0', !'0000', '10100') => __encoding A64_simd_dp_asimdshf_SSHLL_asimdshf_L // SSHLL_asimdshf_L
                        when ('0', !'0000', '11100') => __encoding A64_simd_dp_asimdshf_SCVTF_asimdshf_C // SCVTF_asimdshf_C
                        when ('0', !'0000', '11111') => __encoding A64_simd_dp_asimdshf_FCVTZS_asimdshf_C // FCVTZS_asimdshf_C
                        when ('1', !'0000', '00000') => __encoding A64_simd_dp_asimdshf_USHR_asimdshf_R // USHR_asimdshf_R
                        when ('1', !'0000', '00010') => __encoding A64_simd_dp_asimdshf_USRA_asimdshf_R // USRA_asimdshf_R
                        when ('1', !'0000', '00100') => __encoding A64_simd_dp_asimdshf_URSHR_asimdshf_R // URSHR_asimdshf_R
                        when ('1', !'0000', '00110') => __encoding A64_simd_dp_asimdshf_URSRA_asimdshf_R // URSRA_asimdshf_R
                        when ('1', !'0000', '01000') => __encoding A64_simd_dp_asimdshf_SRI_asimdshf_R // SRI_asimdshf_R
                        when ('1', !'0000', '01010') => __encoding A64_simd_dp_asimdshf_SLI_asimdshf_R // SLI_asimdshf_R
                        when ('1', !'0000', '01100') => __encoding A64_simd_dp_asimdshf_SQSHLU_asimdshf_R // SQSHLU_asimdshf_R
                        when ('1', !'0000', '01110') => __encoding A64_simd_dp_asimdshf_UQSHL_asimdshf_R // UQSHL_asimdshf_R
                        when ('1', !'0000', '10000') => __encoding A64_simd_dp_asimdshf_SQSHRUN_asimdshf_N // SQSHRUN_asimdshf_N
                        when ('1', !'0000', '10001') => __encoding A64_simd_dp_asimdshf_SQRSHRUN_asimdshf_N // SQRSHRUN_asimdshf_N
                        when ('1', !'0000', '10010') => __encoding A64_simd_dp_asimdshf_UQSHRN_asimdshf_N // UQSHRN_asimdshf_N
                        when ('1', !'0000', '10011') => __encoding A64_simd_dp_asimdshf_UQRSHRN_asimdshf_N // UQRSHRN_asimdshf_N
                        when ('1', !'0000', '10100') => __encoding A64_simd_dp_asimdshf_USHLL_asimdshf_L // USHLL_asimdshf_L
                        when ('1', !'0000', '11100') => __encoding A64_simd_dp_asimdshf_UCVTF_asimdshf_C // UCVTF_asimdshf_C
                        when ('1', !'0000', '11111') => __encoding A64_simd_dp_asimdshf_FCVTZU_asimdshf_C // FCVTZU_asimdshf_C
                when ('0xx0', _, '1x', _, 'xxxxxxxx0', _) => // asimdelem
                    __field Q 30 +: 1
                    __field U 29 +: 1
                    __field size 22 +: 2
                    __field L 21 +: 1
                    __field M 20 +: 1
                    __field Rm 16 +: 4
                    __field opcode 12 +: 4
                    __field H 11 +: 1
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Q, U, size, opcode) of
                        when (_, _, '01', '1001') => __UNALLOCATED
                        when (_, '0', _, '0010') => __encoding A64_simd_dp_asimdelem_SMLAL_asimdelem_L // SMLAL_asimdelem_L
                        when (_, '0', _, '0011') => __encoding A64_simd_dp_asimdelem_SQDMLAL_asimdelem_L // SQDMLAL_asimdelem_L
                        when (_, '0', !'10', '0100') => __UNALLOCATED
                        when (_, '0', _, '0110') => __encoding A64_simd_dp_asimdelem_SMLSL_asimdelem_L // SMLSL_asimdelem_L
                        when (_, '0', _, '0111') => __encoding A64_simd_dp_asimdelem_SQDMLSL_asimdelem_L // SQDMLSL_asimdelem_L
                        when (_, '0', _, '1000') => __encoding A64_simd_dp_asimdelem_MUL_asimdelem_R // MUL_asimdelem_R
                        when (_, '0', _, '1010') => __encoding A64_simd_dp_asimdelem_SMULL_asimdelem_L // SMULL_asimdelem_L
                        when (_, '0', _, '1011') => __encoding A64_simd_dp_asimdelem_SQDMULL_asimdelem_L // SQDMULL_asimdelem_L
                        when (_, '0', _, '1100') => __encoding A64_simd_dp_asimdelem_SQDMULH_asimdelem_R // SQDMULH_asimdelem_R
                        when (_, '0', _, '1101') => __encoding A64_simd_dp_asimdelem_SQRDMULH_asimdelem_R // SQRDMULH_asimdelem_R
                        when (_, '0', _, '1110') => __encoding A64_simd_dp_asimdelem_SDOT_asimdelem_D // SDOT_asimdelem_D
                        when (_, '0', '00', '0000') => __encoding A64_simd_dp_asimdelem_FDOT_asimdelem_D // FDOT_asimdelem_D
                        when (_, '0', '00', '0001') => __encoding A64_simd_dp_asimdelem_FMLA_asimdelem_RH_H // FMLA_asimdelem_RH_H
                        when (_, '0', '00', '0101') => __encoding A64_simd_dp_asimdelem_FMLS_asimdelem_RH_H // FMLS_asimdelem_RH_H
                        when (_, '0', '00', '1001') => __encoding A64_simd_dp_asimdelem_FMUL_asimdelem_RH_H // FMUL_asimdelem_RH_H
                        when (_, '0', '00', '1111') => __encoding A64_simd_dp_asimdelem_SUDOT_asimdelem_D // SUDOT_asimdelem_D
                        when (_, '0', '01', '0x01') => __UNALLOCATED
                        when (_, '0', '01', '0000') => __encoding A64_simd_dp_asimdelem_FDOT_asimdelem_G // FDOT_asimdelem_G
                        when (_, '0', '01', '1111') => __encoding A64_simd_dp_asimdelem_BFDOT_asimdelem_E // BFDOT_asimdelem_E
                        when (_, '0', '1x', '0001') => __encoding A64_simd_dp_asimdelem_FMLA_asimdelem_R_SD // FMLA_asimdelem_R_SD
                        when (_, '0', '1x', '0101') => __encoding A64_simd_dp_asimdelem_FMLS_asimdelem_R_SD // FMLS_asimdelem_R_SD
                        when (_, '0', '1x', '1001') => __encoding A64_simd_dp_asimdelem_FMUL_asimdelem_R_SD // FMUL_asimdelem_R_SD
                        when (_, '0', '10', '0000') => __encoding A64_simd_dp_asimdelem_FMLAL_asimdelem_LH // FMLAL_asimdelem_LH
                        when (_, '0', '10', '0100') => __encoding A64_simd_dp_asimdelem_FMLSL_asimdelem_LH // FMLSL_asimdelem_LH
                        when (_, '0', '10', '1111') => __encoding A64_simd_dp_asimdelem_USDOT_asimdelem_D // USDOT_asimdelem_D
                        when (_, '0', '11', '1111') => __encoding A64_simd_dp_asimdelem_BFMLAL_asimdelem_F // BFMLAL_asimdelem_F
                        when (_, '1', _, '0xx1') => __encoding A64_simd_dp_asimdelem_FCMLA_advsimd_elt // FCMLA_advsimd_elt
                        when (_, '1', _, '0000') => __encoding A64_simd_dp_asimdelem_MLA_asimdelem_R // MLA_asimdelem_R
                        when (_, '1', _, '0010') => __encoding A64_simd_dp_asimdelem_UMLAL_asimdelem_L // UMLAL_asimdelem_L
                        when (_, '1', _, '0100') => __encoding A64_simd_dp_asimdelem_MLS_asimdelem_R // MLS_asimdelem_R
                        when (_, '1', _, '0110') => __encoding A64_simd_dp_asimdelem_UMLSL_asimdelem_L // UMLSL_asimdelem_L
                        when (_, '1', _, '1010') => __encoding A64_simd_dp_asimdelem_UMULL_asimdelem_L // UMULL_asimdelem_L
                        when (_, '1', _, '1011') => __UNALLOCATED
                        when (_, '1', _, '1101') => __encoding A64_simd_dp_asimdelem_SQRDMLAH_asimdelem_R // SQRDMLAH_asimdelem_R
                        when (_, '1', _, '1110') => __encoding A64_simd_dp_asimdelem_UDOT_asimdelem_D // UDOT_asimdelem_D
                        when (_, '1', _, '1111') => __encoding A64_simd_dp_asimdelem_SQRDMLSH_asimdelem_R // SQRDMLSH_asimdelem_R
                        when (_, '1', '0x', '1100') => __UNALLOCATED
                        when (_, '1', '00', '1001') => __encoding A64_simd_dp_asimdelem_FMULX_asimdelem_RH_H // FMULX_asimdelem_RH_H
                        when (_, '1', '1x', '1001') => __encoding A64_simd_dp_asimdelem_FMULX_asimdelem_R_SD // FMULX_asimdelem_R_SD
                        when (_, '1', '10', '1000') => __encoding A64_simd_dp_asimdelem_FMLAL2_asimdelem_LH // FMLAL2_asimdelem_LH
                        when (_, '1', '10', '1100') => __encoding A64_simd_dp_asimdelem_FMLSL2_asimdelem_LH // FMLSL2_asimdelem_LH
                        when (_, '1', '11', '1x00') => __UNALLOCATED
                        when ('0', '0', '11', '0000') => __encoding A64_simd_dp_asimdelem_FMLALB_asimdelem_H // FMLALB_asimdelem_H
                        when ('0', '1', '00', '1000') => __encoding A64_simd_dp_asimdelem_FMLALLBB_asimdelem_J // FMLALLBB_asimdelem_J
                        when ('0', '1', '01', '1000') => __encoding A64_simd_dp_asimdelem_FMLALLBB_asimdelem_J // FMLALLBT_asimdelem_J
                        when ('1', '0', '11', '0000') => __encoding A64_simd_dp_asimdelem_FMLALB_asimdelem_H // FMLALT_asimdelem_H
                        when ('1', '1', '00', '1000') => __encoding A64_simd_dp_asimdelem_FMLALLBB_asimdelem_J // FMLALLTB_asimdelem_J
                        when ('1', '1', '01', '1000') => __encoding A64_simd_dp_asimdelem_FMLALLBB_asimdelem_J // FMLALLTT_asimdelem_J
                when ('10x0', _, _, _, _, _) => __UNPREDICTABLE
                when ('1100', _, '00', '0xxx', 'xxx1xxxxx', _) => __UNPREDICTABLE
                when ('1100', _, '00', '10xx', 'xxx10xxxx', _) => // crypto3_imm2
                    __field Rm 16 +: 5
                    __field imm2 12 +: 2
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('00') => __encoding A64_simd_dp_crypto3_imm2_SM3TT1A_VVV4_crypto3_imm2 // SM3TT1A_VVV4_crypto3_imm2
                        when ('01') => __encoding A64_simd_dp_crypto3_imm2_SM3TT1B_VVV4_crypto3_imm2 // SM3TT1B_VVV4_crypto3_imm2
                        when ('10') => __encoding A64_simd_dp_crypto3_imm2_SM3TT2A_VVV4_crypto3_imm2 // SM3TT2A_VVV4_crypto3_imm2
                        when ('11') => __encoding A64_simd_dp_crypto3_imm2_SM3TT2B_VVV_crypto3_imm2 // SM3TT2B_VVV_crypto3_imm2
                when ('1100', _, '00', '10xx', 'xxx11xxxx', _) => __UNPREDICTABLE
                when ('1100', _, '00', '11xx', 'xxx1x00xx', _) => // cryptosha512_3
                    __field Rm 16 +: 5
                    __field O 14 +: 1
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (O, opcode) of
                        when ('0', '00') => __encoding A64_simd_dp_cryptosha512_3_SHA512H_QQV_cryptosha512_3 // SHA512H_QQV_cryptosha512_3
                        when ('0', '01') => __encoding A64_simd_dp_cryptosha512_3_SHA512H2_QQV_cryptosha512_3 // SHA512H2_QQV_cryptosha512_3
                        when ('0', '10') => __encoding A64_simd_dp_cryptosha512_3_SHA512SU1_VVV2_cryptosha512_3 // SHA512SU1_VVV2_cryptosha512_3
                        when ('0', '11') => __encoding A64_simd_dp_cryptosha512_3_RAX1_VVV2_cryptosha512_3 // RAX1_VVV2_cryptosha512_3
                        when ('1', '00') => __encoding A64_simd_dp_cryptosha512_3_SM3PARTW1_VVV4_cryptosha512_3 // SM3PARTW1_VVV4_cryptosha512_3
                        when ('1', '01') => __encoding A64_simd_dp_cryptosha512_3_SM3PARTW2_VVV4_cryptosha512_3 // SM3PARTW2_VVV4_cryptosha512_3
                        when ('1', '10') => __encoding A64_simd_dp_cryptosha512_3_SM4EKEY_VVV4_cryptosha512_3 // SM4EKEY_VVV4_cryptosha512_3
                        when ('1', '11') => __UNALLOCATED
                when ('1100', _, '00', '11xx', 'xxx1x01xx', _) => __UNPREDICTABLE
                when ('1100', _, '00', '11xx', 'xxx1x1xxx', _) => __UNPREDICTABLE
                when ('1100', _, '00', _, 'xxx0xxxxx', _) => // crypto4
                    __field Op0 21 +: 2
                    __field Rm 16 +: 5
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (Op0) of
                        when ('00') => __encoding A64_simd_dp_crypto4_EOR3_VVV16_crypto4 // EOR3_VVV16_crypto4
                        when ('01') => __encoding A64_simd_dp_crypto4_BCAX_VVV16_crypto4 // BCAX_VVV16_crypto4
                        when ('10') => __encoding A64_simd_dp_crypto4_SM3SS1_VVV4_crypto4 // SM3SS1_VVV4_crypto4
                        when ('11') => __UNALLOCATED
                when ('1100', _, '01', '00xx', _, _) => // crypto3_imm6
                    __field Rm 16 +: 5
                    __field imm6 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case () of
                        when () => __encoding A64_simd_dp_crypto3_imm6_XAR_VVV2_crypto3_imm6 // XAR_VVV2_crypto3_imm6
                when ('1100', _, '01', '1000', '0000xxxxx', _) => __UNPREDICTABLE
                when ('1100', _, '01', '1000', '0001000xx', _) => // cryptosha512_2
                    __field opcode 10 +: 2
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (opcode) of
                        when ('00') => __encoding A64_simd_dp_cryptosha512_2_SHA512SU0_VV2_cryptosha512_2 // SHA512SU0_VV2_cryptosha512_2
                        when ('01') => __encoding A64_simd_dp_cryptosha512_2_SM4E_VV4_cryptosha512_2 // SM4E_VV4_cryptosha512_2
                        when ('1x') => __UNALLOCATED
                when ('1100', _, '01', '1000', '0001100xx', _) => __UNPREDICTABLE
                when ('1100', _, '01', '1000', '0001x01xx', _) => __UNPREDICTABLE
                when ('1100', _, '01', '1000', '0001x1xxx', _) => __UNPREDICTABLE
                when ('1100', _, '01', '1000', '001xxxxxx', _) => __UNPREDICTABLE
                when ('1100', _, '01', '1000', '01xxxxxxx', _) => __UNPREDICTABLE
                when ('1100', _, '01', '1000', '1xxxxxxxx', _) => __UNPREDICTABLE
                when ('1100', _, '01', '1001', _, _) => __UNPREDICTABLE
                when ('1100', _, '01', '101x', _, _) => __UNPREDICTABLE
                when ('1100', _, '01', 'x1xx', _, _) => __UNPREDICTABLE
                when ('1100', _, '1x', _, _, _) => __UNPREDICTABLE
                when ('1110', _, _, _, _, _) => __UNPREDICTABLE
                when ('11x1', _, _, _, _, _) => __UNPREDICTABLE
                when ('x0x1', _, '0x', 'x0xx', _, _) => // float2fix
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field rmode 19 +: 2
                    __field opcode 16 +: 3
                    __field scale 10 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, ftype, rmode, opcode) of
                        when (_, '0', _, _, '1xx') => __UNALLOCATED
                        when (_, '0', !'10', 'x1', '01x') => __UNALLOCATED
                        when (_, '0', !'10', '0x', '00x') => __UNALLOCATED
                        when (_, '0', !'10', '10', '0xx') => __UNALLOCATED
                        when (_, '0', '10', _, '0xx') => __UNALLOCATED
                        when (_, '1', _, _, _) => __UNALLOCATED
                        when ('0', '0', '00', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_S32_float2fix
                        when ('0', '0', '00', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_S32_float2fix
                        when ('0', '0', '00', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_32S_float2fix
                        when ('0', '0', '00', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_32S_float2fix
                        when ('0', '0', '01', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_D32_float2fix
                        when ('0', '0', '01', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_D32_float2fix
                        when ('0', '0', '01', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_32D_float2fix
                        when ('0', '0', '01', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_32D_float2fix
                        when ('0', '0', '11', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_H32_float2fix
                        when ('0', '0', '11', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_H32_float2fix
                        when ('0', '0', '11', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_32H_float2fix
                        when ('0', '0', '11', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_32H_float2fix
                        when ('1', '0', '00', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_S64_float2fix
                        when ('1', '0', '00', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_S64_float2fix
                        when ('1', '0', '00', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_64S_float2fix
                        when ('1', '0', '00', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_64S_float2fix
                        when ('1', '0', '01', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_D64_float2fix
                        when ('1', '0', '01', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_D64_float2fix
                        when ('1', '0', '01', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_64D_float2fix
                        when ('1', '0', '01', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_64D_float2fix
                        when ('1', '0', '11', '00', '010') => __encoding A64_simd_dp_float2fix_SCVTF_H32_float2fix // SCVTF_H64_float2fix
                        when ('1', '0', '11', '00', '011') => __encoding A64_simd_dp_float2fix_UCVTF_H32_float2fix // UCVTF_H64_float2fix
                        when ('1', '0', '11', '11', '000') => __encoding A64_simd_dp_float2fix_FCVTZS_32H_float2fix // FCVTZS_64H_float2fix
                        when ('1', '0', '11', '11', '001') => __encoding A64_simd_dp_float2fix_FCVTZU_32H_float2fix // FCVTZU_64H_float2fix
                when ('x0x1', _, '0x', 'x1xx', 'xxx000000', _) => // float2int
                    __field sf 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field rmode 19 +: 2
                    __field opcode 16 +: 3
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (sf, S, ftype, rmode, opcode) of
                        when (_, '0', !'10', '01', '10x') => __UNALLOCATED
                        when (_, '0', '10', 'x0', _) => __UNALLOCATED
                        when (_, '0', '10', 'x1', '0xx') => __UNALLOCATED
                        when (_, '0', '10', 'x1', '10x') => __UNALLOCATED
                        when (_, '0', '11', 'x1', '11x') => __UNALLOCATED
                        when (_, '1', _, _, _) => __UNALLOCATED
                        when ('0', '0', 'x0', '01', '11x') => __UNALLOCATED
                        when ('0', '0', '00', !'00', '01x') => __UNALLOCATED
                        when ('0', '0', '00', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_32S_float2int
                        when ('0', '0', '00', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_32S_float2int
                        when ('0', '0', '00', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_S32_float2int
                        when ('0', '0', '00', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_S32_float2int
                        when ('0', '0', '00', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_32S_float2int
                        when ('0', '0', '00', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_32S_float2int
                        when ('0', '0', '00', '00', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_32S_float2int
                        when ('0', '0', '00', '00', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_S32_float2int
                        when ('0', '0', '00', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_32S_float2int
                        when ('0', '0', '00', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_32S_float2int
                        when ('0', '0', '00', '1x', '1xx') => __UNALLOCATED
                        when ('0', '0', '00', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_32S_float2int
                        when ('0', '0', '00', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_32S_float2int
                        when ('0', '0', '00', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_32S_float2int
                        when ('0', '0', '00', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_32S_float2int
                        when ('0', '0', '01', '0x', '11x') => __UNALLOCATED
                        when ('0', '0', '01', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_32D_float2int
                        when ('0', '0', '01', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_32D_float2int
                        when ('0', '0', '01', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_D32_float2int
                        when ('0', '0', '01', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_D32_float2int
                        when ('0', '0', '01', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_32D_float2int
                        when ('0', '0', '01', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_32D_float2int
                        when ('0', '0', '01', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_32D_float2int
                        when ('0', '0', '01', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_32D_float2int
                        when ('0', '0', '01', '01', '010') => __encoding A64_simd_dp_float2int_FCVTNS_sisd_32H // FCVTNS_sisd_32D
                        when ('0', '0', '01', '01', '011') => __encoding A64_simd_dp_float2int_FCVTNU_sisd_32H // FCVTNU_sisd_32D
                        when ('0', '0', '01', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_32D_float2int
                        when ('0', '0', '01', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_32D_float2int
                        when ('0', '0', '01', '10', '010') => __encoding A64_simd_dp_float2int_FCVTPS_sisd_32H // FCVTPS_sisd_32D
                        when ('0', '0', '01', '10', '011') => __encoding A64_simd_dp_float2int_FCVTPU_sisd_32H // FCVTPU_sisd_32D
                        when ('0', '0', '01', '10', '100') => __encoding A64_simd_dp_float2int_FCVTMS_sisd_32H // FCVTMS_sisd_32D
                        when ('0', '0', '01', '10', '101') => __encoding A64_simd_dp_float2int_FCVTMU_sisd_32H // FCVTMU_sisd_32D
                        when ('0', '0', '01', '10', '110') => __encoding A64_simd_dp_float2int_FCVTZS_sisd_32H // FCVTZS_sisd_32D
                        when ('0', '0', '01', '10', '111') => __encoding A64_simd_dp_float2int_FCVTZU_sisd_32H // FCVTZU_sisd_32D
                        when ('0', '0', '01', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_32D_float2int
                        when ('0', '0', '01', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_32D_float2int
                        when ('0', '0', '01', '11', '010') => __encoding A64_simd_dp_float2int_FCVTAS_sisd_32H // FCVTAS_sisd_32D
                        when ('0', '0', '01', '11', '011') => __encoding A64_simd_dp_float2int_FCVTAU_sisd_32H // FCVTAU_sisd_32D
                        when ('0', '0', '01', '11', '100') => __encoding A64_simd_dp_float2int_SCVTF_sisd_32H // SCVTF_sisd_32D
                        when ('0', '0', '01', '11', '101') => __encoding A64_simd_dp_float2int_UCVTF_sisd_32H // UCVTF_sisd_32D
                        when ('0', '0', '01', '11', '110') => __encoding A64_simd_dp_float2int_FJCVTZS_32D_float2int // FJCVTZS_32D_float2int
                        when ('0', '0', '01', '11', '111') => __UNALLOCATED
                        when ('0', '0', '10', '11', '11x') => __UNALLOCATED
                        when ('0', '0', '11', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_32H_float2int
                        when ('0', '0', '11', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_32H_float2int
                        when ('0', '0', '11', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_H32_float2int
                        when ('0', '0', '11', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_H32_float2int
                        when ('0', '0', '11', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_32H_float2int
                        when ('0', '0', '11', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_32H_float2int
                        when ('0', '0', '11', '00', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_32H_float2int
                        when ('0', '0', '11', '00', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_H32_float2int
                        when ('0', '0', '11', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_32H_float2int
                        when ('0', '0', '11', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_32H_float2int
                        when ('0', '0', '11', '01', '010') => __encoding A64_simd_dp_float2int_FCVTNS_sisd_32H // FCVTNS_sisd_32H
                        when ('0', '0', '11', '01', '011') => __encoding A64_simd_dp_float2int_FCVTNU_sisd_32H // FCVTNU_sisd_32H
                        when ('0', '0', '11', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_32H_float2int
                        when ('0', '0', '11', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_32H_float2int
                        when ('0', '0', '11', '10', '010') => __encoding A64_simd_dp_float2int_FCVTPS_sisd_32H // FCVTPS_sisd_32H
                        when ('0', '0', '11', '10', '011') => __encoding A64_simd_dp_float2int_FCVTPU_sisd_32H // FCVTPU_sisd_32H
                        when ('0', '0', '11', '10', '100') => __encoding A64_simd_dp_float2int_FCVTMS_sisd_32H // FCVTMS_sisd_32H
                        when ('0', '0', '11', '10', '101') => __encoding A64_simd_dp_float2int_FCVTMU_sisd_32H // FCVTMU_sisd_32H
                        when ('0', '0', '11', '10', '110') => __encoding A64_simd_dp_float2int_FCVTZS_sisd_32H // FCVTZS_sisd_32H
                        when ('0', '0', '11', '10', '111') => __encoding A64_simd_dp_float2int_FCVTZU_sisd_32H // FCVTZU_sisd_32H
                        when ('0', '0', '11', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_32H_float2int
                        when ('0', '0', '11', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_32H_float2int
                        when ('0', '0', '11', '11', '010') => __encoding A64_simd_dp_float2int_FCVTAS_sisd_32H // FCVTAS_sisd_32H
                        when ('0', '0', '11', '11', '011') => __encoding A64_simd_dp_float2int_FCVTAU_sisd_32H // FCVTAU_sisd_32H
                        when ('0', '0', '11', '11', '100') => __encoding A64_simd_dp_float2int_SCVTF_sisd_32H // SCVTF_sisd_32H
                        when ('0', '0', '11', '11', '101') => __encoding A64_simd_dp_float2int_UCVTF_sisd_32H // UCVTF_sisd_32H
                        when ('1', '0', 'x0', '11', '11x') => __UNALLOCATED
                        when ('1', '0', '00', '0x', '11x') => __UNALLOCATED
                        when ('1', '0', '00', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_64S_float2int
                        when ('1', '0', '00', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_64S_float2int
                        when ('1', '0', '00', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_S64_float2int
                        when ('1', '0', '00', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_S64_float2int
                        when ('1', '0', '00', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_64S_float2int
                        when ('1', '0', '00', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_64S_float2int
                        when ('1', '0', '00', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_64S_float2int
                        when ('1', '0', '00', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_64S_float2int
                        when ('1', '0', '00', '01', '010') => __encoding A64_simd_dp_float2int_FCVTNS_sisd_32H // FCVTNS_sisd_64S
                        when ('1', '0', '00', '01', '011') => __encoding A64_simd_dp_float2int_FCVTNU_sisd_32H // FCVTNU_sisd_64S
                        when ('1', '0', '00', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_64S_float2int
                        when ('1', '0', '00', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_64S_float2int
                        when ('1', '0', '00', '10', '010') => __encoding A64_simd_dp_float2int_FCVTPS_sisd_32H // FCVTPS_sisd_64S
                        when ('1', '0', '00', '10', '011') => __encoding A64_simd_dp_float2int_FCVTPU_sisd_32H // FCVTPU_sisd_64S
                        when ('1', '0', '00', '10', '100') => __encoding A64_simd_dp_float2int_FCVTMS_sisd_32H // FCVTMS_sisd_64S
                        when ('1', '0', '00', '10', '101') => __encoding A64_simd_dp_float2int_FCVTMU_sisd_32H // FCVTMU_sisd_64S
                        when ('1', '0', '00', '10', '110') => __encoding A64_simd_dp_float2int_FCVTZS_sisd_32H // FCVTZS_sisd_64S
                        when ('1', '0', '00', '10', '111') => __encoding A64_simd_dp_float2int_FCVTZU_sisd_32H // FCVTZU_sisd_64S
                        when ('1', '0', '00', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_64S_float2int
                        when ('1', '0', '00', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_64S_float2int
                        when ('1', '0', '00', '11', '010') => __encoding A64_simd_dp_float2int_FCVTAS_sisd_32H // FCVTAS_sisd_64S
                        when ('1', '0', '00', '11', '011') => __encoding A64_simd_dp_float2int_FCVTAU_sisd_32H // FCVTAU_sisd_64S
                        when ('1', '0', '00', '11', '100') => __encoding A64_simd_dp_float2int_SCVTF_sisd_32H // SCVTF_sisd_64S
                        when ('1', '0', '00', '11', '101') => __encoding A64_simd_dp_float2int_UCVTF_sisd_32H // UCVTF_sisd_64S
                        when ('1', '0', '01', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_64D_float2int
                        when ('1', '0', '01', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_64D_float2int
                        when ('1', '0', '01', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_D64_float2int
                        when ('1', '0', '01', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_D64_float2int
                        when ('1', '0', '01', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_64D_float2int
                        when ('1', '0', '01', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_64D_float2int
                        when ('1', '0', '01', '00', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_64D_float2int
                        when ('1', '0', '01', '00', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_D64_float2int
                        when ('1', '0', '01', '01', 'x1x') => __UNALLOCATED
                        when ('1', '0', '01', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_64D_float2int
                        when ('1', '0', '01', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_64D_float2int
                        when ('1', '0', '01', '1x', '01x') => __UNALLOCATED
                        when ('1', '0', '01', '1x', '1xx') => __UNALLOCATED
                        when ('1', '0', '01', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_64D_float2int
                        when ('1', '0', '01', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_64D_float2int
                        when ('1', '0', '01', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_64D_float2int
                        when ('1', '0', '01', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_64D_float2int
                        when ('1', '0', '10', '01', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_64VX_float2int
                        when ('1', '0', '10', '01', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_V64I_float2int
                        when ('1', '0', '11', '00', '000') => __encoding A64_simd_dp_float2int_FCVTNS_32H_float2int // FCVTNS_64H_float2int
                        when ('1', '0', '11', '00', '001') => __encoding A64_simd_dp_float2int_FCVTNU_32H_float2int // FCVTNU_64H_float2int
                        when ('1', '0', '11', '00', '010') => __encoding A64_simd_dp_float2int_SCVTF_H32_float2int // SCVTF_H64_float2int
                        when ('1', '0', '11', '00', '011') => __encoding A64_simd_dp_float2int_UCVTF_H32_float2int // UCVTF_H64_float2int
                        when ('1', '0', '11', '00', '100') => __encoding A64_simd_dp_float2int_FCVTAS_32H_float2int // FCVTAS_64H_float2int
                        when ('1', '0', '11', '00', '101') => __encoding A64_simd_dp_float2int_FCVTAU_32H_float2int // FCVTAU_64H_float2int
                        when ('1', '0', '11', '00', '110') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_64H_float2int
                        when ('1', '0', '11', '00', '111') => __encoding A64_simd_dp_float2int_FMOV_32H_float2int // FMOV_H64_float2int
                        when ('1', '0', '11', '01', '000') => __encoding A64_simd_dp_float2int_FCVTPS_32H_float2int // FCVTPS_64H_float2int
                        when ('1', '0', '11', '01', '001') => __encoding A64_simd_dp_float2int_FCVTPU_32H_float2int // FCVTPU_64H_float2int
                        when ('1', '0', '11', '01', '010') => __encoding A64_simd_dp_float2int_FCVTNS_sisd_32H // FCVTNS_sisd_64H
                        when ('1', '0', '11', '01', '011') => __encoding A64_simd_dp_float2int_FCVTNU_sisd_32H // FCVTNU_sisd_64H
                        when ('1', '0', '11', '10', '000') => __encoding A64_simd_dp_float2int_FCVTMS_32H_float2int // FCVTMS_64H_float2int
                        when ('1', '0', '11', '10', '001') => __encoding A64_simd_dp_float2int_FCVTMU_32H_float2int // FCVTMU_64H_float2int
                        when ('1', '0', '11', '10', '010') => __encoding A64_simd_dp_float2int_FCVTPS_sisd_32H // FCVTPS_sisd_64H
                        when ('1', '0', '11', '10', '011') => __encoding A64_simd_dp_float2int_FCVTPU_sisd_32H // FCVTPU_sisd_64H
                        when ('1', '0', '11', '10', '100') => __encoding A64_simd_dp_float2int_FCVTMS_sisd_32H // FCVTMS_sisd_64H
                        when ('1', '0', '11', '10', '101') => __encoding A64_simd_dp_float2int_FCVTMU_sisd_32H // FCVTMU_sisd_64H
                        when ('1', '0', '11', '10', '110') => __encoding A64_simd_dp_float2int_FCVTZS_sisd_32H // FCVTZS_sisd_64H
                        when ('1', '0', '11', '10', '111') => __encoding A64_simd_dp_float2int_FCVTZU_sisd_32H // FCVTZU_sisd_64H
                        when ('1', '0', '11', '11', '000') => __encoding A64_simd_dp_float2int_FCVTZS_32H_float2int // FCVTZS_64H_float2int
                        when ('1', '0', '11', '11', '001') => __encoding A64_simd_dp_float2int_FCVTZU_32H_float2int // FCVTZU_64H_float2int
                        when ('1', '0', '11', '11', '010') => __encoding A64_simd_dp_float2int_FCVTAS_sisd_32H // FCVTAS_sisd_64H
                        when ('1', '0', '11', '11', '011') => __encoding A64_simd_dp_float2int_FCVTAU_sisd_32H // FCVTAU_sisd_64H
                        when ('1', '0', '11', '11', '100') => __encoding A64_simd_dp_float2int_SCVTF_sisd_32H // SCVTF_sisd_64H
                        when ('1', '0', '11', '11', '101') => __encoding A64_simd_dp_float2int_UCVTF_sisd_32H // UCVTF_sisd_64H
                when ('x0x1', _, '0x', 'x1xx', 'xxx100000', _) => __UNPREDICTABLE
                when ('x0x1', _, '0x', 'x1xx', 'xxxx10000', _) => // floatdp1
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field opcode 15 +: 6
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype, opcode) of
                        when ('0', '0', !'10', '001101') => __UNALLOCATED
                        when ('0', '0', _, '1xxxxx') => __UNALLOCATED
                        when ('0', '0', '0x', '0101xx') => __UNALLOCATED
                        when ('0', '0', '0x', '011xxx') => __UNALLOCATED
                        when ('0', '0', '00', '000000') => __encoding A64_simd_dp_floatdp1_FMOV_H_floatdp1 // FMOV_S_floatdp1
                        when ('0', '0', '00', '000001') => __encoding A64_simd_dp_floatdp1_FABS_H_floatdp1 // FABS_S_floatdp1
                        when ('0', '0', '00', '000010') => __encoding A64_simd_dp_floatdp1_FNEG_H_floatdp1 // FNEG_S_floatdp1
                        when ('0', '0', '00', '000011') => __encoding A64_simd_dp_floatdp1_FSQRT_H_floatdp1 // FSQRT_S_floatdp1
                        when ('0', '0', '00', '0001x0') => __UNALLOCATED
                        when ('0', '0', '00', '000101') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_DS_floatdp1
                        when ('0', '0', '00', '000111') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_HS_floatdp1
                        when ('0', '0', '00', '001000') => __encoding A64_simd_dp_floatdp1_FRINTN_H_floatdp1 // FRINTN_S_floatdp1
                        when ('0', '0', '00', '001001') => __encoding A64_simd_dp_floatdp1_FRINTP_H_floatdp1 // FRINTP_S_floatdp1
                        when ('0', '0', '00', '001010') => __encoding A64_simd_dp_floatdp1_FRINTM_H_floatdp1 // FRINTM_S_floatdp1
                        when ('0', '0', '00', '001011') => __encoding A64_simd_dp_floatdp1_FRINTZ_H_floatdp1 // FRINTZ_S_floatdp1
                        when ('0', '0', '00', '001100') => __encoding A64_simd_dp_floatdp1_FRINTA_H_floatdp1 // FRINTA_S_floatdp1
                        when ('0', '0', '00', '001110') => __encoding A64_simd_dp_floatdp1_FRINTX_H_floatdp1 // FRINTX_S_floatdp1
                        when ('0', '0', '00', '001111') => __encoding A64_simd_dp_floatdp1_FRINTI_H_floatdp1 // FRINTI_S_floatdp1
                        when ('0', '0', '00', '010000') => __encoding A64_simd_dp_floatdp1_FRINT32Z_S_floatdp1 // FRINT32Z_S_floatdp1
                        when ('0', '0', '00', '010001') => __encoding A64_simd_dp_floatdp1_FRINT32X_S_floatdp1 // FRINT32X_S_floatdp1
                        when ('0', '0', '00', '010010') => __encoding A64_simd_dp_floatdp1_FRINT64Z_S_floatdp1 // FRINT64Z_S_floatdp1
                        when ('0', '0', '00', '010011') => __encoding A64_simd_dp_floatdp1_FRINT64X_S_floatdp1 // FRINT64X_S_floatdp1
                        when ('0', '0', '01', '000000') => __encoding A64_simd_dp_floatdp1_FMOV_H_floatdp1 // FMOV_D_floatdp1
                        when ('0', '0', '01', '000001') => __encoding A64_simd_dp_floatdp1_FABS_H_floatdp1 // FABS_D_floatdp1
                        when ('0', '0', '01', '000010') => __encoding A64_simd_dp_floatdp1_FNEG_H_floatdp1 // FNEG_D_floatdp1
                        when ('0', '0', '01', '000011') => __encoding A64_simd_dp_floatdp1_FSQRT_H_floatdp1 // FSQRT_D_floatdp1
                        when ('0', '0', '01', '000100') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_SD_floatdp1
                        when ('0', '0', '01', '000101') => __UNALLOCATED
                        when ('0', '0', '01', '000110') => __encoding A64_simd_dp_floatdp1_BFCVT_BS_floatdp1 // BFCVT_BS_floatdp1
                        when ('0', '0', '01', '000111') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_HD_floatdp1
                        when ('0', '0', '01', '001000') => __encoding A64_simd_dp_floatdp1_FRINTN_H_floatdp1 // FRINTN_D_floatdp1
                        when ('0', '0', '01', '001001') => __encoding A64_simd_dp_floatdp1_FRINTP_H_floatdp1 // FRINTP_D_floatdp1
                        when ('0', '0', '01', '001010') => __encoding A64_simd_dp_floatdp1_FRINTM_H_floatdp1 // FRINTM_D_floatdp1
                        when ('0', '0', '01', '001011') => __encoding A64_simd_dp_floatdp1_FRINTZ_H_floatdp1 // FRINTZ_D_floatdp1
                        when ('0', '0', '01', '001100') => __encoding A64_simd_dp_floatdp1_FRINTA_H_floatdp1 // FRINTA_D_floatdp1
                        when ('0', '0', '01', '001110') => __encoding A64_simd_dp_floatdp1_FRINTX_H_floatdp1 // FRINTX_D_floatdp1
                        when ('0', '0', '01', '001111') => __encoding A64_simd_dp_floatdp1_FRINTI_H_floatdp1 // FRINTI_D_floatdp1
                        when ('0', '0', '01', '010000') => __encoding A64_simd_dp_floatdp1_FRINT32Z_S_floatdp1 // FRINT32Z_D_floatdp1
                        when ('0', '0', '01', '010001') => __encoding A64_simd_dp_floatdp1_FRINT32X_S_floatdp1 // FRINT32X_D_floatdp1
                        when ('0', '0', '01', '010010') => __encoding A64_simd_dp_floatdp1_FRINT64Z_S_floatdp1 // FRINT64Z_D_floatdp1
                        when ('0', '0', '01', '010011') => __encoding A64_simd_dp_floatdp1_FRINT64X_S_floatdp1 // FRINT64X_D_floatdp1
                        when ('0', '0', '10', '0xxxxx') => __UNALLOCATED
                        when ('0', '0', '11', '000000') => __encoding A64_simd_dp_floatdp1_FMOV_H_floatdp1 // FMOV_H_floatdp1
                        when ('0', '0', '11', '000001') => __encoding A64_simd_dp_floatdp1_FABS_H_floatdp1 // FABS_H_floatdp1
                        when ('0', '0', '11', '000010') => __encoding A64_simd_dp_floatdp1_FNEG_H_floatdp1 // FNEG_H_floatdp1
                        when ('0', '0', '11', '000011') => __encoding A64_simd_dp_floatdp1_FSQRT_H_floatdp1 // FSQRT_H_floatdp1
                        when ('0', '0', '11', '000100') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_SH_floatdp1
                        when ('0', '0', '11', '000101') => __encoding A64_simd_dp_floatdp1_FCVT_SH_floatdp1 // FCVT_DH_floatdp1
                        when ('0', '0', '11', '00011x') => __UNALLOCATED
                        when ('0', '0', '11', '001000') => __encoding A64_simd_dp_floatdp1_FRINTN_H_floatdp1 // FRINTN_H_floatdp1
                        when ('0', '0', '11', '001001') => __encoding A64_simd_dp_floatdp1_FRINTP_H_floatdp1 // FRINTP_H_floatdp1
                        when ('0', '0', '11', '001010') => __encoding A64_simd_dp_floatdp1_FRINTM_H_floatdp1 // FRINTM_H_floatdp1
                        when ('0', '0', '11', '001011') => __encoding A64_simd_dp_floatdp1_FRINTZ_H_floatdp1 // FRINTZ_H_floatdp1
                        when ('0', '0', '11', '001100') => __encoding A64_simd_dp_floatdp1_FRINTA_H_floatdp1 // FRINTA_H_floatdp1
                        when ('0', '0', '11', '001110') => __encoding A64_simd_dp_floatdp1_FRINTX_H_floatdp1 // FRINTX_H_floatdp1
                        when ('0', '0', '11', '001111') => __encoding A64_simd_dp_floatdp1_FRINTI_H_floatdp1 // FRINTI_H_floatdp1
                        when ('0', '0', '11', '01xxxx') => __UNALLOCATED
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxx1000', _) => // floatcmp
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field Rm 16 +: 5
                    __field op 14 +: 2
                    __field Rn 5 +: 5
                    __field opcode2 0 +: 5
                    case (M, S, ftype, op, opcode2) of
                        when ('0', '0', _, !'00', _) => __UNALLOCATED
                        when ('0', '0', _, '00', 'xx001') => __UNALLOCATED
                        when ('0', '0', _, '00', 'xx01x') => __UNALLOCATED
                        when ('0', '0', _, '00', 'xx1xx') => __UNALLOCATED
                        when ('0', '0', '00', '00', '00000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_S_floatcmp
                        when ('0', '0', '00', '00', '01000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_SZ_floatcmp
                        when ('0', '0', '00', '00', '10000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_S_floatcmp
                        when ('0', '0', '00', '00', '11000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_SZ_floatcmp
                        when ('0', '0', '01', '00', '00000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_D_floatcmp
                        when ('0', '0', '01', '00', '01000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_DZ_floatcmp
                        when ('0', '0', '01', '00', '10000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_D_floatcmp
                        when ('0', '0', '01', '00', '11000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_DZ_floatcmp
                        when ('0', '0', '10', '00', 'xx000') => __UNALLOCATED
                        when ('0', '0', '11', '00', '00000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_H_floatcmp
                        when ('0', '0', '11', '00', '01000') => __encoding A64_simd_dp_floatcmp_FCMP_H_floatcmp // FCMP_HZ_floatcmp
                        when ('0', '0', '11', '00', '10000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_H_floatcmp
                        when ('0', '0', '11', '00', '11000') => __encoding A64_simd_dp_floatcmp_FCMPE_H_floatcmp // FCMPE_HZ_floatcmp
                        when ('0', '1', _, _, _) => __UNALLOCATED
                        when ('1', _, _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxx100', _) => // floatimm
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field imm8 13 +: 8
                    __field imm5 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype, imm5) of
                        when ('0', '0', _, !'00000') => __UNALLOCATED
                        when ('0', '0', '00', '00000') => __encoding A64_simd_dp_floatimm_FMOV_H_floatimm // FMOV_S_floatimm
                        when ('0', '0', '01', '00000') => __encoding A64_simd_dp_floatimm_FMOV_H_floatimm // FMOV_D_floatimm
                        when ('0', '0', '10', '00000') => __UNALLOCATED
                        when ('0', '0', '11', '00000') => __encoding A64_simd_dp_floatimm_FMOV_H_floatimm // FMOV_H_floatimm
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx01', _) => // floatccmp
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field Rn 5 +: 5
                    __field op 4 +: 1
                    __field nzcv 0 +: 4
                    case (M, S, ftype, op) of
                        when ('0', '0', '00', '0') => __encoding A64_simd_dp_floatccmp_FCCMP_H_floatccmp // FCCMP_S_floatccmp
                        when ('0', '0', '00', '1') => __encoding A64_simd_dp_floatccmp_FCCMPE_H_floatccmp // FCCMPE_S_floatccmp
                        when ('0', '0', '01', '0') => __encoding A64_simd_dp_floatccmp_FCCMP_H_floatccmp // FCCMP_D_floatccmp
                        when ('0', '0', '01', '1') => __encoding A64_simd_dp_floatccmp_FCCMPE_H_floatccmp // FCCMPE_D_floatccmp
                        when ('0', '0', '10', _) => __UNALLOCATED
                        when ('0', '0', '11', '0') => __encoding A64_simd_dp_floatccmp_FCCMP_H_floatccmp // FCCMP_H_floatccmp
                        when ('0', '0', '11', '1') => __encoding A64_simd_dp_floatccmp_FCCMPE_H_floatccmp // FCCMPE_H_floatccmp
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx10', _) => // floatdp2
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype, opcode) of
                        when ('0', '0', !'10', '1001') => __UNALLOCATED
                        when ('0', '0', !'10', '101x') => __UNALLOCATED
                        when ('0', '0', !'10', '11xx') => __UNALLOCATED
                        when ('0', '0', '00', '0000') => __encoding A64_simd_dp_floatdp2_FMUL_H_floatdp2 // FMUL_S_floatdp2
                        when ('0', '0', '00', '0001') => __encoding A64_simd_dp_floatdp2_FDIV_H_floatdp2 // FDIV_S_floatdp2
                        when ('0', '0', '00', '0010') => __encoding A64_simd_dp_floatdp2_FADD_H_floatdp2 // FADD_S_floatdp2
                        when ('0', '0', '00', '0011') => __encoding A64_simd_dp_floatdp2_FSUB_H_floatdp2 // FSUB_S_floatdp2
                        when ('0', '0', '00', '0100') => __encoding A64_simd_dp_floatdp2_FMAX_H_floatdp2 // FMAX_S_floatdp2
                        when ('0', '0', '00', '0101') => __encoding A64_simd_dp_floatdp2_FMIN_H_floatdp2 // FMIN_S_floatdp2
                        when ('0', '0', '00', '0110') => __encoding A64_simd_dp_floatdp2_FMAXNM_H_floatdp2 // FMAXNM_S_floatdp2
                        when ('0', '0', '00', '0111') => __encoding A64_simd_dp_floatdp2_FMINNM_H_floatdp2 // FMINNM_S_floatdp2
                        when ('0', '0', '00', '1000') => __encoding A64_simd_dp_floatdp2_FNMUL_H_floatdp2 // FNMUL_S_floatdp2
                        when ('0', '0', '01', '0000') => __encoding A64_simd_dp_floatdp2_FMUL_H_floatdp2 // FMUL_D_floatdp2
                        when ('0', '0', '01', '0001') => __encoding A64_simd_dp_floatdp2_FDIV_H_floatdp2 // FDIV_D_floatdp2
                        when ('0', '0', '01', '0010') => __encoding A64_simd_dp_floatdp2_FADD_H_floatdp2 // FADD_D_floatdp2
                        when ('0', '0', '01', '0011') => __encoding A64_simd_dp_floatdp2_FSUB_H_floatdp2 // FSUB_D_floatdp2
                        when ('0', '0', '01', '0100') => __encoding A64_simd_dp_floatdp2_FMAX_H_floatdp2 // FMAX_D_floatdp2
                        when ('0', '0', '01', '0101') => __encoding A64_simd_dp_floatdp2_FMIN_H_floatdp2 // FMIN_D_floatdp2
                        when ('0', '0', '01', '0110') => __encoding A64_simd_dp_floatdp2_FMAXNM_H_floatdp2 // FMAXNM_D_floatdp2
                        when ('0', '0', '01', '0111') => __encoding A64_simd_dp_floatdp2_FMINNM_H_floatdp2 // FMINNM_D_floatdp2
                        when ('0', '0', '01', '1000') => __encoding A64_simd_dp_floatdp2_FNMUL_H_floatdp2 // FNMUL_D_floatdp2
                        when ('0', '0', '10', _) => __UNALLOCATED
                        when ('0', '0', '11', '0000') => __encoding A64_simd_dp_floatdp2_FMUL_H_floatdp2 // FMUL_H_floatdp2
                        when ('0', '0', '11', '0001') => __encoding A64_simd_dp_floatdp2_FDIV_H_floatdp2 // FDIV_H_floatdp2
                        when ('0', '0', '11', '0010') => __encoding A64_simd_dp_floatdp2_FADD_H_floatdp2 // FADD_H_floatdp2
                        when ('0', '0', '11', '0011') => __encoding A64_simd_dp_floatdp2_FSUB_H_floatdp2 // FSUB_H_floatdp2
                        when ('0', '0', '11', '0100') => __encoding A64_simd_dp_floatdp2_FMAX_H_floatdp2 // FMAX_H_floatdp2
                        when ('0', '0', '11', '0101') => __encoding A64_simd_dp_floatdp2_FMIN_H_floatdp2 // FMIN_H_floatdp2
                        when ('0', '0', '11', '0110') => __encoding A64_simd_dp_floatdp2_FMAXNM_H_floatdp2 // FMAXNM_H_floatdp2
                        when ('0', '0', '11', '0111') => __encoding A64_simd_dp_floatdp2_FMINNM_H_floatdp2 // FMINNM_H_floatdp2
                        when ('0', '0', '11', '1000') => __encoding A64_simd_dp_floatdp2_FNMUL_H_floatdp2 // FNMUL_H_floatdp2
                        when ('0', '1', _, _) => __UNALLOCATED
                        when ('1', _, _, _) => __UNALLOCATED
                when ('x0x1', _, '0x', 'x1xx', 'xxxxxxx11', _) => // floatsel
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field Rm 16 +: 5
                    __field cond 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype) of
                        when ('0', '0', '00') => __encoding A64_simd_dp_floatsel_FCSEL_H_floatsel // FCSEL_S_floatsel
                        when ('0', '0', '01') => __encoding A64_simd_dp_floatsel_FCSEL_H_floatsel // FCSEL_D_floatsel
                        when ('0', '0', '10') => __UNALLOCATED
                        when ('0', '0', '11') => __encoding A64_simd_dp_floatsel_FCSEL_H_floatsel // FCSEL_H_floatsel
                        when ('0', '1', _) => __UNALLOCATED
                        when ('1', _, _) => __UNALLOCATED
                when ('x0x1', _, '1x', _, _, _) => // floatdp3
                    __field M 31 +: 1
                    __field S 29 +: 1
                    __field ftype 22 +: 2
                    __field o1 21 +: 1
                    __field Rm 16 +: 5
                    __field o0 15 +: 1
                    __field Ra 10 +: 5
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (M, S, ftype, o1, o0) of
                        when ('0', '0', '00', '0', '0') => __encoding A64_simd_dp_floatdp3_FMADD_H_floatdp3 // FMADD_S_floatdp3
                        when ('0', '0', '00', '0', '1') => __encoding A64_simd_dp_floatdp3_FMSUB_H_floatdp3 // FMSUB_S_floatdp3
                        when ('0', '0', '00', '1', '0') => __encoding A64_simd_dp_floatdp3_FNMADD_H_floatdp3 // FNMADD_S_floatdp3
                        when ('0', '0', '00', '1', '1') => __encoding A64_simd_dp_floatdp3_FNMSUB_H_floatdp3 // FNMSUB_S_floatdp3
                        when ('0', '0', '01', '0', '0') => __encoding A64_simd_dp_floatdp3_FMADD_H_floatdp3 // FMADD_D_floatdp3
                        when ('0', '0', '01', '0', '1') => __encoding A64_simd_dp_floatdp3_FMSUB_H_floatdp3 // FMSUB_D_floatdp3
                        when ('0', '0', '01', '1', '0') => __encoding A64_simd_dp_floatdp3_FNMADD_H_floatdp3 // FNMADD_D_floatdp3
                        when ('0', '0', '01', '1', '1') => __encoding A64_simd_dp_floatdp3_FNMSUB_H_floatdp3 // FNMSUB_D_floatdp3
                        when ('0', '0', '10', _, _) => __UNALLOCATED
                        when ('0', '0', '11', '0', '0') => __encoding A64_simd_dp_floatdp3_FMADD_H_floatdp3 // FMADD_H_floatdp3
                        when ('0', '0', '11', '0', '1') => __encoding A64_simd_dp_floatdp3_FMSUB_H_floatdp3 // FMSUB_H_floatdp3
                        when ('0', '0', '11', '1', '0') => __encoding A64_simd_dp_floatdp3_FNMADD_H_floatdp3 // FNMADD_H_floatdp3
                        when ('0', '0', '11', '1', '1') => __encoding A64_simd_dp_floatdp3_FNMSUB_H_floatdp3 // FNMSUB_H_floatdp3
                        when ('0', '1', _, _, _) => __UNALLOCATED
                        when ('1', _, _, _, _) => __UNALLOCATED
        when (_, _, 'x1x0', _) =>
            // ldst
            case (28 +: 4, 27 +: 1, 26 +: 1, 25 +: 1, 10 +: 15, 0 +: 10) of
                when ('0000', _, '0', _, '1xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0001', _, '1', _, '1xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '0', _, '00x1xxxxxxxxxxx', _) => // comswappr
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0, Rt2) of
                        when (_, _, _, !'11111') => __UNALLOCATED
                        when ('0', '0', '0', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASP_CP32_comswappr
                        when ('0', '0', '1', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPL_CP32_comswappr
                        when ('0', '1', '0', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPA_CP32_comswappr
                        when ('0', '1', '1', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPAL_CP32_comswappr
                        when ('1', '0', '0', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASP_CP64_comswappr
                        when ('1', '0', '1', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPL_CP64_comswappr
                        when ('1', '1', '0', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPA_CP64_comswappr
                        when ('1', '1', '1', '11111') => __encoding A64_ldst_comswappr_CASP_CP32_comswappr // CASPAL_CP64_comswappr
                when ('0x00', _, '0', _, '10x0xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '0', _, '11x0xxxxxxxxxxx', _) => // comswappr_unpriv
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0, Rt2) of
                        when ('0', _, _, _) => __UNALLOCATED
                        when ('1', _, _, !'11111') => __UNALLOCATED
                        when ('1', '0', '0', '11111') => __encoding A64_ldst_comswappr_unpriv_CASPT_CP64_comswappr_unpriv // CASPT_CP64_comswappr_unpriv
                        when ('1', '0', '1', '11111') => __encoding A64_ldst_comswappr_unpriv_CASPT_CP64_comswappr_unpriv // CASPLT_CP64_comswappr_unpriv
                        when ('1', '1', '0', '11111') => __encoding A64_ldst_comswappr_unpriv_CASPT_CP64_comswappr_unpriv // CASPAT_CP64_comswappr_unpriv
                        when ('1', '1', '1', '11111') => __encoding A64_ldst_comswappr_unpriv_CASPT_CP64_comswappr_unpriv // CASPALT_CP64_comswappr_unpriv
                when ('0x00', _, '1', _, '00x000000xxxxxx', _) => // asisdlse
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field opcode 12 +: 4
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, opcode) of
                        when (_, 'x0x1') => __UNALLOCATED
                        when (_, '0101') => __UNALLOCATED
                        when (_, '11xx') => __UNALLOCATED
                        when ('0', '0000') => __encoding A64_ldst_asisdlse_ST4_asisdlse_R4 // ST4_asisdlse_R4
                        when ('0', '0010') => __encoding A64_ldst_asisdlse_ST1_asisdlse_R1_1v // ST1_asisdlse_R4_4v
                        when ('0', '0100') => __encoding A64_ldst_asisdlse_ST3_asisdlse_R3 // ST3_asisdlse_R3
                        when ('0', '0110') => __encoding A64_ldst_asisdlse_ST1_asisdlse_R1_1v // ST1_asisdlse_R3_3v
                        when ('0', '0111') => __encoding A64_ldst_asisdlse_ST1_asisdlse_R1_1v // ST1_asisdlse_R1_1v
                        when ('0', '1000') => __encoding A64_ldst_asisdlse_ST2_asisdlse_R2 // ST2_asisdlse_R2
                        when ('0', '1010') => __encoding A64_ldst_asisdlse_ST1_asisdlse_R1_1v // ST1_asisdlse_R2_2v
                        when ('1', '0000') => __encoding A64_ldst_asisdlse_LD4_asisdlse_R4 // LD4_asisdlse_R4
                        when ('1', '0010') => __encoding A64_ldst_asisdlse_LD1_asisdlse_R1_1v // LD1_asisdlse_R4_4v
                        when ('1', '0100') => __encoding A64_ldst_asisdlse_LD3_asisdlse_R3 // LD3_asisdlse_R3
                        when ('1', '0110') => __encoding A64_ldst_asisdlse_LD1_asisdlse_R1_1v // LD1_asisdlse_R3_3v
                        when ('1', '0111') => __encoding A64_ldst_asisdlse_LD1_asisdlse_R1_1v // LD1_asisdlse_R1_1v
                        when ('1', '1000') => __encoding A64_ldst_asisdlse_LD2_asisdlse_R2 // LD2_asisdlse_R2
                        when ('1', '1010') => __encoding A64_ldst_asisdlse_LD1_asisdlse_R1_1v // LD1_asisdlse_R2_2v
                when ('0x00', _, '1', _, '00x000001xxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '01x0xxxxxxxxxxx', _) => // asisdlsep
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field Rm 16 +: 5
                    __field opcode 12 +: 4
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, Rm, opcode) of
                        when (_, _, 'x0x1') => __UNALLOCATED
                        when (_, _, '0101') => __UNALLOCATED
                        when (_, _, '11xx') => __UNALLOCATED
                        when ('0', !'11111', '0000') => __encoding A64_ldst_asisdlsep_ST4_asisdlsep_I4_i // ST4_asisdlsep_R4_r
                        when ('0', !'11111', '0010') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_R4_r4
                        when ('0', !'11111', '0100') => __encoding A64_ldst_asisdlsep_ST3_asisdlsep_I3_i // ST3_asisdlsep_R3_r
                        when ('0', !'11111', '0110') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_R3_r3
                        when ('0', !'11111', '0111') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_R1_r1
                        when ('0', !'11111', '1000') => __encoding A64_ldst_asisdlsep_ST2_asisdlsep_I2_i // ST2_asisdlsep_R2_r
                        when ('0', !'11111', '1010') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_R2_r2
                        when ('0', '11111', '0000') => __encoding A64_ldst_asisdlsep_ST4_asisdlsep_I4_i // ST4_asisdlsep_I4_i
                        when ('0', '11111', '0010') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_I4_i4
                        when ('0', '11111', '0100') => __encoding A64_ldst_asisdlsep_ST3_asisdlsep_I3_i // ST3_asisdlsep_I3_i
                        when ('0', '11111', '0110') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_I3_i3
                        when ('0', '11111', '0111') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_I1_i1
                        when ('0', '11111', '1000') => __encoding A64_ldst_asisdlsep_ST2_asisdlsep_I2_i // ST2_asisdlsep_I2_i
                        when ('0', '11111', '1010') => __encoding A64_ldst_asisdlsep_ST1_asisdlsep_I1_i1 // ST1_asisdlsep_I2_i2
                        when ('1', !'11111', '0000') => __encoding A64_ldst_asisdlsep_LD4_asisdlsep_I4_i // LD4_asisdlsep_R4_r
                        when ('1', !'11111', '0010') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_R4_r4
                        when ('1', !'11111', '0100') => __encoding A64_ldst_asisdlsep_LD3_asisdlsep_I3_i // LD3_asisdlsep_R3_r
                        when ('1', !'11111', '0110') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_R3_r3
                        when ('1', !'11111', '0111') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_R1_r1
                        when ('1', !'11111', '1000') => __encoding A64_ldst_asisdlsep_LD2_asisdlsep_I2_i // LD2_asisdlsep_R2_r
                        when ('1', !'11111', '1010') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_R2_r2
                        when ('1', '11111', '0000') => __encoding A64_ldst_asisdlsep_LD4_asisdlsep_I4_i // LD4_asisdlsep_I4_i
                        when ('1', '11111', '0010') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_I4_i4
                        when ('1', '11111', '0100') => __encoding A64_ldst_asisdlsep_LD3_asisdlsep_I3_i // LD3_asisdlsep_I3_i
                        when ('1', '11111', '0110') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_I3_i3
                        when ('1', '11111', '0111') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_I1_i1
                        when ('1', '11111', '1000') => __encoding A64_ldst_asisdlsep_LD2_asisdlsep_I2_i // LD2_asisdlsep_I2_i
                        when ('1', '11111', '1010') => __encoding A64_ldst_asisdlsep_LD1_asisdlsep_I1_i1 // LD1_asisdlsep_I2_i2
                when ('0x00', _, '1', _, '0xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10x10001xxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10x1001xxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10x101xxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10x11xxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, '10xx0000xxxxxxx', _) => // asisdlso
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field R 21 +: 1
                    __field o2 16 +: 1
                    __field opcode 13 +: 3
                    __field S 12 +: 1
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, R, o2, opcode, S, size) of
                        when (_, _, '0', '01x', _, 'x1') => __UNALLOCATED
                        when (_, _, '0', '10x', _, '1x') => __UNALLOCATED
                        when (_, _, '0', '10x', '1', '01') => __UNALLOCATED
                        when (_, '0', '1', !'100', _, _) => __UNALLOCATED
                        when (_, '0', '1', '100', _, !'01') => __UNALLOCATED
                        when (_, '0', '1', '100', '1', '01') => __UNALLOCATED
                        when (_, '1', '1', _, _, _) => __UNALLOCATED
                        when ('0', _, '0', '11x', _, _) => __UNALLOCATED
                        when ('0', '0', '0', '000', _, _) => __encoding A64_ldst_asisdlso_ST1_asisdlso_B1_1b // ST1_asisdlso_B1_1b
                        when ('0', '0', '0', '001', _, _) => __encoding A64_ldst_asisdlso_ST3_asisdlso_B3_3b // ST3_asisdlso_B3_3b
                        when ('0', '0', '0', '010', _, 'x0') => __encoding A64_ldst_asisdlso_ST1_asisdlso_B1_1b // ST1_asisdlso_H1_1h
                        when ('0', '0', '0', '011', _, 'x0') => __encoding A64_ldst_asisdlso_ST3_asisdlso_B3_3b // ST3_asisdlso_H3_3h
                        when ('0', '0', '0', '100', _, '00') => __encoding A64_ldst_asisdlso_ST1_asisdlso_B1_1b // ST1_asisdlso_S1_1s
                        when ('0', '0', '0', '100', '0', '01') => __encoding A64_ldst_asisdlso_ST1_asisdlso_B1_1b // ST1_asisdlso_D1_1d
                        when ('0', '0', '0', '101', _, '00') => __encoding A64_ldst_asisdlso_ST3_asisdlso_B3_3b // ST3_asisdlso_S3_3s
                        when ('0', '0', '0', '101', '0', '01') => __encoding A64_ldst_asisdlso_ST3_asisdlso_B3_3b // ST3_asisdlso_D3_3d
                        when ('0', '0', '1', '100', '0', '01') => __encoding A64_ldst_asisdlso_STL1_asisdlso_D1 // STL1_asisdlso_D1
                        when ('0', '1', '0', '000', _, _) => __encoding A64_ldst_asisdlso_ST2_asisdlso_B2_2b // ST2_asisdlso_B2_2b
                        when ('0', '1', '0', '001', _, _) => __encoding A64_ldst_asisdlso_ST4_asisdlso_B4_4b // ST4_asisdlso_B4_4b
                        when ('0', '1', '0', '010', _, 'x0') => __encoding A64_ldst_asisdlso_ST2_asisdlso_B2_2b // ST2_asisdlso_H2_2h
                        when ('0', '1', '0', '011', _, 'x0') => __encoding A64_ldst_asisdlso_ST4_asisdlso_B4_4b // ST4_asisdlso_H4_4h
                        when ('0', '1', '0', '100', _, '00') => __encoding A64_ldst_asisdlso_ST2_asisdlso_B2_2b // ST2_asisdlso_S2_2s
                        when ('0', '1', '0', '100', '0', '01') => __encoding A64_ldst_asisdlso_ST2_asisdlso_B2_2b // ST2_asisdlso_D2_2d
                        when ('0', '1', '0', '101', _, '00') => __encoding A64_ldst_asisdlso_ST4_asisdlso_B4_4b // ST4_asisdlso_S4_4s
                        when ('0', '1', '0', '101', '0', '01') => __encoding A64_ldst_asisdlso_ST4_asisdlso_B4_4b // ST4_asisdlso_D4_4d
                        when ('1', _, '0', '11x', '1', _) => __UNALLOCATED
                        when ('1', '0', '0', '000', _, _) => __encoding A64_ldst_asisdlso_LD1_asisdlso_B1_1b // LD1_asisdlso_B1_1b
                        when ('1', '0', '0', '001', _, _) => __encoding A64_ldst_asisdlso_LD3_asisdlso_B3_3b // LD3_asisdlso_B3_3b
                        when ('1', '0', '0', '010', _, 'x0') => __encoding A64_ldst_asisdlso_LD1_asisdlso_B1_1b // LD1_asisdlso_H1_1h
                        when ('1', '0', '0', '011', _, 'x0') => __encoding A64_ldst_asisdlso_LD3_asisdlso_B3_3b // LD3_asisdlso_H3_3h
                        when ('1', '0', '0', '100', _, '00') => __encoding A64_ldst_asisdlso_LD1_asisdlso_B1_1b // LD1_asisdlso_S1_1s
                        when ('1', '0', '0', '100', '0', '01') => __encoding A64_ldst_asisdlso_LD1_asisdlso_B1_1b // LD1_asisdlso_D1_1d
                        when ('1', '0', '0', '101', _, '00') => __encoding A64_ldst_asisdlso_LD3_asisdlso_B3_3b // LD3_asisdlso_S3_3s
                        when ('1', '0', '0', '101', '0', '01') => __encoding A64_ldst_asisdlso_LD3_asisdlso_B3_3b // LD3_asisdlso_D3_3d
                        when ('1', '0', '0', '110', '0', _) => __encoding A64_ldst_asisdlso_LD1R_asisdlso_R1 // LD1R_asisdlso_R1
                        when ('1', '0', '0', '111', '0', _) => __encoding A64_ldst_asisdlso_LD3R_asisdlso_R3 // LD3R_asisdlso_R3
                        when ('1', '0', '1', '100', '0', '01') => __encoding A64_ldst_asisdlso_LDAP1_asisdlso_D1 // LDAP1_asisdlso_D1
                        when ('1', '1', '0', '000', _, _) => __encoding A64_ldst_asisdlso_LD2_asisdlso_B2_2b // LD2_asisdlso_B2_2b
                        when ('1', '1', '0', '001', _, _) => __encoding A64_ldst_asisdlso_LD4_asisdlso_B4_4b // LD4_asisdlso_B4_4b
                        when ('1', '1', '0', '010', _, 'x0') => __encoding A64_ldst_asisdlso_LD2_asisdlso_B2_2b // LD2_asisdlso_H2_2h
                        when ('1', '1', '0', '011', _, 'x0') => __encoding A64_ldst_asisdlso_LD4_asisdlso_B4_4b // LD4_asisdlso_H4_4h
                        when ('1', '1', '0', '100', _, '00') => __encoding A64_ldst_asisdlso_LD2_asisdlso_B2_2b // LD2_asisdlso_S2_2s
                        when ('1', '1', '0', '100', '0', '01') => __encoding A64_ldst_asisdlso_LD2_asisdlso_B2_2b // LD2_asisdlso_D2_2d
                        when ('1', '1', '0', '101', _, '00') => __encoding A64_ldst_asisdlso_LD4_asisdlso_B4_4b // LD4_asisdlso_S4_4s
                        when ('1', '1', '0', '101', '0', '01') => __encoding A64_ldst_asisdlso_LD4_asisdlso_B4_4b // LD4_asisdlso_D4_4d
                        when ('1', '1', '0', '110', '0', _) => __encoding A64_ldst_asisdlso_LD2R_asisdlso_R2 // LD2R_asisdlso_R2
                        when ('1', '1', '0', '111', '0', _) => __encoding A64_ldst_asisdlso_LD4R_asisdlso_R4 // LD4R_asisdlso_R4
                when ('0x00', _, '1', _, '11xxxxxxxxxxxxx', _) => // asisdlsop
                    __field Q 30 +: 1
                    __field L 22 +: 1
                    __field R 21 +: 1
                    __field Rm 16 +: 5
                    __field opcode 13 +: 3
                    __field S 12 +: 1
                    __field size 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (L, R, Rm, opcode, S, size) of
                        when (_, _, _, '01x', _, 'x1') => __UNALLOCATED
                        when (_, _, _, '10x', _, '1x') => __UNALLOCATED
                        when (_, _, _, '10x', '1', '01') => __UNALLOCATED
                        when ('0', _, _, '11x', _, _) => __UNALLOCATED
                        when ('0', '0', !'11111', '000', _, _) => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_BX1_r1b
                        when ('0', '0', !'11111', '001', _, _) => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_BX3_r3b
                        when ('0', '0', !'11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_HX1_r1h
                        when ('0', '0', !'11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_HX3_r3h
                        when ('0', '0', !'11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_SX1_r1s
                        when ('0', '0', !'11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_DX1_r1d
                        when ('0', '0', !'11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_SX3_r3s
                        when ('0', '0', !'11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_DX3_r3d
                        when ('0', '0', '11111', '000', _, _) => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_B1_i1b
                        when ('0', '0', '11111', '001', _, _) => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_B3_i3b
                        when ('0', '0', '11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_H1_i1h
                        when ('0', '0', '11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_H3_i3h
                        when ('0', '0', '11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_S1_i1s
                        when ('0', '0', '11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_ST1_asisdlsop_B1_i1b // ST1_asisdlsop_D1_i1d
                        when ('0', '0', '11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_S3_i3s
                        when ('0', '0', '11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_ST3_asisdlsop_B3_i3b // ST3_asisdlsop_D3_i3d
                        when ('0', '1', !'11111', '000', _, _) => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_BX2_r2b
                        when ('0', '1', !'11111', '001', _, _) => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_BX4_r4b
                        when ('0', '1', !'11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_HX2_r2h
                        when ('0', '1', !'11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_HX4_r4h
                        when ('0', '1', !'11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_SX2_r2s
                        when ('0', '1', !'11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_DX2_r2d
                        when ('0', '1', !'11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_SX4_r4s
                        when ('0', '1', !'11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_DX4_r4d
                        when ('0', '1', '11111', '000', _, _) => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_B2_i2b
                        when ('0', '1', '11111', '001', _, _) => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_B4_i4b
                        when ('0', '1', '11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_H2_i2h
                        when ('0', '1', '11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_H4_i4h
                        when ('0', '1', '11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_S2_i2s
                        when ('0', '1', '11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_ST2_asisdlsop_B2_i2b // ST2_asisdlsop_D2_i2d
                        when ('0', '1', '11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_S4_i4s
                        when ('0', '1', '11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_ST4_asisdlsop_B4_i4b // ST4_asisdlsop_D4_i4d
                        when ('1', _, _, '11x', '1', _) => __UNALLOCATED
                        when ('1', '0', !'11111', '000', _, _) => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_BX1_r1b
                        when ('1', '0', !'11111', '001', _, _) => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_BX3_r3b
                        when ('1', '0', !'11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_HX1_r1h
                        when ('1', '0', !'11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_HX3_r3h
                        when ('1', '0', !'11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_SX1_r1s
                        when ('1', '0', !'11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_DX1_r1d
                        when ('1', '0', !'11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_SX3_r3s
                        when ('1', '0', !'11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_DX3_r3d
                        when ('1', '0', !'11111', '110', '0', _) => __encoding A64_ldst_asisdlsop_LD1R_asisdlsop_R1_i // LD1R_asisdlsop_RX1_r
                        when ('1', '0', !'11111', '111', '0', _) => __encoding A64_ldst_asisdlsop_LD3R_asisdlsop_R3_i // LD3R_asisdlsop_RX3_r
                        when ('1', '0', '11111', '000', _, _) => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_B1_i1b
                        when ('1', '0', '11111', '001', _, _) => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_B3_i3b
                        when ('1', '0', '11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_H1_i1h
                        when ('1', '0', '11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_H3_i3h
                        when ('1', '0', '11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_S1_i1s
                        when ('1', '0', '11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_LD1_asisdlsop_B1_i1b // LD1_asisdlsop_D1_i1d
                        when ('1', '0', '11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_S3_i3s
                        when ('1', '0', '11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_LD3_asisdlsop_B3_i3b // LD3_asisdlsop_D3_i3d
                        when ('1', '0', '11111', '110', '0', _) => __encoding A64_ldst_asisdlsop_LD1R_asisdlsop_R1_i // LD1R_asisdlsop_R1_i
                        when ('1', '0', '11111', '111', '0', _) => __encoding A64_ldst_asisdlsop_LD3R_asisdlsop_R3_i // LD3R_asisdlsop_R3_i
                        when ('1', '1', !'11111', '000', _, _) => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_BX2_r2b
                        when ('1', '1', !'11111', '001', _, _) => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_BX4_r4b
                        when ('1', '1', !'11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_HX2_r2h
                        when ('1', '1', !'11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_HX4_r4h
                        when ('1', '1', !'11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_SX2_r2s
                        when ('1', '1', !'11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_DX2_r2d
                        when ('1', '1', !'11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_SX4_r4s
                        when ('1', '1', !'11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_DX4_r4d
                        when ('1', '1', !'11111', '110', '0', _) => __encoding A64_ldst_asisdlsop_LD2R_asisdlsop_R2_i // LD2R_asisdlsop_RX2_r
                        when ('1', '1', !'11111', '111', '0', _) => __encoding A64_ldst_asisdlsop_LD4R_asisdlsop_R4_i // LD4R_asisdlsop_RX4_r
                        when ('1', '1', '11111', '000', _, _) => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_B2_i2b
                        when ('1', '1', '11111', '001', _, _) => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_B4_i4b
                        when ('1', '1', '11111', '010', _, 'x0') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_H2_i2h
                        when ('1', '1', '11111', '011', _, 'x0') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_H4_i4h
                        when ('1', '1', '11111', '100', _, '00') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_S2_i2s
                        when ('1', '1', '11111', '100', '0', '01') => __encoding A64_ldst_asisdlsop_LD2_asisdlsop_B2_i2b // LD2_asisdlsop_D2_i2d
                        when ('1', '1', '11111', '101', _, '00') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_S4_i4s
                        when ('1', '1', '11111', '101', '0', '01') => __encoding A64_ldst_asisdlsop_LD4_asisdlsop_B4_i4b // LD4_asisdlsop_D4_i4d
                        when ('1', '1', '11111', '110', '0', _) => __encoding A64_ldst_asisdlsop_LD2R_asisdlsop_R2_i // LD2R_asisdlsop_R2_i
                        when ('1', '1', '11111', '111', '0', _) => __encoding A64_ldst_asisdlsop_LD4R_asisdlsop_R4_i // LD4R_asisdlsop_R4_i
                when ('0x00', _, '1', _, 'x0x00001xxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0x0001xxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0x001xxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x00', _, '1', _, 'x0x01xxxxxxxxxx', _) => __UNPREDICTABLE
                when ('0x01', _, '0', _, '1xx0xxxxxxxxx11', _) => __UNPREDICTABLE
                when ('0x01', _, '0', _, '1xx1xxxxx000010', _) => // rcwcomswap
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R) of
                        when ('0', '0', '0') => __encoding A64_ldst_rcwcomswap_RCWCAS_C64_rcwcomswap // RCWCAS_C64_rcwcomswap
                        when ('0', '0', '1') => __encoding A64_ldst_rcwcomswap_RCWCAS_C64_rcwcomswap // RCWCASL_C64_rcwcomswap
                        when ('0', '1', '0') => __encoding A64_ldst_rcwcomswap_RCWCAS_C64_rcwcomswap // RCWCASA_C64_rcwcomswap
                        when ('0', '1', '1') => __encoding A64_ldst_rcwcomswap_RCWCAS_C64_rcwcomswap // RCWCASAL_C64_rcwcomswap
                        when ('1', '0', '0') => __encoding A64_ldst_rcwcomswap_RCWSCAS_C64_rcwcomswap // RCWSCAS_C64_rcwcomswap
                        when ('1', '0', '1') => __encoding A64_ldst_rcwcomswap_RCWSCAS_C64_rcwcomswap // RCWSCASL_C64_rcwcomswap
                        when ('1', '1', '0') => __encoding A64_ldst_rcwcomswap_RCWSCAS_C64_rcwcomswap // RCWSCASA_C64_rcwcomswap
                        when ('1', '1', '1') => __encoding A64_ldst_rcwcomswap_RCWSCAS_C64_rcwcomswap // RCWSCASAL_C64_rcwcomswap
                when ('0x01', _, '0', _, '1xx1xxxxx000011', _) => // rcwcomswappr
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R) of
                        when ('0', '0', '0') => __encoding A64_ldst_rcwcomswappr_RCWCASP_C64_rcwcomswappr // RCWCASP_C64_rcwcomswappr
                        when ('0', '0', '1') => __encoding A64_ldst_rcwcomswappr_RCWCASP_C64_rcwcomswappr // RCWCASPL_C64_rcwcomswappr
                        when ('0', '1', '0') => __encoding A64_ldst_rcwcomswappr_RCWCASP_C64_rcwcomswappr // RCWCASPA_C64_rcwcomswappr
                        when ('0', '1', '1') => __encoding A64_ldst_rcwcomswappr_RCWCASP_C64_rcwcomswappr // RCWCASPAL_C64_rcwcomswappr
                        when ('1', '0', '0') => __encoding A64_ldst_rcwcomswappr_RCWSCASP_C64_rcwcomswappr // RCWSCASP_C64_rcwcomswappr
                        when ('1', '0', '1') => __encoding A64_ldst_rcwcomswappr_RCWSCASP_C64_rcwcomswappr // RCWSCASPL_C64_rcwcomswappr
                        when ('1', '1', '0') => __encoding A64_ldst_rcwcomswappr_RCWSCASP_C64_rcwcomswappr // RCWSCASPA_C64_rcwcomswappr
                        when ('1', '1', '1') => __encoding A64_ldst_rcwcomswappr_RCWSCASP_C64_rcwcomswappr // RCWSCASPAL_C64_rcwcomswappr
                when ('0x01', _, '0', _, '1xx1xxxxx00011x', _) => __UNPREDICTABLE
                when ('0x01', _, '0', _, '1xx1xxxxx001x1x', _) => __UNPREDICTABLE
                when ('0x01', _, '0', _, '1xx1xxxxx01xx1x', _) => __UNPREDICTABLE
                when ('0x01', _, '0', _, '1xx1xxxxx1xxx1x', _) => __UNPREDICTABLE
                when ('0x01', _, '0', _, '1xx1xxxxxxxxx00', _) => // memop_128
                    __field S 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rt2 16 +: 5
                    __field o3 15 +: 1
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (S, A, R, o3, opc) of
                        when (_, _, _, _, '1xx') => __UNALLOCATED
                        when ('0', _, _, '0', '0x0') => __UNALLOCATED
                        when ('0', '0', '0', '0', '001') => __encoding A64_ldst_memop_128_LDCLRP_128_memop_128 // LDCLRP_128_memop_128
                        when ('0', '0', '0', '0', '011') => __encoding A64_ldst_memop_128_LDSETP_128_memop_128 // LDSETP_128_memop_128
                        when ('0', '0', '0', '1', '000') => __encoding A64_ldst_memop_128_SWPP_128_memop_128 // SWPP_128_memop_128
                        when ('0', '0', '0', '1', '001') => __encoding A64_ldst_memop_128_RCWCLRP_128_memop_128 // RCWCLRP_128_memop_128
                        when ('0', '0', '0', '1', '010') => __encoding A64_ldst_memop_128_RCWSWPP_128_memop_128 // RCWSWPP_128_memop_128
                        when ('0', '0', '0', '1', '011') => __encoding A64_ldst_memop_128_RCWSETP_128_memop_128 // RCWSETP_128_memop_128
                        when ('0', '0', '1', '0', '001') => __encoding A64_ldst_memop_128_LDCLRP_128_memop_128 // LDCLRPL_128_memop_128
                        when ('0', '0', '1', '0', '011') => __encoding A64_ldst_memop_128_LDSETP_128_memop_128 // LDSETPL_128_memop_128
                        when ('0', '0', '1', '1', '000') => __encoding A64_ldst_memop_128_SWPP_128_memop_128 // SWPPL_128_memop_128
                        when ('0', '0', '1', '1', '001') => __encoding A64_ldst_memop_128_RCWCLRP_128_memop_128 // RCWCLRPL_128_memop_128
                        when ('0', '0', '1', '1', '010') => __encoding A64_ldst_memop_128_RCWSWPP_128_memop_128 // RCWSWPPL_128_memop_128
                        when ('0', '0', '1', '1', '011') => __encoding A64_ldst_memop_128_RCWSETP_128_memop_128 // RCWSETPL_128_memop_128
                        when ('0', '1', '0', '0', '001') => __encoding A64_ldst_memop_128_LDCLRP_128_memop_128 // LDCLRPA_128_memop_128
                        when ('0', '1', '0', '0', '011') => __encoding A64_ldst_memop_128_LDSETP_128_memop_128 // LDSETPA_128_memop_128
                        when ('0', '1', '0', '1', '000') => __encoding A64_ldst_memop_128_SWPP_128_memop_128 // SWPPA_128_memop_128
                        when ('0', '1', '0', '1', '001') => __encoding A64_ldst_memop_128_RCWCLRP_128_memop_128 // RCWCLRPA_128_memop_128
                        when ('0', '1', '0', '1', '010') => __encoding A64_ldst_memop_128_RCWSWPP_128_memop_128 // RCWSWPPA_128_memop_128
                        when ('0', '1', '0', '1', '011') => __encoding A64_ldst_memop_128_RCWSETP_128_memop_128 // RCWSETPA_128_memop_128
                        when ('0', '1', '1', '0', '001') => __encoding A64_ldst_memop_128_LDCLRP_128_memop_128 // LDCLRPAL_128_memop_128
                        when ('0', '1', '1', '0', '011') => __encoding A64_ldst_memop_128_LDSETP_128_memop_128 // LDSETPAL_128_memop_128
                        when ('0', '1', '1', '1', '000') => __encoding A64_ldst_memop_128_SWPP_128_memop_128 // SWPPAL_128_memop_128
                        when ('0', '1', '1', '1', '001') => __encoding A64_ldst_memop_128_RCWCLRP_128_memop_128 // RCWCLRPAL_128_memop_128
                        when ('0', '1', '1', '1', '010') => __encoding A64_ldst_memop_128_RCWSWPP_128_memop_128 // RCWSWPPAL_128_memop_128
                        when ('0', '1', '1', '1', '011') => __encoding A64_ldst_memop_128_RCWSETP_128_memop_128 // RCWSETPAL_128_memop_128
                        when ('1', _, _, '0', '0xx') => __UNALLOCATED
                        when ('1', _, _, '1', '000') => __UNALLOCATED
                        when ('1', '0', '0', '1', '001') => __encoding A64_ldst_memop_128_RCWSCLRP_128_memop_128 // RCWSCLRP_128_memop_128
                        when ('1', '0', '0', '1', '010') => __encoding A64_ldst_memop_128_RCWSSWPP_128_memop_128 // RCWSSWPP_128_memop_128
                        when ('1', '0', '0', '1', '011') => __encoding A64_ldst_memop_128_RCWSSETP_128_memop_128 // RCWSSETP_128_memop_128
                        when ('1', '0', '1', '1', '001') => __encoding A64_ldst_memop_128_RCWSCLRP_128_memop_128 // RCWSCLRPL_128_memop_128
                        when ('1', '0', '1', '1', '010') => __encoding A64_ldst_memop_128_RCWSSWPP_128_memop_128 // RCWSSWPPL_128_memop_128
                        when ('1', '0', '1', '1', '011') => __encoding A64_ldst_memop_128_RCWSSETP_128_memop_128 // RCWSSETPL_128_memop_128
                        when ('1', '1', '0', '1', '001') => __encoding A64_ldst_memop_128_RCWSCLRP_128_memop_128 // RCWSCLRPA_128_memop_128
                        when ('1', '1', '0', '1', '010') => __encoding A64_ldst_memop_128_RCWSSWPP_128_memop_128 // RCWSSWPPA_128_memop_128
                        when ('1', '1', '0', '1', '011') => __encoding A64_ldst_memop_128_RCWSSETP_128_memop_128 // RCWSSETPA_128_memop_128
                        when ('1', '1', '1', '1', '001') => __encoding A64_ldst_memop_128_RCWSCLRP_128_memop_128 // RCWSCLRPAL_128_memop_128
                        when ('1', '1', '1', '1', '010') => __encoding A64_ldst_memop_128_RCWSSWPP_128_memop_128 // RCWSSWPPAL_128_memop_128
                        when ('1', '1', '1', '1', '011') => __encoding A64_ldst_memop_128_RCWSSETP_128_memop_128 // RCWSSETPAL_128_memop_128
                when ('0x01', _, '0', _, '1xx1xxxxxxxxx01', _) => // memop_unpriv
                    __field sz 30 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field o3 15 +: 1
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, A, R, o3, opc) of
                        when (_, _, _, _, '010') => __UNALLOCATED
                        when (_, _, _, _, '1xx') => __UNALLOCATED
                        when (_, _, _, '1', '0x1') => __UNALLOCATED
                        when ('0', '0', '0', '0', '000') => __encoding A64_ldst_memop_unpriv_LDTADD_32_memop_unpriv // LDTADD_32_memop_unpriv
                        when ('0', '0', '0', '0', '001') => __encoding A64_ldst_memop_unpriv_LDTCLR_32_memop_unpriv // LDTCLR_32_memop_unpriv
                        when ('0', '0', '0', '0', '011') => __encoding A64_ldst_memop_unpriv_LDTSET_32_memop_unpriv // LDTSET_32_memop_unpriv
                        when ('0', '0', '0', '1', '000') => __encoding A64_ldst_memop_unpriv_SWPT_32_memop_unpriv // SWPT_32_memop_unpriv
                        when ('0', '0', '1', '0', '000') => __encoding A64_ldst_memop_unpriv_LDTADD_32_memop_unpriv // LDTADDL_32_memop_unpriv
                        when ('0', '0', '1', '0', '001') => __encoding A64_ldst_memop_unpriv_LDTCLR_32_memop_unpriv // LDTCLRL_32_memop_unpriv
                        when ('0', '0', '1', '0', '011') => __encoding A64_ldst_memop_unpriv_LDTSET_32_memop_unpriv // LDTSETL_32_memop_unpriv
                        when ('0', '0', '1', '1', '000') => __encoding A64_ldst_memop_unpriv_SWPT_32_memop_unpriv // SWPTL_32_memop_unpriv
                        when ('0', '1', '0', '0', '000') => __encoding A64_ldst_memop_unpriv_LDTADD_32_memop_unpriv // LDTADDA_32_memop_unpriv
                        when ('0', '1', '0', '0', '001') => __encoding A64_ldst_memop_unpriv_LDTCLR_32_memop_unpriv // LDTCLRA_32_memop_unpriv
                        when ('0', '1', '0', '0', '011') => __encoding A64_ldst_memop_unpriv_LDTSET_32_memop_unpriv // LDTSETA_32_memop_unpriv
                        when ('0', '1', '0', '1', '000') => __encoding A64_ldst_memop_unpriv_SWPT_32_memop_unpriv // SWPTA_32_memop_unpriv
                        when ('0', '1', '1', '0', '000') => __encoding A64_ldst_memop_unpriv_LDTADD_32_memop_unpriv // LDTADDAL_32_memop_unpriv
                        when ('0', '1', '1', '0', '001') => __encoding A64_ldst_memop_unpriv_LDTCLR_32_memop_unpriv // LDTCLRAL_32_memop_unpriv
                        when ('0', '1', '1', '0', '011') => __encoding A64_ldst_memop_unpriv_LDTSET_32_memop_unpriv // LDTSETAL_32_memop_unpriv
                        when ('0', '1', '1', '1', '000') => __encoding A64_ldst_memop_unpriv_SWPT_32_memop_unpriv // SWPTAL_32_memop_unpriv
                        when ('1', '0', '0', '0', '000') => __encoding A64_ldst_memop_unpriv_LDTADD_32_memop_unpriv // LDTADD_64_memop_unpriv
                        when ('1', '0', '0', '0', '001') => __encoding A64_ldst_memop_unpriv_LDTCLR_32_memop_unpriv // LDTCLR_64_memop_unpriv
                        when ('1', '0', '0', '0', '011') => __encoding A64_ldst_memop_unpriv_LDTSET_32_memop_unpriv // LDTSET_64_memop_unpriv
                        when ('1', '0', '0', '1', '000') => __encoding A64_ldst_memop_unpriv_SWPT_32_memop_unpriv // SWPT_64_memop_unpriv
                        when ('1', '0', '1', '0', '000') => __encoding A64_ldst_memop_unpriv_LDTADD_32_memop_unpriv // LDTADDL_64_memop_unpriv
                        when ('1', '0', '1', '0', '001') => __encoding A64_ldst_memop_unpriv_LDTCLR_32_memop_unpriv // LDTCLRL_64_memop_unpriv
                        when ('1', '0', '1', '0', '011') => __encoding A64_ldst_memop_unpriv_LDTSET_32_memop_unpriv // LDTSETL_64_memop_unpriv
                        when ('1', '0', '1', '1', '000') => __encoding A64_ldst_memop_unpriv_SWPT_32_memop_unpriv // SWPTL_64_memop_unpriv
                        when ('1', '1', '0', '0', '000') => __encoding A64_ldst_memop_unpriv_LDTADD_32_memop_unpriv // LDTADDA_64_memop_unpriv
                        when ('1', '1', '0', '0', '001') => __encoding A64_ldst_memop_unpriv_LDTCLR_32_memop_unpriv // LDTCLRA_64_memop_unpriv
                        when ('1', '1', '0', '0', '011') => __encoding A64_ldst_memop_unpriv_LDTSET_32_memop_unpriv // LDTSETA_64_memop_unpriv
                        when ('1', '1', '0', '1', '000') => __encoding A64_ldst_memop_unpriv_SWPT_32_memop_unpriv // SWPTA_64_memop_unpriv
                        when ('1', '1', '1', '0', '000') => __encoding A64_ldst_memop_unpriv_LDTADD_32_memop_unpriv // LDTADDAL_64_memop_unpriv
                        when ('1', '1', '1', '0', '001') => __encoding A64_ldst_memop_unpriv_LDTCLR_32_memop_unpriv // LDTCLRAL_64_memop_unpriv
                        when ('1', '1', '1', '0', '011') => __encoding A64_ldst_memop_unpriv_LDTSET_32_memop_unpriv // LDTSETAL_64_memop_unpriv
                        when ('1', '1', '1', '1', '000') => __encoding A64_ldst_memop_unpriv_SWPT_32_memop_unpriv // SWPTAL_64_memop_unpriv
                when ('1001', _, '0', _, '1xx0xxxxxxxxx11', _) => __UNPREDICTABLE
                when ('1001', _, '1', _, '1xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('100x', _, '0', _, '1xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1000111110xxx11', _) => // ldst_gcs
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc) of
                        when ('000') => __encoding A64_ldst_ldst_gcs_GCSSTR_64_ldst_gcs // GCSSTR_64_ldst_gcs
                        when ('001') => __encoding A64_ldst_ldst_gcs_GCSSTTR_64_ldst_gcs // GCSSTTR_64_ldst_gcs
                        when ('01x') => __UNALLOCATED
                        when ('1xx') => __UNALLOCATED
                when ('1101', _, '0', _, '1100111110xxx11', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1x000xxxxxxxx11', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1x0010xxxxxxx11', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1x00110xxxxxx11', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1x001110xxxxx11', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1x0011110xxxx11', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1x00111111xxx11', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1x10xxxxxxxxx11', _) => __UNPREDICTABLE
                when ('1101', _, '0', _, '1xx1xxxxxxxxxxx', _) => // ldsttags
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field op2 10 +: 2
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, imm9, op2) of
                        when (!'01', !'000000000', '00') => __UNALLOCATED
                        when ('00', _, '01') => __encoding A64_ldst_ldsttags_STG_64Spost_ldsttags // STG_64Spost_ldsttags
                        when ('00', _, '10') => __encoding A64_ldst_ldsttags_STG_64Soffset_ldsttags // STG_64Soffset_ldsttags
                        when ('00', _, '11') => __encoding A64_ldst_ldsttags_STG_64Spre_ldsttags // STG_64Spre_ldsttags
                        when ('00', '000000000', '00') => __encoding A64_ldst_ldsttags_STZGM_64bulk_ldsttags // STZGM_64bulk_ldsttags
                        when ('01', _, '00') => __encoding A64_ldst_ldsttags_LDG_64Loffset_ldsttags // LDG_64Loffset_ldsttags
                        when ('01', _, '01') => __encoding A64_ldst_ldsttags_STZG_64Spost_ldsttags // STZG_64Spost_ldsttags
                        when ('01', _, '10') => __encoding A64_ldst_ldsttags_STZG_64Soffset_ldsttags // STZG_64Soffset_ldsttags
                        when ('01', _, '11') => __encoding A64_ldst_ldsttags_STZG_64Spre_ldsttags // STZG_64Spre_ldsttags
                        when ('10', _, '01') => __encoding A64_ldst_ldsttags_ST2G_64Spost_ldsttags // ST2G_64Spost_ldsttags
                        when ('10', _, '10') => __encoding A64_ldst_ldsttags_ST2G_64Soffset_ldsttags // ST2G_64Soffset_ldsttags
                        when ('10', _, '11') => __encoding A64_ldst_ldsttags_ST2G_64Spre_ldsttags // ST2G_64Spre_ldsttags
                        when ('10', '000000000', '00') => __encoding A64_ldst_ldsttags_STGM_64bulk_ldsttags // STGM_64bulk_ldsttags
                        when ('11', _, '01') => __encoding A64_ldst_ldsttags_STZ2G_64Spost_ldsttags // STZ2G_64Spost_ldsttags
                        when ('11', _, '10') => __encoding A64_ldst_ldsttags_STZ2G_64Soffset_ldsttags // STZ2G_64Soffset_ldsttags
                        when ('11', _, '11') => __encoding A64_ldst_ldsttags_STZ2G_64Spre_ldsttags // STZ2G_64Spre_ldsttags
                        when ('11', '000000000', '00') => __encoding A64_ldst_ldsttags_LDGM_64bulk_ldsttags // LDGM_64bulk_ldsttags
                when ('1x00', _, '0', _, '00x1xxxxxxxxxxx', _) => // ldstexclp
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0) of
                        when ('0', '0', '0') => __encoding A64_ldst_ldstexclp_STXP_SP32_ldstexclp // STXP_SP32_ldstexclp
                        when ('0', '0', '1') => __encoding A64_ldst_ldstexclp_STLXP_SP32_ldstexclp // STLXP_SP32_ldstexclp
                        when ('0', '1', '0') => __encoding A64_ldst_ldstexclp_LDXP_LP32_ldstexclp // LDXP_LP32_ldstexclp
                        when ('0', '1', '1') => __encoding A64_ldst_ldstexclp_LDAXP_LP32_ldstexclp // LDAXP_LP32_ldstexclp
                        when ('1', '0', '0') => __encoding A64_ldst_ldstexclp_STXP_SP32_ldstexclp // STXP_SP64_ldstexclp
                        when ('1', '0', '1') => __encoding A64_ldst_ldstexclp_STLXP_SP32_ldstexclp // STLXP_SP64_ldstexclp
                        when ('1', '1', '0') => __encoding A64_ldst_ldstexclp_LDXP_LP32_ldstexclp // LDXP_LP64_ldstexclp
                        when ('1', '1', '1') => __encoding A64_ldst_ldstexclp_LDAXP_LP32_ldstexclp // LDAXP_LP64_ldstexclp
                when ('1x00', _, '0', _, '10x0xxxxxxxxxxx', _) => // ldstexclr_unpriv
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0) of
                        when ('0', '0', '0') => __encoding A64_ldst_ldstexclr_unpriv_STTXR_SR32_ldstexclr_unpriv // STTXR_SR32_ldstexclr_unpriv
                        when ('0', '0', '1') => __encoding A64_ldst_ldstexclr_unpriv_STLTXR_SR32_ldstexclr_unpriv // STLTXR_SR32_ldstexclr_unpriv
                        when ('0', '1', '0') => __encoding A64_ldst_ldstexclr_unpriv_LDTXR_LR32_ldstexclr_unpriv // LDTXR_LR32_ldstexclr_unpriv
                        when ('0', '1', '1') => __encoding A64_ldst_ldstexclr_unpriv_LDATXR_LR32_ldstexclr_unpriv // LDATXR_LR32_ldstexclr_unpriv
                        when ('1', '0', '0') => __encoding A64_ldst_ldstexclr_unpriv_STTXR_SR32_ldstexclr_unpriv // STTXR_SR64_ldstexclr_unpriv
                        when ('1', '0', '1') => __encoding A64_ldst_ldstexclr_unpriv_STLTXR_SR32_ldstexclr_unpriv // STLTXR_SR64_ldstexclr_unpriv
                        when ('1', '1', '0') => __encoding A64_ldst_ldstexclr_unpriv_LDTXR_LR32_ldstexclr_unpriv // LDTXR_LR64_ldstexclr_unpriv
                        when ('1', '1', '1') => __encoding A64_ldst_ldstexclr_unpriv_LDATXR_LR32_ldstexclr_unpriv // LDATXR_LR64_ldstexclr_unpriv
                when ('1x00', _, '0', _, '11x0xxxxxxxxxxx', _) => // comswap_unpriv
                    __field sz 30 +: 1
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (sz, L, o0, Rt2) of
                        when ('0', _, _, _) => __UNALLOCATED
                        when ('1', _, _, !'11111') => __UNALLOCATED
                        when ('1', '0', '0', '11111') => __encoding A64_ldst_comswap_unpriv_CAST_C64_comswap_unpriv // CAST_C64_comswap_unpriv
                        when ('1', '0', '1', '11111') => __encoding A64_ldst_comswap_unpriv_CAST_C64_comswap_unpriv // CASLT_C64_comswap_unpriv
                        when ('1', '1', '0', '11111') => __encoding A64_ldst_comswap_unpriv_CAST_C64_comswap_unpriv // CASAT_C64_comswap_unpriv
                        when ('1', '1', '1', '11111') => __encoding A64_ldst_comswap_unpriv_CAST_C64_comswap_unpriv // CASALT_C64_comswap_unpriv
                when ('1x00', _, '1', _, _, _) => __UNPREDICTABLE
                when ('x100', _, '0', _, '1xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('x101', _, '1', _, '1xx1xxxxxxxxxxx', _) => __UNPREDICTABLE
                when ('xx00', _, '0', _, '00x0xxxxxxxxxxx', _) => // ldstexclr
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstexclr_STXRB_SR32_ldstexclr // STXRB_SR32_ldstexclr
                        when ('00', '0', '1') => __encoding A64_ldst_ldstexclr_STLXRB_SR32_ldstexclr // STLXRB_SR32_ldstexclr
                        when ('00', '1', '0') => __encoding A64_ldst_ldstexclr_LDXRB_LR32_ldstexclr // LDXRB_LR32_ldstexclr
                        when ('00', '1', '1') => __encoding A64_ldst_ldstexclr_LDAXRB_LR32_ldstexclr // LDAXRB_LR32_ldstexclr
                        when ('01', '0', '0') => __encoding A64_ldst_ldstexclr_STXRH_SR32_ldstexclr // STXRH_SR32_ldstexclr
                        when ('01', '0', '1') => __encoding A64_ldst_ldstexclr_STLXRH_SR32_ldstexclr // STLXRH_SR32_ldstexclr
                        when ('01', '1', '0') => __encoding A64_ldst_ldstexclr_LDXRH_LR32_ldstexclr // LDXRH_LR32_ldstexclr
                        when ('01', '1', '1') => __encoding A64_ldst_ldstexclr_LDAXRH_LR32_ldstexclr // LDAXRH_LR32_ldstexclr
                        when ('10', '0', '0') => __encoding A64_ldst_ldstexclr_STXR_SR32_ldstexclr // STXR_SR32_ldstexclr
                        when ('10', '0', '1') => __encoding A64_ldst_ldstexclr_STLXR_SR32_ldstexclr // STLXR_SR32_ldstexclr
                        when ('10', '1', '0') => __encoding A64_ldst_ldstexclr_LDXR_LR32_ldstexclr // LDXR_LR32_ldstexclr
                        when ('10', '1', '1') => __encoding A64_ldst_ldstexclr_LDAXR_LR32_ldstexclr // LDAXR_LR32_ldstexclr
                        when ('11', '0', '0') => __encoding A64_ldst_ldstexclr_STXR_SR32_ldstexclr // STXR_SR64_ldstexclr
                        when ('11', '0', '1') => __encoding A64_ldst_ldstexclr_STLXR_SR32_ldstexclr // STLXR_SR64_ldstexclr
                        when ('11', '1', '0') => __encoding A64_ldst_ldstexclr_LDXR_LR32_ldstexclr // LDXR_LR64_ldstexclr
                        when ('11', '1', '1') => __encoding A64_ldst_ldstexclr_LDAXR_LR32_ldstexclr // LDAXR_LR64_ldstexclr
                when ('xx00', _, '0', _, '01x0xxxxxxxxxxx', _) => // ldstord
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstord_STLLRB_SL32_ldstord // STLLRB_SL32_ldstord
                        when ('00', '0', '1') => __encoding A64_ldst_ldstord_STLRB_SL32_ldstord // STLRB_SL32_ldstord
                        when ('00', '1', '0') => __encoding A64_ldst_ldstord_LDLARB_LR32_ldstord // LDLARB_LR32_ldstord
                        when ('00', '1', '1') => __encoding A64_ldst_ldstord_LDARB_LR32_ldstord // LDARB_LR32_ldstord
                        when ('01', '0', '0') => __encoding A64_ldst_ldstord_STLLRH_SL32_ldstord // STLLRH_SL32_ldstord
                        when ('01', '0', '1') => __encoding A64_ldst_ldstord_STLRH_SL32_ldstord // STLRH_SL32_ldstord
                        when ('01', '1', '0') => __encoding A64_ldst_ldstord_LDLARH_LR32_ldstord // LDLARH_LR32_ldstord
                        when ('01', '1', '1') => __encoding A64_ldst_ldstord_LDARH_LR32_ldstord // LDARH_LR32_ldstord
                        when ('10', '0', '0') => __encoding A64_ldst_ldstord_STLLR_SL32_ldstord // STLLR_SL32_ldstord
                        when ('10', '0', '1') => __encoding A64_ldst_ldstord_STLR_SL32_ldstord // STLR_SL32_ldstord
                        when ('10', '1', '0') => __encoding A64_ldst_ldstord_LDLAR_LR32_ldstord // LDLAR_LR32_ldstord
                        when ('10', '1', '1') => __encoding A64_ldst_ldstord_LDAR_LR32_ldstord // LDAR_LR32_ldstord
                        when ('11', '0', '0') => __encoding A64_ldst_ldstord_STLLR_SL32_ldstord // STLLR_SL64_ldstord
                        when ('11', '0', '1') => __encoding A64_ldst_ldstord_STLR_SL32_ldstord // STLR_SL64_ldstord
                        when ('11', '1', '0') => __encoding A64_ldst_ldstord_LDLAR_LR32_ldstord // LDLAR_LR64_ldstord
                        when ('11', '1', '1') => __encoding A64_ldst_ldstord_LDAR_LR32_ldstord // LDAR_LR64_ldstord
                when ('xx00', _, '0', _, '01x1xxxxxxxxxxx', _) => // comswap
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rs 16 +: 5
                    __field o0 15 +: 1
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, o0, Rt2) of
                        when (_, _, _, !'11111') => __UNALLOCATED
                        when ('00', '0', '0', '11111') => __encoding A64_ldst_comswap_CASB_C32_comswap // CASB_C32_comswap
                        when ('00', '0', '1', '11111') => __encoding A64_ldst_comswap_CASB_C32_comswap // CASLB_C32_comswap
                        when ('00', '1', '0', '11111') => __encoding A64_ldst_comswap_CASB_C32_comswap // CASAB_C32_comswap
                        when ('00', '1', '1', '11111') => __encoding A64_ldst_comswap_CASB_C32_comswap // CASALB_C32_comswap
                        when ('01', '0', '0', '11111') => __encoding A64_ldst_comswap_CASH_C32_comswap // CASH_C32_comswap
                        when ('01', '0', '1', '11111') => __encoding A64_ldst_comswap_CASH_C32_comswap // CASLH_C32_comswap
                        when ('01', '1', '0', '11111') => __encoding A64_ldst_comswap_CASH_C32_comswap // CASAH_C32_comswap
                        when ('01', '1', '1', '11111') => __encoding A64_ldst_comswap_CASH_C32_comswap // CASALH_C32_comswap
                        when ('10', '0', '0', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CAS_C32_comswap
                        when ('10', '0', '1', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASL_C32_comswap
                        when ('10', '1', '0', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASA_C32_comswap
                        when ('10', '1', '1', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASAL_C32_comswap
                        when ('11', '0', '0', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CAS_C64_comswap
                        when ('11', '0', '1', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASL_C64_comswap
                        when ('11', '1', '0', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASA_C64_comswap
                        when ('11', '1', '1', '11111') => __encoding A64_ldst_comswap_CAS_C32_comswap // CASAL_C64_comswap
                when ('xx01', _, '0', _, '10x0xxxxxxxxx10', _) => // ldiappstilp
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rt2 16 +: 5
                    __field opc2 12 +: 4
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L, opc2) of
                        when ('0x', _, _) => __UNALLOCATED
                        when ('1x', _, '001x') => __UNALLOCATED
                        when ('1x', _, '01xx') => __UNALLOCATED
                        when ('1x', _, '1xxx') => __UNALLOCATED
                        when ('10', '0', '0000') => __encoding A64_ldst_ldiappstilp_STILP_32SE_ldiappstilp // STILP_32SE_ldiappstilp
                        when ('10', '0', '0001') => __encoding A64_ldst_ldiappstilp_STILP_32SE_ldiappstilp // STILP_32S_ldiappstilp
                        when ('10', '1', '0000') => __encoding A64_ldst_ldiappstilp_LDIAPP_32LE_ldiappstilp // LDIAPP_32LE_ldiappstilp
                        when ('10', '1', '0001') => __encoding A64_ldst_ldiappstilp_LDIAPP_32LE_ldiappstilp // LDIAPP_32L_ldiappstilp
                        when ('11', '0', '0000') => __encoding A64_ldst_ldiappstilp_STILP_32SE_ldiappstilp // STILP_64SS_ldiappstilp
                        when ('11', '0', '0001') => __encoding A64_ldst_ldiappstilp_STILP_32SE_ldiappstilp // STILP_64S_ldiappstilp
                        when ('11', '1', '0000') => __encoding A64_ldst_ldiappstilp_LDIAPP_32LE_ldiappstilp // LDIAPP_64LS_ldiappstilp
                        when ('11', '1', '0001') => __encoding A64_ldst_ldiappstilp_LDIAPP_32LE_ldiappstilp // LDIAPP_64L_ldiappstilp
                when ('xx01', _, '0', _, '11x000000000010', _) => // ldapstl_writeback
                    __field size 30 +: 2
                    __field L 22 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, L) of
                        when ('0x', _) => __UNALLOCATED
                        when ('10', '0') => __encoding A64_ldst_ldapstl_writeback_STLR_32S_ldapstl_writeback // STLR_32S_ldapstl_writeback
                        when ('10', '1') => __encoding A64_ldst_ldapstl_writeback_LDAPR_32L_ldapstl_writeback // LDAPR_32L_ldapstl_writeback
                        when ('11', '0') => __encoding A64_ldst_ldapstl_writeback_STLR_32S_ldapstl_writeback // STLR_64S_ldapstl_writeback
                        when ('11', '1') => __encoding A64_ldst_ldapstl_writeback_LDAPR_32L_ldapstl_writeback // LDAPR_64L_ldapstl_writeback
                when ('xx01', _, '0', _, '11x000000000110', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '11x000000001x10', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '11x00000001xx10', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '11x0000001xxx10', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '11x000001xxxx10', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '11x00001xxxxx10', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '11x0001xxxxxx10', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '11x001xxxxxxx10', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '11x01xxxxxxxx10', _) => __UNPREDICTABLE
                when ('xx01', _, '0', _, '1xx0xxxxxxxxx00', _) => // ldapstl_unscaled
                    __field size 30 +: 2
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, opc) of
                        when ('00', '00') => __encoding A64_ldst_ldapstl_unscaled_STLURB_32_ldapstl_unscaled // STLURB_32_ldapstl_unscaled
                        when ('00', '01') => __encoding A64_ldst_ldapstl_unscaled_LDAPURB_32_ldapstl_unscaled // LDAPURB_32_ldapstl_unscaled
                        when ('00', '10') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSB_32_ldapstl_unscaled // LDAPURSB_64_ldapstl_unscaled
                        when ('00', '11') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSB_32_ldapstl_unscaled // LDAPURSB_32_ldapstl_unscaled
                        when ('01', '00') => __encoding A64_ldst_ldapstl_unscaled_STLURH_32_ldapstl_unscaled // STLURH_32_ldapstl_unscaled
                        when ('01', '01') => __encoding A64_ldst_ldapstl_unscaled_LDAPURH_32_ldapstl_unscaled // LDAPURH_32_ldapstl_unscaled
                        when ('01', '10') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSH_32_ldapstl_unscaled // LDAPURSH_64_ldapstl_unscaled
                        when ('01', '11') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSH_32_ldapstl_unscaled // LDAPURSH_32_ldapstl_unscaled
                        when ('10', '00') => __encoding A64_ldst_ldapstl_unscaled_STLUR_32_ldapstl_unscaled // STLUR_32_ldapstl_unscaled
                        when ('10', '01') => __encoding A64_ldst_ldapstl_unscaled_LDAPUR_32_ldapstl_unscaled // LDAPUR_32_ldapstl_unscaled
                        when ('10', '10') => __encoding A64_ldst_ldapstl_unscaled_LDAPURSW_64_ldapstl_unscaled // LDAPURSW_64_ldapstl_unscaled
                        when ('10', '11') => __UNALLOCATED
                        when ('11', '00') => __encoding A64_ldst_ldapstl_unscaled_STLUR_32_ldapstl_unscaled // STLUR_64_ldapstl_unscaled
                        when ('11', '01') => __encoding A64_ldst_ldapstl_unscaled_LDAPUR_32_ldapstl_unscaled // LDAPUR_64_ldapstl_unscaled
                        when ('11', '1x') => __UNALLOCATED
                when ('xx01', _, '1', _, '1xx0xxxxxxxxx00', _) => __UNPREDICTABLE
                when ('xx01', _, '1', _, '1xx0xxxxxxxxx10', _) => // ldapstl_simd
                    __field size 30 +: 2
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, opc) of
                        when (!'00', '1x') => __UNALLOCATED
                        when ('00', '00') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_B_ldapstl_simd
                        when ('00', '01') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_B_ldapstl_simd
                        when ('00', '10') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_Q_ldapstl_simd
                        when ('00', '11') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_Q_ldapstl_simd
                        when ('01', '00') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_H_ldapstl_simd
                        when ('01', '01') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_H_ldapstl_simd
                        when ('10', '00') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_S_ldapstl_simd
                        when ('10', '01') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_S_ldapstl_simd
                        when ('11', '00') => __encoding A64_ldst_ldapstl_simd_STLUR_B_ldapstl_simd // STLUR_D_ldapstl_simd
                        when ('11', '01') => __encoding A64_ldst_ldapstl_simd_LDAPUR_B_ldapstl_simd // LDAPUR_D_ldapstl_simd
                when ('xx01', _, '1', _, '1xx0xxxxxxxxx11', _) => __UNPREDICTABLE
                when ('xx01', _, _, _, '0xxxxxxxxxxxxxx', _) => // loadlit
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field imm19 5 +: 19
                    __field Rt 0 +: 5
                    case (opc, VR) of
                        when ('00', '0') => __encoding A64_ldst_loadlit_LDR_32_loadlit // LDR_32_loadlit
                        when ('00', '1') => __encoding A64_ldst_loadlit_LDR_S_loadlit // LDR_S_loadlit
                        when ('01', '0') => __encoding A64_ldst_loadlit_LDR_32_loadlit // LDR_64_loadlit
                        when ('01', '1') => __encoding A64_ldst_loadlit_LDR_S_loadlit // LDR_D_loadlit
                        when ('10', '0') => __encoding A64_ldst_loadlit_LDRSW_64_loadlit // LDRSW_64_loadlit
                        when ('10', '1') => __encoding A64_ldst_loadlit_LDR_S_loadlit // LDR_Q_loadlit
                        when ('11', '0') => __encoding A64_ldst_loadlit_PRFM_P_loadlit // PRFM_P_loadlit
                        when ('11', '1') => __UNALLOCATED
                when ('xx01', _, _, _, '1xx0xxxxxxxxx01', _) => // memcms
                    __field size 30 +: 2
                    __field o0 26 +: 1
                    __field op1 22 +: 2
                    __field Rs 16 +: 5
                    __field op2 12 +: 4
                    __field Rn 5 +: 5
                    __field Rd 0 +: 5
                    case (o0, op1, op2) of
                        when (_, '11', '11xx') => __UNALLOCATED
                        when ('0', '00', '0000') => __encoding A64_ldst_memcms_CPYFP_CPY_memcms // CPYFP_CPY_memcms
                        when ('0', '00', '0001') => __encoding A64_ldst_memcms_CPYFPWT_CPY_memcms // CPYFPWT_CPY_memcms
                        when ('0', '00', '0010') => __encoding A64_ldst_memcms_CPYFPRT_CPY_memcms // CPYFPRT_CPY_memcms
                        when ('0', '00', '0011') => __encoding A64_ldst_memcms_CPYFPT_CPY_memcms // CPYFPT_CPY_memcms
                        when ('0', '00', '0100') => __encoding A64_ldst_memcms_CPYFPWN_CPY_memcms // CPYFPWN_CPY_memcms
                        when ('0', '00', '0101') => __encoding A64_ldst_memcms_CPYFPWTWN_CPY_memcms // CPYFPWTWN_CPY_memcms
                        when ('0', '00', '0110') => __encoding A64_ldst_memcms_CPYFPRTWN_CPY_memcms // CPYFPRTWN_CPY_memcms
                        when ('0', '00', '0111') => __encoding A64_ldst_memcms_CPYFPTWN_CPY_memcms // CPYFPTWN_CPY_memcms
                        when ('0', '00', '1000') => __encoding A64_ldst_memcms_CPYFPRN_CPY_memcms // CPYFPRN_CPY_memcms
                        when ('0', '00', '1001') => __encoding A64_ldst_memcms_CPYFPWTRN_CPY_memcms // CPYFPWTRN_CPY_memcms
                        when ('0', '00', '1010') => __encoding A64_ldst_memcms_CPYFPRTRN_CPY_memcms // CPYFPRTRN_CPY_memcms
                        when ('0', '00', '1011') => __encoding A64_ldst_memcms_CPYFPTRN_CPY_memcms // CPYFPTRN_CPY_memcms
                        when ('0', '00', '1100') => __encoding A64_ldst_memcms_CPYFPN_CPY_memcms // CPYFPN_CPY_memcms
                        when ('0', '00', '1101') => __encoding A64_ldst_memcms_CPYFPWTN_CPY_memcms // CPYFPWTN_CPY_memcms
                        when ('0', '00', '1110') => __encoding A64_ldst_memcms_CPYFPRTN_CPY_memcms // CPYFPRTN_CPY_memcms
                        when ('0', '00', '1111') => __encoding A64_ldst_memcms_CPYFPTN_CPY_memcms // CPYFPTN_CPY_memcms
                        when ('0', '01', '0000') => __encoding A64_ldst_memcms_CPYFP_CPY_memcms // CPYFM_CPY_memcms
                        when ('0', '01', '0001') => __encoding A64_ldst_memcms_CPYFPWT_CPY_memcms // CPYFMWT_CPY_memcms
                        when ('0', '01', '0010') => __encoding A64_ldst_memcms_CPYFPRT_CPY_memcms // CPYFMRT_CPY_memcms
                        when ('0', '01', '0011') => __encoding A64_ldst_memcms_CPYFPT_CPY_memcms // CPYFMT_CPY_memcms
                        when ('0', '01', '0100') => __encoding A64_ldst_memcms_CPYFPWN_CPY_memcms // CPYFMWN_CPY_memcms
                        when ('0', '01', '0101') => __encoding A64_ldst_memcms_CPYFPWTWN_CPY_memcms // CPYFMWTWN_CPY_memcms
                        when ('0', '01', '0110') => __encoding A64_ldst_memcms_CPYFPRTWN_CPY_memcms // CPYFMRTWN_CPY_memcms
                        when ('0', '01', '0111') => __encoding A64_ldst_memcms_CPYFPTWN_CPY_memcms // CPYFMTWN_CPY_memcms
                        when ('0', '01', '1000') => __encoding A64_ldst_memcms_CPYFPRN_CPY_memcms // CPYFMRN_CPY_memcms
                        when ('0', '01', '1001') => __encoding A64_ldst_memcms_CPYFPWTRN_CPY_memcms // CPYFMWTRN_CPY_memcms
                        when ('0', '01', '1010') => __encoding A64_ldst_memcms_CPYFPRTRN_CPY_memcms // CPYFMRTRN_CPY_memcms
                        when ('0', '01', '1011') => __encoding A64_ldst_memcms_CPYFPTRN_CPY_memcms // CPYFMTRN_CPY_memcms
                        when ('0', '01', '1100') => __encoding A64_ldst_memcms_CPYFPN_CPY_memcms // CPYFMN_CPY_memcms
                        when ('0', '01', '1101') => __encoding A64_ldst_memcms_CPYFPWTN_CPY_memcms // CPYFMWTN_CPY_memcms
                        when ('0', '01', '1110') => __encoding A64_ldst_memcms_CPYFPRTN_CPY_memcms // CPYFMRTN_CPY_memcms
                        when ('0', '01', '1111') => __encoding A64_ldst_memcms_CPYFPTN_CPY_memcms // CPYFMTN_CPY_memcms
                        when ('0', '10', '0000') => __encoding A64_ldst_memcms_CPYFP_CPY_memcms // CPYFE_CPY_memcms
                        when ('0', '10', '0001') => __encoding A64_ldst_memcms_CPYFPWT_CPY_memcms // CPYFEWT_CPY_memcms
                        when ('0', '10', '0010') => __encoding A64_ldst_memcms_CPYFPRT_CPY_memcms // CPYFERT_CPY_memcms
                        when ('0', '10', '0011') => __encoding A64_ldst_memcms_CPYFPT_CPY_memcms // CPYFET_CPY_memcms
                        when ('0', '10', '0100') => __encoding A64_ldst_memcms_CPYFPWN_CPY_memcms // CPYFEWN_CPY_memcms
                        when ('0', '10', '0101') => __encoding A64_ldst_memcms_CPYFPWTWN_CPY_memcms // CPYFEWTWN_CPY_memcms
                        when ('0', '10', '0110') => __encoding A64_ldst_memcms_CPYFPRTWN_CPY_memcms // CPYFERTWN_CPY_memcms
                        when ('0', '10', '0111') => __encoding A64_ldst_memcms_CPYFPTWN_CPY_memcms // CPYFETWN_CPY_memcms
                        when ('0', '10', '1000') => __encoding A64_ldst_memcms_CPYFPRN_CPY_memcms // CPYFERN_CPY_memcms
                        when ('0', '10', '1001') => __encoding A64_ldst_memcms_CPYFPWTRN_CPY_memcms // CPYFEWTRN_CPY_memcms
                        when ('0', '10', '1010') => __encoding A64_ldst_memcms_CPYFPRTRN_CPY_memcms // CPYFERTRN_CPY_memcms
                        when ('0', '10', '1011') => __encoding A64_ldst_memcms_CPYFPTRN_CPY_memcms // CPYFETRN_CPY_memcms
                        when ('0', '10', '1100') => __encoding A64_ldst_memcms_CPYFPN_CPY_memcms // CPYFEN_CPY_memcms
                        when ('0', '10', '1101') => __encoding A64_ldst_memcms_CPYFPWTN_CPY_memcms // CPYFEWTN_CPY_memcms
                        when ('0', '10', '1110') => __encoding A64_ldst_memcms_CPYFPRTN_CPY_memcms // CPYFERTN_CPY_memcms
                        when ('0', '10', '1111') => __encoding A64_ldst_memcms_CPYFPTN_CPY_memcms // CPYFETN_CPY_memcms
                        when ('0', '11', '0000') => __encoding A64_ldst_memcms_SETP_SET_memcms // SETP_SET_memcms
                        when ('0', '11', '0001') => __encoding A64_ldst_memcms_SETPT_SET_memcms // SETPT_SET_memcms
                        when ('0', '11', '0010') => __encoding A64_ldst_memcms_SETPN_SET_memcms // SETPN_SET_memcms
                        when ('0', '11', '0011') => __encoding A64_ldst_memcms_SETPTN_SET_memcms // SETPTN_SET_memcms
                        when ('0', '11', '0100') => __encoding A64_ldst_memcms_SETP_SET_memcms // SETM_SET_memcms
                        when ('0', '11', '0101') => __encoding A64_ldst_memcms_SETPT_SET_memcms // SETMT_SET_memcms
                        when ('0', '11', '0110') => __encoding A64_ldst_memcms_SETPN_SET_memcms // SETMN_SET_memcms
                        when ('0', '11', '0111') => __encoding A64_ldst_memcms_SETPTN_SET_memcms // SETMTN_SET_memcms
                        when ('0', '11', '1000') => __encoding A64_ldst_memcms_SETP_SET_memcms // SETE_SET_memcms
                        when ('0', '11', '1001') => __encoding A64_ldst_memcms_SETPT_SET_memcms // SETET_SET_memcms
                        when ('0', '11', '1010') => __encoding A64_ldst_memcms_SETPN_SET_memcms // SETEN_SET_memcms
                        when ('0', '11', '1011') => __encoding A64_ldst_memcms_SETPTN_SET_memcms // SETETN_SET_memcms
                        when ('1', '00', '0000') => __encoding A64_ldst_memcms_CPYP_CPY_memcms // CPYP_CPY_memcms
                        when ('1', '00', '0001') => __encoding A64_ldst_memcms_CPYPWT_CPY_memcms // CPYPWT_CPY_memcms
                        when ('1', '00', '0010') => __encoding A64_ldst_memcms_CPYPRT_CPY_memcms // CPYPRT_CPY_memcms
                        when ('1', '00', '0011') => __encoding A64_ldst_memcms_CPYPT_CPY_memcms // CPYPT_CPY_memcms
                        when ('1', '00', '0100') => __encoding A64_ldst_memcms_CPYPWN_CPY_memcms // CPYPWN_CPY_memcms
                        when ('1', '00', '0101') => __encoding A64_ldst_memcms_CPYPWTWN_CPY_memcms // CPYPWTWN_CPY_memcms
                        when ('1', '00', '0110') => __encoding A64_ldst_memcms_CPYPRTWN_CPY_memcms // CPYPRTWN_CPY_memcms
                        when ('1', '00', '0111') => __encoding A64_ldst_memcms_CPYPTWN_CPY_memcms // CPYPTWN_CPY_memcms
                        when ('1', '00', '1000') => __encoding A64_ldst_memcms_CPYPRN_CPY_memcms // CPYPRN_CPY_memcms
                        when ('1', '00', '1001') => __encoding A64_ldst_memcms_CPYPWTRN_CPY_memcms // CPYPWTRN_CPY_memcms
                        when ('1', '00', '1010') => __encoding A64_ldst_memcms_CPYPRTRN_CPY_memcms // CPYPRTRN_CPY_memcms
                        when ('1', '00', '1011') => __encoding A64_ldst_memcms_CPYPTRN_CPY_memcms // CPYPTRN_CPY_memcms
                        when ('1', '00', '1100') => __encoding A64_ldst_memcms_CPYPN_CPY_memcms // CPYPN_CPY_memcms
                        when ('1', '00', '1101') => __encoding A64_ldst_memcms_CPYPWTN_CPY_memcms // CPYPWTN_CPY_memcms
                        when ('1', '00', '1110') => __encoding A64_ldst_memcms_CPYPRTN_CPY_memcms // CPYPRTN_CPY_memcms
                        when ('1', '00', '1111') => __encoding A64_ldst_memcms_CPYPTN_CPY_memcms // CPYPTN_CPY_memcms
                        when ('1', '01', '0000') => __encoding A64_ldst_memcms_CPYP_CPY_memcms // CPYM_CPY_memcms
                        when ('1', '01', '0001') => __encoding A64_ldst_memcms_CPYPWT_CPY_memcms // CPYMWT_CPY_memcms
                        when ('1', '01', '0010') => __encoding A64_ldst_memcms_CPYPRT_CPY_memcms // CPYMRT_CPY_memcms
                        when ('1', '01', '0011') => __encoding A64_ldst_memcms_CPYPT_CPY_memcms // CPYMT_CPY_memcms
                        when ('1', '01', '0100') => __encoding A64_ldst_memcms_CPYPWN_CPY_memcms // CPYMWN_CPY_memcms
                        when ('1', '01', '0101') => __encoding A64_ldst_memcms_CPYPWTWN_CPY_memcms // CPYMWTWN_CPY_memcms
                        when ('1', '01', '0110') => __encoding A64_ldst_memcms_CPYPRTWN_CPY_memcms // CPYMRTWN_CPY_memcms
                        when ('1', '01', '0111') => __encoding A64_ldst_memcms_CPYPTWN_CPY_memcms // CPYMTWN_CPY_memcms
                        when ('1', '01', '1000') => __encoding A64_ldst_memcms_CPYPRN_CPY_memcms // CPYMRN_CPY_memcms
                        when ('1', '01', '1001') => __encoding A64_ldst_memcms_CPYPWTRN_CPY_memcms // CPYMWTRN_CPY_memcms
                        when ('1', '01', '1010') => __encoding A64_ldst_memcms_CPYPRTRN_CPY_memcms // CPYMRTRN_CPY_memcms
                        when ('1', '01', '1011') => __encoding A64_ldst_memcms_CPYPTRN_CPY_memcms // CPYMTRN_CPY_memcms
                        when ('1', '01', '1100') => __encoding A64_ldst_memcms_CPYPN_CPY_memcms // CPYMN_CPY_memcms
                        when ('1', '01', '1101') => __encoding A64_ldst_memcms_CPYPWTN_CPY_memcms // CPYMWTN_CPY_memcms
                        when ('1', '01', '1110') => __encoding A64_ldst_memcms_CPYPRTN_CPY_memcms // CPYMRTN_CPY_memcms
                        when ('1', '01', '1111') => __encoding A64_ldst_memcms_CPYPTN_CPY_memcms // CPYMTN_CPY_memcms
                        when ('1', '10', '0000') => __encoding A64_ldst_memcms_CPYP_CPY_memcms // CPYE_CPY_memcms
                        when ('1', '10', '0001') => __encoding A64_ldst_memcms_CPYPWT_CPY_memcms // CPYEWT_CPY_memcms
                        when ('1', '10', '0010') => __encoding A64_ldst_memcms_CPYPRT_CPY_memcms // CPYERT_CPY_memcms
                        when ('1', '10', '0011') => __encoding A64_ldst_memcms_CPYPT_CPY_memcms // CPYET_CPY_memcms
                        when ('1', '10', '0100') => __encoding A64_ldst_memcms_CPYPWN_CPY_memcms // CPYEWN_CPY_memcms
                        when ('1', '10', '0101') => __encoding A64_ldst_memcms_CPYPWTWN_CPY_memcms // CPYEWTWN_CPY_memcms
                        when ('1', '10', '0110') => __encoding A64_ldst_memcms_CPYPRTWN_CPY_memcms // CPYERTWN_CPY_memcms
                        when ('1', '10', '0111') => __encoding A64_ldst_memcms_CPYPTWN_CPY_memcms // CPYETWN_CPY_memcms
                        when ('1', '10', '1000') => __encoding A64_ldst_memcms_CPYPRN_CPY_memcms // CPYERN_CPY_memcms
                        when ('1', '10', '1001') => __encoding A64_ldst_memcms_CPYPWTRN_CPY_memcms // CPYEWTRN_CPY_memcms
                        when ('1', '10', '1010') => __encoding A64_ldst_memcms_CPYPRTRN_CPY_memcms // CPYERTRN_CPY_memcms
                        when ('1', '10', '1011') => __encoding A64_ldst_memcms_CPYPTRN_CPY_memcms // CPYETRN_CPY_memcms
                        when ('1', '10', '1100') => __encoding A64_ldst_memcms_CPYPN_CPY_memcms // CPYEN_CPY_memcms
                        when ('1', '10', '1101') => __encoding A64_ldst_memcms_CPYPWTN_CPY_memcms // CPYEWTN_CPY_memcms
                        when ('1', '10', '1110') => __encoding A64_ldst_memcms_CPYPRTN_CPY_memcms // CPYERTN_CPY_memcms
                        when ('1', '10', '1111') => __encoding A64_ldst_memcms_CPYPTN_CPY_memcms // CPYETN_CPY_memcms
                        when ('1', '11', '0000') => __encoding A64_ldst_memcms_SETGP_SET_memcms // SETGP_SET_memcms
                        when ('1', '11', '0001') => __encoding A64_ldst_memcms_SETGPT_SET_memcms // SETGPT_SET_memcms
                        when ('1', '11', '0010') => __encoding A64_ldst_memcms_SETGPN_SET_memcms // SETGPN_SET_memcms
                        when ('1', '11', '0011') => __encoding A64_ldst_memcms_SETGPTN_SET_memcms // SETGPTN_SET_memcms
                        when ('1', '11', '0100') => __encoding A64_ldst_memcms_SETGP_SET_memcms // SETGM_SET_memcms
                        when ('1', '11', '0101') => __encoding A64_ldst_memcms_SETGPT_SET_memcms // SETGMT_SET_memcms
                        when ('1', '11', '0110') => __encoding A64_ldst_memcms_SETGPN_SET_memcms // SETGMN_SET_memcms
                        when ('1', '11', '0111') => __encoding A64_ldst_memcms_SETGPTN_SET_memcms // SETGMTN_SET_memcms
                        when ('1', '11', '1000') => __encoding A64_ldst_memcms_SETGP_SET_memcms // SETGE_SET_memcms
                        when ('1', '11', '1001') => __encoding A64_ldst_memcms_SETGPT_SET_memcms // SETGET_SET_memcms
                        when ('1', '11', '1010') => __encoding A64_ldst_memcms_SETGPN_SET_memcms // SETGEN_SET_memcms
                        when ('1', '11', '1011') => __encoding A64_ldst_memcms_SETGPTN_SET_memcms // SETGETN_SET_memcms
                when ('xx10', _, _, _, '00xxxxxxxxxxxxx', _) => // ldstnapair_offs
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, VR, L) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_32_ldstnapair_offs // STNP_32_ldstnapair_offs
                        when ('00', '0', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_32_ldstnapair_offs // LDNP_32_ldstnapair_offs
                        when ('00', '1', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_S_ldstnapair_offs // STNP_S_ldstnapair_offs
                        when ('00', '1', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_S_ldstnapair_offs // LDNP_S_ldstnapair_offs
                        when ('01', '0', _) => __UNALLOCATED
                        when ('01', '1', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_S_ldstnapair_offs // STNP_D_ldstnapair_offs
                        when ('01', '1', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_S_ldstnapair_offs // LDNP_D_ldstnapair_offs
                        when ('10', '0', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_32_ldstnapair_offs // STNP_64_ldstnapair_offs
                        when ('10', '0', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_32_ldstnapair_offs // LDNP_64_ldstnapair_offs
                        when ('10', '1', '0') => __encoding A64_ldst_ldstnapair_offs_STNP_S_ldstnapair_offs // STNP_Q_ldstnapair_offs
                        when ('10', '1', '1') => __encoding A64_ldst_ldstnapair_offs_LDNP_S_ldstnapair_offs // LDNP_Q_ldstnapair_offs
                        when ('11', '0', '0') => __encoding A64_ldst_ldstnapair_offs_STTNP_64_ldstnapair_offs // STTNP_64_ldstnapair_offs
                        when ('11', '0', '1') => __encoding A64_ldst_ldstnapair_offs_LDTNP_64_ldstnapair_offs // LDTNP_64_ldstnapair_offs
                        when ('11', '1', '0') => __encoding A64_ldst_ldstnapair_offs_STTNP_Q_ldstnapair_offs // STTNP_Q_ldstnapair_offs
                        when ('11', '1', '1') => __encoding A64_ldst_ldstnapair_offs_LDTNP_Q_ldstnapair_offs // LDTNP_Q_ldstnapair_offs
                when ('xx10', _, _, _, '01xxxxxxxxxxxxx', _) => // ldstpair_post
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, VR, L) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstpair_post_STP_32_ldstpair_post // STP_32_ldstpair_post
                        when ('00', '0', '1') => __encoding A64_ldst_ldstpair_post_LDP_32_ldstpair_post // LDP_32_ldstpair_post
                        when ('00', '1', '0') => __encoding A64_ldst_ldstpair_post_STP_S_ldstpair_post // STP_S_ldstpair_post
                        when ('00', '1', '1') => __encoding A64_ldst_ldstpair_post_LDP_S_ldstpair_post // LDP_S_ldstpair_post
                        when ('01', '0', '0') => __encoding A64_ldst_ldstpair_post_STGP_64_ldstpair_post // STGP_64_ldstpair_post
                        when ('01', '0', '1') => __encoding A64_ldst_ldstpair_post_LDPSW_64_ldstpair_post // LDPSW_64_ldstpair_post
                        when ('01', '1', '0') => __encoding A64_ldst_ldstpair_post_STP_S_ldstpair_post // STP_D_ldstpair_post
                        when ('01', '1', '1') => __encoding A64_ldst_ldstpair_post_LDP_S_ldstpair_post // LDP_D_ldstpair_post
                        when ('10', '0', '0') => __encoding A64_ldst_ldstpair_post_STP_32_ldstpair_post // STP_64_ldstpair_post
                        when ('10', '0', '1') => __encoding A64_ldst_ldstpair_post_LDP_32_ldstpair_post // LDP_64_ldstpair_post
                        when ('10', '1', '0') => __encoding A64_ldst_ldstpair_post_STP_S_ldstpair_post // STP_Q_ldstpair_post
                        when ('10', '1', '1') => __encoding A64_ldst_ldstpair_post_LDP_S_ldstpair_post // LDP_Q_ldstpair_post
                        when ('11', '0', '0') => __encoding A64_ldst_ldstpair_post_STTP_64_ldstpair_post // STTP_64_ldstpair_post
                        when ('11', '0', '1') => __encoding A64_ldst_ldstpair_post_LDTP_64_ldstpair_post // LDTP_64_ldstpair_post
                        when ('11', '1', '0') => __encoding A64_ldst_ldstpair_post_STTP_Q_ldstpair_post // STTP_Q_ldstpair_post
                        when ('11', '1', '1') => __encoding A64_ldst_ldstpair_post_LDTP_Q_ldstpair_post // LDTP_Q_ldstpair_post
                when ('xx10', _, _, _, '10xxxxxxxxxxxxx', _) => // ldstpair_off
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, VR, L) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstpair_off_STP_32_ldstpair_off // STP_32_ldstpair_off
                        when ('00', '0', '1') => __encoding A64_ldst_ldstpair_off_LDP_32_ldstpair_off // LDP_32_ldstpair_off
                        when ('00', '1', '0') => __encoding A64_ldst_ldstpair_off_STP_S_ldstpair_off // STP_S_ldstpair_off
                        when ('00', '1', '1') => __encoding A64_ldst_ldstpair_off_LDP_S_ldstpair_off // LDP_S_ldstpair_off
                        when ('01', '0', '0') => __encoding A64_ldst_ldstpair_off_STGP_64_ldstpair_off // STGP_64_ldstpair_off
                        when ('01', '0', '1') => __encoding A64_ldst_ldstpair_off_LDPSW_64_ldstpair_off // LDPSW_64_ldstpair_off
                        when ('01', '1', '0') => __encoding A64_ldst_ldstpair_off_STP_S_ldstpair_off // STP_D_ldstpair_off
                        when ('01', '1', '1') => __encoding A64_ldst_ldstpair_off_LDP_S_ldstpair_off // LDP_D_ldstpair_off
                        when ('10', '0', '0') => __encoding A64_ldst_ldstpair_off_STP_32_ldstpair_off // STP_64_ldstpair_off
                        when ('10', '0', '1') => __encoding A64_ldst_ldstpair_off_LDP_32_ldstpair_off // LDP_64_ldstpair_off
                        when ('10', '1', '0') => __encoding A64_ldst_ldstpair_off_STP_S_ldstpair_off // STP_Q_ldstpair_off
                        when ('10', '1', '1') => __encoding A64_ldst_ldstpair_off_LDP_S_ldstpair_off // LDP_Q_ldstpair_off
                        when ('11', '0', '0') => __encoding A64_ldst_ldstpair_off_STTP_64_ldstpair_off // STTP_64_ldstpair_off
                        when ('11', '0', '1') => __encoding A64_ldst_ldstpair_off_LDTP_64_ldstpair_off // LDTP_64_ldstpair_off
                        when ('11', '1', '0') => __encoding A64_ldst_ldstpair_off_STTP_Q_ldstpair_off // STTP_Q_ldstpair_off
                        when ('11', '1', '1') => __encoding A64_ldst_ldstpair_off_LDTP_Q_ldstpair_off // LDTP_Q_ldstpair_off
                when ('xx10', _, _, _, '11xxxxxxxxxxxxx', _) => // ldstpair_pre
                    __field opc 30 +: 2
                    __field VR 26 +: 1
                    __field L 22 +: 1
                    __field imm7 15 +: 7
                    __field Rt2 10 +: 5
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (opc, VR, L) of
                        when ('00', '0', '0') => __encoding A64_ldst_ldstpair_pre_STP_32_ldstpair_pre // STP_32_ldstpair_pre
                        when ('00', '0', '1') => __encoding A64_ldst_ldstpair_pre_LDP_32_ldstpair_pre // LDP_32_ldstpair_pre
                        when ('00', '1', '0') => __encoding A64_ldst_ldstpair_pre_STP_S_ldstpair_pre // STP_S_ldstpair_pre
                        when ('00', '1', '1') => __encoding A64_ldst_ldstpair_pre_LDP_S_ldstpair_pre // LDP_S_ldstpair_pre
                        when ('01', '0', '0') => __encoding A64_ldst_ldstpair_pre_STGP_64_ldstpair_pre // STGP_64_ldstpair_pre
                        when ('01', '0', '1') => __encoding A64_ldst_ldstpair_pre_LDPSW_64_ldstpair_pre // LDPSW_64_ldstpair_pre
                        when ('01', '1', '0') => __encoding A64_ldst_ldstpair_pre_STP_S_ldstpair_pre // STP_D_ldstpair_pre
                        when ('01', '1', '1') => __encoding A64_ldst_ldstpair_pre_LDP_S_ldstpair_pre // LDP_D_ldstpair_pre
                        when ('10', '0', '0') => __encoding A64_ldst_ldstpair_pre_STP_32_ldstpair_pre // STP_64_ldstpair_pre
                        when ('10', '0', '1') => __encoding A64_ldst_ldstpair_pre_LDP_32_ldstpair_pre // LDP_64_ldstpair_pre
                        when ('10', '1', '0') => __encoding A64_ldst_ldstpair_pre_STP_S_ldstpair_pre // STP_Q_ldstpair_pre
                        when ('10', '1', '1') => __encoding A64_ldst_ldstpair_pre_LDP_S_ldstpair_pre // LDP_Q_ldstpair_pre
                        when ('11', '0', '0') => __encoding A64_ldst_ldstpair_pre_STTP_64_ldstpair_pre // STTP_64_ldstpair_pre
                        when ('11', '0', '1') => __encoding A64_ldst_ldstpair_pre_LDTP_64_ldstpair_pre // LDTP_64_ldstpair_pre
                        when ('11', '1', '0') => __encoding A64_ldst_ldstpair_pre_STTP_Q_ldstpair_pre // STTP_Q_ldstpair_pre
                        when ('11', '1', '1') => __encoding A64_ldst_ldstpair_pre_LDTP_Q_ldstpair_pre // LDTP_Q_ldstpair_pre
                when ('xx11', _, _, _, '0xx0xxxxxxxxx00', _) => // ldst_unscaled
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when (!'00', '1', '1x') => __UNALLOCATED
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_unscaled_STURB_32_ldst_unscaled // STURB_32_ldst_unscaled
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_unscaled_LDURB_32_ldst_unscaled // LDURB_32_ldst_unscaled
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_unscaled_LDURSB_32_ldst_unscaled // LDURSB_64_ldst_unscaled
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_unscaled_LDURSB_32_ldst_unscaled // LDURSB_32_ldst_unscaled
                        when ('00', '1', '00') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_B_ldst_unscaled
                        when ('00', '1', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_B_ldst_unscaled
                        when ('00', '1', '10') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_Q_ldst_unscaled
                        when ('00', '1', '11') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_Q_ldst_unscaled
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_unscaled_STURH_32_ldst_unscaled // STURH_32_ldst_unscaled
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_unscaled_LDURH_32_ldst_unscaled // LDURH_32_ldst_unscaled
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_unscaled_LDURSH_32_ldst_unscaled // LDURSH_64_ldst_unscaled
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_unscaled_LDURSH_32_ldst_unscaled // LDURSH_32_ldst_unscaled
                        when ('01', '1', '00') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_H_ldst_unscaled
                        when ('01', '1', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_H_ldst_unscaled
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_unscaled_STUR_32_ldst_unscaled // STUR_32_ldst_unscaled
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_32_ldst_unscaled // LDUR_32_ldst_unscaled
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_unscaled_LDURSW_64_ldst_unscaled // LDURSW_64_ldst_unscaled
                        when ('10', '1', '00') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_S_ldst_unscaled
                        when ('10', '1', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_S_ldst_unscaled
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_unscaled_STUR_32_ldst_unscaled // STUR_64_ldst_unscaled
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_32_ldst_unscaled // LDUR_64_ldst_unscaled
                        when ('11', '0', '10') => __encoding A64_ldst_ldst_unscaled_PRFUM_P_ldst_unscaled // PRFUM_P_ldst_unscaled
                        when ('11', '1', '00') => __encoding A64_ldst_ldst_unscaled_STUR_B_ldst_unscaled // STUR_D_ldst_unscaled
                        when ('11', '1', '01') => __encoding A64_ldst_ldst_unscaled_LDUR_B_ldst_unscaled // LDUR_D_ldst_unscaled
                when ('xx11', _, _, _, '0xx0xxxxxxxxx01', _) => // ldst_immpost
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_immpost_STRB_32_ldst_immpost // STRB_32_ldst_immpost
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_immpost_LDRB_32_ldst_immpost // LDRB_32_ldst_immpost
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_immpost_LDRSB_32_ldst_immpost // LDRSB_64_ldst_immpost
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_immpost_LDRSB_32_ldst_immpost // LDRSB_32_ldst_immpost
                        when ('00', '1', '00') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_B_ldst_immpost
                        when ('00', '1', '01') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_B_ldst_immpost
                        when ('00', '1', '10') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_Q_ldst_immpost
                        when ('00', '1', '11') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_Q_ldst_immpost
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_immpost_STRH_32_ldst_immpost // STRH_32_ldst_immpost
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_immpost_LDRH_32_ldst_immpost // LDRH_32_ldst_immpost
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_immpost_LDRSH_32_ldst_immpost // LDRSH_64_ldst_immpost
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_immpost_LDRSH_32_ldst_immpost // LDRSH_32_ldst_immpost
                        when ('01', '1', '00') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_H_ldst_immpost
                        when ('01', '1', '01') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_H_ldst_immpost
                        when ('01', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_immpost_STR_32_ldst_immpost // STR_32_ldst_immpost
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_immpost_LDR_32_ldst_immpost // LDR_32_ldst_immpost
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_immpost_LDRSW_64_ldst_immpost // LDRSW_64_ldst_immpost
                        when ('10', '0', '11') => __UNALLOCATED
                        when ('10', '1', '00') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_S_ldst_immpost
                        when ('10', '1', '01') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_S_ldst_immpost
                        when ('10', '1', '1x') => __UNALLOCATED
                        when ('11', _, '1x') => __UNALLOCATED
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_immpost_STR_32_ldst_immpost // STR_64_ldst_immpost
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_immpost_LDR_32_ldst_immpost // LDR_64_ldst_immpost
                        when ('11', '1', '00') => __encoding A64_ldst_ldst_immpost_STR_B_ldst_immpost // STR_D_ldst_immpost
                        when ('11', '1', '01') => __encoding A64_ldst_ldst_immpost_LDR_B_ldst_immpost // LDR_D_ldst_immpost
                when ('xx11', _, _, _, '0xx0xxxxxxxxx10', _) => // ldst_unpriv
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when (_, '1', _) => __UNALLOCATED
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_unpriv_STTRB_32_ldst_unpriv // STTRB_32_ldst_unpriv
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_unpriv_LDTRB_32_ldst_unpriv // LDTRB_32_ldst_unpriv
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_unpriv_LDTRSB_32_ldst_unpriv // LDTRSB_64_ldst_unpriv
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_unpriv_LDTRSB_32_ldst_unpriv // LDTRSB_32_ldst_unpriv
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_unpriv_STTRH_32_ldst_unpriv // STTRH_32_ldst_unpriv
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_unpriv_LDTRH_32_ldst_unpriv // LDTRH_32_ldst_unpriv
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_unpriv_LDTRSH_32_ldst_unpriv // LDTRSH_64_ldst_unpriv
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_unpriv_LDTRSH_32_ldst_unpriv // LDTRSH_32_ldst_unpriv
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_unpriv_STTR_32_ldst_unpriv // STTR_32_ldst_unpriv
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_unpriv_LDTR_32_ldst_unpriv // LDTR_32_ldst_unpriv
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_unpriv_LDTRSW_64_ldst_unpriv // LDTRSW_64_ldst_unpriv
                        when ('10', '0', '11') => __UNALLOCATED
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_unpriv_STTR_32_ldst_unpriv // STTR_64_ldst_unpriv
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_unpriv_LDTR_32_ldst_unpriv // LDTR_64_ldst_unpriv
                        when ('11', '0', '1x') => __UNALLOCATED
                when ('xx11', _, _, _, '0xx0xxxxxxxxx11', _) => // ldst_immpre
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm9 12 +: 9
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_immpre_STRB_32_ldst_immpre // STRB_32_ldst_immpre
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_immpre_LDRB_32_ldst_immpre // LDRB_32_ldst_immpre
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_immpre_LDRSB_32_ldst_immpre // LDRSB_64_ldst_immpre
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_immpre_LDRSB_32_ldst_immpre // LDRSB_32_ldst_immpre
                        when ('00', '1', '00') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_B_ldst_immpre
                        when ('00', '1', '01') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_B_ldst_immpre
                        when ('00', '1', '10') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_Q_ldst_immpre
                        when ('00', '1', '11') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_Q_ldst_immpre
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_immpre_STRH_32_ldst_immpre // STRH_32_ldst_immpre
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_immpre_LDRH_32_ldst_immpre // LDRH_32_ldst_immpre
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_immpre_LDRSH_32_ldst_immpre // LDRSH_64_ldst_immpre
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_immpre_LDRSH_32_ldst_immpre // LDRSH_32_ldst_immpre
                        when ('01', '1', '00') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_H_ldst_immpre
                        when ('01', '1', '01') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_H_ldst_immpre
                        when ('01', '1', '1x') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_immpre_STR_32_ldst_immpre // STR_32_ldst_immpre
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_immpre_LDR_32_ldst_immpre // LDR_32_ldst_immpre
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_immpre_LDRSW_64_ldst_immpre // LDRSW_64_ldst_immpre
                        when ('10', '0', '11') => __UNALLOCATED
                        when ('10', '1', '00') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_S_ldst_immpre
                        when ('10', '1', '01') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_S_ldst_immpre
                        when ('10', '1', '1x') => __UNALLOCATED
                        when ('11', _, '1x') => __UNALLOCATED
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_immpre_STR_32_ldst_immpre // STR_64_ldst_immpre
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_immpre_LDR_32_ldst_immpre // LDR_64_ldst_immpre
                        when ('11', '1', '00') => __encoding A64_ldst_ldst_immpre_STR_B_ldst_immpre // STR_D_ldst_immpre
                        when ('11', '1', '01') => __encoding A64_ldst_ldst_immpre_LDR_B_ldst_immpre // LDR_D_ldst_immpre
                when ('xx11', _, _, _, '0xx1xxxxxxxxx00', _) => // memop
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field A 23 +: 1
                    __field R 22 +: 1
                    __field Rs 16 +: 5
                    __field o3 15 +: 1
                    __field opc 12 +: 3
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, A, R, Rs, o3, opc, Rt) of
                        when (_, '0', '0', _, _, '1', '100', _) => __UNALLOCATED
                        when (_, '0', '0', _, _, '1', '11x', _) => __UNALLOCATED
                        when (_, '0', '1', '1', _, '1', '100', _) => __UNALLOCATED
                        when (_, '1', _, _, _, '0', '001', _) => __UNALLOCATED
                        when (_, '1', _, _, _, '0', '01x', _) => __UNALLOCATED
                        when (_, '1', '0', _, _, '1', _, !'11111') => __UNALLOCATED
                        when (_, '1', '0', _, _, '1', '001', '11111') => __UNALLOCATED
                        when (_, '1', '0', _, _, '1', '01x', '11111') => __UNALLOCATED
                        when (_, '1', '1', _, _, '1', _, _) => __UNALLOCATED
                        when ('0x', '0', _, '0', _, '1', '101', _) => __UNALLOCATED
                        when ('0x', '0', '0', '1', _, '1', '101', _) => __UNALLOCATED
                        when ('0x', '0', '1', _, _, '1', '11x', _) => __UNALLOCATED
                        when ('0x', '0', '1', '1', _, '1', '101', _) => __UNALLOCATED
                        when ('00', '0', '0', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDADDB_32_memop // LDADDB_32_memop
                        when ('00', '0', '0', '0', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLRB_32_memop // LDCLRB_32_memop
                        when ('00', '0', '0', '0', _, '0', '010', _) => __encoding A64_ldst_memop_LDEORB_32_memop // LDEORB_32_memop
                        when ('00', '0', '0', '0', _, '0', '011', _) => __encoding A64_ldst_memop_LDSETB_32_memop // LDSETB_32_memop
                        when ('00', '0', '0', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAXB_32_memop // LDSMAXB_32_memop
                        when ('00', '0', '0', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMINB_32_memop // LDSMINB_32_memop
                        when ('00', '0', '0', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAXB_32_memop // LDUMAXB_32_memop
                        when ('00', '0', '0', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMINB_32_memop // LDUMINB_32_memop
                        when ('00', '0', '0', '0', _, '1', '000', _) => __encoding A64_ldst_memop_SWPB_32_memop // SWPB_32_memop
                        when ('00', '0', '0', '0', _, '1', '001', _) => __encoding A64_ldst_memop_RCWCLR_64_memop // RCWCLR_64_memop
                        when ('00', '0', '0', '0', _, '1', '010', _) => __encoding A64_ldst_memop_RCWSWP_64_memop // RCWSWP_64_memop
                        when ('00', '0', '0', '0', _, '1', '011', _) => __encoding A64_ldst_memop_RCWSET_64_memop // RCWSET_64_memop
                        when ('00', '0', '0', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDADDB_32_memop // LDADDLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLRB_32_memop // LDCLRLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '010', _) => __encoding A64_ldst_memop_LDEORB_32_memop // LDEORLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '011', _) => __encoding A64_ldst_memop_LDSETB_32_memop // LDSETLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAXB_32_memop // LDSMAXLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMINB_32_memop // LDSMINLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAXB_32_memop // LDUMAXLB_32_memop
                        when ('00', '0', '0', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMINB_32_memop // LDUMINLB_32_memop
                        when ('00', '0', '0', '1', _, '1', '000', _) => __encoding A64_ldst_memop_SWPB_32_memop // SWPLB_32_memop
                        when ('00', '0', '0', '1', _, '1', '001', _) => __encoding A64_ldst_memop_RCWCLR_64_memop // RCWCLRL_64_memop
                        when ('00', '0', '0', '1', _, '1', '010', _) => __encoding A64_ldst_memop_RCWSWP_64_memop // RCWSWPL_64_memop
                        when ('00', '0', '0', '1', _, '1', '011', _) => __encoding A64_ldst_memop_RCWSET_64_memop // RCWSETL_64_memop
                        when ('00', '0', '1', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDADDB_32_memop // LDADDAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLRB_32_memop // LDCLRAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '010', _) => __encoding A64_ldst_memop_LDEORB_32_memop // LDEORAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '011', _) => __encoding A64_ldst_memop_LDSETB_32_memop // LDSETAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAXB_32_memop // LDSMAXAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMINB_32_memop // LDSMINAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAXB_32_memop // LDUMAXAB_32_memop
                        when ('00', '0', '1', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMINB_32_memop // LDUMINAB_32_memop
                        when ('00', '0', '1', '0', _, '1', '000', _) => __encoding A64_ldst_memop_SWPB_32_memop // SWPAB_32_memop
                        when ('00', '0', '1', '0', _, '1', '001', _) => __encoding A64_ldst_memop_RCWCLR_64_memop // RCWCLRA_64_memop
                        when ('00', '0', '1', '0', _, '1', '010', _) => __encoding A64_ldst_memop_RCWSWP_64_memop // RCWSWPA_64_memop
                        when ('00', '0', '1', '0', _, '1', '011', _) => __encoding A64_ldst_memop_RCWSET_64_memop // RCWSETA_64_memop
                        when ('00', '0', '1', '0', _, '1', '100', _) => __encoding A64_ldst_memop_LDAPRB_32L_memop // LDAPRB_32L_memop
                        when ('00', '0', '1', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDADDB_32_memop // LDADDALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLRB_32_memop // LDCLRALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '010', _) => __encoding A64_ldst_memop_LDEORB_32_memop // LDEORALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '011', _) => __encoding A64_ldst_memop_LDSETB_32_memop // LDSETALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAXB_32_memop // LDSMAXALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMINB_32_memop // LDSMINALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAXB_32_memop // LDUMAXALB_32_memop
                        when ('00', '0', '1', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMINB_32_memop // LDUMINALB_32_memop
                        when ('00', '0', '1', '1', _, '1', '000', _) => __encoding A64_ldst_memop_SWPB_32_memop // SWPALB_32_memop
                        when ('00', '0', '1', '1', _, '1', '001', _) => __encoding A64_ldst_memop_RCWCLR_64_memop // RCWCLRAL_64_memop
                        when ('00', '0', '1', '1', _, '1', '010', _) => __encoding A64_ldst_memop_RCWSWP_64_memop // RCWSWPAL_64_memop
                        when ('00', '0', '1', '1', _, '1', '011', _) => __encoding A64_ldst_memop_RCWSET_64_memop // RCWSETAL_64_memop
                        when ('00', '1', '0', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDBFADD_16 // LDBFADD_16
                        when ('00', '1', '0', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDBFMAX_16 // LDBFMAX_16
                        when ('00', '1', '0', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDBFMIN_16 // LDBFMIN_16
                        when ('00', '1', '0', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDBFMAXNM_16 // LDBFMAXNM_16
                        when ('00', '1', '0', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDBFMINNM_16 // LDBFMINNM_16
                        when ('00', '1', '0', '0', _, '1', '000', '11111') => __encoding A64_ldst_memop_STBFADD_16 // STBFADD_16
                        when ('00', '1', '0', '0', _, '1', '100', '11111') => __encoding A64_ldst_memop_STBFMAX_16 // STBFMAX_16
                        when ('00', '1', '0', '0', _, '1', '101', '11111') => __encoding A64_ldst_memop_STBFMIN_16 // STBFMIN_16
                        when ('00', '1', '0', '0', _, '1', '110', '11111') => __encoding A64_ldst_memop_STBFMAXNM_16 // STBFMAXNM_16
                        when ('00', '1', '0', '0', _, '1', '111', '11111') => __encoding A64_ldst_memop_STBFMINNM_16 // STBFMINNM_16
                        when ('00', '1', '0', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDBFADD_16 // LDBFADDL_16
                        when ('00', '1', '0', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDBFMAX_16 // LDBFMAXL_16
                        when ('00', '1', '0', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDBFMIN_16 // LDBFMINL_16
                        when ('00', '1', '0', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDBFMAXNM_16 // LDBFMAXNML_16
                        when ('00', '1', '0', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDBFMINNM_16 // LDBFMINNML_16
                        when ('00', '1', '0', '1', _, '1', '000', '11111') => __encoding A64_ldst_memop_STBFADD_16 // STBFADDL_16
                        when ('00', '1', '0', '1', _, '1', '100', '11111') => __encoding A64_ldst_memop_STBFMAX_16 // STBFMAXL_16
                        when ('00', '1', '0', '1', _, '1', '101', '11111') => __encoding A64_ldst_memop_STBFMIN_16 // STBFMINL_16
                        when ('00', '1', '0', '1', _, '1', '110', '11111') => __encoding A64_ldst_memop_STBFMAXNM_16 // STBFMAXNML_16
                        when ('00', '1', '0', '1', _, '1', '111', '11111') => __encoding A64_ldst_memop_STBFMINNM_16 // STBFMINNML_16
                        when ('00', '1', '1', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDBFADD_16 // LDBFADDA_16
                        when ('00', '1', '1', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDBFMAX_16 // LDBFMAXA_16
                        when ('00', '1', '1', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDBFMIN_16 // LDBFMINA_16
                        when ('00', '1', '1', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDBFMAXNM_16 // LDBFMAXNMA_16
                        when ('00', '1', '1', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDBFMINNM_16 // LDBFMINNMA_16
                        when ('00', '1', '1', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDBFADD_16 // LDBFADDAL_16
                        when ('00', '1', '1', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDBFMAX_16 // LDBFMAXAL_16
                        when ('00', '1', '1', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDBFMIN_16 // LDBFMINAL_16
                        when ('00', '1', '1', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDBFMAXNM_16 // LDBFMAXNMAL_16
                        when ('00', '1', '1', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDBFMINNM_16 // LDBFMINNMAL_16
                        when ('01', '0', '0', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDADDH_32_memop // LDADDH_32_memop
                        when ('01', '0', '0', '0', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLRH_32_memop // LDCLRH_32_memop
                        when ('01', '0', '0', '0', _, '0', '010', _) => __encoding A64_ldst_memop_LDEORH_32_memop // LDEORH_32_memop
                        when ('01', '0', '0', '0', _, '0', '011', _) => __encoding A64_ldst_memop_LDSETH_32_memop // LDSETH_32_memop
                        when ('01', '0', '0', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAXH_32_memop // LDSMAXH_32_memop
                        when ('01', '0', '0', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMINH_32_memop // LDSMINH_32_memop
                        when ('01', '0', '0', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAXH_32_memop // LDUMAXH_32_memop
                        when ('01', '0', '0', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMINH_32_memop // LDUMINH_32_memop
                        when ('01', '0', '0', '0', _, '1', '000', _) => __encoding A64_ldst_memop_SWPH_32_memop // SWPH_32_memop
                        when ('01', '0', '0', '0', _, '1', '001', _) => __encoding A64_ldst_memop_RCWSCLR_64_memop // RCWSCLR_64_memop
                        when ('01', '0', '0', '0', _, '1', '010', _) => __encoding A64_ldst_memop_RCWSSWP_64_memop // RCWSSWP_64_memop
                        when ('01', '0', '0', '0', _, '1', '011', _) => __encoding A64_ldst_memop_RCWSSET_64_memop // RCWSSET_64_memop
                        when ('01', '0', '0', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDADDH_32_memop // LDADDLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLRH_32_memop // LDCLRLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '010', _) => __encoding A64_ldst_memop_LDEORH_32_memop // LDEORLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '011', _) => __encoding A64_ldst_memop_LDSETH_32_memop // LDSETLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAXH_32_memop // LDSMAXLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMINH_32_memop // LDSMINLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAXH_32_memop // LDUMAXLH_32_memop
                        when ('01', '0', '0', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMINH_32_memop // LDUMINLH_32_memop
                        when ('01', '0', '0', '1', _, '1', '000', _) => __encoding A64_ldst_memop_SWPH_32_memop // SWPLH_32_memop
                        when ('01', '0', '0', '1', _, '1', '001', _) => __encoding A64_ldst_memop_RCWSCLR_64_memop // RCWSCLRL_64_memop
                        when ('01', '0', '0', '1', _, '1', '010', _) => __encoding A64_ldst_memop_RCWSSWP_64_memop // RCWSSWPL_64_memop
                        when ('01', '0', '0', '1', _, '1', '011', _) => __encoding A64_ldst_memop_RCWSSET_64_memop // RCWSSETL_64_memop
                        when ('01', '0', '1', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDADDH_32_memop // LDADDAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLRH_32_memop // LDCLRAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '010', _) => __encoding A64_ldst_memop_LDEORH_32_memop // LDEORAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '011', _) => __encoding A64_ldst_memop_LDSETH_32_memop // LDSETAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAXH_32_memop // LDSMAXAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMINH_32_memop // LDSMINAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAXH_32_memop // LDUMAXAH_32_memop
                        when ('01', '0', '1', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMINH_32_memop // LDUMINAH_32_memop
                        when ('01', '0', '1', '0', _, '1', '000', _) => __encoding A64_ldst_memop_SWPH_32_memop // SWPAH_32_memop
                        when ('01', '0', '1', '0', _, '1', '001', _) => __encoding A64_ldst_memop_RCWSCLR_64_memop // RCWSCLRA_64_memop
                        when ('01', '0', '1', '0', _, '1', '010', _) => __encoding A64_ldst_memop_RCWSSWP_64_memop // RCWSSWPA_64_memop
                        when ('01', '0', '1', '0', _, '1', '011', _) => __encoding A64_ldst_memop_RCWSSET_64_memop // RCWSSETA_64_memop
                        when ('01', '0', '1', '0', _, '1', '100', _) => __encoding A64_ldst_memop_LDAPRH_32L_memop // LDAPRH_32L_memop
                        when ('01', '0', '1', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDADDH_32_memop // LDADDALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLRH_32_memop // LDCLRALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '010', _) => __encoding A64_ldst_memop_LDEORH_32_memop // LDEORALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '011', _) => __encoding A64_ldst_memop_LDSETH_32_memop // LDSETALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAXH_32_memop // LDSMAXALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMINH_32_memop // LDSMINALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAXH_32_memop // LDUMAXALH_32_memop
                        when ('01', '0', '1', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMINH_32_memop // LDUMINALH_32_memop
                        when ('01', '0', '1', '1', _, '1', '000', _) => __encoding A64_ldst_memop_SWPH_32_memop // SWPALH_32_memop
                        when ('01', '0', '1', '1', _, '1', '001', _) => __encoding A64_ldst_memop_RCWSCLR_64_memop // RCWSCLRAL_64_memop
                        when ('01', '0', '1', '1', _, '1', '010', _) => __encoding A64_ldst_memop_RCWSSWP_64_memop // RCWSSWPAL_64_memop
                        when ('01', '0', '1', '1', _, '1', '011', _) => __encoding A64_ldst_memop_RCWSSET_64_memop // RCWSSETAL_64_memop
                        when ('01', '1', '0', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADD_16
                        when ('01', '1', '0', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAX_16
                        when ('01', '1', '0', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMIN_16
                        when ('01', '1', '0', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNM_16
                        when ('01', '1', '0', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNM_16
                        when ('01', '1', '0', '0', _, '1', '000', '11111') => __encoding A64_ldst_memop_STFADD_16 // STFADD_16
                        when ('01', '1', '0', '0', _, '1', '100', '11111') => __encoding A64_ldst_memop_STFMAX_16 // STFMAX_16
                        when ('01', '1', '0', '0', _, '1', '101', '11111') => __encoding A64_ldst_memop_STFMIN_16 // STFMIN_16
                        when ('01', '1', '0', '0', _, '1', '110', '11111') => __encoding A64_ldst_memop_STFMAXNM_16 // STFMAXNM_16
                        when ('01', '1', '0', '0', _, '1', '111', '11111') => __encoding A64_ldst_memop_STFMINNM_16 // STFMINNM_16
                        when ('01', '1', '0', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDL_16
                        when ('01', '1', '0', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXL_16
                        when ('01', '1', '0', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINL_16
                        when ('01', '1', '0', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNML_16
                        when ('01', '1', '0', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNML_16
                        when ('01', '1', '0', '1', _, '1', '000', '11111') => __encoding A64_ldst_memop_STFADD_16 // STFADDL_16
                        when ('01', '1', '0', '1', _, '1', '100', '11111') => __encoding A64_ldst_memop_STFMAX_16 // STFMAXL_16
                        when ('01', '1', '0', '1', _, '1', '101', '11111') => __encoding A64_ldst_memop_STFMIN_16 // STFMINL_16
                        when ('01', '1', '0', '1', _, '1', '110', '11111') => __encoding A64_ldst_memop_STFMAXNM_16 // STFMAXNML_16
                        when ('01', '1', '0', '1', _, '1', '111', '11111') => __encoding A64_ldst_memop_STFMINNM_16 // STFMINNML_16
                        when ('01', '1', '1', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDA_16
                        when ('01', '1', '1', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXA_16
                        when ('01', '1', '1', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINA_16
                        when ('01', '1', '1', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNMA_16
                        when ('01', '1', '1', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNMA_16
                        when ('01', '1', '1', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDAL_16
                        when ('01', '1', '1', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXAL_16
                        when ('01', '1', '1', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINAL_16
                        when ('01', '1', '1', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNMAL_16
                        when ('01', '1', '1', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNMAL_16
                        when ('1x', '0', '1', _, _, '1', 'x01', _) => __UNALLOCATED
                        when ('1x', '0', '1', _, _, '1', 'x1x', _) => __UNALLOCATED
                        when ('10', '0', '0', _, _, '1', 'x01', _) => __UNALLOCATED
                        when ('10', '0', '0', _, _, '1', '010', _) => __UNALLOCATED
                        when ('10', '0', '0', _, _, '1', '011', _) => __UNALLOCATED
                        when ('10', '0', '0', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDADD_32_memop // LDADD_32_memop
                        when ('10', '0', '0', '0', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLR_32_memop
                        when ('10', '0', '0', '0', _, '0', '010', _) => __encoding A64_ldst_memop_LDEOR_32_memop // LDEOR_32_memop
                        when ('10', '0', '0', '0', _, '0', '011', _) => __encoding A64_ldst_memop_LDSET_32_memop // LDSET_32_memop
                        when ('10', '0', '0', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAX_32_memop
                        when ('10', '0', '0', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMIN_32_memop
                        when ('10', '0', '0', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAX_32_memop
                        when ('10', '0', '0', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMIN_32_memop
                        when ('10', '0', '0', '0', _, '1', '000', _) => __encoding A64_ldst_memop_SWP_32_memop // SWP_32_memop
                        when ('10', '0', '0', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDADD_32_memop // LDADDL_32_memop
                        when ('10', '0', '0', '1', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRL_32_memop
                        when ('10', '0', '0', '1', _, '0', '010', _) => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORL_32_memop
                        when ('10', '0', '0', '1', _, '0', '011', _) => __encoding A64_ldst_memop_LDSET_32_memop // LDSETL_32_memop
                        when ('10', '0', '0', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXL_32_memop
                        when ('10', '0', '0', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINL_32_memop
                        when ('10', '0', '0', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXL_32_memop
                        when ('10', '0', '0', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINL_32_memop
                        when ('10', '0', '0', '1', _, '1', '000', _) => __encoding A64_ldst_memop_SWP_32_memop // SWPL_32_memop
                        when ('10', '0', '1', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDADD_32_memop // LDADDA_32_memop
                        when ('10', '0', '1', '0', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRA_32_memop
                        when ('10', '0', '1', '0', _, '0', '010', _) => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORA_32_memop
                        when ('10', '0', '1', '0', _, '0', '011', _) => __encoding A64_ldst_memop_LDSET_32_memop // LDSETA_32_memop
                        when ('10', '0', '1', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXA_32_memop
                        when ('10', '0', '1', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINA_32_memop
                        when ('10', '0', '1', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXA_32_memop
                        when ('10', '0', '1', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINA_32_memop
                        when ('10', '0', '1', '0', _, '1', '000', _) => __encoding A64_ldst_memop_SWP_32_memop // SWPA_32_memop
                        when ('10', '0', '1', '0', _, '1', '100', _) => __encoding A64_ldst_memop_LDAPR_32L_memop // LDAPR_32L_memop
                        when ('10', '0', '1', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDADD_32_memop // LDADDAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '010', _) => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '011', _) => __encoding A64_ldst_memop_LDSET_32_memop // LDSETAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXAL_32_memop
                        when ('10', '0', '1', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINAL_32_memop
                        when ('10', '0', '1', '1', _, '1', '000', _) => __encoding A64_ldst_memop_SWP_32_memop // SWPAL_32_memop
                        when ('10', '1', '0', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADD_32
                        when ('10', '1', '0', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAX_32
                        when ('10', '1', '0', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMIN_32
                        when ('10', '1', '0', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNM_32
                        when ('10', '1', '0', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNM_32
                        when ('10', '1', '0', '0', _, '1', '000', '11111') => __encoding A64_ldst_memop_STFADD_16 // STFADD_32
                        when ('10', '1', '0', '0', _, '1', '100', '11111') => __encoding A64_ldst_memop_STFMAX_16 // STFMAX_32
                        when ('10', '1', '0', '0', _, '1', '101', '11111') => __encoding A64_ldst_memop_STFMIN_16 // STFMIN_32
                        when ('10', '1', '0', '0', _, '1', '110', '11111') => __encoding A64_ldst_memop_STFMAXNM_16 // STFMAXNM_32
                        when ('10', '1', '0', '0', _, '1', '111', '11111') => __encoding A64_ldst_memop_STFMINNM_16 // STFMINNM_32
                        when ('10', '1', '0', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDL_32
                        when ('10', '1', '0', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXL_32
                        when ('10', '1', '0', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINL_32
                        when ('10', '1', '0', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNML_32
                        when ('10', '1', '0', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNML_32
                        when ('10', '1', '0', '1', _, '1', '000', '11111') => __encoding A64_ldst_memop_STFADD_16 // STFADDL_32
                        when ('10', '1', '0', '1', _, '1', '100', '11111') => __encoding A64_ldst_memop_STFMAX_16 // STFMAXL_32
                        when ('10', '1', '0', '1', _, '1', '101', '11111') => __encoding A64_ldst_memop_STFMIN_16 // STFMINL_32
                        when ('10', '1', '0', '1', _, '1', '110', '11111') => __encoding A64_ldst_memop_STFMAXNM_16 // STFMAXNML_32
                        when ('10', '1', '0', '1', _, '1', '111', '11111') => __encoding A64_ldst_memop_STFMINNM_16 // STFMINNML_32
                        when ('10', '1', '1', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDA_32
                        when ('10', '1', '1', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXA_32
                        when ('10', '1', '1', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINA_32
                        when ('10', '1', '1', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNMA_32
                        when ('10', '1', '1', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNMA_32
                        when ('10', '1', '1', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDAL_32
                        when ('10', '1', '1', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXAL_32
                        when ('10', '1', '1', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINAL_32
                        when ('10', '1', '1', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNMAL_32
                        when ('10', '1', '1', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNMAL_32
                        when ('11', '0', '0', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDADD_32_memop // LDADD_64_memop
                        when ('11', '0', '0', '0', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLR_64_memop
                        when ('11', '0', '0', '0', _, '0', '010', _) => __encoding A64_ldst_memop_LDEOR_32_memop // LDEOR_64_memop
                        when ('11', '0', '0', '0', _, '0', '011', _) => __encoding A64_ldst_memop_LDSET_32_memop // LDSET_64_memop
                        when ('11', '0', '0', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAX_64_memop
                        when ('11', '0', '0', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMIN_64_memop
                        when ('11', '0', '0', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAX_64_memop
                        when ('11', '0', '0', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMIN_64_memop
                        when ('11', '0', '0', '0', !'11111', '1', 'x01', _) => __UNALLOCATED
                        when ('11', '0', '0', '0', _, '1', '000', _) => __encoding A64_ldst_memop_SWP_32_memop // SWP_64_memop
                        when ('11', '0', '0', '0', _, '1', '010', _) => __encoding A64_ldst_memop_ST64BV0_64_memop // ST64BV0_64_memop
                        when ('11', '0', '0', '0', _, '1', '011', _) => __encoding A64_ldst_memop_ST64BV_64_memop // ST64BV_64_memop
                        when ('11', '0', '0', '0', '11111', '1', '001', _) => __encoding A64_ldst_memop_ST64B_64L_memop // ST64B_64L_memop
                        when ('11', '0', '0', '0', '11111', '1', '101', _) => __encoding A64_ldst_memop_LD64B_64L_memop // LD64B_64L_memop
                        when ('11', '0', '0', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDADD_32_memop // LDADDL_64_memop
                        when ('11', '0', '0', '1', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRL_64_memop
                        when ('11', '0', '0', '1', _, '0', '010', _) => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORL_64_memop
                        when ('11', '0', '0', '1', _, '0', '011', _) => __encoding A64_ldst_memop_LDSET_32_memop // LDSETL_64_memop
                        when ('11', '0', '0', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXL_64_memop
                        when ('11', '0', '0', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINL_64_memop
                        when ('11', '0', '0', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXL_64_memop
                        when ('11', '0', '0', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINL_64_memop
                        when ('11', '0', '0', '1', _, '1', 'x01', _) => __UNALLOCATED
                        when ('11', '0', '0', '1', _, '1', '000', _) => __encoding A64_ldst_memop_SWP_32_memop // SWPL_64_memop
                        when ('11', '0', '0', '1', _, '1', '010', _) => __UNALLOCATED
                        when ('11', '0', '0', '1', _, '1', '011', _) => __UNALLOCATED
                        when ('11', '0', '1', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDADD_32_memop // LDADDA_64_memop
                        when ('11', '0', '1', '0', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRA_64_memop
                        when ('11', '0', '1', '0', _, '0', '010', _) => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORA_64_memop
                        when ('11', '0', '1', '0', _, '0', '011', _) => __encoding A64_ldst_memop_LDSET_32_memop // LDSETA_64_memop
                        when ('11', '0', '1', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXA_64_memop
                        when ('11', '0', '1', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINA_64_memop
                        when ('11', '0', '1', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXA_64_memop
                        when ('11', '0', '1', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINA_64_memop
                        when ('11', '0', '1', '0', _, '1', '000', _) => __encoding A64_ldst_memop_SWP_32_memop // SWPA_64_memop
                        when ('11', '0', '1', '0', _, '1', '100', _) => __encoding A64_ldst_memop_LDAPR_32L_memop // LDAPR_64L_memop
                        when ('11', '0', '1', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDADD_32_memop // LDADDAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '001', _) => __encoding A64_ldst_memop_LDCLR_32_memop // LDCLRAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '010', _) => __encoding A64_ldst_memop_LDEOR_32_memop // LDEORAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '011', _) => __encoding A64_ldst_memop_LDSET_32_memop // LDSETAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDSMAX_32_memop // LDSMAXAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDSMIN_32_memop // LDSMINAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDUMAX_32_memop // LDUMAXAL_64_memop
                        when ('11', '0', '1', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDUMIN_32_memop // LDUMINAL_64_memop
                        when ('11', '0', '1', '1', _, '1', '000', _) => __encoding A64_ldst_memop_SWP_32_memop // SWPAL_64_memop
                        when ('11', '1', '0', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADD_64
                        when ('11', '1', '0', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAX_64
                        when ('11', '1', '0', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMIN_64
                        when ('11', '1', '0', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNM_64
                        when ('11', '1', '0', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNM_64
                        when ('11', '1', '0', '0', _, '1', '000', '11111') => __encoding A64_ldst_memop_STFADD_16 // STFADD_64
                        when ('11', '1', '0', '0', _, '1', '100', '11111') => __encoding A64_ldst_memop_STFMAX_16 // STFMAX_64
                        when ('11', '1', '0', '0', _, '1', '101', '11111') => __encoding A64_ldst_memop_STFMIN_16 // STFMIN_64
                        when ('11', '1', '0', '0', _, '1', '110', '11111') => __encoding A64_ldst_memop_STFMAXNM_16 // STFMAXNM_64
                        when ('11', '1', '0', '0', _, '1', '111', '11111') => __encoding A64_ldst_memop_STFMINNM_16 // STFMINNM_64
                        when ('11', '1', '0', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDL_64
                        when ('11', '1', '0', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXL_64
                        when ('11', '1', '0', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINL_64
                        when ('11', '1', '0', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNML_64
                        when ('11', '1', '0', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNML_64
                        when ('11', '1', '0', '1', _, '1', '000', '11111') => __encoding A64_ldst_memop_STFADD_16 // STFADDL_64
                        when ('11', '1', '0', '1', _, '1', '100', '11111') => __encoding A64_ldst_memop_STFMAX_16 // STFMAXL_64
                        when ('11', '1', '0', '1', _, '1', '101', '11111') => __encoding A64_ldst_memop_STFMIN_16 // STFMINL_64
                        when ('11', '1', '0', '1', _, '1', '110', '11111') => __encoding A64_ldst_memop_STFMAXNM_16 // STFMAXNML_64
                        when ('11', '1', '0', '1', _, '1', '111', '11111') => __encoding A64_ldst_memop_STFMINNM_16 // STFMINNML_64
                        when ('11', '1', '1', '0', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDA_64
                        when ('11', '1', '1', '0', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXA_64
                        when ('11', '1', '1', '0', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINA_64
                        when ('11', '1', '1', '0', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNMA_64
                        when ('11', '1', '1', '0', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNMA_64
                        when ('11', '1', '1', '1', _, '0', '000', _) => __encoding A64_ldst_memop_LDFADD_16 // LDFADDAL_64
                        when ('11', '1', '1', '1', _, '0', '100', _) => __encoding A64_ldst_memop_LDFMAX_16 // LDFMAXAL_64
                        when ('11', '1', '1', '1', _, '0', '101', _) => __encoding A64_ldst_memop_LDFMIN_16 // LDFMINAL_64
                        when ('11', '1', '1', '1', _, '0', '110', _) => __encoding A64_ldst_memop_LDFMAXNM_16 // LDFMAXNMAL_64
                        when ('11', '1', '1', '1', _, '0', '111', _) => __encoding A64_ldst_memop_LDFMINNM_16 // LDFMINNMAL_64
                when ('xx11', _, _, _, '0xx1xxxxxxxxx10', _) => // ldst_regoff
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field Rm 16 +: 5
                    __field option 13 +: 3
                    __field S 12 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc, option, Rt) of
                        when (!'00', '1', '1x', _, _) => __UNALLOCATED
                        when ('00', '0', '00', !'011', _) => __encoding A64_ldst_ldst_regoff_STRB_32B_ldst_regoff // STRB_32B_ldst_regoff
                        when ('00', '0', '00', '011', _) => __encoding A64_ldst_ldst_regoff_STRB_32B_ldst_regoff // STRB_32BL_ldst_regoff
                        when ('00', '0', '01', !'011', _) => __encoding A64_ldst_ldst_regoff_LDRB_32B_ldst_regoff // LDRB_32B_ldst_regoff
                        when ('00', '0', '01', '011', _) => __encoding A64_ldst_ldst_regoff_LDRB_32B_ldst_regoff // LDRB_32BL_ldst_regoff
                        when ('00', '0', '10', !'011', _) => __encoding A64_ldst_ldst_regoff_LDRSB_32B_ldst_regoff // LDRSB_64B_ldst_regoff
                        when ('00', '0', '10', '011', _) => __encoding A64_ldst_ldst_regoff_LDRSB_32B_ldst_regoff // LDRSB_64BL_ldst_regoff
                        when ('00', '0', '11', !'011', _) => __encoding A64_ldst_ldst_regoff_LDRSB_32B_ldst_regoff // LDRSB_32B_ldst_regoff
                        when ('00', '0', '11', '011', _) => __encoding A64_ldst_ldst_regoff_LDRSB_32B_ldst_regoff // LDRSB_32BL_ldst_regoff
                        when ('00', '1', '00', !'011', _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_B_ldst_regoff
                        when ('00', '1', '00', '011', _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_BL_ldst_regoff
                        when ('00', '1', '01', !'011', _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_B_ldst_regoff
                        when ('00', '1', '01', '011', _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_BL_ldst_regoff
                        when ('00', '1', '10', _, _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_Q_ldst_regoff
                        when ('00', '1', '11', _, _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_Q_ldst_regoff
                        when ('01', '0', '00', _, _) => __encoding A64_ldst_ldst_regoff_STRH_32_ldst_regoff // STRH_32_ldst_regoff
                        when ('01', '0', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDRH_32_ldst_regoff // LDRH_32_ldst_regoff
                        when ('01', '0', '10', _, _) => __encoding A64_ldst_ldst_regoff_LDRSH_32_ldst_regoff // LDRSH_64_ldst_regoff
                        when ('01', '0', '11', _, _) => __encoding A64_ldst_ldst_regoff_LDRSH_32_ldst_regoff // LDRSH_32_ldst_regoff
                        when ('01', '1', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_H_ldst_regoff
                        when ('01', '1', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_H_ldst_regoff
                        when ('1x', '0', '11', _, _) => __UNALLOCATED
                        when ('10', '0', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_32_ldst_regoff // STR_32_ldst_regoff
                        when ('10', '0', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_32_ldst_regoff // LDR_32_ldst_regoff
                        when ('10', '0', '10', _, _) => __encoding A64_ldst_ldst_regoff_LDRSW_64_ldst_regoff // LDRSW_64_ldst_regoff
                        when ('10', '1', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_S_ldst_regoff
                        when ('10', '1', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_S_ldst_regoff
                        when ('11', '0', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_32_ldst_regoff // STR_64_ldst_regoff
                        when ('11', '0', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_32_ldst_regoff // LDR_64_ldst_regoff
                        when ('11', '0', '10', 'x1x', !'11xxx') => __encoding A64_ldst_ldst_regoff_PRFM_P_ldst_regoff // PRFM_P_ldst_regoff
                        when ('11', '0', '10', 'x1x', '11xxx') => __encoding A64_ldst_ldst_regoff_RPRFM_R_ldst_regoff // RPRFM_R_ldst_regoff
                        when ('11', '0', '10', 'x0x', _) => __UNALLOCATED
                        when ('11', '1', '00', _, _) => __encoding A64_ldst_ldst_regoff_STR_B_ldst_regoff // STR_D_ldst_regoff
                        when ('11', '1', '01', _, _) => __encoding A64_ldst_ldst_regoff_LDR_B_ldst_regoff // LDR_D_ldst_regoff
                when ('xx11', _, _, _, '0xx1xxxxxxxxxx1', _) => // ldst_pac
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field M 23 +: 1
                    __field S 22 +: 1
                    __field imm9 12 +: 9
                    __field W 11 +: 1
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, M, W) of
                        when (!'11', _, _, _) => __UNALLOCATED
                        when ('11', '0', '0', '0') => __encoding A64_ldst_ldst_pac_LDRAA_64_ldst_pac // LDRAA_64_ldst_pac
                        when ('11', '0', '0', '1') => __encoding A64_ldst_ldst_pac_LDRAA_64_ldst_pac // LDRAA_64W_ldst_pac
                        when ('11', '0', '1', '0') => __encoding A64_ldst_ldst_pac_LDRAA_64_ldst_pac // LDRAB_64_ldst_pac
                        when ('11', '0', '1', '1') => __encoding A64_ldst_ldst_pac_LDRAA_64_ldst_pac // LDRAB_64W_ldst_pac
                        when ('11', '1', _, _) => __UNALLOCATED
                when ('xx11', _, _, _, '1xxxxxxxxxxxxxx', _) => // ldst_pos
                    __field size 30 +: 2
                    __field VR 26 +: 1
                    __field opc 22 +: 2
                    __field imm12 10 +: 12
                    __field Rn 5 +: 5
                    __field Rt 0 +: 5
                    case (size, VR, opc) of
                        when (!'00', '1', '1x') => __UNALLOCATED
                        when ('00', '0', '00') => __encoding A64_ldst_ldst_pos_STRB_32_ldst_pos // STRB_32_ldst_pos
                        when ('00', '0', '01') => __encoding A64_ldst_ldst_pos_LDRB_32_ldst_pos // LDRB_32_ldst_pos
                        when ('00', '0', '10') => __encoding A64_ldst_ldst_pos_LDRSB_32_ldst_pos // LDRSB_64_ldst_pos
                        when ('00', '0', '11') => __encoding A64_ldst_ldst_pos_LDRSB_32_ldst_pos // LDRSB_32_ldst_pos
                        when ('00', '1', '00') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_B_ldst_pos
                        when ('00', '1', '01') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_B_ldst_pos
                        when ('00', '1', '10') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_Q_ldst_pos
                        when ('00', '1', '11') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_Q_ldst_pos
                        when ('01', '0', '00') => __encoding A64_ldst_ldst_pos_STRH_32_ldst_pos // STRH_32_ldst_pos
                        when ('01', '0', '01') => __encoding A64_ldst_ldst_pos_LDRH_32_ldst_pos // LDRH_32_ldst_pos
                        when ('01', '0', '10') => __encoding A64_ldst_ldst_pos_LDRSH_32_ldst_pos // LDRSH_64_ldst_pos
                        when ('01', '0', '11') => __encoding A64_ldst_ldst_pos_LDRSH_32_ldst_pos // LDRSH_32_ldst_pos
                        when ('01', '1', '00') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_H_ldst_pos
                        when ('01', '1', '01') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_H_ldst_pos
                        when ('1x', '0', '11') => __UNALLOCATED
                        when ('10', '0', '00') => __encoding A64_ldst_ldst_pos_STR_32_ldst_pos // STR_32_ldst_pos
                        when ('10', '0', '01') => __encoding A64_ldst_ldst_pos_LDR_32_ldst_pos // LDR_32_ldst_pos
                        when ('10', '0', '10') => __encoding A64_ldst_ldst_pos_LDRSW_64_ldst_pos // LDRSW_64_ldst_pos
                        when ('10', '1', '00') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_S_ldst_pos
                        when ('10', '1', '01') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_S_ldst_pos
                        when ('11', '0', '00') => __encoding A64_ldst_ldst_pos_STR_32_ldst_pos // STR_64_ldst_pos
                        when ('11', '0', '01') => __encoding A64_ldst_ldst_pos_LDR_32_ldst_pos // LDR_64_ldst_pos
                        when ('11', '0', '10') => __encoding A64_ldst_ldst_pos_PRFM_P_ldst_pos // PRFM_P_ldst_pos
                        when ('11', '1', '00') => __encoding A64_ldst_ldst_pos_STR_B_ldst_pos // STR_D_ldst_pos
                        when ('11', '1', '01') => __encoding A64_ldst_ldst_pos_LDR_B_ldst_pos // LDR_D_ldst_pos
